--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: usp_parse_race_detail(bigint); Type: FUNCTION; Schema: public; Owner: colin
--

CREATE FUNCTION usp_parse_race_detail(i_race_id bigint) RETURNS TABLE(status_id integer, status_text text)
    LANGUAGE plpgsql
    AS $$
DECLARE
_arr TEXT;
_col TEXT;
_odds NUMERIC(10,2);
_col_count INT;
_col_start INT;
_race_number INT;
_race_line BOOLEAN;
_result_line BOOLEAN;
BEGIN

_col_count = 0;
SELECT COALESCE(MAX(race_number), 1)
  INTO _race_number
  FROM race_details
 WHERE race_id = i_race_id;

FOR _arr IN 
SELECT regexp_split_to_table(details, E'\n')
  FROM race 
 WHERE id = COALESCE(i_race_id, id)
LOOP

RAISE NOTICE 'race_id: %, race_number: %',i_race_id, _race_number;
    IF _arr LIKE '%Temperature: %' THEN
    _race_line = FALSE;
    _result_line = TRUE;
    _race_number = _race_number + 1;
    END IF;
    IF _race_line THEN
INSERT INTO race_details (race_id, race_number, 
horse_number, horse,hv, pp, quarter, half,
thirdq, stretch, finish, finish_parsed, time, lastq, driver,
odds, trainer)
SELECT i_race_id, _race_number, 
TRIM(substring(_arr FROM 0 FOR 3))::INT,
substring(_arr FROM 4 FOR 23),
substring(_arr FROM 26 FOR 4),
substring(_arr FROM 30 FOR 5),
substring(_arr FROM 37 FOR 7),
substring(_arr FROM 45 FOR 7),
substring(_arr FROM 53 FOR 7),
substring(_arr FROM 61 FOR 7),
substring(_arr FROM 70 FOR 8),
substring(split_part(substring(_arr FROM 70 FOR 8), '/', 1) FROM '[0-9]+')::INT,
substring(_arr FROM 81 FOR 8),
substring(_arr FROM 89 FOR 5),
substring(_arr FROM 94 FOR 15),
CASE WHEN 
REPLACE(REPLACE(REPLACE(TRIM(substring(
_arr FROM 109 FOR 8)), '*',''), 'N', ''), 'R', '') = '' THEN NULL
ELSE 
REPLACE(REPLACE(REPLACE(TRIM(substring(
_arr FROM 109 FOR 8)), '*',''), 'N', ''), 'R', '')::NUMERIC(10,2)
END,
substring(_arr FROM 118 FOR 12);

    END IF;

    IF _arr LIKE '%Trainer%' THEN
    _race_line = TRUE;
    END IF;

END LOOP;

RETURN QUERY
SELECT 200, 'OK'::TEXT;
END;
$$;


ALTER FUNCTION public.usp_parse_race_detail(i_race_id bigint) OWNER TO colin;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: race; Type: TABLE; Schema: public; Owner: colin; Tablespace: 
--

CREATE TABLE race (
    id bigint NOT NULL,
    track_id bigint,
    race_date text,
    details text NOT NULL
);


ALTER TABLE race OWNER TO colin;

--
-- Name: race_details; Type: TABLE; Schema: public; Owner: colin; Tablespace: 
--

CREATE TABLE race_details (
    id bigint,
    race_id integer,
    race_number integer,
    horse_number integer,
    horse text,
    hv text,
    pp text,
    quarter text,
    half text,
    thirdq text,
    stretch text,
    finish text,
    finish_parsed integer,
    "time" text,
    lastq text,
    driver text,
    odds numeric(10,2),
    trainer text
);


ALTER TABLE race_details OWNER TO colin;

--
-- Name: race_details_20160724; Type: TABLE; Schema: public; Owner: colin; Tablespace: 
--

CREATE TABLE race_details_20160724 (
    id bigint NOT NULL,
    race_id integer,
    race_number integer,
    horse_number integer,
    horse text,
    hv text,
    pp text,
    quarter text,
    half text,
    thirdq text,
    stretch text,
    finish text,
    finish_parsed integer,
    "time" text,
    lastq text,
    driver text,
    odds numeric(10,2),
    trainer text
);


ALTER TABLE race_details_20160724 OWNER TO colin;

--
-- Name: race_details_id_seq; Type: SEQUENCE; Schema: public; Owner: colin
--

CREATE SEQUENCE race_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE race_details_id_seq OWNER TO colin;

--
-- Name: race_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: colin
--

ALTER SEQUENCE race_details_id_seq OWNED BY race_details_20160724.id;


--
-- Name: race_id_seq; Type: SEQUENCE; Schema: public; Owner: colin
--

CREATE SEQUENCE race_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE race_id_seq OWNER TO colin;

--
-- Name: race_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: colin
--

ALTER SEQUENCE race_id_seq OWNED BY race.id;


--
-- Name: track; Type: TABLE; Schema: public; Owner: colin; Tablespace: 
--

CREATE TABLE track (
    id bigint NOT NULL,
    name text,
    code text,
    country text
);


ALTER TABLE track OWNER TO colin;

--
-- Name: track_id_seq; Type: SEQUENCE; Schema: public; Owner: colin
--

CREATE SEQUENCE track_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE track_id_seq OWNER TO colin;

--
-- Name: track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: colin
--

ALTER SEQUENCE track_id_seq OWNED BY track.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: colin
--

ALTER TABLE ONLY race ALTER COLUMN id SET DEFAULT nextval('race_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: colin
--

ALTER TABLE ONLY race_details_20160724 ALTER COLUMN id SET DEFAULT nextval('race_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: colin
--

ALTER TABLE ONLY track ALTER COLUMN id SET DEFAULT nextval('track_id_seq'::regclass);


--
-- Data for Name: race; Type: TABLE DATA; Schema: public; Owner: colin
--

COPY race (id, track_id, race_date, details) FROM stdin;
122	14	0717	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Great Luck                  2    2/2H    2/2T    2/2H    2/1      1/Q        2:06.1  30.3 R Gillis             NB J Murphy\n1   P H Showboat                1    1/2H    1/2T    1/2H    1/1      2/Q        2:06.1  31   A Macdonell          NB A Macdonell\nTime: 31.4, 1:03.4, 1:35.1, 2:06.1 (Temperature: 21, Condition: FT, Variant: 0)\n\n1st  Great Luck          (b,g,10 - E Dees Cam-Direct Bride-Direct Scooter)\n                         Owner: John Murphy,Port Hawkesbury,NS\n2nd  P H Showboat        (b,g,8 - Real Desire-Whitleys Scooter-Matts Scooter)\n                         Owner: A Lewis Macdonell,Port Hood,NS\n
126	14	0724	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Macnamarra                  2    1/18    1/27    1/35    1/35     1/38       1:58    31.1 J Mac Dougall        NB R Smith\n1   Gigolos Boozer              1    2/18    2/27    2/35    2/35     2/38       2:05.3  31.4 R Gillis             NB S Harper Jr\nTime: 27.4, 56.1, 1:26.4, 1:58 (Temperature: 26, Condition: FT, Variant: 0)\n\n1st  Macnamarra          (b,g,11 - Camluck-Tropicana Chris-Die Laughing)\n                         Owner: Roderick C Smith,Inverness,NS\n2nd  Gigolos Boozer      (b,g,5 - Ameripan Gigolo-Tipphill Booze Hag-Bettors Delight)\n                         Owner: Ronald J Garland,Sydney,NS\n
136	16	0722	\n1\n\n1 MILE, PACE.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Lil Richie                  4    1/1T    1/3H    1/2H    1/3      1/7H       1:56    30   B Mcclure            NB D Nixon\n6   Badlyinclined               6    2/1T    2/3H    2/2H    2/3      2/7H       1:57.2  31   M Saftic             NB Alan D Fair\n1   Norcross Blue Chip          1    4/5Q    5/11T   6/17    6/14H    3/14T      1:59    29.3 D Megens             NB D Megens\n7   Pylater                     7    7/10T   6@/13Q  4@/15H  3/10H    4/15       1:59    30   Ph Hudon             NB K Mcmaster\n3   Big Dylan                   3    6@/8Q   3@/7T   3/14H   5/13H    5/16       1:59.1  30.2 S Young              NB M Brealey\n8   Acefortyfouramanda          8    8/12T   8/16    8/18Q   7/17     6/16       1:59.1  29.3 W Henry              NB L Bako\n9   Birdie                      9    3/3T    4/11H   5@@/15T 4/12     7/17       1:59.2  30.1 S Filion             NB D Daigneault\n2   Fade Away                   2    5/8     7/15T   7@/17H  8/25     8/28       2:01.3  32.1 Ja Macdonald         NB R Muir\n5   Brightside Gretel           5X   9/DIS   9/DIS   9/DIS   9/DIS    9/DIS                   J Jamieson           NB W Reda\nTime: 29.2, 57.2, 1:26, 1:56 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Brightside Gretel-BREAKS\n\n1st  Lil Richie          (b,g,3 - Mach Three-Warrawee Lil-Astreos)\n                         Owner: ICR Racing,Pefferlaw,ON\n2nd  Badlyinclined       (b,m,5 - Badlands Hanover-Artisticlyinclined-Artsplace)\n                         Owner: Elizabeth Fair,Ancaster,ON\n3rd  Norcross Blue Chip  (b,f,3 - Bettors Delight-I Lady-Western Ideal)\n                         Owner: Donna M Fox-Robert J Fox,Stoney Creek-Dan H Megens,Hamilton,ON\n2\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Noblecrest                  3    2/2H    1/2H    1/2H    1/4      1/4Q       2:03    30.2 J Jamieson           NB V Hayter\n3   Crazy Girl=                 2    1/2H    2/2H    2/2H    2/4      2/4Q       2:03.4  30.4 S Condren            NB C Mitchell\n2   Try To Resist               1    3/8     3/15    3/25    3/35     3/46       2:12.1  34.3 M Saftic             NB G Sloan\nTime: 32.1, 1:02.3, 1:32.3, 2:03 (Temperature: 28, Condition: FT, Variant: 0)\n\n1st  Noblecrest          (br,c,2 - Angus Hall-Spilled Milk-Wesgate Crown)\n                         Owner: Joann M Hayter,Stratford,ON\n2nd  Crazy Girl          (br,f,2 - Crazed-Yankeedoodlebrandy-Muscles Yankee)\n                         Owner: Douglas W Millard,Woodstock,ON\n3rd  Try To Resist       (b,f,2 - Windsong Espoir-Torre Mozza-Striking Sahbra)\n                         Owner: Joanne C Sloan,Harley,ON\n3\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Real Lucky Day              2    2/4     2/1T    2/2H    2/2H     1/HD       1:59.3  30.2 S Filion             NB S Larocque\n1   Magic Night                 1    1/4     1/1T    1/2H    1/2H     2/HD       1:59.3  30.4 W Henry              NB W Henry\n4   Victors Magic=              X4   4/30    4/25    3/25    3/22     3/22       2:04    30.1 J Jamieson           NB J Darling\n3   Jayport Sport=              X3   3/25    3/DIS   4/DIS   4/DIS    4/DIS                   M Saftic             NB D Obrian\nTime: 28.4, 58.4, 1:28.4, 1:59.3 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Victors Magic-BREAKS, Jayport Sport-BREAKS\n\n1st  Real Lucky Day      (br,c,2 - Donato Hanover-Norway No Day-Self Possessed)\n                         Owner: Ecuries R L Belanger,Laval,QC\n2nd  Magic Night         (br,g,2 - Kadabra-Bedtime Song-Windsongs Legacy)\n                         Owner: Tommy B Andersson,Gotene,SWD\n3rd  Victors Magic       (br,c,2 - Manofmanymissions-Streak-Credit Winner)\n                         Owner: Jack Darling Stables Ltd,Cambridge,ON-Thomas R Dillon,Anson,ME\n4\n\n1 MILE, PACE.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Gateway To Victory          2X   5/7H    1@/1Q   1/2     1/3      1/H        1:56    29.1 J Jamieson           NB T Alagna\n6   Rodeo Sports                6    2@/1Q   2/1Q    2/2     2/3      2/H        1:56    28.4 J Drury              NB C Coleman\n3   Fade                        3    3/2T    4/5T    4/9     4/6T     3/2T       1:56.3  28   S Condren            NB C Coleman\n1   Pretty Angel Eyes           1    1/1Q    3/4     3/5H    3/5T     4/5Q       1:57    29.1 R Mayotte            NB R Mayotte\n5   Treasure Mach               5    4/5H    5/8     5/10H   5/9      5/8H       1:57.3  28.4 S Filion             NB T Osullivan\n4   Daenerys Hanover            4    6/11    6/11H   6/13T   6/11T    6/10Q      1:58    28.2 P Macdonell          NB S Mehlenbacher\nTime: 29.4, 58.3, 1:26.4, 1:56 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Gateway To Victory-BREAKS, Daenerys Hanover-COGGINS\n\n1st  Gateway To Victory  (b,f,2 - Artistic Fella-Shut Her Down-Tell All)\n                         Owner: Riverview Racing LLC,Boynton Beach,FL-Alagna Racing LLC,Manalapan,NJ\n2nd  Rodeo Sports        (b,c,2 - Sportswriter-Moving Pictures-D M Dilinger)\n                         Owner: West Wins Stable,Cambridge,ON-Howard A Taylor,Philadelphia,PA-Jim H Fielding,Toronto,ON\n3rd  Fade                (br,f,2 - Shadow Play-Breathe-Northern Luck)\n                         Owner: West Wins Stable,Cambridge-Steve W Calhoun,Chatham,ON\n5\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Anutherdynamic              3    1/3H    1/4     1/Q     1/3      1/4H       2:00.2  30   P Macdonell          NB W Walters\n4   Windshield=                 4    3/5T    3/7Q    3/3T    3/5T     2/4H       2:01.1  30   Ja Macdonald         NB G Graham\n2   Thee Desperado=             2    2/3H    2/4     2@/Q    2/3      3/4H       2:01.1  30.4 S Condren            NB T Mckibbin\n1   Results May Vary=           1    4/8     4/10T   4/6T    4/9T     4/12Q      2:02.4  31   M Saftic             NB K Bodz\nTime: 30.3, 1:00.1, 1:30.2, 2:00.2 (Temperature: 28, Condition: FT, Variant: 0)\n\n1st  Anutherdynamic      (b,g,5 - Super Pleasure-Its All Go-Angus Hall)\n                         Owner: Linda A Rumney,Tiny-William T Walters,Coldwater,ON\n2nd  Windshield          (b,g,7 - Political Briefing-Cr Mimosa-Cr Commando)\n                         Owner: Sherry L Graham,Caledonia-Tim J Gallant,Hamilton,ON\n3rd  Thee Desperado      (b,g,3 - Manofmanymissions-Front Porch Swing-Royal Strength)\n                         Owner: Karen Macintyre-Daniel Macintyre,London-Joshua McKibbin,Tillsonburg-Nancy I Newport,Ingersoll,ON\n
137	22	0720	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Goodmorning Ky              1    2/Q     1@/T    1@/1    1/2      1/2        2:05    31.1 N Rogers             NB N Rogers\n3   Southfield Speedy           3    3/3     3/3H    3@/2Q   3/3      2/2        2:05.2  31.1 T Gallant            NB T Gallant\n2   Myambrose                   2    1@/Q    2/T     2/1     2/2      3/4Q       2:05.4  31.4 G Chappell           NB C Macdougall\nTime: 32, 1:03.2, 1:33.4, 2:05 (Temperature: 21, Condition: FT, Variant: 0)\n\n1st  Goodmorning Ky      (blk,f,2 - Aahm Canadian Now-Cinnamon Snowflake-Camotion)\n                         Owner: Greg Richard,Wellington,PE\n2nd  Southfield Speedy   (br,c,2 - Proven Lover-Paid In Silver-Astreos)\n                         Owner: Southfield Farms Inc,Summerside,PE\n3rd  Myambrose           (gr,g,2 - Brandons Cowboy-Another Rose-Paris Dexter)\n                         Owner: Carl W Macdougall,Ellerslie-Jason B Macdougall,Miscouche,PE\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   R Es Nancy+                 3    1/7H    1/14    1/23    1/25     1/29       1:59    29.2 M Pezzarello         NB D Sweet\n1   Southfield Spirit           1    2/7H    2/14    2/23    2/25     2/29       2:04.4  30.3 N Rogers             NB T Mann\n2   Elm Grove Kaptain           X2   3/DIS   3/DIS   3/DIS   3/DIS    3/DIS                   J Hughes             NB B Mckenna\nTime: 29.3, 59.2, 1:29.3, 1:59 (Temperature: 21, Condition: FT, Variant: 0)\nJudges List: Elm Grove Kaptain-BREAKS//MUST QUALIFY\n\n1st  R Es Nancy          (br,m,7 - Astronomical-Kona Queen-Camtastic)\n                         Owner: Dana L Sweet,Bloomfield Station,PE\n2nd  Southfield Spirit   (b,f,3 - Aahm Canadian Now-Southfield Sarah-Drop Off)\n                         Owner: Southfield Farms Inc,Summerside-Thane R Mann,Kensington,PE\n3rd  Elm Grove Kaptain   (b,g,3 - Coastocoast Yankee-Elm Grove Starlite-Beach Towel)\n                         Owner: Molly A Murphy,Borden-Carleton,PE\n3\n\n1 MILE, BOTH.QUALIFIER - TROT & PACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Shouldabeenaclown           2    1/1T    2/1Q    2/2Q    2/1T     1/NK       2:11.1  31.4 E Stewart            NB E Stewart\n1   Winny                       1    2/1T    1@/1Q   1/2Q    1/1T     2/NK       2:11.1  32.1 N Rogers             NB N Rogers\n3   Ladies Gone Wild(T)         X3   3BE/3T  3/2T    3/4T    3/4T     3/5Q       2:12.1  32.1 G Cole               NB G Cole\nTime: 32.4, 1:06.3, 1:39, 2:11.1 (Temperature: 21, Condition: FT, Variant: 0)\nJudges List: Shouldabeenaclown-TIME//MUST QUALIFY, Winny-TIME//MUST QUALIFY, Ladies Gone Wild-BREAKS//MUST QUALIFY\n\n1st  Shouldabeenaclown   (b,f,2 - Brandons Cowboy-Binies Bismark J-Drop Off)\n                         Owner: Edgar B Stewart,Ellerslie,PE\n2nd  Winny               (br,f,2 - Toofunnyforwords-Res Donna-Drop Off)\n                         Owner: Greg Richard,Wellington,PE\n3rd  Ladies Gone Wild    (b,f,3 - Meadowagogo-The Traders Lady-Balance Of Trade)\n                         Owner: Garth Cole,Kensington,PE\n
138	22	0724	\n1\n\n1 MILE, TROT.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Ladies Gone Wild            2    1/5Q    1/6     1/2T    1/2      1/1        2:09.1  32.2 G Cole               NB G Cole\n1   Here Comes Joe              1    2/5Q    2/6     2/2T    2/2      2/1        2:09.2  32   K Murphy             NB C Smith\nTime: 32.3, 1:04.1, 1:36.4, 2:09.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Ladies Gone Wild    (b,f,3 - Meadowagogo-The Traders Lady-Balance Of Trade)\n                         Owner: Garth Cole,Kensington,PE\n2nd  Here Comes Joe      (b,c,3 - Neal-Chucaro Resera-Altheas Crown)\n                         Owner: Roderick J Gillis,Florence,NS-Clark Smith,Oyster Bed Bridge,PE-William R Unsworth,Sydney River,NS\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Elm Grove Kaptain           3    3/5T    2@/1    1/7Q    1/15     1/24       2:01.1  30   K Murphy             NB B Mckenna\n2   Shouldabeenaclown           2    2/3Q    3/1T    3/9     3/16     2/24       2:06    33   E Stewart            NB E Stewart\n1   Winny                       1    1/3Q    1/1     2/7Q    2/15     3/27       2:06.3  34   N Rogers             NB N Rogers\nTime: 30.1, 1:01.2, 1:31.1, 2:01.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Elm Grove Kaptain   (b,g,3 - Coastocoast Yankee-Elm Grove Starlite-Beach Towel)\n                         Owner: Molly A Murphy,Borden-Carleton,PE\n2nd  Shouldabeenaclown   (b,f,2 - Brandons Cowboy-Binies Bismark J-Drop Off)\n                         Owner: Edgar B Stewart,Ellerslie,PE\n3rd  Winny               (br,f,2 - Toofunnyforwords-Res Donna-Drop Off)\n                         Owner: Greg Richard,Wellington,PE\n
141	23	0717	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Rj Gigolo                   2    1/2Q    1/3     1/2     1/1      1/2Q       2:05.1  30.3 D Carey              NB J Green\n3   Howmacs Dragonator          3    3/4H    3/5H    3@/3    2/1      2/2Q       2:05.3  30.2 B Mccallum           NB B Mccallum\n1   Bourbonstreet Lady+         1    2/2Q    2/3     2/2     3/2T     3/4Q       2:06    31   D Romo               NB D Romo\nTime: 32.1, 1:03.3, 1:34.3, 2:05.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Rj Gigolo           (b,c,2 - Ameripan Gigolo-Papas Little Rose-Sea Gull Hershey)\n                         Owner: Cameron Maceachen,Truro,NS\n2nd  Howmacs Dragonator  (br,g,2 - Articulator-Howmacs Dragon-Dragon Again)\n                         Owner: Debbie E Denney,Mount Uniacke,NS\n3rd  Bourbonstreet Lady  (b,f,2 - Carnivore-Bradelle-Largo)\n                         Owner: Ian N Banks,Truro-Susan C Karrel,Great Village,NS-Debra Downing,Moncton,NB\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Lucbobski                   2    2@/2    1/4H    1/6     1/8H     1/19H      2:00.4  29.1 D Romo               NB D Romo\n4   Secret Fantasy              4    1/2     2/4H    2/6     2/8H     2/19H      2:04.3  31.4 R Ellis              NB R Chase\n3   Southwind Oasis             3    3/2Q    3/7T    3/13    3/13H    3/21       2:05    30.4 C Isenor             NB W Mcneil\n1   Big Joe Doby                1    4/4     4/10H   4/15    4/15     4/23       2:05.2  30.4 B Mccallum           NB J Janega\nTime: 31.4, 1:01.4, 1:31.3, 2:00.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Lucbobski           (b,g,2 - Articulator-Wild Ride Hanover-Western Ideal)\n                         Owner: Robert J Skinner,Truro-Jeffrey R Skinner,Hammonds Plains,NS\n2nd  Secret Fantasy      (b,g,12 - Island Fantasy-Hot Cameleon-Cameleon)\n                         Owner: Rhea Chase,Bible Hill-Bailey J Chase Merner,Truro,NS\n3rd  Southwind Oasis     (br,f,3 - Sportswriter-Its Only Rocknroll-Rocknroll Hanover)\n                         Owner: Saulsbrook Stables Inc,Windsor,NS-Laverne T Turnbull,Kitchener,ON\n
144	23	0719	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Video Storage               3    1/5     1/9     1/7     1/5      1/3        2:02    29.4 D Crowe              NB L Johnson\n2   Maudail Mac                 2    2/5     2/9     2/7     2/5      2/3        2:02.3  29   M Macdonald          NB M Macdonald\n1   Heads Up Hanover            1    3/6H    3/10T   3/9     3/6H     3/3H       2:02.3  28.3 C Isenor             NB W Mcneil\nTime: 30, 1:01.2, 1:32.1, 2:02 (Temperature: 26, Condition: FT, Variant: 0)\n\n1st  Video Storage       (b,m,6 - I Am A Fool-Dimona-No Nukes)\n                         Owner: Lee D Johnson,Upper Brookside,NS\n2nd  Maudail Mac         (b,f,3 - Brandons Cowboy-Bonnie G Mac-Brewster Blue Chip)\n                         Owner: Angus R Mac Innis,Mabou,NS\n3rd  Heads Up Hanover    (b,f,3 - Well Said-Holding Court-Life Sign)\n                         Owner: Saulsbrook Stables Inc,Windsor,NS\n
59	16	0723	\nRESULTS NOT YET AVAILABLE\n
132	16	0719	\n1\n\n1 MILE, PACE.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n8   Traceur Hanover             8    1/1T    2/1T    2/1T    3/2Q     1/NS       1:55.2  27.2 S Filion             NB R Moreau\n4   Beast Mode                  4    2/1T    1/1T    1/1T    1/1      2/NS       1:55.2  27.4 Trev Henry           NB C Nicol\n7   Ideal Jet                   7    3/4     3/3H    3/3H    2/1      3/H        1:55.2  27.1 J Jamieson           NB C Barss\n5   Bringhome Theblue           5    4/6T    4/5H    4@/5Q   4/6T     4/6Q       1:56.3  28   C Auciello           NB C Auciello\n2   Homer Run                   2    6/13H   6/12H   6@/11   6/13T    5/17       1:58.4  29   Dr J Flanigan        NB Dr J Flanigan\n1   Passion Quizrace            1    5/10    5/8     5/9H    5/12H    6/19       1:59.1  29.4 Ph Hudon             NB K Gangell\n3   Real Buzz                   3    7/18    7/15H   7/12Q   7/16T    7/22       1:59.4  29.4 Do Brown             NB L Blais\n6   Nicholas Ryan               6    8/21H   8/17    8/14H   8/20H    8/28       2:01    30.3 J Drury              NB C Auciello\nTime: 28.2, 57.4, 1:27.3, 1:55.2 (Temperature: 25, Condition: FT, Variant: 0)\n\n1st  Traceur Hanover     (b,h,4 - Western Ideal-Transference-Camluck)\n                         Owner: Richard Berthiaume,Pointe-Aux-Trembles,QC\n2nd  Beast Mode          (b,c,3 - Rock N Roll Heaven-Gaias Gold-Village Jove)\n                         Owner: Christopher J Nicol,Waterdown,ON\n3rd  Ideal Jet           (br,h,5 - Jeremes Jet-Ashlees Luck-Camluck)\n                         Owner: Nurko Sokolovic,Waterloo-Craig A Barss,Cobourg,ON\n2\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n8   Mister Herbie               8    2/1H    1/3     1/8H    1/8T     1/4Q       1:56.1  29.1 J Jamieson           NB J Gillis\n2   Marquis Volo=               2    5/9H    5/11T   4@/11H  2/8T     2/4Q       1:57    27.4 P Henriksen          NB P Henriksen\n3   Way Outta Here=             3    6/11T   6/14T   5@/13Q  4/12H    3/9Q       1:58    28.2 M Vanderkemp         NB M Vanderkemp\n6   Moonbeam Hall               6    4/7     4/9H    6/13H   6/15H    4/12       1:58.3  29   M Baillargeon        NB B Baillargeon\n7   Little Stuie                7    1/1H    2/3     2/8H    3/11H    5/14Q      1:59    30.2 Ph Hudon             NB W Dunn\n1   Joyous Hall                 1    3/3T    3/5T    3/10Q   5/14     6/19       2:00    31   M Saftic             NB B Bahr\n5   Danielle Hall               5X   X8/DIS  7/DIS   7/DIS   7/DIS    7/DIS                   C Jamieson           NB C Jamieson\n4   April Breeze On By=         4X   X7/DIS  8/DIS   8/DIS   8/DIS    8/DIS                   J Renaud             NB J Walker\nTime: 28.4, 58.4, 1:27, 1:56.1 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Mister Herbie-COGGINS, Danielle Hall-BREAKS, April Breeze On By-BREAKS\n\n1st  Mister Herbie       (br,g,8 - Here Comes Herbie-Independent Lassie-Brisco Hanover)\n                         Owner: Jeffrey R Gillis,Everett-Mac T Nichol,Burlington,ON-Gerald T Stay,Buffalo,NY\n2nd  Marquis Volo        (br,g,4 - Credit Winner-Margarita Momma-Yankee Glide)\n                         Owner: Tor Jan Larsen,Norwood,ON-Gerald T Stay,Buffalo,NY-Mac T Nichol,Burlington-Big Als Stables Inc,Woodbridge,ON\n3rd  Way Outta Here      (b,g,5 - Broadway Hall-Im A Pearl-Enjoy Lavec)\n                         Owner: Michiel C Vanderkemp,Hillsburgh,ON\n3\n\n1 MILE, PACE.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Happy Hannah                4    2/H     1/4     1/3H    1/3H     1/8T       1:56.2  28.3 Ra Waples            NB M Steacy\n6   Manhattan Play              6    8/13H   8/19    7/14T   7/12     2/8T       1:58.1  27.2 M Saftic             NB N Comegna\n5   Dance Craze                 5    5@/6H   5/10T   5/10    5/10Q    3/9T       1:58.2  28.3 S Filion             NB T Osullivan\n2   Wicked Hill                 2    3/2H    3/6T    3/5T    3/4T     4/10       1:58.2  29.2 J Jamieson           NB D Menary\n8   B Fifteen                   8    4@/4    4/8T    4/8Q    4/7H     5/10T      1:58.3  29.1 C Christoforou       NB C Christoforou\n7   Little Hanover              7    1@/H    2/4     2/3H    2/3H     6/11       1:58.3  30.1 Do Brown             NB L Blais\n1   Just Too Spoiled            1    6/7T    6/13H   6/13H   6/11T    7/11T      1:58.4  28.2 D Mcnair             NB P Reid\n3   Two Hearted                 3    7/10H   7/16    8@/15H  8/17T    8/26       2:01.3  30.4 Trev Henry           NB P Hunt\nTime: 29.1, 58, 1:27.4, 1:56.2 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Dance Craze-COGGINS\n\n1st  Happy Hannah        (b,f,2 - Well Said-Hallie Gallie-Village Jolt)\n                         Owner: Stan Klemencic,Trenton,ON-Hudson Standrdbrd Stb Inc,Hudson,QC-Hutt Racing Stable,Paoli,PA\n2nd  Manhattan Play      (b,f,2 - Shadow Play-Panhattan-Kentucky Spur)\n                         Owner: Bruno Comegna,Burlington,ON\n3rd  Dance Craze         (b,f,2 - Art Major-Gone Dancing-Presidential Ball)\n                         Owner: David Goodrow Stable,Cambridge-Lorne K Keller,Exeter,ON\n4\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Dunbar Hall=                7    2/2H    1/2H    1/3H    1/5H     1/8H       2:01    28.3 J Jamieson           NB C Jamieson\n4   Kameran Hanover             4    3/7H    3/7T    3/5T    2/5H     2/8H       2:02.3  29   C Christoforou       NB C Christoforou\n3   Quadrangle                  3    7/19Q   7/19H   6@/13H  5/12H    3/12T      2:03.3  28.3 J Moiseyev           NB C Christoforou\n8   Upvote Hanover=             8    1/2H    2/2H    2/3H    3/6T     4/13H      2:03.3  30.3 P Henriksen          NB P Henriksen\n1   Regal Hill                  1    4/13    4/13H   4/7T    4/10T    5/14H      2:03.4  29.4 G Peck               NB G Peck\n5   Whirlaway Hanover           5    6/16T   6/17    7/13T   6/13     6/15       2:04    28.4 Ri Zeron             NB N Bardier Jr\n6   Persuaded=                  6    5@/15T  5@/15Q  5/12    7/16T    7/18       2:04.3  29.4 S Mahar              NB S Mahar\n2   Jd Luther                   2X   X8/28   8/27    8/22    8/31     8/39       2:08.4  32   Tra Henry            NB Dr J Chandler\nTime: 30.3, 1:01.2, 1:32.2, 2:01 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Kameran Hanover-COGGINS, Jd Luther-BREAKS\n\n1st  Dunbar Hall         (b,c,2 - Deweycheatumnhowe-Debbie Hall-Like A Prayer)\n                         Owner: Carl R Jamieson,Rockwood-Thomas Kyron,Toronto,ON-George Harrison,Preston,ENG\n2nd  Kameran Hanover     (b,c,2 - Donato Hanover-Kandor Hanover-Tagliabue)\n                         Owner: Charalambos Christoforou,Campbellville-Banjo Farms,Toronto-Carolyn Polillo,Brantford-Chad C Hill,Hagersville,ON\n3rd  Quadrangle          (b,c,2 - Muscle Hill-Pilgrims Queen-Broadway Hall)\n                         Owner: Charalambos Christoforou,Campbellville-Banjo Farms,Toronto,ON\n5\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Ready Any Time=             3    3/5Q    3/4H    1@/1Q   1/3T     1/7T       1:57.1  28.4 P Henriksen          NB P Henriksen\n5   Magic Missions=             5    2/2H    2/2     3/2T    2/3T     2/7T       1:58.4  29.4 Ph Hudon             NB W Budd\n8   Sos Harddrive=              8    4/10T   4/7     4/8T    3/11H    3/16       2:00.2  30.1 J Maguire            NB J Maguire\n1   Sass That Mass=             1    6/20    5@/14T  5/12H   4/14H    4/18       2:00.4  30   J Renaud             NB J Walker\n4   Weve Had Enough             4X   X7/25H  7/20H   7/19T   6/18H    5/21       2:01.2  29   R Mayotte            NB R Mayotte\n6   Warrawee Rob                6    5/17T   6/15    6/16T   7/19     6/25       2:02.1  30.2 M Baillargeon        NB B Baillargeon\n7   Derivative=                 7    1/2H    1/2     2/1Q    X5X/17   7/DIS                   T Burgess            NB B Burgess\n2   Work That Magic             X2X  8/DIS   8/DIS   8/DIS   8/DIS    8/DIS                   C Christoforou       NB S Charlton\nTime: 28.2, 58.4, 1:28.2, 1:57.1 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Weve Had Enough-BREAKS, Derivative-BREAKS, Work That Magic-BREAKS\n\n1st  Ready Any Time      (br,f,3 - Kadabra-Spice Queen-Yankee Glide)\n                         Owner: Melvin Hartman,Ottawa,ON-Herb A Liverman,Miami Beach-David H Mc Duffee,Delray Beach,FL-Little E LLC,New York,NY\n2nd  Magic Missions      (b,g,3 - Manofmanymissions-Show Your Lindys-Dream Vacation)\n                         Owner: Macks Stable-Joe P Carnovale,Stoney Creek-William W Budd,Waterdown,ON\n3rd  Sos Harddrive       (br,m,4 - Taurus Dream-Paytheconsequences-Striking Sahbra)\n                         Owner: Dany Blouin,Quebec,QC\n6\n\n1 MILE, PACE.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Hurricane Beach             4    3/4     3/3T    3@/3    1/H      1/1T       1:57.4  28.3 S Filion             NB L Blais\n2   Forrest Porsche             2    1/1T    1/1H    1/2H    2/H      2/1T       1:58.1  29.3 D Graham             NB D Graham\n6   Beach Volley Ball           5    5/10H   5/8     5/8H    4/6      3/3        1:58.2  28.1 Do Brown             NB L Blais\n1   Major Master Piece          1    2/1T    2/1H    2/2H    3/3H     4/4Q       1:58.3  29.3 J Jamieson           NB D Menary\n3   East Bound Eddie            3    4/5T    4/5H    4/6H    5/10H    5/17       2:01.1  31.2 A Macdonald          NB A Macdonald\nTime: 30.1, 59.1, 1:28.3, 1:57.4 (Temperature: 25, Condition: FT, Variant: 0)\n\n1st  Hurricane Beach     (b,c,2 - Somebeachsomewhere-Blazing Yankee-Western Ideal)\n                         Owner: Determination,Montreal,QC\n2nd  Forrest Porsche     (b,c,2 - Art Major-A And Gs Princess-Allamerican Native)\n                         Owner: Larry Todd,Oakwood,ON\n3rd  Beach Volley Ball   (b,c,2 - Sportswriter-Beach Guest-Beach Towel)\n                         Owner: Determination,Montreal,QC\n
133	16	0719	\n7\n\n1 MILE, TROT.QUALIFYING RACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Timepiece=                  1    5/16T   2@/1T   1/3H    1/3H     1/2Q       2:03.4  30.4 A Macdonald          NB A Macdonald\n6   Irenes Love=                5    3/9     4/5Q    3/4T    2/3H     2/2Q       2:04.1  30.1 M Saftic             NB M Dowling\n8   Stritch=                    7    4/12T   5/9H    4/7H    4/6T     3/4        2:04.3  30.1 C Steacy             NB M Steacy\n2   For A Reason                2    1/3H    1/1T    2/3H    3/6      4/9        2:05.3  32   J Jamieson           NB V Cochrane\n7   Kuil Deva=                  6    2/3H    3/2H    X5/17H  5/23     5/16       2:07    30.3 J Whelan             NB J Whelan\n5   Sweet Kimmy=                4X   7/DIS   6/DIS   6/DIS   6/DIS    6/DIS                   Ra Waples            NB B Maxwell\n4   Da Miracle                  X3X  6/DIS   7/DIS   7/DIS   7/DIS    7/DIS                   Trev Henry           NB P Hunt\nTime: 30.4, 1:02.2, 1:33, 2:03.4 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Kuil Deva-BREAKS, Sweet Kimmy-BREAKS, Da Miracle-BREAKS\n\n1st  Timepiece           (b,f,2 - Glidemaster-Social Image-Balanced Image)\n                         Owner: Anthony A Macdonald,Guelph-Bruce S Gaum,Toronto-David L Fasulo,Milton-Robert B Burgess,Campbellville,ON\n2nd  Irenes Love         (br,f,2 - Angus Hall-Hit On Me-Giant Hit)\n                         Owner: Allan R Neal,Grand Bend-Michael R Dowling,Waterford,ON\n3rd  Stritch             (b,f,2 - Majestic Son-Minky Hanover-Lindy Lane)\n                         Owner: David K Reid,Glenburnie,ON-James P Feeley,Pine Bush-Bridle Path Stables Ltd,Ossining,NY-Stephen Klunowski,North York,ON\n
145	23	0721	\n1\n7-Gigs And Reels            9.30   3.40   2.70       181\n8-Putnams Legacy                  10.10   4.50        86\n3-Flag Of Honor                          16.90        50\n\n$2 EXACTOR (7-8) paid 12.20, pool 36\n$2 TRIACTOR (7-8-3) paid 90.20, pool 596\n\n1 MILE, PACE, PURSE $950.\nNON WINNERS 1 PM RACE OR $700 LIFE AND NON WINNERS 2 PM RACES LIFE\nAE: NW $265 L5 OR $70 PS L10 OR IN 2015-16 (MIN 10 STS) HDCP.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Gigs And Reels              7    7/8T    4@/1Q   1@/1H   1/1H     1/3H       2:01    30.2 D Crowe          3.65   D Crowe\n8   Putnams Legacy+             8    8/10    6@/3    4@@/2T  3/2H     2/3H       2:01.3  30.2 B Mccallum      13.70   B Mccallum\n3   Flag Of Honor               3    2/1Q    3/1Q    3@/1T   2/1H     3/4T       2:02    31   J Ramsay Jr      7.25   D Settle\n4   Metro Man                   4    6/7Q    8@/4H   6@/4Q   5/5Q     4/7T       2:02.3  31.1 P Langille       7.35   K Gillis\n1   Prime Time Cowboy           1    4/3     5/2T    5/4Q    4/5      5/8        2:02.3  31.1 D Romo           1.15*  K Harper\n2   J Gs Waylon                 2    5/5     7/4     7/5T    6/7Q     6/11T      2:03.2  31.3 D Spence        13.70   T Maclean\n6   Secret Fantasy              6    1/1Q    1/Q     2/1H    7/8Q     7/22Q      2:05.2  34.3 R Ellis          8.45   R Chase\n5   Milliondollarkevin          5    3@/1T   2@/Q    8/13T   8/18Q    8/30Q      2:07    33.3 Ma Campbell      3.70   S Dixon\nTime: 29, 59.3, 1:30.3, 2:01 (Temperature: 21, Condition: FT, Variant: 0)\n\n1st  Gigs And Reels      (b,f,3 - Ameripan Gigolo-Island United-Nukes Lobell)\n                         Owner: Stephen P Morton,Windsor,NS\n2nd  Putnams Legacy      (b,g,4 - Cookie Dough Boy-Raisin Ruckus-No Nukes)\n                         Owner: Gordon McCabe,Truro-Blaise P Duff,Big Pond,NS\n3rd  Flag Of Honor       (b,g,10 - Allamerican Native-Honeycakes-Albert Albert)\n                         Owner: David M Settle,Truro,NS\n2\n3-Colin N Down              2.80   2.10   2.10       309\n4-J J Antonio                      3.40   2.60        85\n5-Ashes To Ashes                          4.00        62\n\n$2 EXACTOR (3-4) paid 4.80, pool 82\n$2 TRIACTOR (3-4-5) paid 33.00, pool 1164\n\n1 MILE, PACE, PURSE $6,100.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Colin N Down                3    2@/NS   1/2Q    1/1H    1/1H     1/2Q       2:00    29.2 G Barrieau       0.40*  S Mason\n4   J J Antonio                 4    1/NS    2/2Q    2/1H    2/1H     2/2Q       2:00.2  29.3 T Trites         3.25   E Watts\n5   Ashes To Ashes              5    5/7Q    5/6H    4/3T    4/3Q     3/2Q       2:00.2  29   J Hughes         0.65   B Mckenna\n1   Cowboys Dont Cry            1    3/1Q    3/3T    3/2H    3/2H     4/3T       2:00.4  29.4 Ma Campbell      4.05   K Maclean\n2   Private Paradise            2    4/5Q    4@/4    5/8Q    5/10Q    5/21Q      2:04.1  32   R Ellis          8.60   W Mackinnon\nTime: 30.3, 1:01, 1:30.3, 2:00 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Colin N Down        (b,g,2 - Articulator-Khadiva Hanover-No Nukes)\n                         Owner: Downey Stables,Quispamsis,NB\n2nd  J J Antonio         (b,g,2 - Western Paradise-Feel At Home-Grinfromeartoear)\n                         Owner: Windemere Farms,North Wiltshire,PE-Ian R Donald,Fredericton,NB-Hollis P Newson,Cornwall,PE\n3rd  Ashes To Ashes      (b,g,2 - Driven To Win-Red Star Ashlee-The Panderosa)\n                         Owner: J Susanne Mac Keigan,Albert Bridge,NS-Michael J Folkins,Saint John,NB-Alan Conway,Summerside-Lynn D Livingstone,Kensington,PE\n3\n5-Ic A Free Spirit          4.10   2.60   2.10       153\n4-J J Cassius                      4.50   2.60        56\n1-Last Laugh                              2.40        69\n\n$2 DAILY DOUBLE (3-5) paid 5.30, pool 47\n$2 EXACTOR (5-4) paid 22.60, pool 76\n$2 TRIACTOR (5-4-1) paid 104.40, pool 1065\n\n1 MILE, PACE, PURSE $2,500.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "B" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Ic A Free Spirit            5    1/2     1/1     1/2H    1/2      1/NK       2:00.4  29.4 E Laffin         1.05*  E Laffin\n4   J J Cassius                 4    2@/2    3/2     2/2H    2/2      2/NK       2:00.4  29.2 D Romo           5.90   J Belliveau\n1   Last Laugh                  1    5/10H   5/7     5/7T    5/9      3/12       2:03.1  30.3 A Camilli        3.35   A Camilli\n2   P H Bossman                 2    3/3     4/4H    4/4H    4/5T     4/13       2:03.2  31.3 T Trites         5.20   Dr T Shive\n3   Brookdale Jim               3    6/13    6/11Q   6/12T   6/16     5/22       2:05.1  31.3 B Mccallum      10.65   B Mccallum\n6   Windemeredancenart          6    4/5H    2@/1    3@X/3H  3/5      6/43       2:09.2  37.4 Ma Campbell      2.70   E Watts\nTime: 29.4, 1:00.4, 1:31, 2:00.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Ic A Free Spirit    (b,g,2 - Driven To Win-Eternal Optimism-Artsplace)\n                         Owner: Ernest B Laffin,Alton,NS\n2nd  J J Cassius         (br,g,2 - Articulator-Hurricane Heide-Rustler Hanover)\n                         Owner: Jean Charles Belliveau,Scoudouc-Normand O Leger,Shediac,NB\n3rd  Last Laugh          (b,c,2 - Ameripan Gigolo-Post A Smile-Grinfromeartoear)\n                         Owner: Brent Bradbury,Sydney Mines-Angelo A Camilli,Sydney,NS\n4\n4-N S Acadian               4.60   2.70   2.10       282\n3-Brookdale Buster                 2.80   2.10        87\n2-Pictonians Derbie                       2.70        84\n\n$2 EXACTOR (4-3) paid 8.00, pool 47\n$2 TRIACTOR (4-3-2) paid 40.90, pool 84\n\n1 MILE, PACE, PURSE $950.\nNON WINNERS $98 PS L10 OR IN 2015-16 (MIN 10 STS)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   N S Acadian                 4    1/2H    1/1Q    1/3T    1/3T     1/6H       1:57.4  29.3 Ma Campbell      1.30*  H Smallwood\n3   Brookdale Buster            3    2/2H    2/1Q    2/3T    2/3T     2/6H       1:59    30   B Mccallum       1.60   B Mccallum\n2   Pictonians Derbie           2    4/9Q    4/6Q    4/6T    4/5H     3/7H       1:59.1  29.3 A Campbell      10.75   B Mccallum\n1   A Regal Beauty              1    3/7H    3/4     3@/4Q   3/4Q     4/7T       1:59.2  30.2 D Spence         3.50   J Burton\n7   P H Powerful                6    6/13T   6/9T    6@/9H   6/9Q     5/12Q      2:00.1  30.1 T Trites        11.50   H Mac Kay\n5   Ilava                       5    5/12Q   5/8Q    5@/8    5/6T     6/13H      2:00.2  30.3 D Romo           8.80   J Janega\n8   Maiden Heaven               7    7/15Q   7/11T   7/11H   7/11H    7/14Q      2:00.3  30.1 P Langille      14.60   P Langille\n6   Bad Break                   SCRATCHED - JUDGES(TRANSPORTATION)                                                    \nTime: 28.3, 58.3, 1:28.1, 1:57.4 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Bad Break-TRANSPORT - 7 DAYS\n\n1st  N S Acadian         (br,g,9 - Force Of Life-N S Angie-Albatrage)\n                         Owner: Robert D Smallwood,New Minas,NS\n2nd  Brookdale Buster    (b,g,5 - Western Terror-White Sand-Real Desire)\n                         Owner: Douglas R Polley-Douglas E Polley,Amherst,NS\n3rd  Pictonians Derbie   (b,m,5 - Western Terror-Dancing Grin-Grinfromeartoear)\n                         Owner: Paisley S McCallum,Brookfield,NS\n5\n4-Matts Tuition             4.90   7.20   2.40       315\n2-Dixie Flyer                      4.00   2.10       162\n5-Dividend Day                            2.70        58\n\n$2 EXACTOR (4-2) paid 8.60, pool 108\n$2 TRIACTOR (4-2-5) paid 49.50, pool 763\n\n1 MILE, PACE, PURSE $2,500.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "B" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Matts Tuition               4    7/7Q    6@/6    5@@/2Q  4/1H     1/H        2:04.1  31.4 D Crowe          1.45*  D Crowe\n2   Dixie Flyer                 2    2/1Q    3/2Q    2@/H    1/1      2/H        2:04.1  32.1 G Barrieau       1.60   G Barrieau\n5   Dividend Day                5    5/4Q    5@/4T   6@/3H   6/2T     3/1T       2:04.3  32   S Mason         10.05   S Mason\n1   Rj Gigolo                   1    4/2T    4/3H    4@/2Q   3/1H     4/2        2:04.3  32.1 D Carey          9.15   J Green\n7   Big Joe Doby                7    3@/1T   2@/1    1/H     2/1      5/4Q       2:05    33   D Romo           6.75   G Mc Callum\n3   Howmacs Dragonator          3    6/5H    7/6Q    7/3H    7/4Q     6/5        2:05.1  32.3 B Mccallum       8.00   B Mccallum\n6   Slide Guitar                6    1/1Q    1/1     3/2     5/2H     7/5Q       2:05.1  32.4 P Langille       5.65   P Pinkney\nTime: 30.1, 1:00.2, 1:32, 2:04.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Matts Tuition       (b,c,2 - Articulator-Pictonian Flyer-Western Paradise)\n                         Owner: David A Macdonald,Halifax,NS\n2nd  Dixie Flyer         (b,c,2 - Brandons Cowboy-Dixie Dew Bluechip-Art Major)\n                         Owner: Caper Racing Stable,Glace Bay,NS\n3rd  Dividend Day        (b,g,2 - Ameripan Gigolo-Divine Justice-Pro Bono Best)\n                         Owner: Downey Stables,Quispamsis,NB\n6\n3-Mighty Cowboy             3.10   2.40   2.10       223\n4-Complete Player                  2.40   2.20        76\n6-Libertys Choice                         2.10        51\n\n$2 EXACTOR (3-4) paid 5.00, pool 81\n$2 TRIACTOR (3-4-6) paid 14.20, pool 1081\n\n1 MILE, PACE, PURSE $6,100.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Mighty Cowboy               3    1/1H    1/1T    1/T     1/1Q     1/1        2:00.1  29   D Crowe          0.55*  D Crowe\n4   Complete Player             4    2/1H    2/1T    3/1T    3/1H     2/1        2:00.2  28.4 M Bradley        2.50   T Weatherbie\n6   Libertys Choice             5    5/5H    4@/5    2@/T    2/1Q     3/2        2:00.3  29.1 J Hughes         7.55   J Hughes\n1   The Hawk                    1    3/3H    3/4     4/3T    4/3      4/4Q       2:01    29   D Romo           3.75   D Romo\n2   Windemerenightlife          2    4/4Q    5/6     5@/4T   5/5H     5/9Q       2:02    29.4 Ma Campbell      7.15   E Watts\n5   Casstielle                  SCRATCHED - JUDGES(TRANSPORTATION)                                                    \nTime: 30.2, 1:01.4, 1:31.1, 2:00.1 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Casstielle-TRANSPORT - 7 DAYS\n\n1st  Mighty Cowboy       (b,c,2 - Brandons Cowboy-Mission Beach-Jennas Beach Boy)\n                         Owner: David A Macdonald,Halifax,NS\n2nd  Complete Player     (b,c,2 - Brandons Cowboy-Suddenly Susan-Artsplace)\n                         Owner: David L Kennedy,Charlottetown,PE\n3rd  Libertys Choice     (b,g,2 - Ameripan Gigolo-Dream Of Liberty-Gothic Dream)\n                         Owner: Jason K Hughes,Stratford-Tommy A Collings-Arthur B Jay,Mount Stewart,PE\n
146	23	0721	\n7\n7-Our Star                  5.70   2.40   2.40       218\n1-Pride Of Paradise                3.80   4.00       105\n8-Sharon The Moment                      11.10        70\n\n$2 EXACTOR (7-1) paid 28.40, pool 63\n$2 TRIACTOR (7-1-8) paid 163.20, pool 910\n#7 OUR STAR CLAIMED BY KEELAN MACDONALD\n\n1 MILE, PACE, PURSE $1,100.\nNON WINNERS $701 L5 OR $100 L4 OR $141 PS L10 OR IN 2015-16 (MIN 10 STS)\nAE: NON WINNERS 5 PM RACES OR $4000 LIFETIME AE: $4,000 CLAIMERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Our Star                    7    7/8H    7@/8    2@/1Q   1/1      1/4        1:58    29.3 R Ellis          1.85*  G Rennison\n1   Pride Of Paradise           1    3/2H    1/3H    1/1Q    2/1      2/4        1:58.4  30.3 Ma Campbell      7.90   H Smallwood\n8   Sharon The Moment           8    8/10    8/9Q    4@/3T   3/2Q     3/4H       1:58.4  29.4 D Carey         11.25   D Carey\n4   Lil Orphan Cam              4    6@/6T   5@/6Q   6@/4T   4/4Q     4/5Q       1:59    29.4 P Langille       3.25   J Ellis\n6   Arizona Bucks               6    4/4     4@/5    3/3T    5/4T     5/8T       1:59.4  30.4 G Barrieau       4.40   D Pinkney\n2   Eye Forty Seven             2    2/T     3/4T    8/6H    7/7Q     6/9        1:59.4  30.2 T Trites         6.10   J Burton\n3   Go With It                  3    5/5H    6/7     7@/6Q   6/7      7/9Q       1:59.4  30.2 B Mccallum       8.30   G Mccabe\n5   I C Anastro                 5    1@/T    IP2/3H  5/4T    8/9H     8/17       2:01.2  32.1 D Spence         5.40   N White\nTime: 28.4, 57.4, 1:28.1, 1:58 (Temperature: 24, Condition: FT, Variant: 0)\nOUR STAR claimed for $4,000 by Keelan Macdonald.\n\n1st  Our Star            (b,g,7 - Rambaran-Miss Cam Star-Camluck)\n                         Owner: Ryder Matthews Rennison,Truro-Cathy Benedict,Valley,NS\n2nd  Pride Of Paradise   (b,g,4 - Western Paradise-Always Cheery-Grinfromeartoear)\n                         Owner: Robert D Smallwood,New Minas-Cyril P Harvey,Elmsdale,NS\n3rd  Sharon The Moment   (b,g,13 - Artiscape-Sharon Again-Governor Skipper)\n                         Owner: Hollis E White,Kennetcook,NS\n8\n6-Jigtime Jones            10.60   4.00   4.70       304\n4-Nameisonthehalter                2.30   2.30       134\n5-Lucbobski                               3.50       144\n\n$2 EXACTOR (6-4) paid 43.60, pool 138\n$2 TRIACTOR (6-4-5) paid 79.20, pool 988\n\n1 MILE, PACE, PURSE $6,100.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Jigtime Jones               6    4/7T    4/4T    4@/2T   1/Q      1/1        2:00    29.2 R Macdonald      4.30   M Macdonald\n4   Nameisonthehalter           4    3/5T    3@/3    2@/1    2/Q      2/1        2:00.1  30   G Barrieau       0.70*  L Snow\n5   Lucbobski                   5    6/12T   6/8     6/6H    6/4      3/2        2:00.2  29.1 D Romo           4.90   D Romo\n2   Pownal Bay Saul             2    2/2Q    2/1T    3/1H    4/2Q     4/2H       2:00.2  30.1 M Bradley       34.30   T Weatherbie\n3   Ryans Allstar               3    5/10H   5/6Q    5@/5Q   5/3T     5/7T       2:01.3  30.3 Ma Campbell      3.65   Ma Campbell\n1   Windemerefallnforu          1    1/2Q    1/1T    1/1     3/1Q     6/13Q      2:02.3  32.3 T Trites         4.30   E Watts\nTime: 29.1, 59.4, 1:30, 2:00 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Jigtime Jones       (b,g,2 - Western Paradise-Gold Luck-Camluck)\n                         Owner: Rinaldo F Macdonald,Antigonish-Ian Tate,St Andrews,NS\n2nd  Nameisonthehalter   (ch,g,2 - Brandons Cowboy-Keltic Sarah-Rambaran)\n                         Owner: Lawrence M Snow,Glace Bay,NS\n3rd  Lucbobski           (b,g,2 - Articulator-Wild Ride Hanover-Western Ideal)\n                         Owner: Robert J Skinner,Truro-Jeffrey R Skinner,Hammonds Plains,NS\n9\n2-Distinctiv Rusty          2.90   4.40   2.10       152\n4-Gerries Beach                    4.10   2.10        52\n1-Mortal Combat                           2.30        58\n\n$2 EXACTOR (2) paid 5.80, pool 47\n$2 TRIACTOR (2-4-1) paid 47.90, pool 928\nEX PD 2 ALL $5.80\n\n1 MILE, PACE, PURSE $1,475.\nNON WINNERS $951 L5 OR $180 PS IN 2015-16 (MIN 10 STS) AE: NON WINNERS\n7 PMR OR $5000 LIFE AE: $6,000 CLAIMERS AND WINNERS OVER $950 L5 HDCP.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Distinctiv Rusty            2    1/2     1/2T    1/1H    1/1H     1/2        1:56.1  28.4 R Ellis          0.45*  G Rennison\n4   Gerries Beach               4    2/2     2/2T    2/1H    2/1H     2/2        1:56.3  29   D Romo           4.45   K Harper\n1   Mortal Combat               X1   4/5Q    4/5Q    3/3     3/3H     3/3T       1:57    29   D Spence         3.05   A Maclean\n6   J Rs Hurricane              6    6@/8    6/10    6@/6    6/8      4/9Q       1:58    29.2 G Barrieau       4.80   J Belliveau\n3   Dontstandinmyway            3    5/7     5/8     5/5     4/6T     5/9H       1:58    29.3 P Rogerson      54.55   P Rogerson\n5   Threes A Crowd              5    3/3H    3@/3Q   4@/4    5/6T     6/12Q      1:58.3  30.2 T Trites        12.05   Dr T Shive\nTime: 29, 58.4, 1:27.2, 1:56.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Distinctiv Rusty    (br,h,5 - Rambaran-Winnees Luck-Camluck)\n                         Owner: Ryder Matthews Rennison-Andrea L Rennison,Truro-Cathy Benedict,Valley,NS\n2nd  Gerries Beach       (br,g,7 - Jeremes Jet-Peaceful Protest-Cams Card Shark)\n                         Owner: Carrie L Saunders,Truro,NS\n3rd  Mortal Combat       (b,h,6 - Tell All-Hrubys N Diamonds-Western Hanover)\n                         Owner: Angus A Maclean,Port Hood,NS\n10\n6-Tobinator                 4.50   2.20   2.20       136\n1-Carters Caper                    2.10   2.10        56\n2-Southsidelightning                      2.80        58\n\n$2 EXACTOR (6-1) paid 21.30, pool 88\n$2 TRIACTOR (6-1-2) paid 50.80, pool 731\n\n1 MILE, PACE, PURSE $6,100.\nATLANTIC SIRES STAKE\n2 YR OLD PACING COLTS "A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Tobinator                   6    1/2T    1/2H    1/2     1/2Q     1/T        1:58    28.2 R Ellis          1.25   T Hicken\n1   Carters Caper               1    2/2T    2/2H    2/2     2/2Q     2/T        1:58.1  28.1 M Macdonald      1.15*  M Macdonald\n2   Southsidelightning          2    3/4     4/4Q    4/3T    4/4      3/8        1:59.3  29.1 M Bradley        7.25   T Weatherbie\n4   Island Energetic            4    5/9T    5@/4T   5@@/3T  3/3T     4/8Q       1:59.3  29.1 D Romo           4.95   D Romo\n3   Woodmere Soul               3    4/6H    3@/3Q   3@/3    5/4H     5/11H      2:00.1  30   G Barrieau       5.40   E Watts\n5   Jdcyril                     5    6/11Q   6@/6Q   6/5     6/6H     6/13T      2:00.4  30.1 Ma Campbell     48.65   K Maclean\nTime: 28.2, 59.4, 1:29.3, 1:58 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Tobinator           (b,g,2 - Coastocoast Yankee-Southern Blue-Nuclear High)\n                         Owner: Robin F Burke,Ten Mile House-Luke Burke,Pleasant Grove,PE-Perry R Burke,Grosse-Ile,QC-Kent G Livingston,Cornwall,PE\n2nd  Carters Caper       (b,c,2 - Western Paradise-J J Solara-Coastocoast Yankee)\n                         Owner: Morah E Kerr,Greenfield-Phonsie Maceachern,Port Hood,NS\n3rd  Southsidelightning  (b,g,2 - Articulator-Beckys Filly-Paris Dexter)\n                         Owner: Kyle C Gardiner,Cardigan-Joseph P Gardiner,Mount Stewart-Michael F Currie,Cardigan-Jerry J Mackinnon,St Peters Bay,PE\n11\n1-Oppies Artist             7.70   4.60   5.00       120\n7-Four Starz Hold Em               3.60   4.40        72\n3-Putnams Force                           3.00        35\n\n$2 DAILY DOUBLE (6-1) paid 26.60, pool 40\n$2 EXACTOR (1-7) paid 18.90, pool 83\n$2 TRIACTOR (1-7-3) paid 182.50, pool 535\n\n1 MILE, PACE, PURSE $1,000.\nNON WINNERS $401 L5 OR $107 PS L10 OR IN 2015-16 (MIN 10 STS) AE: NON\nWINNERS 4 PM RACES OR $2500 LIFETIME\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Oppies Artist               1    1/2Q    1/1T    1/1T    1/1Q     1/1T       1:57.1  30.3 A Campbell       2.85   A Campbell\n7   Four Starz Hold Em          7    2/2Q    2/1T    2/1T    2/1Q     2/1T       1:57.3  30.3 D Spence         3.10   N White\n3   Putnams Force+              3    I4/8H   3@/5T   4/3T    4/3      3/2T       1:57.4  30.2 T Trites         4.25   J Green\n4   Djs Kocakolacowboy          4    5/11Q   5@/7    3@/2T   3/2Q     4/7T       1:58.4  31.3 Ma Campbell      2.80*  H Smallwood\n6   Brookdale Liz               6    7/14T   6@/12   6/6T    5/5Q     5/9T       1:59.1  31.1 B Mccallum       4.45   B Mccallum\n2   Eyebebuckntuff              2    X3/7Q   4/6T    5@/5T   6/6T     6/10H      1:59.1  31.2 J Ramsay Jr      4.30   D Oconnor\n5   Dashwood Darling            5    6/13Q   7/12Q   7@/8    7/8      7/17Q      2:00.3  32.2 P Langille      20.90   T Ellis\n9   Bizzy Izzy                  8    8/16H   8/14T   8@/12   8/11T    8/17Q      2:00.3  31.3 D Carey              NO N White\n8   Electric Syl                SCRATCHED - VET(SICK)                                                                 \nTime: 28, 57.1, 1:26.3, 1:57.1 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Electric Syl-SCRATCHED - 5 DAYS\n\n1st  Oppies Artist       (br,g,8 - Modern Art-Armbro Opponent-Direct Scooter)\n                         Owner: Andrew H Campbell,New Waterford,NS\n2nd  Four Starz Hold Em  (b,g,10 - Western Hanover-Four Starzzzz Hope-Cams Card Shark)\n                         Owner: Sarah Bruce,Truro,NS\n3rd  Putnams Force       (br,h,9 - Force Of Life-Tooles Gold-Hawaiian Lightning)\n                         Owner: Cindy Christie-Joseph R Green,Truro,NS\nTotal Handle: $14,687\n(Not Official CPMA Information)\n\n
118	11	0723	\n1\n\n1 MILE, PACE.QUALIFIER PACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Last Lecture                4    1/1H    1/1T    1/1T    1/2      1/HD       1:59.4  29.2 J Mayhew             NB J Mayhew\n6   Goldies Bad Girl            5    2/1H    2/1T    2/1T    2/2      2/HD       1:59.4  29   A Moore              NB G Price\n1   Homey Joe                   1    5/6     5@/6    3@/2T   3/2      3/1Q       2:00    29   M Macquarrie         NB M Macquarrie\n3   Apocolyps Seelster          2    3/3H    3/3T    4/3T    4/4      4/4Q       2:00.3  29.2 G Rooney             NB F Maguire\n4   Astreos Squirt              3    4@/4    4/5H    5/5T    5/6      5/5T       2:01    29.2 A Hamlin             NB S Zubaty\nTime: 30, 1:01, 1:30.2, 1:59.4 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Last Lecture-COGGINS, Goldies Bad Girl-COGGINS\n\n1st  Last Lecture        (b,g,9 - Western Terror-Forabber N Abber-Abercrombie)\n                         Owner: Ellie M Mayhew,Windsor-Joanne E Mayhew,London,ON\n2nd  Goldies Bad Girl    (br,m,4 - Badlands Hanover-Goldies Cam-Camluck)\n                         Owner: Greg J Price,Wheatley-Tom Jacobs,Kingsville-Dominic De Santis,Windsor,ON\n3rd  Homey Joe           (b,c,2 - Hes Gorgeous-Give The Gift-Camluck)\n                         Owner: Angus Mac Quarrie,Inverness,NS\n2\n\n1 MILE, TROT.QUALIFIER TROT\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Magical Pockets             2    1/2     1/2     1/2     1/3      1/5T       2:01    29.3 D Rankin Jr          NB R Fulmer\n5   Justice Delight=            4    2/2     2/2     2/2     2/3      2/5T       2:02.1  30.2 M Hamlin             NB M Hamlin\n4   Jimori Shimmer=             3    3/3T    3/3T    3/4     3/4      3/11       2:03.1  31   G Rooney             NB J Ellis\n1   Striking Nikee              1    4/5T    4/6T    4/9     4/10     4/15H      2:04    30.4 J Obrien             NB J Obrien\nTime: 31.1, 1:01.4, 1:31.2, 2:01 (Temperature: 28, Condition: FT, Variant: 0)\n\n1st  Magical Pockets     (b,g,6 - Kadabra-Striking Pockets-Striking Sahbra)\n                         Owner: Randall J Fulmer,Windsor,ON-Phillip E Katcher,Sun City Center,FL\n2nd  Justice Delight     (b,g,5 - Justice Hall-Jewels Brenda-Veeba Rova)\n                         Owner: Keith G Cassell,Smiths Falls,ON\n3rd  Jimori Shimmer      (br,m,5 - Southwind Lustre-Jimoris Saranade-Royal Ballad)\n                         Owner: James K Ellis-Sven A Hansen,London,ON\n
72	1	0717	\n1\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Appellate                   5    6/13    6/15H   3/7H    3/3Q     1/H        1:58.4  28.4 K Clark              NB K Clark\n3   Whisper Well                3    2/4     2/1H    1/1H    1/3      2/H        1:58.4  30.1 B Watt               NB B Watt\n6   Hollywood Redneck           6    1/4     1/1H    2/1H    2/3      3/4Q       1:59.3  30.4 G Hudon              NB G Hudon\n4   A Wish For Wings            4    5/11    5/11H   5/15H   5/15T    4/16Q      2:02    30.2 J Gray               NB S Crump\n1   Speed Shift                 1    3/6     3/6H    4/14H   4/15Q    5/20       2:02.4  31.2 M Hennessy           NB K Read\n2   Fast Lane Denali            2    4/8     4/9H    6/16H   6/19T    6/25T      2:04    32.1 N Sobey              NB T Tracey\nTime: 30, 59.3, 1:28.3, 1:58.4 (Temperature: 18, Condition: FT, Variant: 0)\n\n1st  Appellate           (b,c,3 - Western Terror-Dropitlikeitshot-Cambest)\n                         Owner: Keith L Clark,De Winton-Robert T Jones,Stony Plain,AB\n2nd  Whisper Well        (b,f,3 - Well Said-Lets Imagine-Dragon Again)\n                         Owner: Robert C Watt,Edmonton,AB\n3rd  Hollywood Redneck   (ch,h,4 - Brandons Cowboy-Cameezy-Cambest)\n                         Owner: Gerry J Hudon,Sturgeon County,AB-William J Boden,Vancouver,BC-Donald B McDougall,Calgary,AB\n2\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Lil Bit O Jingle            4    2@/HD   1/1H    1/1H    1/2      1/6        2:02.1  29.4 T Cullen             NB T Cullen\n6   Latestngreatest             6    1/HD    2/1H    2/1H    2/2      2/6        2:03.2  30.4 K Clark              NB K Clark\n3   Blue Star Cascade           3    5/6Q    5/12H   5/10H   3/8      3/8H       2:03.4  29.2 G Hudon              NB G Hudon\n8   Heated Exchange             8    7/11Q   7/17H   6@/12H  5/10     4/9T       2:04.1  29.2 R Cullen             NB T Cullen\n1   Cenalta Cougar              1    3/2Q    3/7H    3/7H    4/9      5/11Q      2:04.2  30.3 T Redwood            NB D Stout\n2   Make Some Smiles            2    4/4Q    4/10H   4/9H    6/10H    6/11T      2:04.3  30.2 K Hoerdt             NB K Hoerdt\n5   Starry Eyes                 5    6/8T    6/15H   7/14    7/16H    7/20T      2:06.2  31.1 D Sifert             NB D Sifert\n7   Orangevale Gazette          X7   8/15Q   8/22H   8/24    8/29     8/36H      2:09.2  32.1 M Bourgeois          NB M Bourgeois\nTime: 31.3, 1:01.3, 1:32.2, 2:02.1 (Temperature: 18, Condition: FT, Variant: 0)\nJudges List: Orangevale Gazette-BREAKS\n\n1st  Lil Bit O Jingle    (b,f,2 - Blue Burner-Rain Drop Hanover-Western Hanover)\n                         Owner: Kurt F & Kathy J Schmidt,Leduc,AB\n2nd  Latestngreatest     (br,c,2 - Mystery Chase-Best Promise-As Promised)\n                         Owner: Keith L Clark,De Winton-Doris E McDougall,Cochrane-Verne Rea,Calgary,AB\n3rd  Blue Star Cascade   (b,f,2 - Blue Burner-Shes Camazing-Camluck)\n                         Owner: Gerry J Hudon,Sturgeon County,AB-William J Boden,Vancouver,BC-Donald B McDougall,Calgary,AB\n3\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Capitol Hill                5    4/4H    4/7     3@/2Q   2/HD     1/2        2:03.2  30   G Clark              NB S Crump\n4   Formula D M                 4    1/1H    1/2     1/2     1/HD     2/2        2:03.4  30.4 G Hudon              NB K Read\n6   Lilmessinaround             6    5/6     5/10    5@/5T   4/5T     3/4H       2:04.1  30   R Schneider          NB R Schneider\n2   The Insinerator             2    2/1H    2/2     2/2     3/5Q     4/12       2:05.4  32.2 D Hudon              NB G Abbott\n1   Ganymeda Gold               1    3/3     3/5H    4/5Q    5/9T     5/18Q      2:07    33   N Sobey              NB N Sobey\n3   El Capone                   3X   6/DIS   6/DIS   6/DIS   6/DIS    6/DIS                   T Tracey             NB T Tracey\nTime: 31.1, 1:01.2, 1:33, 2:03.2 (Temperature: 18, Condition: FT, Variant: 0)\nJudges List: Ganymeda Gold-ALBERTA ONLY//MUST QUALIFY, El Capone-BREAKS\n\n1st  Capitol Hill        (b,m,5 - Badlands Hanover-Champale Blue Chip-No Pan Intended)\n                         Owner: Stephen L Crump-S Kelly Crump,Standard,AB\n2nd  Formula D M         (b,m,5 - D M Dilinger-Grecian Formula-Artsplace)\n                         Owner: Ken J Read,Redwater,AB\n3rd  Lilmessinaround     (b,g,3 - Blue Burner-Messina-Keystone Landmark)\n                         Owner: Richard F Schneider,Sherwood Park,AB\n
73	1	0722	\n1\n5-Cowboys Dirtyboots       17.20   6.00   3.60       480\n2-Hollywood Redneck                8.20   4.90       260\n4-Vow To Win                              4.10       196\n\n$2 EXACTOR (5-2) paid 165.70, pool 807\n$2 TRIACTOR (5-2-4) paid 776.00, pool 1345\n\n1 MILE, PACE, PURSE $4,300.\nTHREE & FOUR YEAR OLD CLAIMING ((4YOS 6000) (3YOS 8000) (PLUS ALLW)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Cowboys Dirtyboots          5    4/5     4/5     4/4H    5/5H     1/H        1:57.4  29.1 R Grundy         7.60   D Crick\n2   Hollywood Redneck           2    2/1H    2/1H    2/1H    2/2      2/H        1:57.4  29.4 G Hudon          9.75   G Hudon\n4   Vow To Win                  4    3/3H    3/3H    3/3     3/3      3/1        1:58    29.3 D Hudon          8.15   Q Schneider\n1   Rock Shooter                1    1/1H    1/1H    1/1H    1/2      4/1Q       1:58    30.1 T Cullen         0.30*  T Cullen\n6   Rare Breed                  6    5/6H    5/6H    5/6     4/5      5/4        1:58.3  29.3 M Hennessy      15.65   D Sifert\n3   Swing N Ace                 X3   6/DIS   6/35    6/35    6/30     6/27H      2:03.1  28.2 E Hensley        9.15   A Hensley\nTime: 29, 59.3, 1:27.4, 1:57.4 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Cowboys Dirtyboots  (br,h,4 - Brandons Cowboy-Modern Promise-Jate Lobell)\n                         Owner: Devann Crick,Lacombe,AB\n2nd  Hollywood Redneck   (ch,h,4 - Brandons Cowboy-Cameezy-Cambest)\n                         Owner: Gerry J Hudon,Sturgeon County,AB-William J Boden,Vancouver,BC-Donald B McDougall,Calgary,AB\n3rd  Vow To Win          (b,g,4 - Brandons Cowboy-Venus Blue Chip-Magical Mike)\n                         Owner: Quentin G & Kimberley A Schneider,Sherwood Park,AB\n2\n6-Cenalta Jade              6.10   3.40   2.50      1071\n1-Awhimaway                        5.20   5.70       375\n4-Minettas Highball                       5.00       345\n\n$2 DAILY DOUBLE (5-6) paid 52.50, pool 541\n$2 EXACTOR (6-1) paid 32.30, pool 1100\n$1 SUPERFECTA (6-1-4-3) paid 98.55, pool 489\n$2 TRIACTOR (6-1-4) paid 67.30, pool 812\n#5 4P6 FOR INTERFERENCE TO #3 AND #7\n\n1 MILE, PACE, PURSE $4,000.\nNW 2 RACES OR 6000 LIFETIME (AB SIRED 8200) CLAIMING 6000 (PLUS ALLW)\n(AB SIRED ALLOWED EXTRA WIN) 5YO & YOUNGER FILLIES & MARES\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Cenalta Jade                6    5@/3T   4@/2Q   2@/HD   2/2      1/NK       2:02    32.3 Jb Campbell      2.05*  M Roy\n1   Awhimaway                   1    1/1H    1/HD    1/HD    1/2      2/NK       2:02    32.3 K Clark          4.95   K Clark\n4   Minettas Highball           4    6/4T    6/5Q    5/5     4/6H     3/1H       2:02.1  31.4 K Ducharme       4.95   L Ducharme\n3   Barbarela Rose              3    4/3Q    5@/4Q   6@@/5H  I5/8     5P4/3T     2:02.4  32.2 T Redwood        3.45   A Arsenault\n7   Nevada                      7    8/7T    8/7T    7@@/7   IX6/9H   6P5/4Q     2:02.4  32   N Sobey         24.35   K Clark\n5   Showmesomeemotion           5    7/6Q    7@/6Q   4@/3H   3/4H     4P6/2      2:02.2  32.2 G Hudon          4.35   P Giesbrecht\n2   Forever Feisty              2    2/1H    3/1Q    3/3Q    7/10H    7/11T      2:04.2  34.2 P Shaw          42.50   D Shaw\n8   Exclusive                   8    3@/1T   2@/HD   8/8     8/23     8/35H      2:09    38   D Hudon         10.30   S Arsenault\nTime: 29.3, 59.3, 1:29.2, 2:02 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Cenalta Jade        (b,f,3 - Allamerican Merlin-Cenalta Destiny-Clintons Cigar)\n                         Owner: Mona M Roy,Water Valley,AB\n2nd  Awhimaway           (b,f,3 - Mystery Chase-Red Star Sugar Gal-Daylon Marshal)\n                         Owner: Keith L Clark,De Winton-Robert T Jones,Stony Plain-Doris E McDougall,Cochrane-John D Hind,Calgary,AB\n3rd  Minettas Highball   (b,m,4 - Lusty Leader-Minettas Martini-Three Olives)\n                         Owner: Lloyd E Ducharme,Carstairs,AB\n3\n2-Mystery Mania             6.00   3.10   2.20       631\n5-Whysantanna                      4.30   2.90       477\n6-Mystery Affair                          3.30       338\n\n$2 EXACTOR (2-5) paid 15.20, pool 1090\n$1 SUPERFECTA (2-5-6-1) paid 74.35, pool 601\n$2 TRIACTOR (2-5-6) paid 41.30, pool 894\n\n1 MILE, PACE, PURSE $4,000.\nNW 2 RACES OR 6000 LIFETIME (AB SIRED 8200) CLAIMING 6000 (PLUS ALLW)\n(AB SIRED ALLOWED EXTRA WIN) 5YO & YOUNGER FILLIES & MARES\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Mystery Mania               2    3/3H    3/3     1@/1    1/4      1/2T       2:00.1  31.1 K Clark          2.00*  K Clark\n5   Whysantanna                 5    7/10H   7/9     6/4H    8/8T     2/2T       2:00.4  31   M Hennessy       3.80   R Hennessy\n6   Mystery Affair              6    8/12    8/10H   8@@/5H  7/8Q     3/4H       2:01    31   G Hudon          5.30   P Giesbrecht\n1   Formula D M                 1    4/5     4/4H    4@/2T   3/4Q     4/4T       2:01.1  31.3 D Hudon         19.20   K Read\n4   Brendons Eileen             4    6/9     6/7H    7@/5    6/7T     5/6Q       2:01.2  31.2 P Shaw           6.45   D Sifert\n7   Moon Struct                 7    2/1H    2/1H    3/2H    5/6T     6/7        2:01.3  32.1 N Sobey         12.65   G Lutz\n3   Emmas Big Girl              3    5/7     5/6     5@@/4Q  4/5T     7/7        2:01.3  31.4 Jb Campbell      3.35   D Shaw\n8   My Glorifly                 8    1/1H    1/1H    2/1     2/4      8/8T       2:02    32.4 R Grundy        23.60   D Crick\nTime: 28.4, 59.3, 1:29, 2:00.1 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Mystery Mania       (br,f,3 - Mystery Chase-Armbro Villa-No Nukes)\n                         Owner: Keith L Clark,De Winton-Doris E McDougall,Cochrane,AB\n2nd  Whysantanna         (b,f,3 - Santanna Blue Chip-Whycantiforgetyou-The Panderosa)\n                         Owner: Rodney D Hennessy,Falun-Jean R Crochetiere,Beaumont-Lorne G Duffield,Edmonton,AB\n3rd  Mystery Affair      (b,f,3 - Mystery Chase-Forbidden Affair-Cambest)\n                         Owner: Diane Bertrand-Robert Gilhespy,Edmonton,AB-Alice M Gilbert,Brandon,MB-Philip Giesbrecht,Sturgeon County,AB\n4\n3-Mystic Messenger         10.60   4.80   3.60       671\n1-Heart N Hustle                   5.90   4.30       366\n8-Caliscape                               2.90       217\n\n$2 EXACTOR (3-1) paid 38.40, pool 1108\n$1 SUPERFECTA (3-1-8-6) paid 237.00, pool 442\n$2 TRIACTOR (3-1-8) paid 104.40, pool 807\n#2 5P6 FOR INTERFERENCE TO #4 IN THE STRETCH\n\n1 MILE, PACE, PURSE $4,300.\nNW 23,500 LIFETIME (AB SIRED 32,500) CLAIMING 6000 (PLUS ALLW)\nAE NW 13,000 LIFE (AB SIRED 18,500) TO DRAW INSIDE 5YO & YOUNGER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Mystic Messenger            3    1/4     1/1H    1/1H    1/2      1/2        1:57.4  29.1 T Bowman         4.30   V Sifert\n1   Heart N Hustle              1    2/4     2/1H    2/1H    2/2      2/2        1:58.1  29.2 Jb Campbell      4.25   M Roy\n8   Caliscape                   8    5/8H    5@/5    5@@/3H  6/7H     3/8        1:59.2  30.1 T Cullen         3.10*  T Cullen\n6   Avonlee Knight              6    4/7     4@/3H   4@/3Q   5/7      4/9        1:59.3  30.2 N Sobey          6.05   G Lutz\n4   Coliseum Hanover            4    6/10    6/5H    6/4H    4I/6     6P5/9T     1:59.4  30.2 R Cullen         7.40   T Cullen\n2   Mister Meister              2    3/5H    3/3     3/3     3/4      5P6/9Q     1:59.3  30.2 R Grundy         8.90   R Grundy\n5   Promise We Can              5    7/11H   7@/6H   7@/5    7/8H     7/10T      2:00    30.2 K Clark          9.10   G Lutz\n7   Thisboycanfinish            7    8/13    8/7H    8@/6H   8/10     8/11H      2:00    30.1 G Clark          6.15   S Crump\nTime: 29, 59.4, 1:28.3, 1:57.4 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Mystic Messenger    (br,g,5 - Camystic-Ella Quinn-As Promised)\n                         Owner: Earla L & Vernon P Sifert-Insight Strategies,Aldergrove,BC\n2nd  Heart N Hustle      (b,g,5 - As Promised-The Grey Escape-Witsends Fiddle)\n                         Owner: Mona M Roy,Water Valley,AB\n3rd  Caliscape           (b,g,3 - Artiscape-Calista-Falcons Future)\n                         Owner: Travis A Cullen-Rachel E Andrew,Airdrie,AB\n5\n8-Mods Mystery             47.60   8.10   4.80       697\n3-Crash My Party                   2.70   2.50       371\n5-Lissie Borden                           3.50       276\n\n$2 EXACTOR (8-3) paid 76.40, pool 980\n$1 SUPERFECTA (8-3-5-4) paid 901.20, pool 480\n$2 TRIACTOR (8-3-5) paid 337.50, pool 967\n\n1 MILE, PACE, PURSE $3,800.\nMAIDEN CLAIMING 7000 (PLUS ALLW) 5YO & YOUNGER\n(2YOS DRAWN INSIDE) FILLIES & MARES\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n8   Mods Mystery                8    4/4H    4/4H    3@/1Q   1/Q      1/5Q       2:01.2  32   A Arsenault     22.80   A Arsenault\n3   Crash My Party              3    1/1H    1/1H    2/1     4/2      2/5Q       2:02.2  33   G Hudon          1.15*  G Hudon\n5   Lissie Borden               5    2@/1H   2/1H    1@/1    2/Q      3/6H       2:02.3  33.2 T Cullen         2.25   D Lamont\n4   Hf Princess Peach           4    6/9     7/8     6@/5Q   3/1T     4/6H       2:02.3  32.2 M Hennessy      17.30   H Haining\n1   Starry Eyes                 1    5/7H    5/6H    7/7Q    7/6H     5/7H       2:02.4  32.1 D Sifert        11.95   D Sifert\n6   Is Santa Real               X6   8/12H   6@/7H   4@/4Q   5/4      6/8Q       2:03    33   N Sobey          6.25   N Sobey\n7   Fast Lane Denali            7    7/11    8/9H    8/9Q    8/8      7/8H       2:03    32   T Tracey        23.20   T Tracey\n2   Miss Bojangles              2    3/3     3/3     5/4T    6/6      8/10Q      2:03.2  33.1 K Clark          8.40   J Ratchford\nTime: 28.2, 59.3, 1:29.1, 2:01.2 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Mods Mystery        (b,f,3 - Mystery Chase-Mod Mod World-Jate Lobell)\n                         Owner: Doug E Woodland,St Albert-William H Woodland,Airdrie,AB\n2nd  Crash My Party      (b,f,3 - Bunkmeister-Southwind Madison-Pacific Fella)\n                         Owner: Gerry J Hudon,Sturgeon County,AB-William J Boden,Vancouver,BC-Donald B McDougall,Calgary,AB\n3rd  Lissie Borden       (b,f,3 - Lis Mara-Ideal Sunrise-Western Ideal)\n                         Owner: David C Lamont-Donna Wyse,Airdrie,AB\n6\n1-Dickies Motel            15.40   7.00   6.50       850\n3-Viola                            5.00   4.00       440\n9-P L Impressive                          5.50       313\n\n$2 EXACTOR (1-3) paid 61.90, pool 1283\n$1 SUPERFECTA (1-3-9-5) paid 2128.55, pool 567\n$2 TRIACTOR (1-3-9) paid 217.20, pool 1144\n\n1 MILE, PACE, PURSE $2,900.\nCLAIMING 4000 (PLUS ALLW) (2) NW 2175 IN LAST 3 STARTS (RACED 5000 CLM\nCND CLM OR LESS IN LAST START) FILLIES & MARES\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Dickies Motel               1    2/1H    3/1H    3@/2    3/1T     1/1H       1:58.1  31.1 Jb Campbell      6.70   R Schneider\n3   Viola                       3    3/3     2@/H    1/1H    1/1H     2/1H       1:58.2  31.4 J Hudon          5.15   J Hudon\n9   P L Impressive              9    4/4H    5@/4    4/7     4/3T     3/2Q       1:58.3  30.3 E Hensley        4.80   A Hensley\n5   Happy Promise               5    1/1H    1/H     2/1H    2/1H     4/3Q       1:58.4  32   G Clark          8.15   G Clark\n7   Royal Classic               7    8/13    8/8T    5/9     5/5T     5/4T       1:59.1  30.4 D Hudon         18.55   Q Schneider\n6   Wigesjet                    6    7/11    7@/8H   6/10H   6/9T     6/10       2:00.1  31.3 T Cullen         4.55   J Marchment\n8   Hoofenanny                  8    9/14H   9/10Q   7/13H   7/12T    7/11Q      2:00.2  31.1 M Hennessy      16.35   D Cutting\n2   Club Dreams                 2    6/9     4/3H    X8/23H  8/17T    8DQ/14T    2:01.1  30   D A Kelly        7.80   R Parish\n4   Terra True                  4    5/7H    6@/5H   IX9/DIS FELL     DNF                     G Hudon          3.05*  G Hudon\nTime: 27.4, 58.3, 1:26.3, 1:58.1 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Dickies Motel       (b,m,8 - Camystic-No Tell Motel-Tyler B)\n                         Owner: Richard F Schneider,Sherwood Park,AB\n2nd  Viola               (b,m,8 - Camcracker-Eureka Dee-Witsends Fiddle)\n                         Owner: John W Hudon,Surrey,BC\n3rd  P L Impressive      (br,m,4 - Sportswriter-B R Dot Cam-Cam Terrific)\n                         Owner: Ashleigh M Hensley-Ed F Hensley,Pompano Beach,FL\n
74	1	0722	\n7\n5-Sudden Storm             10.80   4.50   2.90       920\n6-Outlaw This Is It               10.10   4.90       465\n7-Canelo                                  2.50       300\n\n$2 EXACTOR (5-6) paid 68.10, pool 1205\n$1 SUPERFECTA (5-6-7-9) paid 252.45, pool 471\n$2 TRIACTOR (5-6-7) paid 144.00, pool 825\n\n1 MILE, PACE, PURSE $4,000.\nNW 2 RACES OR 6000 LIFETIME (AB SIRED 8200) CLAIMING 6000 (PLUS ALLW)\n(AB SIRED ALLOWED EXTRA WIN) 5YO & YOUNGER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Sudden Storm                5    1/1H    1/1H    1/H     1/1H     1/T        1:58.2  29.3 T Bowman         4.40   D Sifert\n6   Outlaw This Is It           6    6@/8    5@/3H   2@/H    2/1H     2/T        1:58.3  29.4 T Redwood        6.15   D Stout\n7   Canelo                      7    2/1H    3/1T    3/2     3/3H     3/3H       1:59    29.4 T Cullen         2.70*  T Cullen\n9   Scrappy Fella               9    8/10H   7@/5H   4@/4    4/6H     4/4H       1:59.1  29.3 M Hennessy       4.45   R Hennessy\n4   Cenalta Eclipse             4    7/9     8/7     6/5H    5/8H     5/4T       1:59.2  29.3 R Goulet         2.95   G Empey\n1   Shyloh Sage                 1    3/3     4/3Q    5/5     6/9H     6/8T       2:00.1  30.2 A Arsenault     10.55   A Arsenault\n3   Thisboyisonfire             3    5/7H    6/5     7/7     7/13H    7/18       2:02    31.4 Jb Campbell     22.55   Jb Campbell\n2   Speed Shift                 2    4/4H    2@/1H   8@/7H   8/17H    8/21T      2:02.4  32.3 G Hudon         15.20   K Read\n8   Sayitlikeyoumeanit          SCRATCHED - VET(SICK)                                                                 \nTime: 29, 1:00, 1:28.4, 1:58.2 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Sayitlikeyoumeanit-VET LONG TERM\n\n1st  Sudden Storm        (b,c,3 - Allamerican Navajo-Starring Role-Cams Card Shark)\n                         Owner: Dan F Sifert,Calgary,AB\n2nd  Outlaw This Is It   (br,h,4 - Blue Burner-Gunslingin Gal-Cams Card Shark)\n                         Owner: Derek S Stout,Camrose,AB--Nancy J & Gordon F Retzlaff,Saskatoon,SK\n3rd  Canelo              (br,c,3 - Blue Burner-Rain Drop Hanover-Western Hanover)\n                         Owner: Travis A Cullen,Airdrie,AB-Ronald A Cullen,Glenboro-Keith R Hannah,Waskada,MB\n8\n6-Kim Chee                  8.00   3.70   2.90       832\n4-Shes A Ladro                    10.00   5.70       546\n9-Yanotherhos                             3.40       383\n\n$2 EXACTOR (6-4) paid 70.50, pool 1189\n$2 TRIACTOR (6-4-9) paid 215.10, pool 2222\nWIN SIX (2-3-8-1-5-6) paid 53.55, pool 302\nHIGH FIVE CARRY OVER $303.96 WIN FOUR CARRY OVER $5874.29\nCENTURY SIX CARRY OVER $128.10\n\n1 MILE, PACE, PURSE $2,700.\nCLAIMING 4000 (PLUS ALLW) (1) NW 676 IN LAST 3 STARTS (RACED 5000 CLM, CND CLM\nOR LESS IN LAST START) FILLIES & MARES\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Kim Chee                    6    4/4H    4@/3T   3@/2H   2/2      1/NK       1:58.2  30   N Sobey          3.00   G Lutz\n4   Shes A Ladro                4    1/1H    1/2     1/2     1/2      2/NK       1:58.2  30.2 B Gray          13.10   B Gray\n9   Yanotherhos                 9    5/6     5@/5Q   5@/3T   4/4H     3/1        1:58.3  29.4 T Bowman         2.70*  J Waltenburgh\n1   Fast Lane Ferrari           1    2/1H    2/2     2/2     3/3H     4/3T       1:59.1  30.4 D Hudon          6.20   D Hudon\n8   Triple Action               8    9/12    9/9H    7@@/6H  5/9H     5/8T       2:00.1  31   G Hudon         17.60   J Ratchford\n3   Run And Tell                3    7/9     7/7T    9@@/8T  9/11     6/9H       2:00.1  30.2 T Tracey         5.55   T Tracey\n5   Three Wishes                5    8/10H   8@/8    6@/6Q   8/10H    7/10T      2:00.3  31.2 T Cullen         4.25   K Howard\n7   Little Sister               7    3/3     3@/2Q   4/3H    6/9T     8/14       2:01.1  32.3 T Redwood       13.70   A Macleod\n2   Market For Romance          2    6/7H    6/5T    8/6T    7/10Q    9/16T      2:01.4  32.2 K Ducharme      31.20   K Ducharme\nTime: 29, 59.1, 1:28, 1:58.2 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Kim Chee            (br,m,6 - Shanghai Phil-Funky Kim-Art Major)\n                         Owner: Brinsley M Brooking Lutz--Janine M & Glenn E Lutz,Calgary,AB\n2nd  Shes A Ladro        (b,m,6 - Ludwigpanbeethoven-Madigan Mae-Falcon Seelster)\n                         Lessee: Brian J Gray,Calgary,AB\n3rd  Yanotherhos         (b,m,6 - Allamerican Cobalt-Odds On Carmen-Artsplace)\n                         Owner: Ross W Sharp,Campbell River,BC\nTotal Handle: $38,050\n(Not Official CPMA Information)\n\n
77	1	0723	\n1\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Bees Burner                 3    3/3     3/3     2/1H    2/2      1/H        2:04    31   J Gagne              NB M Dumont\n5   Smokin Barrels              5    1/1H    2/1H    1/1H    1/2      2/H        2:04    31.1 N Sobey              NB J Waltenburgh\n4   Rollin In Paris             4    4/5     4/4H    3/2     3/4      3/2        2:04.2  31.1 T Bowman             NB R Lancaster\n2   Coz And Effect              2X   5/7     5/6     4/6     4/5H     4/4        2:04.4  30.4 T Redwood            NB D Stout\n1   Fescue                      1    2/1H    1/1H    X5/8    5/15H    5/15Q      2:07    32.3 R Hennessy           NB S Johnson\nTime: 31.1, 1:01.3, 1:32.4, 2:04 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Coz And Effect-BREAKS, Fescue-BREAKS\n\n1st  Bees Burner         (b,c,2 - Blue Burner-Western Bee-As Promised)\n                         Owner: Ringneck Enterprises Ltd-James A Sutherland,Calgary,AB\n2nd  Smokin Barrels      (b,g,5 - Brandons Cowboy-Daylon Ara-Camluck)\n                         Owner: Jeffery R Waltenburgh,Abbotsford,BC\n3rd  Rollin In Paris     (b,f,3 - Roll With Joe-Never In Paris-No Nukes)\n                         Owner: Wild Dunes Stables,Surrey,BC\n
80	1	0724	\n1\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Mateo                       2    2/2     2@/Q    1/3     1/4      1/6        2:02    29   E Hensley            NB D Cutting\n4   Stylomilohos                4    4/7     4/4Q    3@/5    2/4      2/6        2:03.1  29.1 T Bowman             NB R Lancaster\n1   Outlawintriguedbyu          1    3/5     3@/2T   2X/3    3/12     3/14H      2:04.4  31.1 C Kolthammer         NB C Kolthammer\n3   Brain Teaser                3    5/9     5/9Q    5/12    5/21     4/22H      2:06.2  31   R Grundy             NB R Grundy\n5   Hf Flying Glory             5    1/2     1/Q     4/7     4/19     5/25H      2:07    32.3 H Haining            NB H Haining\n6   Orangevale Gazette          X6   6/21    6/20    6/32    6/DIS    6/DIS                   D Hudon              NB M Bourgeois\nTime: 30.1, 1:04.1, 1:33, 2:02 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Outlawintriguedbyu-BREAKS, Orangevale Gazette-BREAKS\n\n1st  Mateo               (b,g,2 - Blue Burner-Mater Deo-Western Ideal)\n                         Owner: Christine Cutting-Jim R Marino,Surrey,BC\n2nd  Stylomilohos        (b,f,2 - Mystery Chase-Heart And Style-Make A Deal)\n                         Owner: Ray N Soh,Delta,BC\n3rd  Outlawintriguedbyu  (br,f,2 - Blue Burner-Outlawindependance-Bomb Rickles)\n                         Owner: Outlaw Stable,Falun,AB\n2\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Fire Of The Dragon          3    3/3     4/4H    3/3H    2/Q      1/T        2:02.2  29.4 T Bowman             NB R Lancaster\n5   Bettah                      5    2/1H    3/3     2/2     3/2Q     2/T        2:02.3  30.1 Jb Campbell          NB S Crump\n4   Makin My Move               4    1/1H    2/1H    1/2     1/Q      3/1H       2:02.3  30.3 T Cullen             NB T Cullen\n2   Chief Saratoga              2    5/7     5/6     4/5     4/4Q     4/1T       2:02.4  29.4 R Schneider          NB R Schneider\n1   West Town Lady              1    4/5     1/1H    5/5H    5/13     5/22Q      2:06.4  33.4 N Sobey              NB N Sobey\nTime: 29.4, 1:02.1, 1:32, 2:02.2 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Fire Of The Dragon  (b,g,3 - Dragon Again-Fie Foe Fire-Real Artist)\n                         Owner: Ray N Soh,Delta-Richard D Lancaster,Langley,BC\n2nd  Bettah              (b,m,6 - Bettors Delight-Life Cycle-Life Sign)\n                         Owner: S Kelly Crump,Standard,AB\n3rd  Makin My Move       (b,g,3 - Sportswriter-Southwind Lily-Bettors Delight)\n                         Owner: Kurt F & Kathy J Schmidt,Leduc-Peter J Mikolajczyk-Michelle E Winter,Mcrae,AB\n3\n\n1 MILE, PACE.QUALIFIERS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Skade                       4    1/1H    1/1H    1/1H    1/2      1/3T       1:58.2  28.2 Jb Campbell          NB S Campbell\n2   Nevermissabeat              2    3/3     3/3     3/3     3/4      2/3T       1:59.1  28.3 R Goulet             NB R Goulet\n1   Final Say                   1    2/1H    2/1H    2/1H    2/2      3/3T       1:59.1  29   T Bowman             NB T Bowman\n3   Little Bit Faster           3    4/4H    4/4H    4/4H    4/6      4/5H       1:59.2  28.3 H Haining            NB H Haining\n5   Metajka Road                5    5/6     5/6     5/8H    5/8H     5/8T       2:00.1  28.3 J Gagne              NB M Dumont\nTime: 30.2, 1:01.3, 1:30, 1:58.2 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Skade               (br,m,6 - Dragon Again-Pucker Up-Western Hanover)\n                         Owner: Raymond W Henry,Calgary,AB\n2nd  Nevermissabeat      (b,g,10 - Robust Art-Kings Song-Witsends Fiddle)\n                         Owner: Jerome Smith,Regina,SK\n3rd  Final Say           (b,m,5 - Well Said-Carta Final-Camluck)\n                         Owner: Insight Strategies,Aldergrove,BC\n
83	2	0721	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Rewind Again                2    3/5H    3/4     1/8     1/11     1/14       2:02    30   K Murphy             NB C Murphy\n3   Ic Brandonscowgirl          3    4/9     4/10    3@/11   3/12     2/14       2:04.4  30.3 A Merner             NB A Merner\n4   Gypsy Queen                 4    1/3H    1/2     2/8     2/11     3/18H      2:05.3  32   N Myers              NB M Macdonald\n1   Monastery                   1    2/3H    2/2     4/14    4/DIS    4/DIS                   K Arsenault          NB K Arsenault\nTime: 30.4, 1:01.3, 1:32, 2:02 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Ic Brandonscowgirl-COGGINS, Monastery-PERFORMANCE//TIME//MUST QUALIFY\n\n1st  Rewind Again        (br,f,2 - Dragon Again-Rewound-No Nukes)\n                         Owner: Clifford C Murphy,Brackley-Tommy A Collings,Mount Stewart,PE\n2nd  Ic Brandonscowgirl  (b,f,2 - Brandons Cowboy-Gift Of Life-Life Sign)\n                         Owner: Max Roderick Sehl,Port Morien,NS\n3rd  Gypsy Queen         (b,f,3 - Brandons Cowboy-Run About Girl-This Cams For You)\n                         Owner: Norman E Myers,Cardigan,PE\n2\n\n1 MILE, TROT.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Oceanview Pancho=           4    2/2H    2/2     2/2H    2/2H     1/H        2:06.4  30.3 P Larrabee           NB P Larrabee\n3   B J Classic=                3    1/2H    1/2     1/2H    1/2H     2/H        2:06.4  31   Bri Macphee          NB B Honkoop\n5   Glencove Carter=            5    X3X/9   5/DIS   3/DIS   3/DIS    3/DIS                   H Shepherd           NB C Bagnall\n1   Sanctified=                 X1   5/DIS   4/DIS   4/DIS   4/DIS    4/DIS                   B Andrew             NB B White\n2   Glencove Zsa Zsa            2X   4/DIS   3/DIS   5X/DIS  X5/DIS   5/DIS                   K Arsenault          NB C Bagnall\nTime: 31.3, 1:04.2, 1:35.4, 2:06.4 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Glencove Carter-BREAKS//MUST QUALIFY, Glencove Zsa Zsa-BREAKS//MUST QUALIFY\n\n1st  Oceanview Pancho    (br,c,3 - Neal-Rose Run Frances-Armbro Laser)\n                         Owner: Paul J Larrabee,Belle River-William N Roloson,Belfast,PE\n2nd  B J Classic         (b,g,3 - Meadowagogo-High And Flighty-Dream Vacation)\n                         Owner: Bert J Honkoop,Montague,PE\n3rd  Glencove Carter     (b,c,2 - Bo W-Watch Top-S Js Photo)\n                         Owner: Carl R Bagnall,Stratford,PE\n3\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Mick Dundee                 3    1/2     1/1T    1/2     1/H      1/T        2:01.4  29.1 D Mac Neill          NB D Mac Neill\n1   Ascaryone Hanover           1    2/2     2/1T    2/2     2/H      2/T        2:02    29   K Murphy             NB C Murphy\n2   Jamiesmilingcowboy          2    3/4     3/3H    3/3H    X3/8     3/21       2:06    32.4 K Arsenault          NB K Arsenault\nTime: 30.4, 1:02, 1:32.3, 2:01.4 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Jamiesmilingcowboy-BREAKS//MUST QUALIFY\n\n1st  Mick Dundee         (b,g,2 - Aahm Canadian Now-Big Love-The Panderosa)\n                         Owner: Donald C Mac Neill,Charlottetown,PE\n2nd  Ascaryone Hanover   (b,c,2 - Yankee Cruiser-A Filly To Fear-Western Terror)\n                         Owner: Clifford C Murphy,Brackley-Tommy A Collings,Mount Stewart,PE\n3rd  Jamiesmilingcowboy  (b,c,2 - Brandons Cowboy-Die With A Smile-Die Laughing)\n                         Owner: James R Kennedy,Charlottetown,PE\n4\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Sanchez Blue Chip           1    3/11    3/4Q    2@/1H   2/1H     1/1H       2:02    29.4 V Poulton            NB D Clow\n4   Zanzibar+                   4    1/8     1/2H    1/1H    1/1H     2/1H       2:02.1  30.1 P Morrison           NB P Morrison\n3   Umiztagoodthing+            3    2/8     2/2H    3/2T    3/2T     3/2        2:02.2  29.4 T Walsh              NB T Walsh\n2   Prynne Hanover+             2    4/13H   4/6     4@/3H   4/4H     X4/7H      2:03.2  30.4 A Campbell           NB R Squires\nTime: 28.4, 1:01, 1:32, 2:02 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: Prynne Hanover-BREAKS//MUST QUALIFY\n\n1st  Sanchez Blue Chip   (b,g,5 - Bettors Delight-Western Charmer-Western Hanover)\n                         Owner: Deanna M Clow,New Haven,PE\n2nd  Zanzibar            (br,g,10 - Drop Off-Butterfly Mcqueen-Dragons Lair)\n                         Owner: Kathy Furness,Vernon Bridge,PE\n3rd  Umiztagoodthing     (br,g,7 - Modern Art-Bigamiz-Albert Albert)\n                         Owner: J Darin Mac Kenzie,Charlottetown,PE\n
86	2	0723	\n1\n\n1 MILE, TROT.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Frill Seeker=               3    1/30    1/33    1/37    1/38     1/39H      2:01    30.3 G Hennessey          NB K Arsenault\n1   Sanctified=                 1    2/30    2/33    2/37    2/38     2/39H      2:08.4  31   B Andrew             NB B White\n2   Glencove Carter=            X2X  3/DIS   PULLED UP                DNF                     H Shepherd           NB C Bagnall\nTime: 28.4, 59.2, 1:30.2, 2:01 (Temperature: 26, Condition: FT, Variant: 0)\nJudges List: Glencove Carter-BREAKS//MUST QUALIFY\n\n1st  Frill Seeker        (b,g,8 - Angus Hall-Yankee Frilly-Yankee Paco)\n                         Owner: Ebbsfleet Stables,Stratford,ON\n2nd  Sanctified          (b,g,3 - Explosive Matter-Sanna Hanover-Yankee Glide)\n                         Owner: William E Andrew,Calgary,AB-Blayne L White,Belle River-Brian H Andrew,Milton Station,PE\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Lorne Valley Lucy           1    1/3Q    1/2Q    1/2     1/1T     1/1        2:05    30.2 G Chappell           NB G Chappell\n2   Kashkantbymeluv             2    2/3Q    2/2Q    2/2     2/1T     2/1        2:05.1  30.1 D Mac Neill          NB R Gass\n3   Woodmere Intrepid           3    3/5H    3/4     3@/2Q   3/2H     3/4H       2:05.4  30.4 Ma Campbell          NB Ma Campbell\nTime: 32, 1:03.2, 1:34.3, 2:05 (Temperature: 26, Condition: FT, Variant: 0)\nJudges List: Lorne Valley Lucy-COGGINS, Kashkantbymeluv-COGGINS, Woodmere Intrepid-COGGINS//ELIGIBILITY FEE\n\n1st  Lorne Valley Lucy   (b,f,2 - Articulator-J J Tackoor-Pro Bono Best)\n                         Owner: Kevin A Macleod,Cardigan,PE\n2nd  Kashkantbymeluv     (b,f,2 - Toofunnyforwords-Part Time Lover-Cole Muffler)\n                         Owner: R Kingsley Walsh,Albany,PE\n3rd  Woodmere Intrepid   (br,g,2 - Articulator-Blue Violet-Abercrombie)\n                         Owner: Tanya Tremblett,Sydney Mines-Stevi Jardine,Georges River,NS\n3\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   J J Dazzler                 2    1/2     1/1H    1/1T    1/2Q     1/2        2:02.3  31.1 M Mcguigan           NB K Wilkie\n1   Ourgirlellie                1    2/2     2/1H    2/1T    2/2Q     2/2        2:03    31.1 P Lanigan            NB P Lanigan\nTime: 29.4, 1:00.3, 1:31.2, 2:02.3 (Temperature: 26, Condition: FT, Variant: 0)\n\n1st  J J Dazzler         (b,m,4 - Ameripan Gigolo-Farline Hanover-Big Towner)\n                         Owner: James Whalen Jr,Vernon Bridge,PE\n2nd  Ourgirlellie        (b,m,4 - Force Of Life-Dropelle-Drop Off)\n                         Owner: Peter E Lanigan,Montague,PE\n
119	13	0717	\n1\n6-What A Promise           10.90   5.40   3.70        32\n5-Heartland Spark                  0.00   0.00        16\n4-Trishas Fancy                           6.10        20\n\n$2 QUINELLA (5-6) paid 32.50, pool 71\n$2 TRIACTOR (6) paid 7.80, pool 31\n\n1 MILE, PACE, PURSE $4,106.\nTHE SILK LACE - LEG 1\n3 YR OLD FILLIES MANITOBA SIRED\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   What A Promise              6    2/2     I1/3H   1/13    1/3      2P1/1H     2:14.2  35.3 R Remillard      4.45   B Mcnaughton\n5   Heartland Spark             5    5@/11   I4/5    3/13Q   3/12     3P2/18H    2:17.4  36.2 M Fillion        0.95*  M Fillion\n4   Trishas Fancy               4    3/6     IX6/15  5/20    4/19     4P3/24     2:19    36.1 K Rogers         4.45   K Rogers\n2   Margies Candy               2    4/10    I3/3T   4/18    5/DIS    5P4/DIS                 R Rey                NO R Rey\n7   Dont Chud Me                7    6/12    IX5/8H  6/25    6/DIS    6P5/DIS                 C Manning        9.95   C Manning\n3   Luvn The Life               3    1/2     X2@/3H  2@/13   2/3      1P6/1H     2:14.1  32.4 D Rey            0.95*  D Rey\n1   Cordees Whitesocks          SCRATCHED - VET(LAME)                                                                 \nTime: 30.4, 1:05.2, 1:38.4, 2:14.1 (Temperature: 22, Condition: HY, Variant: 2)\n\n1st  What A Promise      (b,f,3 - Whatayasay-Three Promises-As Promised)\n                         Owner: Barry McNaughton,Oakville,MB\n2nd  Heartland Spark     (b,f,3 - Armbro Baylor-Newport Way-The Panderosa)\n                         Owner: W Allan Drader,Brookdale,MB\n3rd  Trishas Fancy       (b,f,3 - Armbro Baylor-P Ts Fancy-Spy Hard)\n                         Owner: Nicole M Fontaine-Kirk D Rogers,Holland,MB\n2\n3-Gold Star Sonata          8.90   3.70   2.10        39\n4-Wild Chic                        3.70   2.10        54\n2-Smoky Moon                              2.10        22\n\n$2 QUINELLA (3-4) paid 10.80, pool 63\n$2 TRIACTOR (3-4-2) paid 29.70, pool 70\n\n1 MILE, PACE, PURSE $1,750.\nFILLIES & MARES OPEN\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Gold Star Sonata            3    1/1H    1/Q     2/H     2/2      1/NS       2:04.1  32   D Howlett        3.45   T Williams\n4   Wild Chic                   4    2/1H    2@/Q    1@/H    1/2      2/NS       2:04.1  32   R Remillard      1.20*  R Remillard\n2   Smoky Moon                  2    4/5     3@/4H   3/6     3/13     3/13       2:06.4  33.2 M Fillion        1.40   K Hildebrandt\n5   Gottaluckydeal+             5    X6/14   6/9H    6@/11   4/18     4/21       2:08.2  34   C Manning            NO C Manning\n1   Come On Kathryn             1    3/3     4/4T    4/7H    5/19     5/25       2:09.1  35.3 T Grundy         5.65   C Manning\n6   Freedom Forever             6    5/7     5/7     5/10    6/37     6/39       2:12    37.4 M Rey            3.45   M Rey Clark\nTime: 30.4, 1:01.3, 1:32.1, 2:04.1 (Temperature: 22, Condition: HY, Variant: 2)\n\n1st  Gold Star Sonata    (b,m,4 - Rock On-Just Wait Fellas-Pacific Fella)\n                         Owner: Trevor Williams,Winnipeg,MB\n2nd  Wild Chic           (b,m,4 - Western Terror-Be In Style-Jate Lobell)\n                         Owner: Richard A Remillard-Valerie L Emerson,Gladstone-Garett J Isman,Winnipeg,MB\n3rd  Smoky Moon          (br,m,7 - Fort Apache-Illchangeyourluck-Albert Albert)\n                         Owner: Kevin M Hildebrandt,Roseau River-W Allan Drader,Brookdale,MB\n3\n1-Good Chemistry            7.00   2.60   0.00        36\n4-Diggin A Trench                  5.00   0.00        55\n\n$2 QUINELLA (1-4) paid 37.00, pool 54\n$2 TRIACTOR (1-4) paid 35.60, pool 28\nNO SHOW WAGERING\n5TH PLACE MONEY RETAINED BY HOLLAND AG SOCIETY\n\n1 MILE, PACE, PURSE $1,650.\nNON WINNERS 4-7 RACES LIFETIME HDCP\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Good Chemistry              1    2/1H    2/2H    2/2     3/1H     1/1        2:09.2  32   D Howlett        2.50   T Williams\n4   Diggin A Trench             4    3/3     3/4H    3@/3    1/H      2/1        2:09.3  32   M Rey            3.10   R Rey\n5   Home Matters                5    1/1H    1/2H    1/2     2/H      3/3        2:10    33   D Rey            3.10   R Rey\n3   Redonkulous                 3    4/4H    4/6H    4/5     4/11     4/12       2:11.4  33.4 R Rey            0.45*  R Rey\n2   Mixed Blessings+            SCRATCHED - VET(LAME)                                                                 \nTime: 31.1, 1:05.1, 1:37, 2:09.2 (Temperature: 22, Condition: HY, Variant: 2)\n\n1st  Good Chemistry      (b,c,3 - I Zee-Chemistry Major-Art Major)\n                         Owner: Trevor Williams,Winnipeg,MB\n2nd  Diggin A Trench     (b,h,4 - Armbro Trench-Allamerican Orchid-Camluck)\n                         Owner: Richard B & Janet L Rey,St Claude,MB\n3rd  Home Matters        (b,h,5 - Another Matter-Home On The Range-Western Hanover)\n                         Owner: Justin A & Roland Rey,St Claude,MB\nTotal Handle: $591\n(Not Official CPMA Information)\n\n
123	14	0720	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Bay Win                     1    1/NR    1/NR    1/NR    1/NR     1/NR       2:07.3  31.1 R Gillis             NB D Beaton\nTime: 33.1, 1:04.1, 1:36.2, 2:07.3 (Temperature: 18, Condition: FT, Variant: 0)\n\n1st  Bay Win             (b,c,2 - Driven To Win-Pownal Bay Pearl-Artiscape)\n                         Owner: Donald F Beaton-Trenholm Boys Stable,Port Hood,NS\n
89	3	0717	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Catch A Lucky Star          4    3/3T    3/3H    3/3H    3/2T     1/HD       2:00.3  29.2 C Steacy             NB J Watt\n3   Rocket Art                  3    1/2     1/1T    1/1T    1/1Q     2/HD       2:00.3  30   G Rooney             NB D Meekison Jr\n2   Watt A Funny Face           2    2/2     2/1T    2/1T    2/1Q     3/1        2:00.4  29.4 C German             NB J Watt\n1   Shanghai Noodle             1    4/5T    4/5Q    4/5Q    4/4T     4/6        2:01.4  30.1 G Mcclure            NB G Mcclure\nTime: 30, 59.4, 1:30.3, 2:00.3 (Temperature: 25, Condition: FT, Variant: 0)\n\n1st  Catch A Lucky Star  (b,m,6 - Sand Shooter-Leias Star-Cambest)\n                         Owner: Jeffrey Williamson,Blyth,ON\n2nd  Rocket Art          (b,m,8 - Modern Art-Wendys Rocket-Pacific Rocket)\n                         Owner: Megan D Meekison,Belmont,ON\n3rd  Watt A Funny Face   (b,m,5 - Armbro Deuce-Feisty Form-Camluck)\n                         Owner: Morag S Watt,Clinton,ON\n
90	3	0724	\n1\n8-Daniellas Shadow         60.70  37.10   9.50       371\n4-Honi Maker                      12.70   6.40       271\n2-Rocket Art                              7.20       358\n\n$2 EXACTOR (8) paid 181.30, pool 641\n$2 TRIACTOR (8-4-2) paid 3939.10, pool 1077\nEX PAYS ON 8 ALL TR IS .20 PAYOUT\n\n1 MILE, PACE, PURSE $3,000.\nFILLIES & MARES - CLAIMING $6000. (W-ALL) - FOR W/O $500. LAST 5\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n8   Daniellas Shadow            8    5/6     1@/H    1/2     1/2H     1/2Q       1:58.2  29.3 J Harris        29.35   J Watt\n4   Honi Maker                  4    7/9Q    6@/4Q   4@@/3H  2/2H     2/2Q       1:58.4  29.2 L House          7.70   W Walker\n2   Rocket Art                  2    2/1H    3/2     5/4     4/8      3/9H       2:00.1  30.3 R Holliday      16.00   D Meekison Jr\n1   Shes All Good               1    1/1H    2/H     2/2     3/6H     4/9T       2:00.2  31.1 N Steward        0.60*  P Shepherd\n7   Ivegotmyeyeonu              7    3/3     5/4Q    7/6     6/10H    5/10       2:00.2  30.2 C Steacy        16.65   R Steward\n6   Life On The Links           6    8/10T   8/7H    8/7H    7/12     6/10Q      2:00.2  30.1 G Rooney        11.25   E Lock\n3   Zinfandart                  3    4/4H    7/6     6@/5    5/9      7/10T      2:00.3  30.4 D Mcclure       11.15   G Mcclure\n5   Whosurbeast                 5    6/7H    4@/2H   3@/3    8/13Q    8/22H      2:02.4  33.2 A Macdonald      2.60   J Darling\nTime: 29.2, 59.3, 1:28.4, 1:58.2 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Daniellas Shadow    (br,m,5 - Shadow Play-Cr Daniella-Cam Fella)\n                         Owner: Rebecca Williamson,Blyth,ON\n2nd  Honi Maker          (b,m,6 - Badlands Hanover-Honeys Bud Lite-Park Place)\n                         Owner: William J Walker,Aylmer,ON\n3rd  Rocket Art          (b,m,8 - Modern Art-Wendys Rocket-Pacific Rocket)\n                         Owner: Megan D Meekison,Belmont,ON\n2\n6-Little Quick              6.60   2.90   2.10       342\n7-Kennairnlaughaloud               2.80   2.10       159\n2-Its Machademic                          2.40       241\n\n$2 EXACTOR (6-7) paid 24.60, pool 403\n$2 TRIACTOR (6-7-2) paid 54.80, pool 512\n\n1 MILE, PACE, PURSE $4,000.\nCLAIMING $12000. - FOR N/W $50000. LIFETIME (W-ALL)\nA.E. N/W $1500. IN 2016\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Little Quick                4    5/8     5@/4H   3@@/1H  2/1Q     1/1H       1:58.1  28.4 J Harris         2.30   J Watt\n7   Kennairnlaughaloud          5    2/1H    2@/1    2@/H    3/1T     2/1H       1:58.2  29.1 J Ryan           1.20*  J Riehl\n2   Its Machademic              1    3/4     3/2T    4/2H    4/4Q     3/2        1:58.3  29   L House          3.20   C Schneider Jr\n5   Cantcountmeout              3    1/1H    1/1     1/H     1/1Q     4/3H       1:58.4  29.3 A Macdonald      3.90   A Macdonald\n4   Distinctiv Cam              2    4/6H    4/4H    5/8H    5/12Q    5/12       2:00.3  29.4 G Rooney         6.85   K Macnaughton\n3   Acton O So Royal            SCRATCHED - VET(SICK)                                                                 \n1   Hog Aufray                  SCRATCHED - VET(SICK)                                                                 \nTime: 30, 1:00, 1:29.1, 1:58.1 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Acton O So Royal-VET, Hog Aufray-VET\n\n1st  Little Quick        (br,g,9 - Quick Comeback-Norwell Lilyharbor-Coal Harbor)\n                         Owner: Rebecca Williamson,Blyth,ON\n2nd  Kennairnlaughaloud  (b,h,7 - Grinfromeartoear-Decisive Margin-Jate Lobell)\n                         Owner: Kenneth J & Shirley I Ramsey,Goderich,ON\n3rd  Its Machademic      (b,g,4 - Mach Three-Goodnewsbabe-Cams Card Shark)\n                         Owner: Colonel Schneider Jr,Arthur,ON\n3\n4-Onatopp                   6.20   3.50   2.50       330\n6-Burning Memories                 3.90   2.60       159\n1-Highfield                               3.70       254\n\n$2 EXACTOR (4-6) paid 27.70, pool 478\n$2 TRIACTOR (4-6-1) paid 111.80, pool 503\n\n1 MILE, TROT, PURSE $4,300.\nN/W $15000. (F & M $18750.) LIFETIME (W-ALL)\n(N/W $3000. (F & M $3750.) LIFETIME DRAW INSIDE)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Onatopp=                    4    4/4H    2@/T    1@/1T   1/3H     1/1Q       2:03.4  30.2 A Macdonald      2.10*  A Macdonald\n6   Burning Memories            6    5/6     4@/2T   2@/1T   3/3T     2/1Q       2:04    30.1 L House          2.70   R Bryce\n1   Highfield                   1    3/3     5/4     4@/3T   4/5Q     3/1H       2:04    29.4 Do Brown         4.10   P Forgie\n3   Attitude To Burn=           3    2/1H    3/2Q    3/2Q    2/3H     4/2H       2:04.1  30.2 R Holliday       3.80   K Haskell\n5   Ink Master=                 5    1/1H    1/T     X5/5    5/17     5/20       2:07.4  33.2 N Steward        3.30   L Bako\n2   For A Reason                2X   6/DIS   6/DIS   6/DIS   6/DIS    6BE/DIS                 H Lewis          9.90   V Cochrane\nTime: 30.3, 1:02.1, 1:33.2, 2:03.4 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: For A Reason-BREAKS\n\n1st  Onatopp             (br,f,3 - Manofmanymissions-Trophy Bass-Supergill)\n                         Owner: Rene M Allard,Matamoras,PA-Anthony A Macdonald,Guelph,ON\n2nd  Burning Memories    (br,m,4 - Southwind Lustre-Zorgwijk Delicate-Conway Hall)\n                         Owner: R Gary Bryce,Plympton Wyoming,ON\n3rd  Highfield           (ch,f,3 - Deweycheatumnhowe-Angel Creek-Striking Sahbra)\n                         Owner: David M Wilkinson,Goderich,ON\n4\n1-Win One Soon              6.30   4.10   3.50       458\n8-Stoney Durkin                    3.50   2.80       291\n3-Camythical                              5.10       308\n\n$2 EXACTOR (1-8) paid 37.10, pool 718\n$2 TRIACTOR (1-8-3) paid 147.40, pool 964\n\n1 MILE, PACE, PURSE $4,500.\nN/W $2750. LAST 3 OR $4500. LAST 5\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Win One Soon                1    1/1H    1/1     1/1H    1/1      1/1        1:56.3  28.4 R Holliday       2.15*  K Fritsch\n8   Stoney Durkin               8    2/1H    3/2     3/1H    3/2      2/1        1:56.4  28.4 N Steward        3.70   L Fitzsimmons\n3   Camythical                  3    6/11Q   4@/3Q   4/3     4/3H     3/3        1:57.1  28.4 D Megens         7.25   D Megens\n2   Derby Dylan                 2    5/8T    2@/1    2@/1H   2/1      4/3Q       1:57.1  29.1 L House          5.15   C Schneider Jr\n7   Colorado Buck               7    4/4Q    7/5T    8@/6Q   6/5      5/6Q       1:57.4  28.4 A Macdonald      9.45   D Schweitzer\n4   Twilite Zone                4    7/13T   6@/4T   5@/4    5/3H     6/6Q       1:57.4  29.1 Kn Oliver        3.65   Kn Oliver\n6   Bugger Max                  6    8/15T   8@/6T   7@@/6   8/7Q     7/10H      1:58.3  29.3 J Harris         8.95   D Beatson\n5   Rock N Roll Legacy          5    3@/3    5/3T    6/5     7/6      8/14       1:59.2  30.3 G Rooney         3.85   R Marriage\nTime: 28, 58.2, 1:27.4, 1:56.3 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Win One Soon        (b,g,4 - Jeremes Jet-Allamerican Tiger-Grinfromeartoear)\n                         Owner: Ronald Ash,Desboro,ON\n2nd  Stoney Durkin       (b,g,7 - Whosurboy-Stonebridge Flores-Island Fantasy)\n                         Owner: William P Durkin,Sparta-Larry N Fitzsimmons,London,ON\n3rd  Camythical          (br,h,11 - Cambest-Loveandtenderness-Jate Lobell)\n                         Owner: Janice M Van Nest-Dan H Megens,Hamilton,ON\n5\n2-Country Baran             8.00   3.30   2.70       345\n7-Sws Caviar                       2.70   2.40       176\n6-Bradys Play                             2.30       248\n\n$2 EXACTOR (2-7) paid 22.00, pool 575\n$2 TRIACTOR (2-7-6) paid 55.40, pool 1029\n\n1 MILE, PACE, PURSE $4,000.\nN/W $3000. (F & M $4000.) LIFETIME (W-ALL)\n(N/W OF A RACE DRAW INSIDE.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Country Baran               2    2/2     2/1H    3@/2    2/1      1/T        1:59.3  28.4 N Steward        3.00   L Fitzsimmons\n7   Sws Caviar                  7    5/9T    4@/5Q   1@/1    1/1      2/T        1:59.4  29.2 R Holliday       0.80*  J Kerr\n6   Bradys Play                 6    1/2     1/1H    2/1     3/3      3/4        2:00.2  29.4 G Rooney         4.10   C Blake\n4   Larjon Laney                4    3/6     3/3H    4/4     4/6      4/8Q       2:01.1  30   A Macdonald     17.70   L Lane\n1   Vinmara                     1    4/8     5/6Q    5@/5H   5/7Q     5/9T       2:01.3  30.1 L House          8.95   A Shelton\n3   Ponders Xample              3    6/11T   6/18Q   6/DIS   6/DIS    6/DIS                   J Harris        10.55   F Maguire\n5   Shanghai Noodle(vl)         5    7/13Q   X7X/28Q PULLED UP        DNF                     D Mcclure        9.90   G Mcclure\n8   Tailored Service            SCRATCHED - VET(SICK)                                                                 \nTime: 30, 1:00, 1:30.2, 1:59.3 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Ponders Xample-PERFORMANCE, Shanghai Noodle-VET LONG TERM//BREAKS//PERFORMANCE, Tailored Service-VET\n\n1st  Country Baran       (br,c,3 - Rambaran-Out Of Tears-Fundamentalist)\n                         Owner: Larry N Fitzsimmons,London-Richard W Dalby,Tillsonburg,ON\n2nd  Sws Caviar          (b,m,4 - Sportswriter-Armbro Caviar-Western Hanover)\n                         Owner: Jeffrey Williamson,Blyth,ON\n3rd  Bradys Play         (b,c,3 - Shadow Play-Marshamarshamarsha-Northern Luck)\n                         Owner: Curt R Blake,Clinton,ON\n6\n1-Grits N Gravy             5.60   3.50   2.50       370\n8-Flames Cammi Boy                 7.30   5.00       197\n2-Jackstan                                2.30       299\n\n$2 EXACTOR (1-8) paid 40.00, pool 666\n$2 TRIACTOR (1-8-2) paid 75.10, pool 1028\n\n1 MILE, PACE, PURSE $3,000.\nN/W $1250. LAST 3\n(W/O $2500. LAST 5 N/E)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Grits N Gravy               1    1/2     1/1H    1/1     1/1      1/NK       1:59.2  29.1 G Rooney         1.80   W Hamm\n8   Flames Cammi Boy            8    2/2     2/1H    3/2     3/2      2/NK       1:59.2  28.4 T Smith          8.05   J Walker\n2   Jackstan                    2    3/4     3@/2H   2@/1    2/1      3/2T       2:00    29.3 R Holliday       1.20*  F Maguire\n5   Regal Roxy                  4    6/9     5/5H    5/4     5/4      4/3Q       2:00    29   A Macdonald      9.80   T Gilkinson\n7   Blue Chip Sunshine          6    4/5H    4@/4    4@/3    4/3      5/3H       2:00    29.1 Kn Oliver        7.50   Kn Oliver\n6   Stonebridge Scout           5    7/11    7/7Q    7/6H    7/6      6/4H       2:00.1  28.4 L House         11.75   A Hardy\n3   Only The Lonely             3    5/7Q    6@/5H   6@/5    6/5      7/6        2:00.3  29.2 N Steward        8.05   P Shepherd\n4   St Lads Flirt               SCRATCHED - JUDGES(TRANSPORTATION)                                                    \nTime: 29.2, 1:00.2, 1:30.1, 1:59.2 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Grits N Gravy       (blk,g,5 - Daylon Frontier-Casimir Hugs-Sir Luck)\n                         Owner: William R & Jordan A Hamm,West Lorne,ON\n2nd  Flames Cammi Boy    (b,g,9 - Cammibest-Against The Flame-Odds Against)\n                         Owner: Homer M Martin,Elmira,ON\n3rd  Jackstan            (b,g,9 - Island Fantasy-Mytoyboxisfull-Camluck)\n                         Owner: Fred L Maguire,Ailsa Craig,ON\n
91	3	0724	\n7\n2-Dali On Up               12.10   6.20   2.60       570\n6-Wildcat Art                      7.80   5.10       232\n1-Jazzmo                                  2.80       296\n\n$2 EXACTOR (2-6) paid 121.10, pool 645\n$2 TRIACTOR (2-6-1) paid 255.30, pool 1023\n\n1 MILE, PACE, PURSE $3,000.\nHORSES & GELDINGS - CLAIMING $6000. (W-ALL) - FOR W/O $500. LAST 5\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Dali On Up                  2    5/6H    8/7     6@@/6Q  2/1H     1/H        1:59.4  29   R Holliday       5.05   L Fitzsimmons\n6   Wildcat Art                 6    7/9H    5@/3Q   3@/3H   3/1H     2/H        1:59.4  29.3 A Macdonald      1.40*  T Gilkinson\n1   Jazzmo                      1    1/1T    1/1H    1/1T    1/1H     3/2T       2:00.2  30.4 L House          6.00   F Schaeffer\n5   Red Leaf Morgan             5    6/8     2@/1H   2@/1T   4/1H     4/5Q       2:00.4  30.4 J Harris         2.55   J Watt\n8   Passionate Pete             8    3/3Q    4/3     5@/5T   5/2      5/6Q       2:01    30.1 J Ryan           7.25   D Dowling\n7   Slots Of Fun                7    4/4T    6/4H    7/7Q    6/4H     6/6Q       2:01    30   G Rooney        14.45   R Carroll\n4   Julio Lauxmont              4    2/1T    3/1H    4/4T    7/6Q     7/12H      2:02.1  31.3 N Steward        8.35   L Bako\n3   Riverwalk                   3    8/11Q   7@/5H   8EX/10  PU BE    DNF                     C Steacy        31.55   G Jacklin\nTime: 28.4, 59.4, 1:29.3, 1:59.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Dali On Up          (br,g,5 - Dali-Lofty Expectations-Badlands Hanover)\n                         Owner: Michael Arndt,Bluevale,ON\n2nd  Wildcat Art         (b,g,12 - Village Jiffy-Art Expo-Artsplace)\n                         Owner: Cat Sass Stable,Listowel,ON\n3rd  Jazzmo              (b,g,10 - Dream Away-Morocka-Die Laughing)\n                         Owner: Robert F Summers-Sandi T McMillan,St Thomas,ON\n8\n3-Jeannes Faith             4.90   3.20   3.10       281\n2-Modern Man                       6.60   4.00       157\n4-Larjon Emma                             7.50       278\n\n$2 EXACTOR (3-2) paid 31.70, pool 577\n$2 TRIACTOR (3-2-4) paid 134.90, pool 758\n\n1 MILE, PACE, PURSE $2,800.\nCLAIMING $6000. (W-ALL) - FOR N/W $1250. LAST 5 OR $1500. IN 2016\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Jeannes Faith               3    1/1H    1/1     1/1     1/1      1/2        2:00.4  30   N Steward        1.45*  D Schweitzer\n2   Modern Man                  2    3/3     2@/1    2@/1    2/1      2/2        2:01.1  30.1 C Brown          4.00   C Brown\n4   Larjon Emma                 4    2/1H    3/2     3/2     3/2      3/2Q       2:01.1  30   A Macdonald      7.70   L Lane\n1   Joeys Kidd                  1    6/8Q    6@/5    4@/3Q   4/3      4/6        2:02    30.3 H Lewis          2.45   V Cochrane\n7   Albergetty                  7    8/11H   7/6     8/6T    8/7H     5/7        2:02.1  30   C Steacy        15.35   D Walters\n5   Jiffyson                    5    7/9T    8@/7    7@@/5T  6/6      6/8H       2:02.2  30.2 G Rooney         8.45   P Bissett\n6   Bachata Hanover             6    4/5     5/4     5/4Q    5/5      7/10T      2:03    31.2 Kn Oliver        9.20   Kn Oliver\n8   Born With Class             8    5/6H    4@/3    6@/5Q   7/7      8/10T      2:03    31.1 L House          3.90   P Brickman\nTime: 30, 1:00.3, 1:30.4, 2:00.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Jeannes Faith       (b,m,5 - Armbro Baylor-Belle Sahbra-Expensive Scooter)\n                         Owner: Douglas A Schweitzer,West Lorne,ON\n2nd  Modern Man          (b,g,12 - Jate Lobell-Modigliani-Artsplace)\n                         Owner: Christopher A Brown,Acton,ON\n3rd  Larjon Emma         (b,m,4 - L H Stryker-Western Nova-Western Terror)\n                         Owner: Larry D Lane,Goderich,ON\n9\n7-Charmbo Curiosity        12.20   6.50   3.40       403\n6-Buttons                          2.90   2.20       256\n3-Play Like A Pro                         5.20       295\n\n$2 EXACTOR (7-6) paid 26.40, pool 701\n$2 TRIACTOR (7-6-3) paid 228.00, pool 1190\n\n1 MILE, PACE, PURSE $4,300.\nN/W $15000. (F & M $18750.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Charmbo Curiosity           6    5/6     5/5H    4@@/3T  2/2H     1/NS       1:58.2  28.1 A Macdonald      5.10   P Bissett\n6   Buttons                     5    1/1H    1/1     1/1T    1/2H     2/NS       1:58.2  29   N Steward        1.25*  B Belore\n3   Play Like A Pro             3    6/7H    6@/5T   6/5T    5/6H     3/5T       1:59.3  29   J Ryan           5.30   D Dowling\n8   Zetlan Rocket               8    4/4H    4@/3T   3@@@/2T 3/5      4/9        2:00.1  30.1 T Smith         11.10   J Walker\n2   Poplar Duke                 2    3/3     2@/1    2@/1T   4/6      5/9T       2:00.2  30.3 G Rooney         3.50   V Vanstone\n1   Unwavering                  1    2/1H    3/2T    5/4     6/8      6/14T      2:01.2  31.1 R Holliday      20.85   M Taylor\n4   Payback                     4X   7/25H   7/19T   7/18T   7/23     7/28H      2:04    30.4 Da Wall          3.80   De Wall\n5   Kerrfect Fella              SCRATCHED - JUDGES(INELIGIBLE)                                                        \nTime: 30, 59.2, 1:29.2, 1:58.2 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Payback-BREAKS\n\n1st  Charmbo Curiosity   (b,g,4 - Mach Three-Pretty Bo-Bo Knows Jate)\n                         Owner: Shelley L Kerr-C Jane Kerr,Goderich,ON\n2nd  Buttons             (b,g,4 - Astronomical-Naomi Seelster-Camluck)\n                         Owner: Ronald J Thomson,Embro,ON\n3rd  Play Like A Pro     (b,g,5 - No Pan Intended-Artful Angel-Artsplace)\n                         Owner: Keira J Liberte,Dundas,ON\n10\n3-Lexis D J                 8.20   4.60   3.60       856\n1-Kennel Buddy                     5.50   3.70       391\n5-Meadowview Cliffy                       5.50       540\n\n$2 EXACTOR (3-1) paid 33.80, pool 926\n$2 TRIACTOR (3-1-5) paid 226.50, pool 1512\n\n1 MILE, TROT, PURSE $12,500.\nVIC HAYTER MEMORIAL TROT - INVITATION\n(CO-SPONSORED BY THE HAYTER FAMILY)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Lexis D J                   3    1/NS    1/1     1/1H    1/2      1/2        1:59.2  30   B Arsenault      3.10*  S Arsenault\n1   Kennel Buddy=               1    3/1T    3/2     2/1H    2/2      2/2        1:59.4  30.1 J Ryan           3.40   D Dowling\n5   Meadowview Cliffy           5    7/7H    6@/5    5@/3Q   4/4H     3/2H       1:59.4  29.4 Do Brown         4.00   P Forgie\n7   Spartan Victory             7    4@/2T   4@/3    3@/1H   3/3H     4/4T       2:00.2  30.4 R Holliday       5.00   K Di Cenzo\n4   Boots N Hearts              4    5/3T    5/4     4/3Q    5/5T     5/8H       2:01    31   Da Wall          8.70   De Wall\n2   Massive Muscles             2    6/5T    7/6     6/5     6/7Q     6/8H       2:01    30.3 J Renaud         3.55   P Walker\n6   Lets Leavem                 6    2@/NS   2@/1    7@/6T   7/11T    7/15H      2:02.2  31.3 N Steward        4.50   W Robinson\n8   Tortola Sunrise=            8X   8/DIS   8/DIS   8/DIS   8/DIS    8/DIS                   A Macdonald      3.80   A Macdonald\nTime: 29, 58.2, 1:29.2, 1:59.2 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Lexis D J           (b,g,9 - Amigo Hall-Lexus Lulu-Angus Hall)\n                         Owner: Shane J Arsenault,Freelton,ON\n2nd  Kennel Buddy        (b,g,6 - Ken Warkentin-Bernice Daniece-Berndt Hanover)\n                         Owner: Allan R Neal,Grand Bend,ON\n3rd  Meadowview Cliffy   (b,g,5 - Muscle Mass-Meadowviewprincess-Angus Hall)\n                         Owner: Pam M Forgie,Goderich,ON\nTotal Purse:  $45,400\nTotal Handle: $25,683\n(Not Official CPMA Information)\n\n
94	4	0717	\n1\n\n1 MILE, PACE.QUALIFERS - PACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Make Some Memories          3    3/10    3/7     3/1T    1/HD     1/2T       2:03    29.3 A Hamlin             NB T Myers\n2   Beer And A Haircut          2    1/8     1/5     2/NS    2/HD     2/2T       2:03.3  30.3 B Forward            NB S Roberts\n5   Dear Wee Mel                5    4/12    2/5     1@/NS   3/5      3/10H      2:05    32   M Williams           NB L Mansfield\n4   Twelve Apaches              4    5/14    4/13    4/7T    4/11     4/34       2:09.4  35.1 A Lilley             NB A Lilley\n1   Hall Oak                    1    2EX/8   PULLED UP                DNF                     A Moore              NB W Durbridge\nTime: 29.4, 1:01.3, 1:33, 2:03 (Temperature: 27, Condition: FT, Variant: 1)\nJudges List: Hall Oak-ALLERGIC TO LASIX\n\n1st  Make Some Memories  (br,m,6 - Ponder-Breathdefying-Intrepid Seelster)\n                         Owner: Boris Laus,South Woodslee,ON\n2nd  Beer And A Haircut  (b,g,4 - Ponder-Snooze Supreme-Dexter Nukes)\n                         Owner: Stephen E Roberts-Laura Roberts,Melbourne,ON\n3rd  Dear Wee Mel        (b,f,2 - Sportswriter-Paradigm Shift-Camluck)\n                         Owner: Rick S Heaman,Ailsa Craig,ON\n2\n\n1 MILE, PACE.QUALIFERS - PACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Stock Losses                3    2/2H    2/1T    1@/1    1/5      1/7H       2:02.1  29.1 A Hamlin             NB \n3   Acefortyfouramanda          X2   3/4Q    3/3H    3/3     2/5      2/7H       2:03.3  30   A Lilley             NB L Bako\n1   Foreigner                   1    1/2H    1/1T    2/1     3/6      3/16       2:05.2  32.1 B Forward            NB D Dowling\nTime: 31.1, 1:02.1, 1:33, 2:02.1 (Temperature: 27, Condition: FT, Variant: 1)\n\n1st  Stock Losses        (br,h,6 - I Am A Fool-Howthewestwaswon-Western Hanover)\n                         Owner: Michael W Hamlin,Essex,ON\n2nd  Acefortyfouramanda  (b,m,4 - Tigerama-Extra Fine-Falcons Future)\n                         Owner: Colin A Densley Burrows,St Catharines,ON\n3rd  Foreigner           (b,h,4 - Allamerican Native-Tamara Scooter-Matts Scooter)\n                         Owner: Tan M Micallef,Moffat,ON\n
97	4	0724	\n1\n\n1 MILE, BOTH.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Just Like Buttah            4    3/3T    2@/1Q   1/8     1/12     1/18       2:02.3  29.4 C Johnston           NB D Good\n2   Hall Oak                    2    1/1T    1/1Q    2/8     2/12     2/18       2:06.1  31.4 J Coke               NB W Durbridge\n3   Ehmacharena                 3    4/5T    4/14Q   4/17T   4/21     3/22H      2:07    30.3 B Forward            NB M Rogers\n5   Donato B Winnin=(T)         5    2/1T    3/4Q    3/16    3/20     4/24Q      2:07.2  31.2 D Duford             NB A Duford\n1   Duet Seelster=(T)           1    5X/DIS  PULLED UP                DNF                     R Maclean            NB R Maclean\nTime: 31.2, 1:02.1, 1:32.4, 2:02.3 (Temperature: 25, Condition: FT, Variant: 1)\nJudges List: Hall Oak-ALLERGIC TO LASIX, Duet Seelster-BREAKS//PERFORMANCE\n\n1st  Just Like Buttah    (b,f,3 - Allamerican Native-Western Beauty-Western Hanover)\n                         Owner: Douglas J Good,Chatham,ON\n2nd  Hall Oak            (br,g,11 - Blissfull Hall-Quando Mae-Easy Goer)\n                         Owner: William N Durbridge,Dutton,ON\n3rd  Ehmacharena         (b,f,3 - Mach Three-Rustle For It-Rustler Hanover)\n                         Owner: Sherri L Abbott,Windsor,ON\n
98	5	0723	\n1\n5-Take Off Eh              17.20   2.60   2.50        74\n4-Sassyandiknowit                  2.50   2.50        24\n3-Windemere Jimmy                         2.50        22\n\n$2 TRIACTOR (5-4-3) paid 104.40, pool 375\n\n1 MILE, PACE, PURSE $825.\nN/W 1 RACE LIFE ( F & M 2 ) AE N/W $900 LIFETIME\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Take Off Eh                 5    3/3     3/3     4/2T    3@/3     1/T        2:06.2  29.4 C Miles          7.60   C Miles\n4   Sassyandiknowit             4    1/1H    1/1H    1/1H    1/1H     2/T        2:06.3  30.3 T Trites         0.20*  W Mahar\n3   Windemere Jimmy             3    2/1H    2/1H    2/1H    2/1H     3/2Q       2:06.4  30.3 S Trites         3.30   S Watts\n1   Cocagne Countess            1    4/4H    4/4H    5@/4Q   5/5      4/3Q       2:07    30.1 G Gallant        3.70   G Gallant\n2   Little Carny                2    5/6     5/6     3@/2H   4@/4H    5/11H      2:08.3  32.1 M Haig          24.90   D Foley\nTime: 31.1, 1:04.1, 1:36, 2:06.2 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Take Off Eh         (b,g,4 - Aahm Canadian Now-Khayam I Am-Omar Khayam)\n                         Owner: Richard E Canavan,Rusagonis-Todd Canavan,Fredericton,NB\n2nd  Sassyandiknowit     (b,f,3 - Force Of Life-Heather Candido-Paris Dexter)\n                         Owner: Deborah L Mahar,Saint John,NB\n3rd  Windemere Jimmy     (b,c,3 - Articulator-Cool Jolt Hanover-Village Jolt)\n                         Owner: Frank J Balcom,Amherst,NS\n2\n3-Hyperion Blue Chip        3.10   4.20   2.10        90\n1-Choco Du Ruisseau                8.40   3.70        27\n2-Cruise Level                            3.70        20\n\n$2 DAILY DOUBLE (5-3) paid 36.80, pool 79\n$2 QUINELLA (1-3) paid 22.60, pool 97\n$2 TRIACTOR (3-1-2) paid 40.30, pool 288\n#4 MADE A BREAK CAUSING INTERFERENCE TO #5 FIN 2 PLACED 4\n\n1 MILE, PACE, PURSE $950.\nN/W $801 L4 STARTS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Hyperion Blue Chip          3    1@/1    1/1H    1/1H    1/2      1/3        2:02.1  30   Dr M Downey      0.55*  Dr M Downey\n1   Choco Du Ruisseau           1    2/1     2/1H    3/1T    3/2Q     3P2/8      2:03.4  31.1 T Trites         2.50   C Miles\n2   Cruise Level                2    3/5H    5/4     5/3Q    5/4      4P3/8Q     2:03.4  31   C Decourcey     30.50   C Decourcey\n5   Windemere Nick              5    5/8H    4@I/3T  4@/2    4@/3T    5P4/9T     2:04.1  31.3 S Trites         5.30   S Watts\n4   Northern Smoke Out          4    4/7     3@X/2   2@/1H   2@/2     2P5/3      2:02.4  30.2 S Hubbard        2.15   S Wright\nTime: 29.3, 1:01.1, 1:32.1, 2:02.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Hyperion Blue Chip  (b,h,8 - American Ideal-Hawaiian Dixie-Life Sign)\n                         Owner: Michael B Downey,Saint John,NB\n2nd  Choco Du Ruisseau   (b,g,9 - Million Dollar Cam-M B Toblerone-Dragons Lair)\n                         Owner: Tina L Dunphy,Maugerville,NB\n3rd  Cruise Level        (b,g,5 - Yankee Cruiser-Got You Beat-The Panderosa)\n                         Owner: Colin M Decourcey-Melanie N Maunder,New Maryland,NB\n3\n3-Upstairswithron          19.90   5.60   3.70        57\n6-Yankee Dancer                    2.40   2.10        22\n1-Milliondollarjewel                      2.10        57\n\n$2 QUINELLA (3-6) paid 24.70, pool 53\n$2 TRIACTOR (3-6-1) paid 150.60, pool 430\n\n1 MILE, PACE, PURSE $825.\nN/W $201 L4 STARTS ( F & M $241 ) AE N/W $301 L4 STARTS\n( F & M $451 ) DRAW OUTSIDE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Upstairswithron             3    2/1H    2/1H    2@/1H   1@/Q     1/T        2:03.4  30.1 S Hubbard        8.95   R Macneil\n6   Yankee Dancer               6    1/1H    1/1H    1/1H    2/Q      2/T        2:04    30.3 M Haig           3.40   B Goodwin\n1   Milliondollarjewel          1    4/4H    5@/3    3@@/3   3/1T     3/1T       2:04.1  30.1 T Trites         0.55*  C Decourcey\n5   Victory George              5    5@/5    3@/1T   4@/3Q   4/2      4/3        2:04.2  30.2 J Lewis          4.70   J Lewis\n4   Da Vinci Art                4    6/6H    6/4T    6/5T    5/7      5/11       2:06    31.2 S Trites         3.40   R Dickinson\n2   Shipps Xcalibur             2    3/3     4/2T    5/5Q    6/7Q     6/15Q      2:06.4  32.2 W Watts         12.30   D Foley\nTime: 30.3, 1:02, 1:33.2, 2:03.4 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Upstairswithron     (b,g,5 - Quick Comeback-Tigress Killean-Run The Table)\n                         Owner: Robert J Macneil,Saint John,NB\n2nd  Yankee Dancer       (b,m,8 - Coastocoast Yankee-Pillar Of Strength-Paris Dexter)\n                         Owner: Barbara L Goodwin,Fredericton,NB\n3rd  Milliondollarjewel  (br,m,10 - Million Dollar Cam-Immortal Jewel-Village Jasper)\n                         Owner: Stefan J De Courcey-Colin M Decourcey,New Maryland,NB\n4\n\nNO CONTEST ACCIDENT\n\n1 MILE, PACE, PURSE $1,100.\nN/W $1100 L4 STARTS AE PREFERRED DRAW OUTSIDE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Skippy                      NO CONTEST                            DNF                     L Armstrong             H Defazio\n4   Ideal Ticket                NO CONTEST                            DNF                     S Trites                R Dickinson\n2   Allstar Seelster            NO CONTEST                            DNF                     E Harvey                E Harvey\n5   Stare Down                  NO CONTEST                            DNF                     Dr M Downey             E Stevenson\n3   Haunto                      NO CONTEST                            DNF                     M Haig                  G White\n (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Allstar Seelster-MUST QUALIFY, Stare Down-MUST QUALIFY\n\n5\n2-Grimsby                   6.30   4.90   0.00        54\n3-Meter Leader                     6.00   0.00        27\n4-Goldin Opportunity                      0.00          \n\n$2 QUINELLA (2-3) paid 10.70, pool 69\n$2 TRIACTOR (2-3-4) paid 126.10, pool 180\nTRIACTOR PAY $1.00 TICKET\n5TH PLACE PURSE MONEY RETAINED BY TRACK\n\n1 MILE, PACE, PURSE $950.\nN/W $801 L4 STARTS\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Grimsby                     1    3/2Q    3/1Q    3/1Q    2/1      1/1T       2:03.3  32.4 W Hubbard        2.15   W Hubbard\n3   Meter Leader                2    4/4T    4/3     4/2T    4/2      2/1T       2:04    32.4 A Bustard        3.20   P Sowers\n4   Goldin Opportunity          3    2/H     1/Q     1/T     1/1      3/2Q       2:04    33.2 P Reid           2.40   P Reid\n5   Cecils Express              4    1@/H    2@/Q    2@/T    3@/1     4/2H       2:04    33.1 T Trites         0.70*  R Phillips\n1   Simon Said                  SCRATCHED--JUDGES                                                                     \nTime: 28.1, 57.4, 1:30.3, 2:03.3 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Grimsby             (gr,g,8 - Admirals Galley-R Dayzee-Falcon Almahurst)\n                         Owner: Sara Mh Burns,Fredericton-Ronald D Fowlie,Quispamsis,NB\n2nd  Meter Leader        (b,g,8 - Yankee Leader-Millimetre-Basie)\n                         Owner: Robert L Grant Jr,Woodstock-Patricia C Sowers,Debec,NB\n3rd  Goldin Opportunity  (b,g,7 - Lis Mara-Fantasy Jet-Island Fantasy)\n                         Owner: Philip G Reid,Quispamsis,NB\n6\n5-Fall Bliss                3.30   0.00   0.00        48\n4-City Of The Year                 3.50   0.00        10\n2-Magical Alex                            0.00          \n\n$2 QUINELLA (5-4) paid 3.00, pool 45\n$2 TRIACTOR (5-4-2) paid 13.10, pool 301\n5TH PLACE PURSE MONEY RETAINED BY TRACK\n\n1 MILE, PACE, PURSE $1,350.\nPREFERRED 1 ( PP # 5 ASSIGNED )\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Fall Bliss                  4    4/4H    4@/3Q   3@/1Q   1@/T     1/1Q       1:59    29   Dr M Downey      0.65*  Dr M Downey\n4   City Of The Year            3    3/3     1@/1    1@/1    2/T      2/1Q       1:59.1  29.2 M Downey         1.40   M Downey\n2   Magical Alex                1    1/1H    2/1     2/1     3/2Q     3/6        2:00.1  30.1 T Trites        10.20   R Macneil\n3   Coral Snake                 2    2/1H    3/2H    4/2T    4/4      4/8        2:00.3  30.1 L Armstrong      2.05   R Armstrong\n1   Momara                      SCRATCHED-JUDGES                                                                      \nTime: 31.1, 1:01.3, 1:29.4, 1:59 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Coral Snake-SCRATCHED - 5 DAYS\n\n1st  Fall Bliss          (b,r,8 - Blissfull Hall-Fall Festival-Artsplace)\n                         Owner: Michael B Downey,Saint John,NB\n2nd  City Of The Year    (b,g,4 - Royal Mattjesty-What Fools Believe-Western Hanover)\n                         Owner: Michael B Downey,Saint John,NB\n3rd  Magical Alex        (b,g,9 - Harrods-Magical Ball-Magical Mike)\n                         Owner: Robert J Macneil,Saint John,NB\nTotal Handle: $2,449\n(Not Official CPMA Information)\n\n
99	6	0718	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   R Es Miss Eliza             2    1/5     1/5     1/10    1/12     1/15       2:09.4  32.4 S Trites             NB C Miles\n3   The Pita                    3    2/5     2/5     2/10    2/12     2/15       2:12.4  33.4 C Miles              NB C Miles\n1   Elm Grove Lynarush+         X1X  X3/DIS  3/DIS   3/DIS   3/DIS    3/DIS                   G Wright             NB G Wright\nTime: 32.1, 1:04.2, 1:37, 2:09.4 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: R Es Miss Eliza-INADEQUATE//MUST QUALIFY, The Pita-INADEQUATE//MUST QUALIFY, Elm Grove Lynarush-BREAKS//MUST QUALIFY\n\n1st  R Es Miss Eliza     (b,f,2 - Articulator-Jojoes Shabla-Apaches Fame)\n                         Owner: Charles H Miles-Dean H McLaughlin,Fredericton,NB\n2nd  The Pita            (b,c,3 - Camystic-Roan Lady-Admirals Galley)\n                         Owner: Richard E Canavan,Rusagonis,NB\n3rd  Elm Grove Lynarush  (br,f,2 - Camshaft Hanover-Seawind Alpha-Largo)\n                         Owner: Gary L & Shayne S Wright,Upper Woodstock,NB\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Windsong Leo                2    1/3H    1/12    1/15    1/18     1/26       1:59    28.3 S Trites             NB P Jones\n1   Choco Du Ruisseau           1    2/3H    2/12    2/15    2/18     2/26       2:04.1  30.4 T Trites             NB T Dunphy\nTime: 31, 1:01.2, 1:30.2, 1:59 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Windsong Leo        (b,g,4 - Jeremes Jet-Windsong Goldie-Jennas Beach Boy)\n                         Owner: Everette M Hanson,Maugerville,NB\n2nd  Choco Du Ruisseau   (b,g,9 - Million Dollar Cam-M B Toblerone-Dragons Lair)\n                         Owner: Tina L Dunphy,Maugerville,NB\n
100	7	0717	\n1\n5-Mach Messier              5.70   2.90   2.10       817\n3-My Old Master                    2.70   2.10       289\n6-Toy Cop                                 2.80       233\n\n$2 EXACTOR (5-3) paid 10.90, pool 977\n$1 SUPERFECTA (5-3-6-1) paid 63.55, pool 1360\n$2 TRIACTOR (5-3-6) paid 17.15, pool 1895\n\n1 MILE, PACE, PURSE $6,000.\nHORSES & GELDINGS - N/W $3000. LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $2000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Mach Messier                5    4/6H    3@/1H   2@/2    2/1H     1/1T       1:55    28.3 J Ryan           1.85   M Bishop\n3   My Old Master               3    3/3H    1@/HD   1/2     1/1H     2/1T       1:55.2  29.2 B Davis Jr       1.20*  B Macintosh\n6   Toy Cop                     6    5/8H    5@/3H   4@/4    3/2H     3/3T       1:55.4  29   A Carroll        3.25   K Bodz\n1   Santanna Sam                1    2/1H    4/2     5/5H    4/12     4/15Q      1:58    31   P Mackenzie      8.95   R Jarvis\n7   Oforpetesake                7    6/10    6/4H    7/7     6/14     5/15Q      1:58    30.3 R Doyle         27.90   J Hastie\n4   Big Dylan                   4    7/11H   7/6     6@X/6   7/15H    6/15T      1:58.1  31   S Young         17.95   M Brealey\n2   Well Played Out             2    1/1H    2/HD    3/3H    5/12H    7/26       2:00.1  33.3 T Moore          8.05   J Copley\nTime: 26.3, 57.4, 1:26, 1:55 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Mach Messier        (b,h,4 - Mach Three-Whitesand Scarlet-Million Dollar Cam)\n                         Owner: Red Rock Fraser Racing,London,ON\n2nd  My Old Master       (b,g,3 - Vintage Master-Michiko-Jate Lobell)\n                         Owner: Hutt Racing Stable,Paoli,PA\n3rd  Toy Cop             (blk,c,3 - Sportswriter-Lady Buckshot-Dexter Nukes)\n                         Owner: Kevin L Bodz,Arthur,ON\n2\n1-Thrift Shop               5.40   2.50   2.10      1097\n5-Buttercup Baby                   4.70   2.80       277\n3-Justabitevil                            6.40       442\n\n$2 DAILY DOUBLE (5-1) paid 18.00, pool 889\n$2 EXACTOR (1-5) paid 20.20, pool 1113\n$2 TRIACTOR (1-5-3) paid 74.25, pool 1862\n\n1 MILE, PACE, PURSE $5,000.\nFILLIES & MARES - CLAIMING $12000. - FOR N/W $15000. LIFETIME (W-ALL)\n(N/W OF A RACE IN 2016 ALLOWED $3000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Thrift Shop                 1    3/3H    3/3H    2@/1H   1/HD     1/1T       1:56.3  30   S Byron          1.70   J Holding\n5   Buttercup Baby              4    1/1H    1/1H    1/1H    2/HD     2/1T       1:57    30.3 J Ryan           6.55   K Reibeling\n3   Justabitevil+               2    2/1H    2/1H    3/2H    3/2H     3/3H       1:57.1  30.2 A Byron         11.30   T Knight\n6   Come On Eileen              5    4/5     4/5     4/4H    4/5Q     4/9T       1:58.3  31.2 P Mackenzie      3.20   M Brethour\n4   Orch Vicky                  3    X5/6H   5/11H   5/17    5/21H    5/20Q      2:00.3  30.4 S Young          0.90*  G Remmen\n2   Notebookandtablet           SCRATCHED - JUDGES(TRANSPORTATION)                                                    \nTime: 28.3, 58, 1:26.2, 1:56.3 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Thrift Shop         (br,m,4 - Shadow Play-Bastet Hanover-Island Fantasy)\n                         Owner: John J Holding,Kitchener,ON\n2nd  Buttercup Baby      (br,f,3 - Badlands Hanover-Star Of Show-Astreos)\n                         Owner: ICR Racing,Pefferlaw,ON\n3rd  Justabitevil        (br,m,6 - No Pan Intended-Hestia-Astreos)\n                         Owner: Thomas F Hughes,Caledon Village,ON\n3\n1-Missus Big                4.80   2.40   2.40      1151\n2-Miss Print                       2.50   2.10       554\n3-Classic Comedy                          2.80       304\n\n$2 EXACTOR (1-2) paid 10.80, pool 1279\n$2 TRIACTOR (1-2-3) paid 19.05, pool 2550\n\n1 MILE, PACE, PURSE $5,600.\nFILLIES & MARES - CLAIMING $12000. - FOR N/W $37500. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Missus Big                  1    1/1H    1/1H    1/1Q    1/1T     1/3Q       1:57.1  28.1 B Mcclure        1.40   D Tyrrell\n2   Miss Print                  2    2/1H    2/1H    3/1H    2/1T     2/3Q       1:57.4  28.3 N Steward        1.30*  A Mccabe\n3   Classic Comedy              3    3/3     3/3     2@/1Q   3/3H     3/4T       1:58.1  29   Tra Henry        9.70   C Auciello\n4   Casimir Pardon Me           4    4/4H    4/4H    4/4H    4/5      4/5T       1:58.2  28.3 S Byron          4.85   K Reibeling\n6   Badlands Delight            5    5/6     5/6     5/6H    5/6Q     5/6        1:58.2  28.1 A Carroll        3.45   D Lehan\n5   Total Knockout(L)           SCRATCHED - VET(SICK)                                                                 \nTime: 28.3, 1:01, 1:29, 1:57.1 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Total Knockout-VET\n\n1st  Missus Big          (b,m,4 - Mister Big-Highland Dancing-Life Sign)\n                         Owner: Brianna Cuthbert-John G Bruno,Newmarket,ON\n2nd  Miss Print          (b,f,3 - Sportswriter-Stonebridge Grace-Western Hanover)\n                         Owner: Glenview Livestock Ltd,Wallenstein,ON\n3rd  Classic Comedy      (b,m,4 - Classic Card Shark-Kristens Best-Cammibest)\n                         Owner: Wheelhouse Racing Stable,Mississauga,ON\n4\n4-Im A Gift                 4.10   2.50   2.10      1788\n5-Skyway Boomer                    3.30   2.10       658\n3-Lively Freddie                          2.30       523\n\n$2 EXACTOR (4-5) paid 8.60, pool 2135\n$1 SUPERFECTA (4-5-3-1) paid 58.40, pool 2337\n$2 TRIACTOR (4-5-3) paid 14.85, pool 2640\n\n1 MILE, PACE, PURSE $8,800.\nHORSES & GELDINGS - N/W $50000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Im A Gift                   4    3/3     4@/3H   2@/1H   2/Q      1/H        1:53.3  28.3 D Dupont         1.05*  M Dupont\n5   Skyway Boomer               5    4/4H    5@/4H   4@/3H   3/2Q     2/H        1:53.3  28.1 T Moore          2.95   J Copley\n3   Lively Freddie              3    6/7H    7@/6H   6@/5H   5/4H     3/2        1:54    28.1 B Mcclure        2.35   D Nixon\n1   Surf Report                 1    1/1H    1/1H    1/1H    1/Q      4/3H       1:54.1  29.2 A Carroll        9.15   M Etsell\n6   Stature Seelster(L)         6    7/9     6/5     7/6     6/5      5/4T       1:54.3  28.3 P Mackenzie     32.85   M Isabel\n7   Sporty Mercedes             7    5/6     3/3     5/4     7/6Q     6/7T       1:55.1  29.3 B Davis Jr      25.20   B Macintosh\n2   Singhampton Kenny           2    2/1H    2/1H    3/3     4/3      7/12       1:56    30.3 Tra Henry        6.35   L Fuller\nTime: 27, 56.4, 1:24.4, 1:53.3 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Im A Gift           (br,g,4 - Muscle Mass-Im A Checkmate-Cumin)\n                         Owner: Roy D Dobbins,Bryant,AL\n2nd  Skyway Boomer       (b,g,4 - Sportswriter-Buckle Bunni-Four Starzzz Shark)\n                         Owner: Copley Stables,Kenmore,ON-Jody Sanderson,Doha,QT-Dean R Larkin,Kanata,ON\n3rd  Lively Freddie      (ch,g,3 - Panspacificflight-Pan Voyage-No Pan Intended)\n                         Owner: ICR Racing,Pefferlaw,ON\n5\n1-Mckinney                  4.60   2.40   2.30      2591\n2-American Rock                    2.80   2.40      1156\n6-Lets Wait And See                       4.20       872\n\n$2 EXACTOR (1-2) paid 11.60, pool 3104\n$1 SUPERFECTA (1-2-6-4) paid 157.80, pool 4503\n$2 TRIACTOR (1-2-6) paid 50.50, pool 4025\n\n1 MILE, PACE, PURSE $11,000.\nHORSES & GELDINGS - PREFERRED 2\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Mckinney                    1    1/1H    1/1H    1/1     1/1      1/1Q       1:52.1  28.3 B Mcclure        1.30*  Corey Johnson\n2   American Rock               2    2/1H    3/2Q    3/2Q    3/2H     2/1Q       1:52.2  28.2 A Carroll        1.80   R Moreau\n6   Lets Wait And See           6    6/7H    2@/1H   2@/1    2/1      3/1T       1:52.3  28.4 N Steward       17.50   S Friend\n4   Thorn In Your Side(L)       4    3/3     4/3H    5/4     4/4      4/2Q       1:52.3  28.1 Tra Henry        3.55   C Auciello\n3   Buddha Blue Chip            3    4/4H    7/6     7/6     5/4H     5/2T       1:52.4  28   P Mackenzie      5.65   J Dupont\n7   Sports Lightning            7    7/9     5@/4    4@/3H   6/6      6/5T       1:53.2  29.1 S Young         25.90   M Brealey\n5   Haydens Little Man(L)       5    5/6     6@/5H   6@/5H   7/7H     7/7        1:53.3  29   J Ryan          11.40   J Ryan\nTime: 26.2, 56.3, 1:23.3, 1:52.1 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Mckinney            (b,g,6 - Santanna Blue Chip-Thepansofiwojima-Jennas Beach Boy)\n                         Lessee: G Arthur Slack,Rockwood,ON\n2nd  American Rock       (b,g,4 - Rocknroll Hanover-Mrs American Pie-Artsplace)\n                         Owner: Bradley J Grant,Milton-Charles Juravinski,Dundas,ON\n3rd  Lets Wait And See   (br,g,5 - Shadow Play-Remember The Magic-Camluck)\n                         Owner: Gordon E Hart,Odessa,ON\n6\n5-St Lads Lotto             3.50   2.20   2.30      1292\n7-Arrived Late                     9.20   5.20       536\n4-A Marcou Story                          2.50       304\n\n$2 EXACTOR (5-7) paid 25.80, pool 1647\n$1 SUPERFECTA (5-7-4-3) paid 353.00, pool 2155\n$2 TRIACTOR (5-7-4) paid 142.45, pool 2410\n\n1 MILE, PACE, PURSE $5,500.\nHORSES & GELDINGS - N/W $2500. LAST 3 OR $3250. LAST 5\n(W/O $5000. LAST 5 N/E)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   St Lads Lotto(L)            5    1/1H    1/1H    1/1H    1/4      1/2Q       1:52.4  29.2 J Ryan           0.75*  J Ryan\n7   Arrived Late(L)             7    7/9     7/9     7@/5T   6/6Q     2/2Q       1:53.1  28.3 B Mcclure       12.05   C Gilmour\n4   A Marcou Story              4    5/6     5/6     5@/4H   4/5      3/2H       1:53.1  29   R Jones          3.20   R Jones\n3   Crafty Master               3    4/4H    4/4H    3@/2Q   3/4H     4/7H       1:54.1  30.2 A Carroll        4.45   V Puddy\n1   Mac Raider                  1    2/1H    2/1H    2/1H    2/4      5/8Q       1:54.2  30.4 B Davis Jr       9.70   L Fuller\n6   Corsica Hall(L)             6    3/3     3/3     4/3Q    5/5H     6/8Q       1:54.2  30.2 Tra Henry       11.20   C Auciello\n2   My Friend Diaz              2    6/7H    6/7H    6/5     7X/6T    X7/12H     1:55.1  30.4 S Byron          9.00   D Lever\nTime: 26.4, 55.4, 1:23.2, 1:52.4 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  St Lads Lotto       (br,g,6 - Stonebridge Regal-Sweeps Ticket-Camluck)\n                         Owner: Jeffrey A Potok,Lake Worth,FL\n2nd  Arrived Late        (b,g,5 - Million Dollar Cam-Precious Relation-Precious Bunny)\n                         Owner: Brett B Wright,Hamilton-Connor Wright,Dundas,ON\n3rd  A Marcou Story      (b,g,4 - Rocknroll Hanover-Artchitecture-Artsplace)\n                         Owner: Dustin Jones Stables Inc,Waterdown-Noblock Racing Stable,Collingwood,ON\n
101	7	0717	\n7\n6-Lisvinnie                 6.40   2.90   2.30      2760\n5-Sword Ofthe Spirit               9.90   6.60      1264\n2-Mach On The Beach                       5.90       865\n\n$2 EXACTOR (6-5) paid 65.10, pool 3456\n$2 TRIACTOR (6-5-2) paid 154.65, pool 4975\n$1 WIN FOUR (4-1-5-6) paid 141.90, pool 4586\nHI5 6 5 2 3 4 POOL 1272 C/O 1081.42\n\n1 MILE, PACE, PURSE $7,500.\nHORSES & GELDINGS - PREFERRED 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Lisvinnie(L)                6    9/13Q   7@/9H   5@@/4H  4/2H     1/1H       1:53.2  28.3 D St Pierre      2.20   Corey Johnson\n5   Sword Ofthe Spirit          5    1/3     1/2H    1/Q     1/1Q     2/1H       1:53.3  29.3 R Jones         10.30   R Jones\n2   Mach On The Beach           2    2/3     2/2H    3/1H    3/2      3/1T       1:53.4  29.3 S Byron          6.60   D Fontaine\n3   Smack Talk                  3    7/10H   8/11    7@@/5H  6/4H     4/1T       1:53.4  28.4 B Mcclure        4.70   J Williamson\n4   Chosen Hombre               4    6/9     6/8     8/7     8/7Q     5/5        1:54.2  29   P Mackenzie     19.05   M Brethour\n8   Soaking Up The Sun          8    3/4H    3/4     2@/Q    2/1Q     6/5T       1:54.3  30.3 Tra Henry       11.90   R Moreau\n9   Calgary Seelster(L)         9    5/7H    5/7H    6@/5    5/4      7/6T       1:54.4  29.4 N Steward        2.15*  A Mccabe\n1   Canadian Edition(L)         1    4/6     4/6     4/4     7/6      8/6T       1:54.4  30   A Carroll        6.85   V Puddy\n7   One Warrawee                7    8/12    9/12H   9/8Q    9/8T     9/12T      1:56    30.2 A Byron         17.30   E Galinski\nTime: 26.2, 55.4, 1:24, 1:53.2 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Lisvinnie           (br,g,6 - Lis Mara-Vindecor-Western Hanover)\n                         Owner: Michael Goldberg,Toronto,ON\n2nd  Sword Ofthe Spirit  (b,g,5 - Artistic Fella-Im Not Dreamin-Albert Albert)\n                         Lessee: Dustin Jones Stables Inc,Waterdown,ON\n3rd  Mach On The Beach   (b,g,4 - Mach Three-Shannon Deja Vu-Jennas Beach Boy)\n                         Owner: Ecurie Gaetan Bono Inc,Montreal,QC\n8\n1-The Illuminator           7.50   3.70   2.20      1889\n5-Terror Hall                      3.10   2.10       588\n2-Spirit Shadow                           2.10       463\n\n$2 EXACTOR (1-5) paid 33.20, pool 1673\n$1 SUPERFECTA (1-5-2-4) paid 197.10, pool 2505\n$2 TRIACTOR (1-5-2) paid 31.60, pool 3073\n\n1 MILE, PACE, PURSE $8,000.\nHORSES & GELDINGS - N/W $25000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   The Illuminator             1    1/1H    2/1H    2/1H    2/T      1/T        1:54    28.3 B Mcclure        2.75   Ri Zeron\n5   Terror Hall                 5    5/8     5/10H   5@/5    4/4H     2/T        1:54.1  28   A Carroll        3.10   R Moreau\n2   Spirit Shadow               2    2/1H    1/1H    1/1H    1/T      3/2T       1:54.3  29.2 P Mackenzie      0.45*  J Dupont\n4   Lissilas                    4    4/6H    4/7H    4@/3H   3/4      4/3T       1:54.4  29   D St Pierre     71.00   Colin Johnson\n9   Cool Jack                   8    8/12H   8/15    8/8H    5/6      5/5        1:55    28.1 N Steward       36.75   J Copley\n6   Winning Drive               6    6/9H    6/12    6@/5H   6/6H     6/7T       1:55.3  29.2 T Moore         29.50   R Howie\n3   Whiskey Wisdom              3    3/3H    3/4H    3/3     7/7      7/8H       1:55.3  29.4 T Smith         33.40   J Walker\n8   Master Smile                7    7/11    7/13H   7/7     8/8H     8/14Q      1:56.4  30.1 B Davis Jr      29.15   J Mcginnis\n7   Barefoot Bluejeans          SCRATCHED - VET(SICK)                                                                 \nTime: 27.2, 56, 1:25.1, 1:54 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Barefoot Bluejeans-VET\n\n1st  The Illuminator     (b,g,3 - Big Jim-Cristinella Bella-A Stud Named Sue)\n                         Owner: Lomangino Standardbreds,Tinton Falls,NJ\n2nd  Terror Hall         (br,c,3 - Western Terror-Marnie Hall-Blissfull Hall)\n                         Owner: Daniel Plouffe,Bromont-Jean C Dessureault,Candiac,QC\n3rd  Spirit Shadow       (b,g,3 - Shadow Play-Caviart Cheyenne-Artsplace)\n                         Owner: Denis A Goyette,Laval,QC\n9\n2-Kona                      5.80   5.10   3.50      1632\n1-Deck The Halls                   3.80   3.70       474\n4-L H Fillybuster                         2.30       129\n\n$2 EXACTOR (2-1) paid 26.40, pool 1204\n$2 TRIACTOR (2-1-4) paid 23.20, pool 1667\n\n1 MILE, TROT, PURSE $4,600.\nCLAIMING $7000. (W-ALL)\nA.E. N/W $3500. IN 2016\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Kona(L)                     2    4/4H    5/4Q    4@/1H   3/1H     1/1Q       2:00    31.2 D St Pierre      1.90   Colin Johnson\n1   Deck The Halls              1    2/1H    3/1H    3/1H    4/1T     2/1Q       2:00.1  31.3 N Steward        4.60   P Belanger Jr\n4   L H Fillybuster             4    1/1H    1/1     1/NK    2/HD     3/3H       2:00.3  32.1 A Carroll        1.20*  W Budd\n5   Ken U Sing=(L)              5    5/6     2@/1    2@/NK   1/HD     4/5Q       2:01    32.3 D Bowins         2.55   D Bowins\n3   Protege Seelster(L)         3    3/3     4/3     5/8H    5/11H    5/23T      2:04.4  34.4 B Davis Jr      12.90   P Shepherd\nTime: 28.2, 58.1, 1:28.2, 2:00 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Kona                (br,g,9 - Dream Vacation-Our Maggie Rose-Veeba Rova)\n                         Owner: Colin Johnson,Repentigny,QC\n2nd  Deck The Halls      (b,g,7 - Angus Hall-Bourbon Belle-Muscles Yankee)\n                         Owner: John W Sinclair,Palmerston,ON\n3rd  L H Fillybuster     (b,m,8 - Kadabra-Domino-Wesgate Crown)\n                         Owner: James A Wilson,Melancthon,ON\n10\n5-Twomacsonemach            9.80   3.40   2.30      1620\n3-P L Jackson                      2.10   2.10       482\n4-Day Trade Hanover                       2.20       463\n\n$2 DAILY DOUBLE (2-5) paid 62.10, pool 742\n$2 EXACTOR (5-3) paid 20.50, pool 2126\n$2 TRIACTOR (5-3-4) paid 19.35, pool 4268\n$1 WIN FOUR (6-1-2-5) paid 376.40, pool 3557\nHI5 5 3 4 9 8 194.00 4253\n\n1 MILE, PACE, PURSE $7,200.\nHORSES & GELDINGS - N/W $12500. LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $5500.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Twomacsonemach(L)           4    4/5H    4@/3H   2@/1    2/1      1/HD       1:55.2  27.2 A Carroll        3.90   V Puddy\n3   P L Jackson                 2    1/1H    1/1H    1/1     1/1      2/HD       1:55.2  27.3 B Mcclure        0.35*  R Mcmillan\n4   Day Trade Hanover           3    2/1H    2/1H    3/1H    3/2H     3/2Q       1:55.4  27.4 R Jones          3.60   R Jones\n9   Relish                      7    7/10    7@/7Q   6@I/5   5/7      4/9H       1:57.1  28.2 P Mackenzie     31.40   R Mackenzie Jr\n8   Sippen Whisky               6    6/8H    5@/5H   4@I/3Q  4/6H     5/11H      1:57.3  29.1 Tra Henry       10.55   C Fuller\n7   Wawanosh Wave               5    5/7     6/6     7I/5T   6/9H     6/14H      1:58.1  29.1 T Smith         64.00   J Walker\n1   Lil Richie                  1    3/3     3/3     5X/3H   7/16     7/DIS                   A Byron         17.80   D Nixon\n2   Only Half Bad               SCRATCHED - VET(SICK)                                                                 \n6   Six Flags                   SCRATCHED - VET(SICK)                                                                 \nTime: 28.2, 59.2, 1:27.4, 1:55.2 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Only Half Bad-VET, Six Flags-VET\n\n1st  Twomacsonemach      (b,g,3 - Mach Three-Grace And Harv-Dexter Nukes)\n                         Owner: Wayne C Mac Rae,Fall River,NS-Howmac Farms Ltd,North Wiltshire,PE\n2nd  P L Jackson         (b,c,3 - Mach Three-Kg Katriona-Jennas Beach Boy)\n                         Owner: Prince Lee Acres,Uxbridge,ON\n3rd  Day Trade Hanover   (b,g,3 - Big Jim-Deer Valley Miss-Artsplace)\n                         Owner: Dustin Jones Stables Inc,Waterdown,ON-Hudson Standrdbrd Stb Inc,Hudson,QC\nTotal Purse:  $69,200\nTotal Handle: $103,911\n(Not Official CPMA Information)\n\n
102	7	0719	\n1\n6-Heza Workof Art           3.70   2.50   2.20      1572\n7-Wine Shark                       3.20   2.30       639\n2-Arnold Dick                             4.30       373\n\n$2 EXACTOR (6-7) paid 13.10, pool 1291\n$1 SUPERFECTA (6-7-2-3) paid 146.90, pool 2262\n$2 TRIACTOR (6-7-2) paid 32.70, pool 3347\n\n1 MILE, PACE, PURSE $5,200.\nHORSES & GELDINGS - CLAIMING $12000. - FOR N/W $30000. LIFETIME (W-ALL)\n(N/W OF A RACE IN 2016 ALLOWED $2500.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Heza Workof Art             5    5/5H    4@/3    2@/1    1/NS     1/NS       1:54.2  29.1 B Mcclure        0.85*  J Watt\n7   Wine Shark                  6    1/1     1/1     1/1     2/NS     2/NS       1:54.2  29.2 J Ryan           2.40   J Ryan\n2   Arnold Dick                 2    4/4     5/3H    5/7H    3/10     3/12       1:56.4  30.2 P Mackenzie      6.30   P Mackenzie\n3   Highpoint Chip              3    6/7     6/5     6@/8H   5/12     4/17H      1:57.4  31.1 L House         41.40   P Roberts\n1   Roan Bruiser(L)             1    3/2H    2@/1    4@/7    7/14     5/17T      1:58    31.3 Tra Henry        6.40   S Halkes\n8   Amillionbucks               7    7/8H    7/6H    7/9Q    6/12H    6/18T      1:58.1  31.2 S Byron         24.05   G Cicero\n5   Windsun Cheyenne(L)         4    2/1     3/1H    3/6H    4/11H    7/22H      1:58.4  32.3 N Steward        5.15   D Tackoor\n4   Jimmy Be Good               SCRATCHED - VET(SICK)                                                                 \n9   Hot Rock Star               SCRATCHED - VET(SICK)                                                                 \nTime: 27.3, 56, 1:25, 1:54.2 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Jimmy Be Good-VET, Hot Rock Star-VET\n\n1st  Heza Workof Art     (b,g,4 - Art Colony-Western Cat-Western Hanover)\n                         Owner: Jeffrey Williamson,Blyth,ON\n2nd  Wine Shark          (b,g,4 - Cams Card Shark-Princess Merlot-Western Hanover)\n                         Owner: Jeffrey A Potok,Lake Worth,FL\n3rd  Arnold Dick         (b,g,4 - Coastocoast Yankee-Armbro Awesome-Western Hanover)\n                         Owner: Kathy F Mackenzie,Puslinch,ON-Vance R Cameron,Summerside,PE\n2\n1-Classic Bolt              7.20   2.90   2.60      1383\n6-Silversmith                      2.60   2.50       370\n3-Screenwriter                            3.30       346\n\n$2 DAILY DOUBLE (6-1) paid 17.00, pool 984\n$2 EXACTOR (1-6) paid 30.10, pool 1202\n$1 SUPERFECTA (1-6-3-4) paid 259.45, pool 2049\n$2 TRIACTOR (1-6-3) paid 63.35, pool 2443\n#2 F1 PL 5 FOR INTERFERENCE WHILE ON A BREAK\n\n1 MILE, PACE, PURSE $5,000.\nHORSES & GELDINGS - CLAIMING $12000. - FOR N/W $16000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Classic Bolt                1    2/1H    2/1H    2/3H    2/3      2P1/2      1:57    28.4 J Ryan           2.60   C Gilmour\n6   Silversmith                 6    1/1H    1/1H    1/3H    1/3      3P2/2T     1:57.1  29.3 P Mackenzie      1.25*  A Macdonald\n3   Screenwriter                3    4/4H    3@/2    3@/4    3/3T     4P3/6Q     1:57.4  29.2 B Mcclure       10.80   C Fuller\n4   Machcellerator              4    5/6     5/5     6I/7H   6/8      5P4/9Q     1:58.2  29.2 S Young         11.70   T Stein\n2   Tea With Ms Mcgill          2    3/3     4/3H    4X/5H   4/5      1P5/2      TDIS         A Macdonald      1.75   A Macdonald\n7   Home James                  7    7/9     6@/5H   5@/7    5/7H     6/9H       1:58.2  29.2 Tra Henry       15.05   Tra Henry\n5   Hazamenaz                   5    6/7H    7/7     7@/8    7/12     7/22       2:01    31.4 R Holliday      36.10   C Fuller\nTime: 29.2, 59.2, 1:27.3, 1:56.3 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Classic Bolt        (b,h,4 - Badlands Hanover-Northern Jade-Northern Luck)\n                         Owner: B Michael Timpano,Phelpston,ON-Seaspray Stables Ltd,Nanaimo,BC\n2nd  Silversmith         (br,g,3 - Artistic Fella-Smooth Silver-Western Hanover)\n                         Owner: Brent A Hopper,Lexington,KY\n3rd  Screenwriter        (b,g,4 - Sportswriter-C Gs Foxy Lady-Cambest)\n                         Owner: James A Wilson,Melancthon,ON\n3\n5-Go Get Bruce              5.30   2.70   2.40      1422\n2-Rainbow View                     4.40   3.10       632\n4-Tyrone Zoey                             2.10       338\n\n$2 EXACTOR (5-2) paid 20.90, pool 1073\n$2 TRIACTOR (5-2-4) paid 23.55, pool 2024\n\n1 MILE, TROT, PURSE $5,400.\nCLAIMING $12000. - FOR N/W $30000. (F & M $50000.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Go Get Bruce                5    6/6Q    4@/5T   3@/3    3/2Q     1/2        1:58.4  30   B Forward        1.65   S Charlton\n2   Rainbow View                2    2/H     1@/H    1/1Q    1/1      2/2        1:59.1  31   A Haughan        5.20   M Crone\n4   Tyrone Zoey                 4    5/4T    2@/H    2@/1Q   2/1      3/5Q       1:59.4  31.2 B Mcclure        1.50*  J Watt\n3   Burst Hanover               3    4/3Q    6/7H    5@/8Q   5/8H     4/9T       2:00.4  31   L House          7.40   P Roberts\n1   Murs Son=                   1    3/1T    5/6T    6/8T    6/9      5/10       2:00.4  30.4 A Carroll        9.50   C Carss\n6   Fashion Star=(L)            6    1@/H    3/4H    4/6Q    4/6H     6/10H      2:00.4  31.2 A Macdonald      3.70   A Macdonald\nTime: 29.1, 58.2, 1:28.1, 1:58.4 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Go Get Bruce        (br,g,4 - Taurus Dream-Yankeedoodlecandy-Muscles Yankee)\n                         Owner: Larocque Racing Stb Inc,Thornhill,ON\n2nd  Rainbow View        (b,m,4 - Angus Hall-Armbro Rainbow-Sierra Kosmos)\n                         Owner: Hutt Racing Stable,Paoli,PA\n3rd  Tyrone Zoey         (b,m,4 - Kadabra-Showee-King Conch)\n                         Owner: Alyshia Williamson,Blyth,ON\n4\n2-Scotty Mach N            12.10   4.80   3.60      2585\n4-Shootin To Kill                  3.70   2.70      1268\n6-Attaboyaaron                            4.20       756\n\n$2 EXACTOR (2-4) paid 47.60, pool 4430\n$1 SUPERFECTA (2-4-6-1) paid 595.40, pool 3762\n$2 TRIACTOR (2-4-6) paid 131.40, pool 5092\n\n1 MILE, PACE, PURSE $6,000.\nHORSES & GELDINGS - CLAIMING $12000. - FOR N/W $50000. LIFETIME (W-ALL)\nOR $3500. LAST 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Scotty Mach N               2    2/1     1/1H    1/1H    1/1      1/H        1:55.2  29.2 P Mackenzie      5.05   G Way\n4   Shootin To Kill             4    3/2H    3@/2    2@/1H   2/1      2/H        1:55.2  29.1 B Mcclure        0.95*  J Copley\n6   Attaboyaaron                6    4/4     5@/4    4@/3H   3/1H     3/H        1:55.2  28.4 N Steward        9.50   J Watt\n1   Acefortyfourtalon           1    5/5H    4/3H    5/4     4/2H     4/1H       1:55.3  28.4 J Ryan           3.10   G Durbano\n9   Jolted                      8    8/10    8/7H    8/7H    7/5H     5/1T       1:55.4  28.2 Tra Henry       10.20   I Darveau\n8   Twang Twang                 7    7/8H    7@/6    7@/6    8/6H     6/2Q       1:55.4  28.3 K Sheppard      17.35   K Sheppard\n3   Beach Boy                   3    6/7     6/5H    6/5H    6/4      7/5H       1:56.2  29.2 R Holliday       7.45   S Pryjma\n5   Vijayscam                   5    1/1     2/1H    3/2     5/3Q     8/6H       1:56.3  30.1 A Macdonald     15.40   D Graham\n7   Regally Magnified           SCRATCHED - VET(SICK)                                                                 \nTime: 27.3, 57.2, 1:26, 1:55.2 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Regally Magnified-VET\n\n1st  Scotty Mach N       (b,g,11 - Mach Three-Belladonna-Bo Scots Blue Chip)\n                         Owner: George L Way,Manotick,ON\n2nd  Shootin To Kill     (br,g,3 - Sportsmaster-Fd Together Again-Beach Walker)\n                         Owner: Tony F Basile,Toronto,ON\n3rd  Attaboyaaron        (b,g,6 - Modern Art-Brenda Lynne-Fortune Teller)\n                         Owner: Rebecca Williamson,Blyth,ON\n5\n1-Billiondolarsecret       39.70   9.10   5.60          \n2-Bettor Feather                   2.50   2.10      1449\n8-Braonach                                4.80      1256\n\n$2 EXACTOR (1-2) paid 83.80, pool 4260\n$1 SUPERFECTA (1-2-8-7) paid 1790.75, pool 4836\n$2 TRIACTOR (1-2-8) paid 211.65, pool 4549\n\n1 MILE, PACE, PURSE $6,000.\nFILLIES & MARES - N/W $3000. LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $2000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Billiondolarsecret          1    2/1H    2/1H    3/2     2/1H     1/NS       1:57.2  28.3 Tra Henry       18.85   S Doyle\n2   Bettor Feather              2    1/1H    1/1H    1/1H    1/1H     2/NS       1:57.2  29   A Carroll        0.60*  R Moreau\n8   Braonach                    6    6/9     6/7H    5@/5Q   3/4      3/3Q       1:58    28.3 A Macdonald      3.95   A Macdonald\n7   Skittle Hanover             5    5/7H    5/6     6/6     6/7H     4/4T       1:58.2  28.4 A Haughan       35.55   J Williamson\n3   A Royal Hanover             3    3/3     3/3     4/3H    5/6      5/8T       1:59.1  30.1 B Davis Jr      50.70   B Macintosh\n9   The Camel Express           7    7/10H   7/9     7/10    7/11H    6/10H      1:59.2  29   R Holliday       5.95   L Joyce\n5   Big Chute                   4    4/4H    4/4H    2@/1H   4/4H     7/12H      1:59.4  31.1 P Mackenzie      2.60   M Brethour\n4   Crazy Alice                 SCRATCHED - VET(SICK)                                                                 \n6   Im Stunning                 SCRATCHED - VET(SICK)                                                                 \nTime: 29, 59.4, 1:28.2, 1:57.2 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Crazy Alice-VET, Im Stunning-VET\n\n1st  Billiondolarsecret  (b,m,4 - Secrets Nephew-Billiondollarbeach-Million Dollar Cam)\n                         Owner: Shannon P Macarthur,Burlington-Stephen L Doyle,Dundas,ON\n2nd  Bettor Feather      (b,f,3 - Bettors Delight-Puccini Blue Chip-Magical Mike)\n                         Owner: Richard Berthiaume,Pointe-Aux-Trembles,QC\n3rd  Braonach            (b,f,2 - Camluck-Clonlara T-Falcons Future)\n                         Owner: Braonach Stable,Guelph,ON\n6\n4-Severus Hanover          23.20   4.20   3.00      1768\n3-Covert Operative                 2.10   2.20       808\n6-Utopia                           3.20   2.60       547\n\n$2 EXACTOR (4-3) paid 84.50, pool 1724\n$1 SUPERFECTA (4-3-6-5) paid 1126.55, pool 2150\n$2 TRIACTOR (4-3-6) paid 166.40, pool 2501\nEX 4 6 79.60 TR 4 6 3 395.35 SF 4 6 3 5 1225.80\n\n1 MILE, TROT, PURSE $7,500.\nPREFERRED 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Severus Hanover=            4    2/1H    3/3     2@/1H   2/Q      1/1T       1:56.4  29.3 B Mcclure       10.60   D Frey\n3   Covert Operative=(L)        3    3/3     1/1H    1/1H    1/Q      2DH/1T     1:57.1  30.1 N Steward        0.95*  P Henriksen\n6   Utopia=                     6    6/8     6/7H    4@/3    4/2      2DH/1T     1:57.1  29.3 J Ryan           6.10   J Ryan\n5   Chuckalo Caden              5    1/1H    2/1H    3/1H    3/1H     4/2T       1:57.2  30.1 S Young         10.90   C Thompson\n2   Tortola Sunrise=            2    5/6H    5/6     7/5H    7/5      5/3H       1:57.2  29.2 A Macdonald      1.55   A Macdonald\n1   Class Me Nice=(L)           1    4/4H    4/4H    5/3H    5/3H     6/3H       1:57.2  29.4 R Holliday      15.10   B Weinholdt Harris\n7   Amoureuse Hanover           7    7/9H    7/9     6@/5    6/4      7/5        1:57.4  29.4 A Carroll       15.50   B Peterson\n8   Early Hit                   SCRATCHED - VET(SICK)                                                                 \nTime: 28.3, 57.3, 1:27, 1:56.4 (Temperature: 20, Condition: FT, Variant: 0)\nJudges List: Early Hit-VET\n\n1st  Severus Hanover     (b,g,5 - Explosive Matter-Sorbet Hanover-Angus Hall)\n                         Owner: 373818 Ontario Ltd,Maple,ON\n2nd  Covert Operative    (br,g,4 - Deweycheatumnhowe-Serenas Genie-Angus Hall)\n                         Owner: Andrea Lea Racingstables Inc,Lakefield Gore,QC-Asa Farm,Norwood,ON\n2nd  Utopia              (b,g,5 - Mutineer-Brontease-Balanced Image)\n                         Owner: Jeffrey A Potok,Lake Worth,FL\n
103	7	0719	\n7\n9-Dixie Lullaby            15.50   9.00   3.40      2922\n5-Rockin Sockem                   12.50   4.40      1129\n4-Deucette                                2.50       707\n\n$2 EXACTOR (9-5) paid 412.50, pool 2508\n$2 TRIACTOR (9-5-4) paid 344.30, pool 4029\n$1 WIN FOUR (2-2-4-9) paid 860.70, pool 4121\nHI5 9 5 4 2 8 - 1806 C/O 1535.48 W4 PAYS ON 3 OF 4\n\n1 MILE, PACE, PURSE $8,000.\nFILLIES & MARES - N/W $25000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n9   Dixie Lullaby               9    9/12    9@/11   8@/6H   5/4Q     1/1        1:55.1  29   B Forward        6.75   R Fellows\n5   Rockin Sockem               5    2/1H    2/1H    2/1H    2/1      2/1        1:55.2  30.1 P Mackenzie     13.95   T Stokes\n4   Deucette                    4    6/7H    6@/6H   6@/5    3/2      3/1T       1:55.3  29.3 B Mcclure        1.20*  T Jacobson\n2   Jens Credit                 2    4/4H    4@/4H   4@/3    4/2H     4/3        1:55.4  30.1 A Carroll        4.85   V Puddy\n8   P L Jasmine                 8    1/1H    1/1H    1/1H    1/1      5/4        1:56    31   R Holliday      11.90   R Mcmillan\n6   Radar Trap                  6    7/9     7/8H    7/5H    8/7H     6/4H       1:56    30   J Ryan          29.25   C Barss\n3   Casimir Overthetop          3    5/6     5/5     5/3H    6/4H     7/4T       1:56.1  30.3 G Large         12.20   G Large\n7   Ima Holy Terror             7    8/10H   8/9     9/14    9/12     8/12T      1:57.4  30   C Steacy        46.35   R Hughes\n1   Imacutiepatootie            1    3/3     3/3     3@/2H   7/6      9/13       1:57.4  32.2 M Whelan         2.25   A Colville\nTime: 28, 56.1, 1:25, 1:55.1 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Dixie Lullaby       (b,f,3 - If I Can Dream-Dixie Dew Bluechip-Art Major)\n                         Owner: Robert Kyle Fellows,Rockwood,ON-Carl Stafford,Conception Bay South,NL\n2nd  Rockin Sockem       (b,m,4 - Rockin Image-Luv R Diamonds-Jennas Beach Boy)\n                         Owner: Steve Adams,Toronto,ON\n3rd  Deucette            (b,f,3 - Armbro Deuce-Odds On Jenna-Jennas Beach Boy)\n                         Owner: Seaspray Stables Ltd,Nanaimo,BC\n8\n7-Lady Crazy               11.00   7.50   2.50      1483\n5-Jiminey Three                    3.70   2.80       815\n2-Bad At Redhot                           2.90       393\n\n$2 EXACTOR (7-5) paid 67.10, pool 1664\n$1 SUPERFECTA (7-5-2-4) paid 158.20, pool 1534\n$2 TRIACTOR (7-5-2) paid 102.70, pool 2251\nSF 7 5 2 8 438.40\n\n1 MILE, PACE, PURSE $7,200.\nFILLIES & MARES - N/W $13000. LIFETIME (W-ALL)\nA.E. N/W OF A RACE IN 2015/16.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Lady Crazy                  7    2@/1    2@/HD   2@/H    2/HD     1/1        1:56.1  30.1 Tra Henry        4.50   C Bradshaw\n5   Jiminey Three               5    1/1     1/HD    1/H     1/HD     2/1        1:56.2  30.2 A Carroll        2.40*  R Moreau\n2   Bad At Redhot               2    5/4H    5@/5H   4@/2    4/2      3/1Q       1:56.2  30   R Holliday       4.45   W Dunn\n4   Frankies First Luv          4    6/6     6/6     5@@/3H  3/1H     4DH/1H     1:56.2  29.4 B Mcclure        5.45   J Marsden\n8   Northern Prima              8    8/9     8/8H    8/6     7/5H     4DH/1H     1:56.2  29.1 P Mackenzie     14.15   M Brethour\n3   Flower Bomb                 3    4/3     4/4     6/4     8/6H     6/2H       1:56.3  29.4 B Forward        2.70   B Macintosh\n6   Warrawee Rocket             6    7/7H    7/7     7@/4H   6/4      7/2T       1:56.4  30   B Davis Jr       9.95   T Stein\n1   Inexplicable Ruby           1    3/1H    3/3H    3/1H    5/3H     8/4        1:57    30.4 N Steward        9.70   J Copley\nTime: 27.4, 56.2, 1:26, 1:56.1 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Lady Crazy          (b,f,3 - Santanna Blue Chip-Crazy She Calls Me-Mach Three)\n                         Owner: Princeton Farms Inc,Scotland,ON\n2nd  Jiminey Three       (b,f,3 - Mach Three-Disneypan-The Panderosa)\n                         Owner: Gaston Bibeau-9099 3833 Quebec Inc,Sorel-Tracy,QC\n3rd  Bad At Redhot       (b,f,3 - Badlands Hanover-Onenight At Redhot-Camluck)\n                         Owner: Stephen Upson,Georgetown,ON\n9\n1-Par Intended              8.00   3.90   3.00      1475\n2-Markathy                         5.60   2.50       684\n3-E L Spartacus                           4.00       368\n\n$2 EXACTOR (1-2) paid 59.80, pool 1500\n$1 SUPERFECTA (1-2-3-4) paid 98.95, pool 1373\n$2 TRIACTOR (1-2-3) paid 96.70, pool 2417\n#6 CLAIMED\n\n1 MILE, PACE, PURSE $7,000.\nHORSES & GELDINGS - CLAIMING $12000. (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Par Intended                1    1/1H    1/1H    1/1     1/1H     1/H        1:56    28.4 A Carroll        3.00   V Puddy\n2   Markathy                    2    2/1H    2/1H    3/1H    2/1H     2/H        1:56    28.3 N Steward        6.00   P Belanger Jr\n3   E L Spartacus               3    3/3     4/3H    5/3H    4/3      3/1H       1:56.1  28.2 B Mcclure        7.40   J Watt\n4   Panedictine(L)              4    4/4H    3@/2    2@/1    3/1H     4/2Q       1:56.2  29   B Davis Jr       6.80   T Stein\n6   Cruizin K C                 6    6/7H    6@/5H   6@/4H   7/7      5/5Q       1:57    29   P Mackenzie      1.45*  P Coleman\n5   Connery Blue Chip           5    5/6     5@/4    4@/3    5/4H     6/7Q       1:57.2  29.3 C Steacy        12.55   P Shepherd\n7   Amble Over Hanover(L)       7    7/9     7@/6H   7@@/5   6/6      7/7T       1:57.3  29.2 Tra Henry        5.25   L Fuller\n8   Gunpowder                   8    8/10H   8/7H    8/6Q    8/8H     8/7T       1:57.3  29.1 B Forward       17.95   M Rain\nTime: 28.3, 58.3, 1:27.1, 1:56 (Temperature: 20, Condition: FT, Variant: 0)\nCRUIZIN K C claimed for $12,000 by Michael J Gillis.\n\n1st  Par Intended        (b,g,5 - No Pan Intended-Parapanalia-Noble Ability)\n                         Owner: Limco Inc,Chateauguay,QC\n2nd  Markathy            (b,g,5 - Mister Big-Sunbather-Dragon Again)\n                         Owner: Michel Grenier,Gatineau,QC\n3rd  E L Spartacus       (br,g,6 - I Am A Fool-Wild Today-Western Hanover)\n                         Owner: Jeffrey Williamson,Blyth,ON\n10\n1-Platoon Seelster          3.80   2.50   2.40      3179\n7-Big Rich                         4.90   4.10       937\n9-Delcrest Massy                         15.10       656\n\n$2 DAILY DOUBLE (1-1) paid 16.30, pool 547\n$2 EXACTOR (1-7) paid 72.80, pool 2469\n$2 TRIACTOR (1-7-9) paid 228.45, pool 3576\n$1 WIN FOUR (9-7-1-1) paid 853.80, pool 2494\nHI5 1 7 9 8 3 15727.45 2967\n\n1 MILE, TROT, PURSE $11,000.\nPREFERRED 2\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Platoon Seelster            1    3/3     1/1H    1/1     1/1H     1/1        1:56.2  28.4 R Holliday       0.90*  D Holliday\n7   Big Rich=(L)                7    1/1H    2/1H    3/1H    3/2      2/1        1:56.3  28.4 B Davis Jr       5.55   R Moreau\n9   Delcrest Massy=(L)          9    5/6     5/4     4@/3    2/1H     3/1H       1:56.3  28.2 A Carroll       29.35   V Puddy\n8   In Secret=(L)               8    9/12    9/10    9/7Q    7/6      4/1H       1:56.3  27.3 B Mcclure       11.20   P Henriksen\n3   Doubledown Gass             3    2/1H    3/3     5/3H    5/4      5/1T       1:56.4  28.3 R Gassien        4.40   R Gassien\n4   Call Me Richard             4    7/9     6/5H    6@/4H   6/5H     6/3        1:57    28.3 P Mackenzie      4.65   C Bradshaw\n2   Domedomedome(L)             2    6/7H    7/7     7/6     9/7H     7/3T       1:57.1  28.2 Jo Kovacs       14.05   J Moiseyev\n5   R Choochoo Charlie=(L)      5    8/10H   8@/8H   8@/6H   8/7      8/6H       1:57.3  28.4 Tra Henry       15.20   C Auciello\n6   Warrawee Proton             6    4/4H    4/3H    2@/1    4X/3T    9/22       2:00.4  33   B Forward       17.90   T Langille\nTime: 28.1, 57.1, 1:27.3, 1:56.2 (Temperature: 20, Condition: FT, Variant: 0)\n\n1st  Platoon Seelster    (b,g,4 - Federal Flex-Personal Hanover-Yankee Glide)\n                         Owner: Caroline Holliday,Mount Forest-Dennis C Hannath,Harriston,ON\n2nd  Big Rich            (b,g,4 - Donato Hanover-Kidman Hall-Like A Prayer)\n                         Owner: 9099 3833 Quebec Inc,Sorel-Tracy,QC-Frank Spagnolo,Ottawa,ON\n3rd  Delcrest Massy      (br,g,4 - Muscle Mass-Armbro Balandra-Malabar Man)\n                         Owner: Keith G Cassell,Smiths Falls,ON\nTotal Purse:  $68,300\nTotal Handle: $120,985\n(Not Official CPMA Information)\n\n
106	7	0723	\n1\n\n1 MILE, TROT.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Ulysses Bi                  3    1/6Q    1/6H    1/15    1/31     1/37       1:59.3  31.2 S Byron              NB G Lance\n1   Crystal Gumdrop=        -1  1IX  3/38    3/38    3/36    3/31     2/37       2:07    31.3 B Mcclure            NB J Gillis\n5   Media Eclipse               4    2/6Q    2/6H    2/15    2/31     3/DIS                   R Ertel              NB R Ertel\n2   Austin Hall                 2X   4/DIS   4/DIS   4/DIS   4/DIS    4/DIS                   K Jones              NB K Jones\nTime: 29, 58.1, 1:28.1, 1:59.3 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Media Eclipse-PERFORMANCE, Austin Hall-BREAKS\n\n1st  Ulysses Bi          (br,g,3 - Manofmanymissions-Merida Bi-Pine Chip)\n                         Owner: GL Racing Inc,Port Perry,ON\n2nd  Crystal Gumdrop     (b,f,2 - Angus Hall-Crystas Dream-S Js Photo)\n                         Owner: Jeffrey R Gillis,Everett-Mac T Nichol,Burlington,ON-Gerald T Stay,Buffalo,NY\n3rd  Media Eclipse       (b,g,5 - Angus Hall-Mon Amour Hall-Striking Sahbra)\n                         Owner: Cory J Guthrie-Randy P Ertel,Coldwater,ON\n2\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Certain Smiley              4    1/2     1/2     1/1H    1/1T     1/HD       2:00.1  30.2 B Mcclure            NB J Stewart\n1   Machet Time                 1    2/2     2/2     2/1H    2/1T     2/HD       2:00.1  30.1 A Byron              NB D Matson\n2   Jibb                        2    3/3T    3/8H    4/9T    3/14     3/19T      2:04.1  32.2 L Larochelle         NB L Larochelle\n4   Acefortyfourashley          3    4/5Q    4@/8H   3@/9T   4/14T    4/25Q      2:05.1  33.2 T Jacobson           NB G Durbano\nTime: 29.2, 59, 1:29.4, 2:00.1 (Temperature: 25, Condition: FT, Variant: 0)\n\n1st  Certain Smiley      (b,m,6 - Smile As You Go-Certain Celebrity-Apaches Fame)\n                         Owner: Gregory R Mason,Mulmur,ON\n2nd  Machet Time         (b,f,3 - Mach Three-Rocket Time-Pacific Rocket)\n                         Owner: Fred D Brayford,Alliston,ON\n3rd  Jibb                (b,h,4 - Stonebridge Regal-Congenial Diplomat-Albert Albert)\n                         Owner: Express Way Stables,Oro Station,ON\n3\n\n1 MILE, TROT.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Warrawee Quince=            1    4/5     3/5T    3/5     2/2H     1/2        2:02.2  31   S Byron              NB C Fuller\n5   High Society=               5    2@/H    1/3H    1/3H    1/2H     2/2        2:02.4  32.2 R Hughes             NB R Hughes\n3   E L Ima Diesel              3    1/H     2/3H    2/3H    3/3      3/4H       2:03.1  32.1 P Rouleau            NB A Hickey\n4   Zorgwijk Parkhill           4X   3/3H    5/21    5/24    5/26     4/30       2:08.2  33.1 A Byron              NB R Dincognito\n2   Poppis Boys                 2X   5/7Q    4/10    X4/19   4/23     5/32       2:08.4  34.3 R Ertel              NB R Ertel\nTime: 30.4, 59.3, 1:30.2, 2:02.2 (Temperature: 25, Condition: FT, Variant: 0)\nJudges List: Zorgwijk Parkhill-BREAKS, Poppis Boys-BREAKS\n\n1st  Warrawee Quince     (b,m,4 - Kadabra-Cheese Danish-Tagliabue)\n                         Owner: Wilbert R Weatherall,Flesherton,ON\n2nd  High Society        (b,f,3 - Muscle Hill-Machita-Garland Lobell)\n                         Owner: Robert B Burgess,Campbellville-Gregory B Peck,Milton,ON-Christy Markos,Newtown,PA-Rodney M Hughes,Dunsford,ON\n3rd  E L Ima Diesel      (b,g,4 - Muscle Mass-E L Ima Hemi-Duke Of York)\n                         Owner: Ed Lewis,Angus,ON\n
107	9	0718	\n1\n1-Big Yellow                7.80   4.00   2.80      6858\n2-Upgrade Valley                   5.60   2.90      2169\n5-Emperor                                 2.40      1558\n\n$2 EXACTOR (1-2) paid 41.70, pool 6663\n$1 SUPERFECTA (1-2-5-8) paid 491.90, pool 6134\n$2 TRIACTOR (1-2-5) paid 96.10, pool 7890\n$.20SF 98.38\n\n1 MILE, PACE, PURSE $7,200.\nHORSES & GELDINGS - N/W $13000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Big Yellow(L)               1    2/2     2/5     1/1     1/2      1/1H       1:55.2  30.1 S Young          2.90   B Wallace\n2   Upgrade Valley              2    4/4     4@/8    2/1     2/2      2/1H       1:55.3  30.1 P Mackenzie      5.55   P Smith\n5   Emperor                     5    8/12    7/12    4@/5    3/6      3/5H       1:56.2  30.1 A Carroll        1.70*  R Mcintosh\n8   The Avenger                 8    3@/3    3/7     3/4     4/8      4/10       1:57.2  31.2 B Davis Jr      36.55   W Robinson\n6   Stonebridge Marvel          6    9/14    8/14    7/8     6/11     5/12T      1:58    31.1 N Steward       16.80   J Belliveau\n9   Zetlan Rocket               9    5/6     5/9H    5/6     5/10     6/16H      1:58.3  32.1 T Smith         86.05   J Walker\n3   Wild Chance                 3    6/8     6@/10   8/10    7/15     7/21       1:59.3  32.2 B Mcclure        4.65   W Whebby\n7   Derby Dale                  7    1/2     1/5     6/7     8/17     8/30       2:01.2  34.4 B Forward        7.40   V Puddy\n4   Rockstar Drums              4    7X/10   9/17    9/18    9/25     9/34       2:02.1  33.2 L Ouellette     24.35   J Morrison\nTime: 27, 55.3, 1:25.1, 1:55.2 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Big Yellow          (br,g,3 - Big Jim-Up N Coming-Artsplace)\n                         Owner: Wallacestandardbreds Inc,Puslinch,ON-James A Geis,Chicago,IL-Jeffery E Ruch-Madigan Ruch,Innisfil,ON\n2nd  Upgrade Valley      (b,c,3 - Badlands Hanover-Fox Valley Hooker-Sportsmaster)\n                         Owner: Paul D Smith,Woodstock,ON\n3rd  Emperor             (b,g,3 - Ponder-Northern Empress-Camluck)\n                         Owner: Robert McIntosh Stables Inc,Windsor-Al McIntosh Holdings Inc,Leamington,ON-Gordon C Wright,Charlotte,MI\n2\n1-Trishas Wish             21.00   9.60   4.30      3337\n5-Ginger                           8.70   5.40      1367\n3-Blazinhart Hanover                     12.10      1062\n\n$2 DAILY DOUBLE (1-1) paid 152.80, pool 2235\n$2 EXACTOR (1-5) paid 209.30, pool 4585\n$1 SUPERFECTA (1-5-3-2) paid 3777.45, pool 4991\n$2 TRIACTOR (1-5-3) paid 1200.80, pool 6434\n$.20SF 755.49\n\n1 MILE, PACE, PURSE $5,200.\nFILLIES & MARES - CLAIMING $12000. - FOR N/W $30000. LIFETIME (W-ALL)\n(N/W OF A RACE IN 2016 ALLOWED $5000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Trishas Wish                1    2/2     2/1     3/2     3/1      1/H        1:58.4  30.3 R Battin         9.50   R Battin\n5   Ginger                      5    1/2     1/1     1/H     1/H      2/H        1:58.4  31   B Forward        7.45   L Johnson\n3   Blazinhart Hanover          3    6/10    6/6H    6/5     5/2H     3/2        1:59.1  30.2 T Moore         24.05   J Wright\n2   Lady Santana                2    5/7     5@/3H   4@/2H   4/1H     4/2Q       1:59.1  31   B Davis Jr       2.70   J Pereira\n4   Mach Of The Town            4    3/4     4/3     5@/3H   6/3      5/4Q       1:59.3  31.1 N Steward        1.60*  G Robinson\n8   Shanghai Nights             8    9/16    9/11    8/6H    7/3H     6/5T       2:00    31   P Mackenzie     12.15   L Mansfield\n9   Hussys Sport                9    4/5H    3@/1H   2@/H    2/H      7/6Q       2:00    32.1 L House          9.90   S Mcniven\n7   On The Rise                 7    8/14    8@/9    9/7H    9/5H     8/7T       2:00.2  31.1 R Holliday      76.15   W Durbridge\n6   Jinglewriter(L)             6    7/12    7@/7    7@/5H   8/4H     9/12       2:01.1  32.2 A Carroll        7.35   B Treen\nTime: 27.2, 58.2, 1:27.4, 1:58.4 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Trishas Wish        (b,m,6 - E Dees Cam-Ashlees Wish-Magical Mike)\n                         Owner: Carter & Caleb Wright,Monkton,ON\n2nd  Ginger              (ch,m,4 - Badlands Hanover-Hug Me-The Panderosa)\n                         Owner: Larry A Johnson,London,ON\n3rd  Blazinhart Hanover  (b,m,9 - Art Major-Bandolera Hanover-Western Hanover)\n                         Owner: Richard A Wright,Port Perry,ON\n3\n5-Unce Hanover              7.90   3.60   2.90      2532\n4-Hands Up For Luck                2.50   2.10       957\n3-Cam Engine                              4.80      1088\n\n$2 EXACTOR (5-4) paid 19.90, pool 3790\n$1 SUPERFECTA (5-4-3-7) paid 234.25, pool 5165\n$2 TRIACTOR (5-4-3) paid 99.50, pool 5437\n$.20SF 46.85\n\n1 MILE, PACE, PURSE $6,000.\nHORSES & GELDINGS - N/W $3000. LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $2000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Unce Hanover                4    4/4H    3@/2    2@/1    2/1      1/NS       2:02.1  30   A Carroll        2.95   C Coleman\n4   Hands Up For Luck           3    2/1     1/1     1/1     1/1      2/NS       2:02.1  30.1 B Davis Jr       0.65*  A Macdonald\n3   Cam Engine                  2    6/7H    5@/4    3@@/2   3/1H     3/1        2:02.2  30   P Mackenzie     15.70   M Rivest\n7   Chalky                      6    1/1     2/1     4/3H    4/2H     4/1Q       2:02.2  29.4 Mi Horner       12.05   Ma Horner\n8   Flying Solo                 7    7/9     7@/6    5@/4H   6/4H     5/3T       2:03    30.1 Tra Henry       22.10   V Cochrane\n9   All Access                  9    5/6     6/5     7@/6H   7/5H     6/4T       2:03.1  30   N Boyd          22.90   J Dean\n1   Best Of Luck Bilbo          1    3/3     4/3     6/5H    5/4      7/5        2:03.1  30.1 S Hudon         22.00   K Gangell\n6   Little Johnny               5    8/10    8/7H    8/8H    8/8H     8/7H       2:03.3  30   B Forward        9.15   N Liadis\n2   About A Boy                 SCRATCHED - VET(SICK)                                                                 \nTime: 29.1, 1:01.2, 1:32, 2:02.1 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: About A Boy-VET\n\n1st  Unce Hanover        (b,c,2 - Bettors Delight-Up Front Rose-Western Hanover)\n                         Owner: West Wins Stable,Cambridge-Steve W Calhoun,Chatham-Mac T Nichol,Burlington,ON\n2nd  Hands Up For Luck   (b,c,2 - Camluck-Michelles Prayer-Red River Hanover)\n                         Owner: Gary P Volpe,St Thomas,ON-Randy B Lee,Clermont,FL-Dr Robert V Hutchison,North Ridgeville,OH-Shawn R Brisebois,Burlington,ON\n3rd  Cam Engine          (b,g,4 - Camluck-Loving Place-Artsplace)\n                         Owner: Liam J Wallace,Troy,ON\n4\n1-Gia Diamond               8.40   3.90   2.90      3960\n6-Squeeze This                     2.80   3.20      1304\n9-Shes Dignified                          7.10       912\n\n$2 EXACTOR (1-6) paid 24.10, pool 8795\n$1 SUPERFECTA (1-6-9-3) paid 547.20, pool 4889\n$2 TRIACTOR (1-6-9) paid 152.70, pool 6113\n$.20SF 109.44\n\n1 MILE, PACE, PURSE $6,000.\nFILLIES & MARES - CLAIMING $12000. - FOR N/W $50000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Gia Diamond(L)              1    1/1H    1/1     1/1H    1/3      1/7T       1:57.1  29   J Ryan           3.20   J Ryan\n6   Squeeze This                6    5/5     6@/5    5@@/4   4/4H     2/7T       1:58.4  29.4 Tra Henry        0.85*  D Lindsey\n9   Shes Dignified              9    2/1H    2/1     2/1H    2/3      3/8        1:58.4  30.2 P Mackenzie     22.55   S Gillard\n3   All The Ladies              3    4/4     5@/3H   3@@/2H  3/3H     4/9H       1:59    30.2 A Haughan       38.00   M Crone\n2   Sportsonthebeach            2    3/3     3@/2    6@/5    6/7      5/11H      1:59.2  30.1 A Carroll       10.00   G Mcdonnell\n4   Casimir Lucky Lady          4    6/6     4/3     4/3H    5/6H     6/15H      2:00.1  31.2 B Mcclure       17.70   B Kempton\n7   Blushing Promise            7    8/9H    8/8H    8/6H    8/9      7/15T      2:00.2  31   C Brown         40.25   G Laurignano\n8   Mach Shark                  8    9/11    9/11    9/7H    9/10H    8/16       2:00.2  30.4 G Rooney        41.55   V Mcmurren\n5   Mighty Mouse                5    7/8     7@/7    7@@/5H  7/7H     9/16H      2:00.2  31.1 N Steward        4.50   J Watt\nTime: 28.4, 59, 1:28.1, 1:57.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Gia Diamond         (b,m,4 - American Ideal-Here Comes Gia-Sealed N Delivered)\n                         Owner: Jeffrey A Potok,Lake Worth,FL\n2nd  Squeeze This        (b,m,4 - Allamerican Native-Royal Lady Les-Royal Mattjesty)\n                         Owner: Garth S Bechtel,Caledon East,ON\n3rd  Shes Dignified      (br,m,4 - Your Nemesis-Sharonas Dignity-Cams Dignity)\n                         Owner: Stephen M & Marilyn Gillard,Tavistock,ON\n5\n9-Littlebitaswagger        51.20  10.00   5.20      4065\n2-Blue Zombie                      3.50   2.30      1703\n3-Adore Him                               2.70      1455\n\n$2 EXACTOR (9-2) paid 91.80, pool 5819\n$1 SUPERFECTA (9-2-3-1) paid 522.10, pool 5981\n$2 TRIACTOR (9-2-3) paid 749.00, pool 6969\n$.20HI5 9 2 3 1 4 1569.52 POOL 1846 $.20SF 104.42\n\n1 MILE, PACE, PURSE $8,800.\nHORSES & GELDINGS - N/W $50000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n9   Littlebitaswagger           9    4/3     4/3     6/4     4/2H     1/H        1:56.3  29   Tra Henry       24.60   J Harris\n2   Blue Zombie                 2    1/1H    1/1     1/H     1/H      2/H        1:56.3  29.4 A Carroll        1.10*  C Coleman\n3   Adore Him                   3    5/4H    5@/3H   2@@/H   2/H      3/H        1:56.3  29.4 N Steward        1.85   C Blake\n1   Deseronto(L)                1    2/1H    2/1     3/2     3/1H     4/1T       1:57    29.4 R Holliday       9.65   D Lindsey\n4   Another Great Pick          4    6/6H    6/5     8/6     5/4      5/3        1:57.1  29.1 R Battin        18.85   R Battin\n5   Art Again                   5    3@/2    3@/1H   4@/2H   6/4H     6/6        1:57.4  30.3 B Mcclure        6.15   G Mcdonnell\n7   Distinctiv Sean             7    8/9     9/7H    9/8     7/6      7/6H       1:57.4  29.2 G Rooney        62.60   V Mcmurren\n8   Harbourlite Jerry           8    9/10H   8@/6H   7@/5    8/6H     8/8        1:58.1  30.2 B Forward      189.35   J Rankin\n6   Mr Irresistible             6    7/7H    7@/5H   5@/3H   9/7      9/10H      1:58.3  31.1 P Mackenzie     24.00   M Etsell\nTime: 27.3, 57.2, 1:26.4, 1:56.3 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Littlebitaswagger   (b,g,4 - Santanna Blue Chip-Aspirine Semalu-Yankee Cam)\n                         Owner: Jack Harris,Hagersville,ON\n2nd  Blue Zombie         (br,g,3 - Bettors Delight-Queen Of Blues-Artsplace)\n                         Owner: West Wins Stable,Cambridge,ON-Howard A Taylor,Philadelphia,PA\n3rd  Adore Him           (b,g,4 - Shadow Play-Respectednbeloved-Dream Away)\n                         Owner: Curt R Blake,Clinton,ON\n6\n2-Youths Awesome           32.80   9.20   4.20      3761\n6-Here Comes William               3.30   2.60      1447\n9-Goldstar Badlands                       4.10       860\n\n$2 EXACTOR (2-6) paid 94.40, pool 3470\n$1 SUPERFECTA (2-6-9-3) paid 868.70, pool 4014\n$2 TRIACTOR (2-6-9) paid 568.00, pool 4757\n$.20SF 173.74\n\n1 MILE, PACE, PURSE $5,000.\nHORSES & GELDINGS - N/W $2500. LAST 3 (N/W OF A RACE LAST 5\nALLOWED $250.) (W/O $20000. IN 2016 N/E)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Youths Awesome(L)           2    4/4     5/4     5@/3H   5/3      1/NS       1:57.1  30   R Battin        15.40   R Battin\n6   Here Comes William          6    6@/5H   4@/2H   4@/2H   3/1H     2/NS       1:57.1  30.1 D Dupont         0.75*  M Dupont\n9   Goldstar Badlands           9    3/2     2@/H    2@/H    1/1      3/1Q       1:57.2  30.4 G Rooney         9.70   H Toll\n3   Evasive Card Shark          3    2/1     3/2     3/2     4/2      4/1Q       1:57.2  30.2 D St Pierre      9.55   T Staley\n7   Monster In Law              7    9/9H    9/8     7/5H    6/4H     5/1H       1:57.2  29.4 N Steward       47.40   D Beatson\n1   Intrigued Intended          1    1/1     1/H     1/H     2/1      6/3T       1:58    31.2 R Holliday      13.55   G Weatherbee\n5   Grits N Gravy               5    7/7     7@/6H   8@/6    7/5      7/3T       1:58    30.1 B Mcclure        8.80   W Hamm\n8   Big Moment                  8    8@/7H   8/7     9/8     8/6      8/4        1:58    29.4 A Carroll       13.85   R Mcintosh\n4   Relleno Hanover(L)          4    5/5     6@/4H   6@/4H   9/7      9/4H       1:58    30.3 B Forward        6.50   G Mcdonnell\nTime: 28.3, 58.1, 1:26.3, 1:57.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Youths Awesome      (br,h,6 - Camluck-Youthful Seelster-Island Fantasy)\n                         Owner: Ross G Battin,Monkton-Pauline M Patterson,Brussels,ON\n2nd  Here Comes William  (b,g,5 - Dragon Again-Miracles Delight-Bettors Delight)\n                         Owner: Marie B Dupont,Campbellville,ON\n3rd  Goldstar Badlands   (b,h,6 - Badlands Hanover-Rockin Lady-Artsplace)\n                         Owner: Morley J Bradshaw,Wilsonville,ON\n
108	9	0718	\n7\n1-Dreydl Hanover            4.20   2.80   2.80      5391\n9-Bugger Max                       3.80   2.70      2283\n6-St Lads Zeke                            5.10      1491\n\n$2 EXACTOR (1-9) paid 15.50, pool 7692\n$1 SUPERFECTA (1-9-6-3) paid 276.05, pool 6101\n$2 TRIACTOR (1-9-6) paid 139.60, pool 7607\n$1 WIN FOUR (1-9-2-1) paid 3764.10, pool 6970\n$.20SF 55.21 $.20W4 752.82\n\n1 MILE, PACE, PURSE $4,000.\nHORSES & GELDINGS - N/W $1600. LAST 3 (N/W OF A RACE IN 2016\nALLOWED $400.) (W/O $2000. LAST 5 N/E)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Dreydl Hanover              1    1/H     1/1H    1/1H    1/4      1/4H       1:57.1  30.2 A Haughan        1.10*  G Remmen\n9   Bugger Max                  9    3/2     3@/2    2@/1H   2/4      2/4H       1:58    31   N Steward        4.30   D Beatson\n6   St Lads Zeke                6    9/10    9/13    7@/5H   7/7      3/5        1:58.1  30.2 S Young         13.85   G Wain\n3   Kendal Fresco               3    2@/H    2/1H    4/3     3/4H     4/5Q       1:58.1  30.4 L House         11.40   S Mcniven\n4   Hussys Blu Boy              4    6/6     6@/5H   5@/3H   5/5H     5/6        1:58.2  31   B Mcclure        3.00   S Mcniven\n5   Boysgotfever                5    7/7     7@/7    8/6H    6/6H     6/6Q       1:58.2  30.2 T Moore         20.50   M Macri\n2   The Kop                     2    5/4H    5/5     6@/4H   8/7H     7/10T      1:59.2  31.4 R Holliday      20.55   F Maguire\n7   Terra Cotta Lad             7    4@/3    4@/3    3@@/2   4/5      8/13T      2:00    32.4 B Forward       26.25   G Mcdonnell\n8   Machme To The Moon          8    8/8H    8/12    9/10    9/12     9/17T      2:00.4  32   A Carroll       42.50   W Robinson\nTime: 27.4, 57, 1:26.4, 1:57.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Dreydl Hanover      (b,g,6 - Cams Card Shark-Debras Charm-Walton Hanover)\n                         Owner: Gordon A Remmen,Campbellville,ON\n2nd  Bugger Max          (b,g,6 - Believeinbruiser-Spurs Galley-Admirals Galley)\n                         Owner: Don D Beatson,Granton,ON\n3rd  St Lads Zeke        (b,g,5 - Major In Art-Armbro Dandy-Rustler Hanover)\n                         Owner: Sylvia E Peirce,Brantford-Georgia W Longstreet,Orangeville,ON\n8\n9-Spartan Victory           6.20   3.00   2.30      5219\n7-Thundering Ovation               3.20   2.50      2178\n4-Sonny With Achance                      9.10      1589\n\n$2 EXACTOR (9-7) paid 16.00, pool 4794\n$1 SUPERFECTA (9-7-4-2) paid 434.35, pool 6966\n$2 TRIACTOR (9-7-4) paid 177.20, pool 4430\n$.20SF 86.87 REFUND $10462\n#1 REFUNDED FOR UNFAIR START\n\n1 MILE, TROT, PURSE $7,500.\nPREFERRED 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n9   Spartan Victory             9    5/4     3@/1H   3@/1H   2/NS     1/1Q       2:00.3  28.3 R Holliday       2.10   K Di Cenzo\n7   Thundering Ovation          7    1@/1    1/1     1/1     1/NS     2/1Q       2:00.4  29   P Mackenzie      1.50*  G Sloan\n4   Sonny With Achance          4    3/2     4/2H    4/3     4/4      3/5H       2:01.3  29.1 J Obrien        38.05   J Obrien\n2   Stolen Goods                2    2/1     2/1     2/1     3/2H     4/5H       2:01.3  29.3 B Forward       13.35   J Rankin\n5   Flexie                      5    4@/3    6/4H    7/5H    6/5H     5/6Q       2:01.4  29   Tra Henry       26.35   M Giles\n6   Lexus Rocky                 6    7/6     7@/5H   6@/4H   7/6H     6/7Q       2:02    29.2 A Carroll        5.15   D Sinclair\n3   Majestic Mystic=            3    6/5     5@/3H   5@/3H   5/4H     7/8T       2:02.2  30   G Ketros        38.25   G Ketros\n8   Bambino Hall(L)             8    8/8     8/6H    8@/6H   8/7H     8/10       2:02.3  29.3 J Ryan           5.00   J Ryan\n1   Piscean(L)                  X1   9/DIS   9/DIS   9/DIS   9/DIS    9/DIS                   B Mcclure            RE C Beelby\nTime: 28.2, 1:00.4, 1:31.4, 2:00.3 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Piscean-BREAKS\n\n1st  Spartan Victory     (b,g,9 - Hard Rock N Roll-Kandys Kelsey-Wall Street Banker)\n                         Owner: Bradley G Pittock,London,ON\n2nd  Thundering Ovation  (b,m,7 - Thunder Road-Shesintuff-Angus Hall)\n                         Owner: Joanne C & Courtney C Sloan,Harley,ON\n3rd  Sonny With Achance  (b,m,5 - Ken Warkentin-Oaklea Nike-Balanced Image)\n                         Owner: Jeffrey J Obrien,London-Eldon W Wettlaufer-Carol K Wettlaufer-Michele C Frappier,St Thomas,ON\n9\n6-Argyle Alberwhosur       12.00   3.70   2.80      3530\n3-Gossip Model                     2.60   2.30      1235\n2-Noodles                                 3.60      1065\n\n$2 EXACTOR (6-3) paid 25.60, pool 4113\n$1 SUPERFECTA (6-3-2-4) paid 132.30, pool 4737\n$2 TRIACTOR (6-3-2) paid 87.30, pool 4099\n$.20SF 26.46\n\n1 MILE, PACE, PURSE $5,000.\nFILLIES & MARES - CLAIMING $12000. - FOR N/W $17500. LIFETIME (W-ALL)\n(N/W OF A RACE IN 2016 ALLOWED $5000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Argyle Alberwhosur          6    6/7     2@/1    2@/H    1/3      1/7        1:59    30.2 B Forward        5.00   J Pedden\n3   Gossip Model                3    3/3     4@/3    5@/3H   3/3H     2/7        2:00.2  31.1 Tra Henry        0.90*  K Di Cenzo\n2   Noodles                     2    1/1H    1/1     1/H     2/3      3/8H       2:00.3  32   N Steward        4.75   R Mitchell\n4   Flysantanna                 4    2/1H    3/2     3/2     4/4      4/9H       2:00.4  31.4 P Mackenzie      5.65   Alan W Fair\n1   Maritime Girl               1    4/4H    5/4     4/3     5/4H     5/10       2:01    31.4 S Young         15.85   J Wright\n7   Impatient Lady              7    7/8     6@/5    6@/5    7/6      6/10T      2:01.1  31.3 T Moore         25.00   R Duld\n5   Acefourtyfouramber          5    5/6     7/6H    8/6H    8/7      7/10T      2:01.1  31.2 J Ryan          38.45   S Peacock\n8   Sportsillustrator           8    8/9     8@/7    7@@/5H  6/5H     8/11H      2:01.1  31.3 B Mcclure       13.65   R Mcneill\nTime: 28.3, 59.1, 1:28.3, 1:59 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Argyle Alberwhosur  (b,m,4 - Whosurboy-Argyle Alberta-Albert Albert)\n                         Owner: Albert J Gilmour,Ailsa Craig,ON\n2nd  Gossip Model        (b,m,4 - Tell All-On The Catwalk-Pro Bono Best)\n                         Owner: Kristofer D Di Cenzo,Hamilton-John Baldasty,Oakville,ON\n3rd  Noodles             (b,m,4 - Real Desire-Southbrook Tinsel-Tinselator)\n                         Owner: Jason A Mitchell,Severn,ON\n10\n1-B Fast Eddie              5.50   3.10   2.60      5192\n5-The Big Beast                    5.20   5.40      1936\n4-Preppy Art                             16.30      1246\n\n$2 DAILY DOUBLE (6-1) paid 48.00, pool 760\n$2 EXACTOR (1-5) paid 39.60, pool 6654\n$1 SUPERFECTA (1-5-4-2) paid 326.70, pool 5752\n$2 TRIACTOR (1-5-4) paid 245.60, pool 5951\n$1 WIN FOUR (1-9-6-1) paid 195.60, pool 3555\n$.20HI5 1 5 4 2 3 537.68 POOL 3713 $.20SF 65.34 $.20W4 39.15\n\n1 MILE, PACE, PURSE $7,800.\nHORSES & GELDINGS - N/W $25000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   B Fast Eddie                1    1/1     1/1     1/H     1/1H     1/2Q       1:57.1  29   B Mcclure        1.75   B Baillargeon\n5   The Big Beast               5    3/2     3/2     3/2     2/1H     2/2Q       1:57.3  29   L Ouellette      5.65   M Ouimet\n4   Preppy Art                  4    6/5     6/4H    6/4H    4/3H     3/3Q       1:57.4  28.4 T Fritz         31.25   T Fritz\n2   Sutton Seelster             2    2/1     2/1     2@/H    3/2      4/3H       1:57.4  29.3 T Moore          1.50*  Dr I Moore\n3   Mister Big Top              3    5/4     5@/3H   5@@/4   5/4      5/5H       1:58.1  29.1 Tra Henry       44.90   J Byron\n7   Shaker                      7    7/6     7/5H    7/6     6/6      6/5T       1:58.2  29   B Forward       33.30   P Shakes\n6   Rough Trade                 6    8/7H    9/7H    9/8H    7/8      7/7T       1:58.4  29   P Mackenzie     14.10   F Hincks\n8   Cams Lucky Sam(L)           8    9/9     8@/6    8@/6H   8/10     8/9        1:59    29.3 J Ryan          13.15   N Gallucci\n9   Invinceable B               9    4/3     4@/2H   4@/3H   9/12     9/20       2:01.1  32.2 G Rooney        11.65   K Campbell\nTime: 28.2, 59.2, 1:28.1, 1:57.1 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  B Fast Eddie        (b,g,3 - Big Jim-Lake Shore Drive-Real Desire)\n                         Owner: Benoit O Baillargeon,Guelph-Santo Vena,Brampton-Nunzio Vena,Bolton-Twilight Stables Inc,Brampton,ON\n2nd  The Big Beast       (b,c,3 - Mister Big-Tre Cress-Towners Big Guy)\n                         Owner: Michel H Ouimet,Acton,ON-Katelynn Rourke,Rawdon,QC\n3rd  Preppy Art          (b,h,4 - Art Colony-Electric Smile-Die Laughing)\n                         Owner: Terry E Fritz,Walkerton,ON\nTotal Purse:  $62,500\nTotal Handle: $258,667\n(Not Official CPMA Information)\n\n
109	9	0720	\n1\n1-Rosberg                   3.20   2.50   2.40      2305\n4-Zorgwijk Rocket                  3.50   2.40       933\n6-Mr Marshmellow                          2.50       698\n\n$2 EXACTOR (1-4) paid 8.80, pool 2778\n$1 SUPERFECTA (1-4-6-7) paid 52.30, pool 3608\n$2 TRIACTOR (1-4-6) paid 18.90, pool 4089\n$.20SF 10.46\n\n1 MILE, TROT, PURSE $18,000.\nO.S.S. - GRASSROOT #2A - 2 YEAR OLD COLT TROT\n(STARTING FEE $350.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Rosberg                     1    1/1H    1/1     1/1     1/1      1/T        2:01.3  29.4 J Moiseyev       0.60*  J Walker\n4   Zorgwijk Rocket=            4    2/1H    2/1     2/1     2/1      2/T        2:01.4  29.4 J Hudon Jr       3.30   J Hudon Jr\n6   Mr Marshmellow=             6    3/3     3/2H    3/2     3/2      3/3H       2:02.1  30   O Gois           5.50   O Gois\n7   Many A Man                  7    6/9     6@/7    5/5     5/4      4/5        2:02.3  29.4 A Carroll       40.60   R Mcintosh\n2   Yo Yo Mass=                 2    5/7H    5@/5H   4/3H    4/3      5/6        2:02.4  30.2 B Mcclure        6.85   K Reibeling\n3   Stonebridge Brass           3    4/6     4/5     6/10    6/16     6/27       2:07    33.1 S Byron         63.65   J Bax\n5   Adventure Ahead=            5    X7X/24  7/DIS   7/DIS   7/DIS    7/DIS                   A Macdonald     24.55   A Macdonald\nTime: 30.1, 1:01.2, 1:31.4, 2:01.3 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Adventure Ahead-BREAKS\n\n1st  Rosberg             (b,c,2 - Manofmanymissions-Locksweeper-Lockkeeper)\n                         Owner: Julie A Walker,Carlisle-Ronald E Piers,Georgetown-Layhoon Chan Brunner,Etobicoke,ON\n2nd  Zorgwijk Rocket     (b,g,2 - Southwind Lustre-Got Sno Socks-Balanced Image)\n                         Owner: Joseph P Hudon Jr,Acton-R A W Equine Inc,Burlington,ON\n3rd  Mr Marshmellow      (b,c,2 - Federal Flex-Ultra Chic-Donerail)\n                         Owner: Ondrej Gois,Rockwood,ON\n2\n4-Kitarro                  11.20   5.70   2.90      1481\n3-Northern Dazzle                 19.40   3.70       613\n2-Critical Mass                           2.10       508\n\n$2 DAILY DOUBLE (1-4) paid 43.40, pool 1887\n$2 EXACTOR (4-3) paid 97.80, pool 1699\n$1 SUPERFECTA (4-3-2-5) paid 624.95, pool 1362\n$2 TRIACTOR (4-3-2) paid 399.90, pool 1994\n$.20SF 124.99\n\n1 MILE, TROT, PURSE $18,000.\nO.S.S. - GRASSROOT #2A - 2 YEAR OLD COLT TROT\n(STARTING FEE $350.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Kitarro                     4    3/3     3/2     3@/1    3/1H     1/8H       2:03.2  30.1 P Mackenzie      4.60   K Reibeling\n3   Northern Dazzle             3    1/H     2/1     4/4     4/7      2/8H       2:05    31.1 D Mcnair        19.30   R Mcnair\n2   Critical Mass=              2    2@/H    1/1     1/H     1I/H     3/11T      2:05.4  32.4 B Mcclure        0.55*  D Menary\n5   My Big Kadillac             5    4/5     4/3     2@/H    2IX/H    4/12H      2:05.4  32.4 A Carroll        2.90   R Mcintosh\n1   Laminin                     1X   5/12    5/13    5X/14   5X/19    5/22       2:07.4  32   C Jamieson      11.40   C Jamieson\n6   Bourne=                     SCRATCHED - VET(SICK)                                                                 \n7   More Than Majestic=         SCRATCHED - VET(SICK)                                                                 \nTime: 31.1, 1:02.3, 1:33, 2:03.2 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Bourne-VET//BREAKS//2 CONSECUTIVE SCRATCHES//MUST QUALIFY, More Than Majestic-VET\n\n1st  Kitarro             (b,c,2 - Southwind Lustre-Shopaholic-Angus Hall)\n                         Owner: Benbar Stables,Oakville-Kyle D Reibeling,Campbellville,ON\n2nd  Northern Dazzle     (b,c,2 - Kadabra-Northern Blaze-Angus Hall)\n                         Owner: R Gregg McNair,Guelph-Rob N Dennie,Walkerton-James W Dennie,Hanover-William Campbell,Mildmay,ON\n3rd  Critical Mass       (b,g,2 - Muscle Mass-Lukes Elvira-American Winner)\n                         Owner: Menary Racing Inc,Rockton-Michael A Guerriero,Brampton,ON\n3\n1-Clear Idea                5.80   2.80   2.60      4110\n4-Cousin Mary                      2.60   2.30      1675\n3-Michelles Hattrick                      2.60      1052\n\n$2 EXACTOR (1-4) paid 14.80, pool 6256\n$1 SUPERFECTA (1-4-3-2) paid 65.95, pool 5806\n$2 TRIACTOR (1-4-3) paid 44.10, pool 6689\n$.20SF 13.19\n\n1 MILE, PACE, PURSE $6,000.\nFILLIES & MARE - N/W $3000. LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $2000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Clear Idea                  1    1/1     1/1     1/1     1/1      1/H        1:59.2  29.2 B Davis Jr       1.90   B Macintosh\n4   Cousin Mary                 4    4/5     4@/3    3@@/1H  2/1      2/H        1:59.2  29.1 R Holliday       1.40*  J Kerr\n3   Michelles Hattrick          3    3/3     2@/1    2@/1    3/1H     3/2        1:59.4  29.3 Trev Henry       2.85   J Pereira\n2   Dirt On My Skirt            2    2/1     3/2     4/2     4/2      4/2H       1:59.4  29.2 S Young         15.25   C Flanigan\n6   Fading Shadow               6    6/8     6@/5    5@/3H   5/3      5/3Q       2:00    29.2 D Mcnair        11.85   J Darling\n5   Lyons Moonlight             5    5/6H    5/4H    6/4H    6/5      6/4        2:00.1  29.2 A Haughan       68.10   B Goit\n7   Dancing Shadows K           7    8/10H   7@/6H   7@/5    7/6      7/7H       2:00.4  29.4 Ja Macdonald    47.65   P Reid\n9   Uncool                      9    7/9H    8/9H    8/11    8/14     8/23       2:04    31.4 N Steward       80.65   Alan W Fair\n8   Lady Oxford                 SCRATCHED - VET(SICK)                                                                 \nTime: 29.1, 1:00.1, 1:30, 1:59.2 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Lady Oxford-VET\n\n1st  Clear Idea          (b,f,2 - American Ideal-Glass Maker-Artsplace)\n                         Owner: Hutt Racing Stable,Paoli,PA-Blake C Macintosh,Cambridge,ON\n2nd  Cousin Mary         (b,f,3 - Camluck-Chianti Seelster-Modern Art)\n                         Owner: Jeffrey Williamson,Blyth,ON\n3rd  Michelles Hattrick  (b,f,3 - Mach Three-Luck Of Michelle-Camluck)\n                         Owner: The Merks Stable,New York,NY\n4\n2-Prettyndangerous          6.60   4.30   4.10      2288\n3-Moon Lake                        5.20   5.40       934\n7-Romance In Camelot                     10.40       903\n\n$2 EXACTOR (2-3) paid 39.50, pool 2376\n$1 SUPERFECTA (2-3-7-8) paid 725.20, pool 3071\n$2 TRIACTOR (2-3-7) paid 475.70, pool 3225\n$.20SF 145.04\n\n1 MILE, PACE, PURSE $5,200.\nFILLIES & MARES - CLAIMING $8000. (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Prettyndangerous            1    1/1     1/1     1/1     1/1      1/H        1:55.2  30   J Ryan           2.30   B Curran\n3   Moon Lake(L)                2    2/1     2/1     2/1     2/1      2/H        1:55.2  29.4 B Forward        9.50   D Lehan\n7   Romance In Camelot(L)       6    6/7     5/4H    3/2H    3/2      3/3Q       1:56    30.1 R Holliday      35.35   M Rivest\n8   St Lads Pixie               7    7/9     7/6H    5/4H    4/3H     4/4T       1:56.2  30.1 B Mcclure       20.95   J Watt\n4   Cyndalianne Duc             3    4/4     4@/3    6@/5    6/4H     5/5Q       1:56.2  30   N Steward        4.55   G Robinson\n6   Good Luck Kathy             5    5/5     6@/5H   7/6     7/6H     6/5H       1:56.2  29.4 A Carroll        9.40   S Rose\n5   Little Anna Mae(L)          4    3/2     3@/2    4@/3    5/4      7/5T       1:56.3  30.3 Trev Henry       1.15*  L Lalonde Jr\n1   Twilight Katie              SCRATCHED - VET(LAME)                                                                 \nTime: 27.2, 56.3, 1:25.2, 1:55.2 (Temperature: 22, Condition: FT, Variant: 0)\nCYNDALIANNE DUC claimed for $10,000 by James Lee.\nJudges List: Twilight Katie-VET\n\n1st  Prettyndangerous    (b,m,6 - Armbro Deuce-Program Manager-Matts Scooter)\n                         Owner: Blake T Curran,Perth,ON\n2nd  Moon Lake           (b,m,10 - Dream Away-Tarport Mimi-Big Towner)\n                         Owner: Daniel T Lehan,St Catharines,ON\n3rd  Romance In Camelot  (b,m,8 - Camelot Hall-Keystone Romantic-Cams Card Shark)\n                         Owner: Claude Poirier,Havre-Aux-Maisons,QC\n5\n4-Themanofmydreams          2.90   2.60   2.20      2093\n5-Little Lion Man                  4.60   3.40      1003\n2-Lexus Gilmore                           5.90       772\n\n$2 EXACTOR (4-5) paid 7.80, pool 2958\n$1 SUPERFECTA (4-5-2-8) paid 396.85, pool 3384\n$2 TRIACTOR (4-5-2) paid 100.60, pool 3636\n$.20HI5 4 5 2 8 7 136.81 POOL 2086 $.20SF 79.37\n\n1 MILE, TROT, PURSE $18,000.\nO.S.S. - GRASSROOT #2A - 2 YEAR OLD COLT TROT\n(STARTING FEE $350.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Themanofmydreams            3    2/1     1/1H    1/1H    1/1H     1/2T       2:03.3  30   D St Pierre      0.45*  T Staley\n5   Little Lion Man             4    1/1     2/1H    2/1H    2/1H     2/2T       2:04.1  30.2 Trev Henry       6.85   R Moreau\n2   Lexus Gilmore=              1    3/2     3/2H    4/3     3/3      3/6        2:04.4  30.3 L House         28.35   N Dunstan\n8   Smoking Mass                7    6/7H    6/6H    6/5     5/4H     4/7T       2:05.1  30.3 D Dupont        35.90   M Dupont\n7   A J Ricochet                6    5/6     5/5H    5@/4    6/5      5/8Q       2:05.1  30.4 A Carroll       31.25   A Dimmers\n3   Motown Jackpot              2    4/4H    4/4     3@/2    4/3H     6/9        2:05.2  31.2 M Baillargeon    3.25   B Baillargeon\n6   Lmc Mass Gem                5X   7/10    X7/7    7/25    7/30     7/42       2:12    33.2 P Mackenzie     11.35   K Reibeling\n1   Majestic Streak             SCRATCHED - VET(SICK)                                                                 \nTime: 30.1, 1:02, 1:33.3, 2:03.3 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Majestic Streak-VET\n\n1st  Themanofmydreams    (b,c,2 - Muscle Mass-Uneeda Dream-Angus Hall)\n                         Owner: Tiffanee N Staley,Guelph,ON-Alexandre Pilon-Christian Pilon,St-Eustache-Jesse Legault,Lorraine,QC\n2nd  Little Lion Man     (b,g,2 - Muscle Mass-Fin De Maye-King Conch)\n                         Owner: Gestion J Y Blais Inc,Montreal,QC\n3rd  Lexus Gilmore       (b,c,2 - Windsong Espoir-Lexus Hall-Conway Hall)\n                         Owner: Norm H Dunstan,Caledon Village,ON\n6\n5-Coherent                 23.60  12.50   4.80      1748\n4-Tinas War                        9.00   4.30       817\n3-Shes All Muscle                         3.10       718\n\n$2 EXACTOR (5-4) paid 237.90, pool 1900\n$1 SUPERFECTA (5-4-3-9) paid 1290.70, pool 3122\n$2 TRIACTOR (5-4-3) paid 630.00, pool 2934\n$.20SF 258.14\n\n1 MILE, TROT, PURSE $5,000.\nCLAIMING $12000. - FOR N/W $25000. (F & M $31250.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Coherent=                   5    6@/4H   3@/2    2@/H    2/H      1/NK       2:02.4  30.3 R Jenkins Jr    10.80   F Marion\n4   Tinas War                   4    3/2     4/3     4/3H    4/2H     2/NK       2:02.4  30   G Mcknight       8.45   G Mcknight\n3   Shes All Muscle             3    1/1     1/1     1/H     1/H      3/1        2:03    30.4 J Ryan           2.40*  J Wilson\n9   Angel Assault=              9    5/4     8/7     7/6     5/3H     4/2Q       2:03.1  29.4 M Whelan         6.45   W Whelan\n2   Tymal Bolt                  2    2/1     2/1     3/2     3/2      5/3Q       2:03.2  30.4 T Borth          7.80   F Baker Jr\n6   Its Easy To Dance           6    7/6     5@/4    5@/4    7/6      6/11H      2:05    32   R Shepherd       2.85   P Shepherd\n8   Zorgwijk Priority=          7    8/7H    7@/6    6@/5    EX6/4H   7BE/26     2:08    34.4 P Mackenzie     32.15   T Mckibbin\n1   Scorr Again                 1    4/3     6/5H    X8/16   8/26     8/DIS                   Do Brown         4.30   Do Brown\n7   Whatdreamsrmadeof           SCRATCHED - VET(SICK)                                                                 \nTime: 29.2, 1:01.2, 1:32.1, 2:02.4 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Whatdreamsrmadeof-VET\n\n1st  Coherent            (b,f,3 - Donato Hanover-Smarty Mouth-Yankee Glide)\n                         Owner: Felix M Marion,Cambridge,ON\n2nd  Tinas War           (b,m,5 - Mutineer-Gvs Villantina-Cumin)\n                         Owner: Dave Husul,Langton,ON\n3rd  Shes All Muscle     (b,f,3 - Muscle Mass-All Time Favorite-Angus Hall)\n                         Owner: Chris Y Wilson,Dashwood,ON\n
110	9	0720	\n7\n1-Tauriel                   9.30   4.40   3.30      2514\n3-Greystone Ladyluck               2.90   2.70      1290\n9-Life Groove                             3.60       905\n\n$2 EXACTOR (1-3) paid 26.20, pool 3430\n$1 SUPERFECTA (1-3-9-2) paid 171.70, pool 3532\n$2 TRIACTOR (1-3-9) paid 72.10, pool 3858\n$1 WIN FOUR (2-4-5-1) paid 1781.25, pool 6244\n$.20SF 34.34 $.20W4 356.25\n\n1 MILE, PACE, PURSE $7,000.\nFILLIES & MARES - N/W $10000. LIFETIME (W-ALL)\n(N/W OF A RACE LAST 5 ALLOWED $2000.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Tauriel                     1    1/1     1/1     1/1     1/1H     1/1        1:57.1  28.3 B Forward        3.65   J Barton\n3   Greystone Ladyluck          3X   2/1     2/1     3/2     2/1H     2/1        1:57.2  28.2 B Davis Jr       1.30*  B Belore\n9   Life Groove                 9    5/5H    3@/2    2/1     3/2      3/2H       1:57.3  28.4 P Mackenzie      6.25   R Laarman\n2   Alliwannadoisplay           2    4/4H    5/4H    5/4     4/4H     4/6T       1:58.3  29.1 R Shepherd      25.45   G Adair\n5   On A Cloud                  5    6/7     6/6     7/6     6/6H     5/7Q       1:58.3  28.4 Ja Macdonald     4.60   T Bain\n6   Boyur Attractive            6    7/8     7@/6H   6@/4H   7/7H     6/9T       1:59.1  29.4 Trev Henry      14.80   R Steward\n7   Tz Tizzy                    7    8/9     8/7H    8@/6H   8/8      7/10       1:59.1  29.2 L House         28.00   S Mcniven\n4   Evas Best Girl              4    3/2H    4@/3    4@/3    5/5      8/12       1:59.3  30.2 N Steward        8.45   P Core\n8   Lady London                 SCRATCHED - VET(SICK)                                                                 \nTime: 28.2, 59, 1:28.3, 1:57.1 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Lady London-VET\n\n1st  Tauriel             (br,f,3 - Mach Three-Fans Phantom-Island Fantasy)\n                         Owner: James Barton,Branchton,ON\n2nd  Greystone Ladyluck  (b,f,3 - Camluck-Bettor Be Right-Bettors Delight)\n                         Owner: A Jean & James F Caddey,Embro,ON\n3rd  Life Groove         (b,f,3 - Shadow Play-Hay Macarena-Artsplace)\n                         Owner: J Warren Casely,Beeton,ON\n8\n2-St Lads Moonwalk          3.50   2.30   2.10      3205\n3-Newbie                           2.70   2.20      1330\n6-Rockabella                              3.50       954\n\n$2 EXACTOR (2-3) paid 6.10, pool 3703\n$1 SUPERFECTA (2-3-6-8) paid 138.35, pool 5681\n$2 TRIACTOR (2-3-6) paid 27.80, pool 5916\n$.20SF 27.67\n\n1 MILE, PACE, PURSE $7,500.\nHORSES & GELDINGS - PREFERRED 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   St Lads Moonwalk            2    4@/3    1/1H    1/1H    1/1H     1/2H       1:53.4  28.1 D Mcnair         0.75*  J Darling\n3   Newbie                      3    1@/1    2/1H    2/1H    2/1H     2/2H       1:54.1  28.2 B Davis Jr       2.05   I Hyatt\n6   Rockabella                  5    6/9     6/7H    6/5     4/4      3/8        1:55.2  28.4 Trev Henry       8.45   T Stein\n8   Raylan Givens(L)            7    2/1     3/3     4/3H    3/3      4/8T       1:55.3  29.2 C Steacy        89.55   J Morrison\n7   Rock N Roll Legacy(L)       6    8/11    8/9H    8/7     7/6H     5/9Q       1:55.3  28.3 G Rooney        29.15   R Marriage\n1   Ciona Bromach(L)            1    5/6     5/6     5@/4    5/4H     6/9Q       1:55.3  29.1 A Haughan       25.60   D Obrienmoran\n4   Two Of Clubs                4    3/2H    4/4     3@/2    6/5      7/17       1:57.1  31.1 S Young         13.00   G Rivest\n9   Kid Galahad N               9    7/10    7@/8    7@/6    8/7      8/17       1:57.1  30.2 L House         15.15   S Taylor\n5   Mister X                    SCRATCHED - VET(SICK)                                                                 \nTime: 27.3, 56.1, 1:25.3, 1:53.4 (Temperature: 22, Condition: FT, Variant: 0)\nJudges List: Mister X-VET\n\n1st  St Lads Moonwalk    (b,c,3 - Mach Three-Warrawee Cammy-Camluck)\n                         Owner: Jack Darling Stables Ltd,Cambridge,ON\n2nd  Newbie              (b,g,4 - Always A Virgin-Nat A Tat Tat-Blissfull Hall)\n                         Owner: Larry W Ainsworth,Petrolia,ON\n3rd  Rockabella          (b,g,7 - Rocknroll Hanover-Bellys Up-Survivor Gold)\n                         Owner: Robyn Philpott,Waterdown,ON\n9\n1-Tougher Than Ever         7.50   4.00   2.40      3297\n5-Warrawee Shipshape               3.20   2.40      1055\n7-Dontcrampmystyle                        2.50       856\n\n$2 EXACTOR (1-5) paid 23.60, pool 3166\n$1 SUPERFECTA (1-5-7-4) paid 121.15, pool 3988\n$2 TRIACTOR (1-5-7) paid 80.60, pool 4417\n$.20SF 24.23\n\n1 MILE, TROT, PURSE $18,000.\nO.S.S. - GRASSROOT #2A - 2 YEAR OLD COLT TROT\n(STARTING FEE $350.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Tougher Than Ever=          1    3/2H    3/3     2@/H    2/H      1/2Q       2:02.2  30.3 Ja Macdonald     2.75   R Norman\n5   Warrawee Shipshape=         5    2/1     2/1H    3/2     3/2      2/2Q       2:02.4  30.3 A Green          2.00*  A Green\n7   Dontcrampmystyle=           7    1@/1    1/1H    1/H     1/H      3/3Q       2:03    31.1 Trev Henry       2.15   A Mccabe\n4   Jack In My Coke=            4    6/12    5@/6H   4/3H    4/3      4/6H       2:03.3  31.1 J Maguire        7.00   J Maguire\n3   Charmbo Chrome              3    5/11    6/8     5/6H    5/6      5/7T       2:04    31   A Hamilton      38.05   J Rier\n6   Piston Popper               6    7/15    7/12    6/9     6/11     6/16       2:05.3  32   G Rivest        47.70   G Rivest\n2   Airborne Seelster           2    4/8     4/5H    X7/18   7/18     7/24       2:07.1  31.4 D Mcnair         7.15   R Mcnair\nTime: 29.2, 1:00.4, 1:31.4, 2:02.2 (Temperature: 22, Condition: FT, Variant: 0)\n\n1st  Tougher Than Ever   (b,c,2 - Kadabra-One Tough Lass-Muscles Yankee)\n                         Owner: Melvin Hartman,Ottawa,ON-Herb A Liverman,Miami Beach-David H Mc Duffee,Delray Beach,FL\n2nd  Warrawee Shipshape  (b,g,2 - Muscle Mass-U Can Cruise-Malabar Man)\n                         Owner: Michael W Tobin,Port Dover,ON\n3rd  Dontcrampmystyle    (b,c,2 - Muscle Mass-Single Pans Reflex-Andover Hall)\n                         Owner: Glenview Livestock Ltd,Wallenstein,ON\n10\n2-Top Of The Morning        7.70   4.50   3.70      3816\n7-Nor Star Renegade                4.10   6.60      1562\n9-Kablooie                                3.50       685\n\n$2 DAILY DOUBLE (1-2) paid 48.00, pool 771\n$2 EXACTOR (2-7) paid 74.30, pool 3767\n$1 SUPERFECTA (2-7-9-3) paid 477.75, pool 3437\n$2 TRIACTOR (2-7-9) paid 225.20, pool 4739\n$1 WIN FOUR (1-2-1-2) paid 304.00, pool 4678\n$.20HI5 2 7 9 3 5 777.14 POOL 3291 $.20SF 95.55 $.20W4 60.80\n\n1 MILE, PACE, PURSE $4,400.\nHORSES & GELDINGS - CLAIMING $6000. (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Top Of The Morning(L)       2    3/2     3@/1H   2@/H    2/H      1/NK       1:58.1  30.4 T Moore          2.85   T Moore\n7   Nor Star Renegade           7    2@/1    1/1     1/H     1/H      2/NK       1:58.1  30.4 D Mcnair         6.80   R Lindenfield\n9   Kablooie(L)                 9    6/7H    6@/5    5@/3H   5/3      3/2Q       1:58.3  30.3 B Mcclure        3.65   D Lagace\n3   Star Struck Luck            3    7/8H    7@/6H   6@/5    7/4H     4/3Q       1:58.4  30.2 Br Richardson    9.55   E Laybourne\n5   Joeys Kidd                  5    8/10    9@/8H   7@/6    6/3H     5/3H       1:58.4  30.1 P Mackenzie     64.20   V Cochrane\n1   Bandicoot                   1    4/4H    4@/3H   4/3     3/2      6/5        1:59.1  31.1 Trev Henry       2.50*  M Stoikopoulos\n4   Rocknroll Band              4    5/6     5/4H    8/7     8/6H     7/6        1:59.2  30.3 N Steward        7.15   P Belanger Jr\n6   Jackson Killean(L)          6    1/1     2/1     3/2     4/2H     8/7        1:59.3  31.4 B Forward       14.85   L Privett\n8   Two Face(L)                 8    9/11H   8/8     9@/8    9/7      9/7H       1:59.3  30.3 M Whelan        39.85   F Soyka\nTime: 27.3, 57.3, 1:27.2, 1:58.1 (Temperature: 22, Condition: FT, Variant: 0)\nNOR STAR RENEGADE claimed for $7,500 by James W Napper.\n\n1st  Top Of The Morning  (b,g,9 - Cams Card Shark-Converging Spirit-Grinfromeartoear)\n                         Owner: Tyler Moore,Guelph,ON\n2nd  Nor Star Renegade   (b,g,4 - Sportswriter-Allamerican Terra-Western Hanover)\n                         Owner: Wayne H Rowe,Woodham,ON\n3rd  Kablooie            (b,g,6 - Hi Ho Silverheels-Annie Get Your Gun-Distinguishedbaron)\n                         Owner: Daniel G Lagace,Cambridge,ON\nTotal Purse:  $107,100\nTotal Handle: $175,383\n(Not Official CPMA Information)\n\n
111	9	0722	\n1\n4-Ms Medusa                15.30   9.60   3.80      4138\n2-Willie Wonka                     8.30   4.30      1864\n1-Hilarious Hero                          2.80      1434\n\n$2 EXACTOR (4-2) paid 128.20, pool 5047\n$1 SUPERFECTA (4-2-1-6) paid 396.15, pool 5429\n$2 TRIACTOR (4-2-1) paid 345.70, pool 7133\n$.20SF 79.23\n\n1 MILE, TROT, PURSE $6,000.\nN/W $3000. (F & M $3750.) LIFETIME (W-ALL)\n(N/W OF A RACE ALLOWED $2000. (F & M $2500.)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Ms Medusa=                  4    2/1     2/1H    3/2     3/1H     1/H        2:01.1  29.4 P Henriksen      6.65   P Henriksen\n2   Willie Wonka=               2    3/6     3/4     2@/1    2/1      2/H        2:01.1  30   A Carroll        8.70   R Mcintosh\n1   Hilarious Hero=             1    1/1     1/1H    1/1     1/1      3/1Q       2:01.2  30.2 B Mcclure        2.25*  T Macdonnell\n6   Moon Dance                  6    5/9     5/8     4@/3    4/3      4/2H       2:01.3  30   T Durand         2.25*  T Durand\n3   Prince Of Minto             3    4/8     4/7     5/4     5/6      5/5H       2:02.1  30.2 M Baillargeon    3.35   B Baillargeon\n9   Whos Cheatin Who=           9    6/10H   6/11    6/5     X6/8     X6/18H     2:04.4  32.4 R Shepherd      18.55   D Sinclair\n7   Style Spotlight             7    7/12H   7/16    7/17    7/20     7/31       2:07.2  33   P Walker        69.55   P Walker\n5   South Win Bax               5    9/16    9/23    8@/18   8/21     8/32       2:07.3  33   J Bax           18.70   J Bax\n8   Jungle Gem                  8    8/14    8/19    9/20    9/24     9/37       2:08.3  33.3 D Fritz         33.35   D Fritz\nTime: 29.2, 59.3, 1:31, 2:01.1 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Ms Medusa           (b,f,3 - Andover Hall-Medusa Blue Chip-Credit Winner)\n                         Owner: Morten Bjornestad,Stavanger,NOR\n2nd  Willie Wonka        (b,c,2 - Kadabra-Amour Chocolat-Chocolatier)\n                         Owner: Robert McIntosh Stables Inc,Windsor-Dave A Boyle,Bowmanville,ON\n3rd  Hilarious Hero      (b,c,3 - Deweycheatumnhowe-Paycheck Lavec-Mr Lavec)\n                         Owner: Dan H Mogridge,Hillsdale-Jeffery Oborne,Jordan Station,ON\n2\n1-J J Mystic Storm          5.60   3.20   2.40      2121\n5-Southwind Jagger                 5.00   3.00       847\n4-Catch Twenty Two                        3.80       867\n\n$2 DAILY DOUBLE (4-1) paid 30.80, pool 1958\n$2 EXACTOR (1-5) paid 20.00, pool 2300\n$1 SUPERFECTA (1-5-4-6) paid 152.75, pool 2520\n$2 TRIACTOR (1-5-4) paid 76.70, pool 3067\n$.20SF 30.55\n\n1 MILE, PACE, PURSE $5,000.\nHORSES & GELDINGS - CLAIMING $12000. - FOR N/W $15000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   J J Mystic Storm            1    1/1H    1/1     1/1     1/2      1/2T       1:57.2  29   P Mackenzie      1.80   S Charlton\n5   Southwind Jagger            5    2/1H    2/1     2/1     2/2      2/2T       1:58    29.2 T Moore          6.60   R Ellis\n4   Catch Twenty Two            4    5/5H    3@/1H   3@/1H   3/3      3/7H       1:58.4  30.1 B Mcclure        8.40   S Friend\n6   Hes Got Style               6    6/6H    5@/3    4@/3    4/4      4/7H       1:58.4  29.4 L House         11.55   S Mcniven\n2   Jansen Hanover              2    3/3     4/2H    5/4     5/5H     5/7T       1:59    29.4 Br Richardson    1.35*  E Laybourne\n7   Moot Court                  7    7/7H    7/5     6/5     6/7      6/16       2:00.3  31.1 R Holliday      16.75   R Mcnair\n3   Spaniard                    3    4@/4H   6/4H    7/12    7/19     7/31       2:03.3  32.4 A Carroll       17.65   M Etsell\nTime: 28.1, 59, 1:28.2, 1:57.2 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  J J Mystic Storm    (b,g,3 - Camystic-Emblem Seelster-Western Maverick)\n                         Owner: Charles D Price,Nauwigewauk-Daryl W Pierce-Gerald E Lowe,Saint John,NB\n2nd  Southwind Jagger    (b,h,4 - Sportswriter-Jk Sure I Can-Rocknroll Hanover)\n                         Owner: Russell J Ellis,Elmira,ON\n3rd  Catch Twenty Two    (b,g,3 - Roll With Joe-Make Me Blush-Western Ideal)\n                         Owner: Gordon E Hart,Odessa,ON\n3\n1-Life Strikes              4.50   3.10   2.20      2001\n7-Summajestic                      6.00   3.20       860\n5-P L Jade                                2.50       775\n\n$2 EXACTOR (1-7) paid 22.40, pool 1906\n$1 SUPERFECTA (1-7-5-9) paid 106.65, pool 2741\n$2 TRIACTOR (1-7-5) paid 59.60, pool 2944\n$.20SF 21.33\n\n1 MILE, TROT, PURSE $7,000.\nN/W $10000. (F & M $12500.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Life Strikes                1    1/3     1/1H    1/1H    1/1H     1/T        2:00.4  31.4 M Baillargeon    1.25*  M Robitaille\n7   Summajestic                 5    4/6     4/4H    3@/2    3/2      2/T        2:01    31.3 S Byron          5.95   D Byron\n5   P L Jade=                   3    2/3     2/1H    2/1H    2/1H     3/1H       2:01    31.4 M Dupuis         1.75   M Dupuis\n9   Shes All Magic              9    3/4     3/3     4/3H    4/3H     4/3        2:01.2  31.4 P Henriksen      7.45   P Henriksen\n4   Relevant=                   2    5/8     5/6     5/9H    5/9H     5/14T      2:03.4  33   G Macdonald     23.75   L Privett\n8   Tala Seelster               6    X6/12   6/12    6/11    6/11     6/15       2:03.4  32.3 B Mcclure       20.05   W Budd\n6   Moxie Begonia               4X   7/24    7/DIS   7/DIS   7/DIS    7/DIS                   J Harris        18.50   G Oliver\n2   Shezastrikin Loral          SCRATCHED - VET(SICK)                                                                 \n3   Daytrooper                  SCRATCHED - VET(SICK)                                                                 \nTime: 28.3, 59, 1:29, 2:00.4 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Shezastrikin Loral-VET, Daytrooper-VET\n\n1st  Life Strikes        (b,f,3 - Mutineer-Life Class-Angus Hall)\n                         Owner: Marie Eve Robitaille,Acton-Macks Stable,Stoney Creek-Jackie Drysdale,Orangeville-MB Racing Inc,Acton,ON\n2nd  Summajestic         (b,g,3 - Majestic Son-Northern Pixie-Mr Lavec)\n                         Owner: Stephen R Byron,Thornton,ON\n3rd  P L Jade            (b,f,3 - Majestic Son-P L Corina-Muscles Yankee)\n                         Owner: Prince Lee Acres,Uxbridge,ON\n4\n1-Marina Desbi              5.10   3.30   2.30      1737\n2-Lucky                            4.60   3.70       880\n3-Twin B Amour                            3.10      1123\n\n$2 EXACTOR (1-2) paid 25.80, pool 2062\n$1 SUPERFECTA (1-2-3-4) paid 55.80, pool 2721\n$2 TRIACTOR (1-2-3) paid 59.80, pool 3398\n$.20SF 11.16\n\n1 MILE, PACE, PURSE $4,400.\nFILLIES & MARES - CLAIMING $6000. (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Marina Desbi                1    1/1     1/1     1/1     1/1      1/2        1:57.3  29.3 L House          1.55*  M Paulic\n2   Lucky                       2    3/2H    3@/1H   2@/1    2/1      2/2        1:58    29.4 Tra Henry        5.80   M Fitzgerald\n3   Twin B Amour                3    2/1     2/1     3/2     3/2      3/5        1:58.3  30.1 J Harris         3.05   J Harris\n4   The Prophet Mary(L)         4    4/4     4/3     4/3H    4/3      4/5T       1:58.4  30.1 N Steward        4.35   J Watt\n8   Im A Debutant+(L)           8    7@/7    7@/5H   7@/6    7/5H     5/6Q       1:58.4  29.3 T Moore         14.35   L Privett\n6   Lotteria                    6    8/8     8/6H    8@/7    8/6      6/8        1:59.1  29.4 B Mcclure       14.30   G Laurignano\n9   Alibi Terror                9    5/5     5@/3H   5@/4    5/3H     7/8        1:59.1  30.2 R Holliday      26.40   T Schlatman\n5   Mach Denali                 5    6/6     6/5     6/5H    6/5      8/8Q       1:59.1  30.1 A Carroll       20.60   M Etsell\n7   Oh Chute                    7    9/9     9/7     9@/8    9/9      9/16       2:00.4  31.1 P Mackenzie     38.50   Alan W Fair\nTime: 28, 58.4, 1:28, 1:57.3 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Marina Desbi        (ro,m,6 - Shanghai Phil-Diana Desbi-Shipps Schnoops)\n                         Owner: Mary A Paulic,Guelph-Russell J Ellis,Elmira,ON\n2nd  Lucky               (br,m,9 - Astreos-Simply Lucky-Camluck)\n                         Owner: Milton W Fitzgerald,Waterdown,ON\n3rd  Twin B Amour        (br,m,6 - Camluck-Twin B Intrigue-Mcardle)\n                         Owner: Jack Harris,Hagersville,ON\n5\n2-Wilma C                   3.90   2.80   2.70      1698\n9-T C Sno Massive                  6.80   6.20       861\n5-Clone The Tone                          9.80       998\n\n$2 EXACTOR (2-9) paid 43.30, pool 2220\n$1 SUPERFECTA (2-9-5-6) paid 924.20, pool 2131\n$2 TRIACTOR (2-9-5) paid 319.90, pool 2751\nHI5 C/O 1178.16\n\n1 MILE, TROT, PURSE $7,800.\nN/W $25000. (F & M $31250.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Wilma C                     2    3/6     2/1     2@/H    2/H      1/1        2:01.3  31.1 K Sheppard       0.95*  K Sheppard\n9   T C Sno Massive=            9    4/7     4@/3    3@/1H   3/1      2/1        2:01.4  31.1 B Mcclure        9.75   Ri Zeron\n5   Clone The Tone              5    2/1     3/2     4/2H    4/2H     3/1T       2:02    31.1 R Shepherd      44.75   S Weber\n6   Zorgwijk Queen              6    1/1     1/1     1/H     1/H      4/2        2:02    31.3 T Borth         17.40   R Wade\n10  Vimy Ridge Vesta            1    X6/11   6/6     6/7     5/5H     5/10       2:03.3  31.4 L House          9.20   S Loughran\n7   Stonebridge Peace           X7   7/19    7/13    7/13    7/11     6/14H      2:04.2  31.2 T Moore          7.80   J Copley\n4   Beer Before Noon=           4X   X8/24   8/19    8/14    8/13     7/16H      2:04.4  31.3 A Carroll        6.10   P Lawrence\n8   Don Jarvis                  8    5/9     5/4H    5/5H    6/7H     8/16T      2:05    33.3 R Holliday      47.95   M Giles\n3   Lovin Karma                 X3   X9/DIS  X9/DIS  9/DIS   9/DIS    9/DIS                   P Mackenzie      5.40   C Yates\n1   Citizen Hall                SCRATCHED - VET(SICK)                                                                 \nTime: 29.1, 1:01, 1:30.2, 2:01.3 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Lovin Karma-BREAKS, Citizen Hall-VET\n\n1st  Wilma C             (b,f,3 - Muscle Mass-Ziggy Wiggy-S Js Photo)\n                         Owner: Sea Of Green Inc,Dundas,ON\n2nd  T C Sno Massive     (b,f,3 - Muscle Mass-Sno Doubt About It-Balanced Image)\n                         Owner: Rick Zeron Stables,Oakville-Bruno Dipoce,Wasaga Beach-Seleena F Baksh,Etobicoke,ON\n3rd  Clone The Tone      (b,g,3 - Muscle Mass-R Tonys Girl-Kadabra)\n                         Owner: Thomas A Rankin-Elizabeth C Rankin,St Catharines,ON\n6\n2-Let Em Bounce             5.80   2.20   2.20      2353\n7-Heza Workof Art                  3.50   3.70      1491\n5-Whim Roader                             8.10      1117\n\n$2 EXACTOR (2-7) paid 17.80, pool 2951\n$1 SUPERFECTA (2-7-5-9) paid 386.80, pool 3295\n$2 TRIACTOR (2-7-5) paid 119.30, pool 3819\n$.20SF 77.36\n\n1 MILE, PACE, PURSE $5,200.\nHORSES & GELDINGS - CLAIMING $12000. - FOR N/W $30000. LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Let Em Bounce               2    2/1     1/1     1/1     1/1      1/T        1:57.3  29.4 B Mcclure        1.90*  W Budd\n7   Heza Workof Art             7    1@/1    2/1     2/1     2/1      2/T        1:57.4  29.4 J Harris        20.00   J Watt\n5   Whim Roader                 5    7/7     5/11    3@/4    3/2      3/3        1:58.1  29.3 B Forward       37.20   L Privett\n9   Sports Vision               9    6/5H    4/10    4/5     4/4      4/8T       1:59.2  30.3 A Carroll        7.60   S Friend\n8   Casimir Obama               8    9/10    7/13    5/6H    5/5      5/10H      1:59.3  30.3 L House         68.30   R Deacon\n6   Gotameeting                 6    8/8H    6/12    6/8     6/7      6/12       2:00    30.3 P Mackenzie     39.35   J Loosemore\n4   Sharks Play                 4    5/4     8/23    7/12    7/13     7/30       2:03.3  33.2 N Steward       15.90   P Shepherd\n3   Jet Er Done(L)              3    3/2     3/7     8/17    8/25     8CH/DIS                 T Moore         35.90   T Moore\n1   Master Smile                1    4/3     9/DIS   PULLED UP        DNF                     Tra Henry        2.85   J Mcginnis\nTime: 27.2, 57, 1:27.4, 1:57.3 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Jet Er Done-VET//CHOKED//PERFORMANCE, Master Smile-PERFORMANCE\n\n1st  Let Em Bounce       (b,g,5 - I Am A Fool-Game Bunny-Precious Bunny)\n                         Owner: James A Wilson,Melancthon,ON\n2nd  Heza Workof Art     (b,g,4 - Art Colony-Western Cat-Western Hanover)\n                         Owner: Jeffrey Williamson,Blyth,ON\n3rd  Whim Roader         (b,h,5 - Nukamickie-Water Sprite-Water Tower)\n                         Owner: Brooke E Clarey,Montague,PE\n
112	9	0722	\n7\n1-Whosgoingtocatchus        4.00   2.30   2.40      2029\n2-Tymal Wizard                     4.30   3.10      1374\n6-Howie                                   3.90      1057\n\n$2 EXACTOR (1-2) paid 12.00, pool 2334\n$1 SUPERFECTA (1-2-6-4) paid 174.50, pool 2675\n$2 TRIACTOR (1-2-6) paid 70.70, pool 3010\n$1 WIN FOUR (1-2-2-1) paid 50.05, pool 4930\n$.20SF 34.90 $.20W4 10.01\n\n1 MILE, TROT, PURSE $8,800.\nN/W $50000. (F & M $62500.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Whosgoingtocatchus          1    1/1     1/H     1/1     1/1      1/1Q       1:59.1  30.1 A Carroll        1.00*  J Pond\n2   Tymal Wizard=               2    2/1     3/1H    3/1H    2/1      2/1Q       1:59.2  30.1 P Mackenzie      4.55   Alan W Fair\n6   Howie=                      6    3@/1H   2@/H    2@/1    3/1H     3/3H       1:59.4  30.3 R Shepherd       5.45   C Yates\n4   Irish Thunder               4    4/3     4/2H    4/2H    4/2H     4/4        2:00    30.3 L House         14.00   P Brickman\n5   Windsun Hugo                5    6/6     6@/5    5@/3    5/3      5/4Q       2:00    30.2 R Holliday      14.25   K Di Cenzo\n9   William Star                9    5/5     5/4     6@/4    6/3H     6/4Q       2:00    30.1 J Maguire       16.20   J Maguire\n7   Allies Gift                 7    8/8     8@X/8   7@@/4H  7/4      7/4H       2:00    30.1 B Mcclure        7.85   L Ouellette\n3   Hot Stikynsweet             3    7/7     7/7H    8/6     8/5      8/5H       2:00.1  30   S Young         36.25   G Carachi\n8   All Out Henry               8    9/9     9/9     9@/6H   9/6      9/5T       2:00.2  30.1 Do Brown        20.60   P Forgie\nTime: 29.2, 59, 1:29, 1:59.1 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Whosgoingtocatchus  (b,m,4 - Muscle Mass-Who Tookem-Inquirer)\n                         Owner: Joanne K Pond,Hawkestone,ON\n2nd  Tymal Wizard        (b,g,4 - Kadabra-Patsys Point-Striking Sahbra)\n                         Owner: Alan W Fair,Ancaster,ON\n3rd  Howie               (b,g,4 - Deweycheatumnhowe-Tequila Slammer-Yankee Glide)\n                         Owner: Frank C Lamacchia,Brantford-Wayne Deserres,Burlington,ON\n8\n1-Rain Cloud Hanover        8.10   4.90   3.50      1437\n2-Tilikum                          2.70   2.40       933\n6-Doo Wee Rusty                           3.00       890\n\n$2 EXACTOR (1-2) paid 17.90, pool 1514\n$1 SUPERFECTA (1-2-6-3) paid 205.55, pool 2548\n$2 TRIACTOR (1-2-6) paid 148.20, pool 2694\n$.20SF 41.11\n\n1 MILE, PACE, PURSE $5,200.\nFILLIES & MARES - N/W $2750. LAST 3\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Rain Cloud Hanover          1    1/1H    1/1     1/1     1/1H     1/T        1:55.1  28.3 P Mackenzie      3.05   C Nicol\n2   Tilikum                     2    2/1H    2/1     3/1H    2/1H     2/T        1:55.2  28.3 D St Pierre      1.85*  T Staley\n6   Doo Wee Rusty(L)            6    7/8     3@/1H   2@/1    3/2      3/5Q       1:56.1  29.2 J Harris         4.15   J Harris\n3   Miss Brandi K               3    3/3     4/3     5/3H    4/3      4/6Q       1:56.2  29.1 R Shepherd       8.40   D Obrien\n4   Fast Flyin Mach             4    4/4H    6/5     6@/4H   6/4H     5/8        1:56.4  29.2 D Fritz         27.45   D Fritz\n7   Island Blue                 7    8/9H    5@/3H   4@/2    5/3H     6/8T       1:57    30   L House         58.95   S Mcniven\n9   Cards That Count            9    6/7     8@/6H   8@/7    8/8      7/14       1:58    30   R Holliday      16.80   P Core\n5   Emerald Rihanna             5    5/6     7/6     7/6H    7/7      8/16       1:58.2  30.3 N Steward        3.95   C Schneider Jr\n8   Winning Matrimony           SCRATCHED - JUDGES                                                                    \nTime: 27.2, 58, 1:26.3, 1:55.1 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Rain Cloud Hanover  (b,m,5 - Art Major-River Hanover-The Panderosa)\n                         Owner: Christopher J Nicol,Waterdown,ON\n2nd  Tilikum             (br,m,4 - Jeremes Jet-Alice Emily-Bettors Delight)\n                         Owner: Denis St Pierre-Tiffanee N Staley,Guelph,ON\n3rd  Doo Wee Rusty       (b,m,5 - Somebeachsomewhere-Girly Brown-Art Major)\n                         Owner: Jack Harris,Hagersville,ON\n9\n3-Spy Flex                 10.30   3.60   3.10      1484\n4-Don Luigi                        5.30   3.60       716\n1-Toss It Back                            3.70       725\n\n$2 EXACTOR (3-4) paid 44.90, pool 1457\n$1 SUPERFECTA (3-4-1-7) paid 1002.80, pool 1986\n$2 TRIACTOR (3-4-1) paid 190.10, pool 2034\n$.20SF 200.56\n\n1 MILE, TROT, PURSE $7,800.\nN/W $25000. (F & M $31250.) LIFETIME (W-ALL)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Spy Flex=                   3    1/1     1/1     1/H     1/1      1/NK       2:01.1  30.3 G Rooney         4.15   F Drouillard\n4   Don Luigi                   4    2/1     2/1     3/1H    2/1      2/NK       2:01.1  30.2 J Harris         6.70   R Griffiths\n1   Toss It Back                1    4/4H    4/2H    4/3     4/3      3/1        2:01.2  30.1 P Mackenzie      4.65   P Hunt\n7   Talbotcreek Suzie=          7    3/2     3@/1H   2@/H    3/1H     4/5        2:02.1  31.3 G Mcknight       5.85   G Mcknight\n6   Nashville                   6    5/6H    5@/3    5@/3H   5/3H     5/7Q       2:02.3  31.2 R Holliday       3.60*  N Elliott\n8   Dead Red Hitter=            8    7/9H    7/6     7/5H    6/5      6/7T       2:02.4  31.1 A Carroll       71.55   M Giles\n9   Tiz                         9    6/8     6@/5    6@/4H   7/5H     7/8        2:02.4  31.2 B Forward       18.25   J Pedden\n5   Holiday Bro                 5I   8/10H   8/8     8/6H    8/7      8/10T      2:03.2  31.3 T Moore          5.60   I Gallant\n10  Leroys Dream=               2X   9/12    9/9     9/8H    9/11     9/20       2:05.1  33   A Macdonald      6.95   A Macdonald\n2   La Bella Rosa               SCRATCHED - VET(SICK)                                                                 \nTime: 29, 1:00.3, 1:30.3, 2:01.1 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Leroys Dream-BREAKS, La Bella Rosa-VET\n\n1st  Spy Flex            (b,h,4 - Federal Flex-Scottish Delight-Angus Hall)\n                         Owner: Fred S Drouillard,Dutton,ON\n2nd  Don Luigi           (b,g,4 - Windsong Espoir-Bees To Honey-Berndt Hanover)\n                         Owner: Douglas B Weldon,Arva,ON\n3rd  Toss It Back        (b,f,3 - Majestic Son-Backflip-Cantab Hall)\n                         Owner: Leo V Fleming,Campbellville-Patrick J Hunt,Cambridge,ON\n10\n4-Lady Caterina            14.90  11.70   7.90      1615\n1-Chewey                           2.80   2.50       822\n9-Noble Power                             4.90       592\n\n$2 DAILY DOUBLE (3-4) paid 285.90, pool 504\n$2 EXACTOR (4-1) paid 153.40, pool 1602\n$1 SUPERFECTA (4-1-9-6) paid 2421.85, pool 1971\n$2 TRIACTOR (4-1-9) paid 1593.50, pool 2684\n$1 WIN FOUR (1-1-3-4) paid 5529.90, pool 2602\n$.20HI5 4 1 9 6 2 3340.05 POOL 2543 $.20SF 484.37 $.20W4 1105.98\n\n1 MILE, TROT, PURSE $5,000.\nN/W $2500. (F & M $3125.) LAST 3 (W/O $5000. (F & M $6250.) LAST 5 N/E)\n(W/O $25000. (F & M $31250.) IN 2016 N/E)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Lady Caterina=              4    2/1     2/1H    2/1     3/1H     1/NS       2:00.1  31   N Steward        6.45   Alan D Fair\n1   Chewey=                     1    1@/1    1/1H    1/1     1/H      2/NS       2:00.1  31.1 B Mcclure        1.30*  E Galinski\n9   Noble Power                 9    3/2     3@/2    3@/1H   2/H      3/1        2:00.2  31.1 P Mackenzie     10.10   S Kerwood\n6   Excellence                  6    4/3     5/4     4/2     4/3      4/1T       2:00.3  31.1 J Harris         8.00   I Downey\n2   Increditable(L)             2    5/4     4@/3    5@/3    5/3H     5/2T       2:00.4  31.1 R Shepherd       3.85   J Dupont\n7   Incredable Frank(L)         7    8/7H    8/7H    8/7     7/6      6/3H       2:00.4  30.2 A Carroll        7.35   R Moreau\n10  Mr Putter                   5    7/6     7/6H    6/5     6/4H     7/4H       2:01    31   R Holliday      18.85   T Genoe\n3   Lima Playtime               3    6/5     6@/5    7/6     8/8      8/6T       2:01.3  31.2 S Barrington    24.40   Ri Zeron\n8   Nomad=(L)                   8    9/9     9@/8    9/8H    9/9      9/9        2:02    31.2 Do Brown        34.10   L Jonasson\n5   Lady Dynamite=(L)           SCRATCHED - VET(SICK)                                                                 \nTime: 28.2, 59, 1:29, 2:00.1 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Lady Dynamite-VET\n\n1st  Lady Caterina       (b,m,4 - Holiday Road-The Lady Money-Credit Winner)\n                         Owner: Elizabeth Fair,Ancaster,ON\n2nd  Chewey              (b,g,10 - Trainforthefuture-Marie Adonno-Overcomer)\n                         Lessee: Kingfisher Farm,Seneca,ON\n3rd  Noble Power         (br,h,4 - Muscles Yankee-Pilgrims Queen-Broadway Hall)\n                         Owner: Rene Dion,Saint-Lazare,QC-Susanne J Kerwood,Rockwood,ON\nTotal Purse:  $62,200\nTotal Handle: $139,780\n(Not Official CPMA Information)\n\n
115	10	0723	\n1\n\n1 MILE, BOTH.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   A Crafty Lady               2    3/4     3@/2H   1/2     1/3      1/4T       1:59.3  29.3 R Shepherd           NB A Hohner\n8   Rods Famous Ribs            6    4/5T    4@/4    3@/2H   2/3      2/4T       2:00.3  30.1 N Day                NB R Moore\n3   Thor Seelster(T)            3    5/7Q    5/5     5@/4    4/5      3/14Q      2:02.2  31.3 R Holliday           NB N Elliott\n1   Twin B Serenity             1    2/1H    2/1H    4/3     5/5H     4/18Q      2:03.1  32.3 R Gebhardt           NB R Gebhardt\n5   Jettin To Vegas             5    1/1H    1/1H    2/2     3/4      5/19T      2:03.3  33.1 W Tymcio             NB W Tymcio\n4   First N Third               X4X  6/27Q   6/DIS   6/DIS   6/DIS    6/DIS                   J Lee                NB J Lee\nTime: 29.2, 1:00.4, 1:30, 1:59.3 (Temperature: 28, Condition: FT, Variant: 0)\nJudges List: First N Third-BREAKS\n\n1st  A Crafty Lady       (b,f,3 - Mach Three-Cams Leading Lady-Million Dollar Cam)\n                         Owner: Robert L Hamather,Exeter,ON\n2nd  Rods Famous Ribs    (b,g,11 - Hi Ho Silverheels-Beast Of Eden-Denali)\n                         Owner: Ruth A Moore-James G Hastie,Chatsworth,ON\n3rd  Thor Seelster       (b,g,7 - Pegasus Spur-Tia Seelster-Angus Hall)\n                         Owner: Natalie D Elliott,Clinton,ON\n
129	15	0723	\n1\n\n1 MILE, BOTH.QUALIFIER - TROT AND PACE\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Nothing But Bad             2    1/1H    2/2Q    1/5H    1/10     1/10H      2:00.4  30.2 J Gillespie          NB T Gillespie\n4   Featured Illusion(T)        4    3/7     3/8H    3/9     2/10     2/10H      2:02.4  30.3 M Johnson            NB M Johnson\n5   Top Dollar(T)               5    4/8H    4/10H   4/11    4/12H    3/12       2:03.1  30.3 A Larsen             NB A Larsen\n1   Casimir Q Motion            1    5/11    5/13    5/13H   5/14     4/14T      2:03.4  30.4 G Brown              NB D Mccaw\n3   Oaklea Victor(T)            3    2/1H    1/2Q    2/5H    3/10H    5/19       2:04.3  33.1 J Bailey             NB G Hart\n6   Melanie C=(T)               6    6/13H   6/16H   6/17    6/19     6/21H      2:05    31.1 B Collins            NB B Collins\nTime: 29.1, 59.3, 1:30.2, 2:00.4 (Temperature: 31, Condition: FT, Variant: 0)\n\n1st  Nothing But Bad     (br,c,3 - Badlands Hanover-Nothing Scares Me-Goliath Bayama)\n                         Owner: Bonnie Oddie,Joyceville,ON\n2nd  Featured Illusion   (b,g,4 - Kadabra-Featured Image-Balanced Image)\n                         Owner: Denise Ball,Bailieboro,ON\n3rd  Top Dollar          (b,g,4 - Deweycheatumnhowe-Moms Millionaire-Pine Chip)\n                         Owner: Ann Karin Larsen,Norwood-Steve D Organ,Aurora-Stig C Westrum-Tor Jan Larsen,Norwood,ON\n
134	16	0721	\n1\n5-Janettes Image            4.00   3.60   3.90     15995\n6-Diamond Tested                  15.80   8.90      6649\n3-Misty De Vie                            8.20      5152\n\n$2 EXACTOR (5-6) paid 68.80, pool 19200\n$1 SUPERFECTA (5-6-3-1) paid 342.70, pool 17577\n$2 TRIACTOR (5-6-3) paid 302.20, pool 26185\n\n1 MILE, PACE, PURSE $14,000.\n2 & 3 YEAR OLD FILLIES, NW 1 RACE OR $7,000 LIFETIME.\nAE: NOT AVERAGING $1,800 PER START LIFETIME.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Janettes Image              5    4/5T    4/5T    3@/2H   2/NK     1/H        1:54.3  27.3 Ja Macdonald     1.00   D Nixon\n6   Diamond Tested              6    6/10H   6/10H   5@/4H   3/2      2/H        1:54.3  27.1 D Mcnair        25.90   M Brethour\n3   Misty De Vie                3    5/8H    5/8Q    6/6     6/6H     3BE/2H     1:55    27.1 C Christoforou  15.50   G Hunt\n1   Place To Rocknroll          1    1/1T    1/2Q    1/2Q    1/NK     4/2H       1:55    28.2 S Filion         0.85*  T Alagna\n2   Nic Nac Patty Mach          2    3/3H    3/3H    4/3T    5/4T     5/3        1:55.1  27.4 Ra Waples       20.40   C Mitchell\n4   Electric Ponder             4    2/1T    2/2Q    2/2Q    4/3H     6/5H       1:55.3  28.3 M Saftic        44.80   D Brewer\n7   City Charm                  7    7/12H   7/12H   7@/6H   7/7Q     7/12H      1:57    29.1 J Drury         67.00   B Macintosh\nTime: 27.4, 57.1, 1:26.3, 1:54.3 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Janettes Image      (b,f,3 - Rockin Image-Moselle Hanover-Cambest)\n                         Owner: Dean L Nixon,Amherstburg,ON-Dr Kenneth M Rucker,Mondovi,WI\n2nd  Diamond Tested      (br,f,3 - Bettors Delight-More Diamonds-Dragon Again)\n                         Owner: Murray L Brethour,Sunderland-Noblock Racing Stable,Collingwood-Dean S Campbell,Orleans,ON\n3rd  Misty De Vie        (br,f,3 - Dragon Again-Smoldering Heart-Albatross)\n                         Owner: George E Hunt,Otonabee-Marvyn Walter McKee-Greg G Hunt,Peterborough,ON\n2\n6-Candlelight Dinner        2.20   2.10   0.00     11639\n5-Black Jack Pat                   4.10   0.00     57373\n2-Moment To Ponder                        0.00          \n\n$2 DAILY DOUBLE (5-6) paid 5.30, pool 16528\n$2 EXACTOR (6-5) paid 8.90, pool 19744\n$1 SUPERFECTA (6-5-2-7) paid 46.95, pool 15665\n$2 TRIACTOR (6-5-2) paid 36.90, pool 22264\nNO SHOW WAGERING\n\n1 MILE, PACE, PURSE $14,000.\nWHENUWISHUPONASTAR - 1ST LEG - 2 YEAR OLD FILLIES.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Candlelight Dinner          5    3@/2    1/2     2@/H    1/2      1/6        1:54.2  27.2 J Drury          0.10*  C Coleman\n5   Black Jack Pat              4    1/2     2/2     3/2H    3/3T     2/6        1:55.3  28.1 J Jamieson      12.25   D Menary\n2   Moment To Ponder            2    4/4     4/5T    6@/6    6/8Q     3/7Q       1:55.4  27.3 Ra Waples       16.85   R Mcintosh\n7   Touching Thought            6    6/7H    6@/8Q   1/H     2/2      4/7T       1:56    29   Trev Henry       9.30   R Mcintosh\n1   Braida Hanover              1    2/2     3/4     5/4H    4/6H     5/7T       1:56    28.1 Ph Hudon        39.95   Colin Johnson\n3   Ohello Blue Chip(L)         3    5/5T    5/8     4@/4Q   5/7H     6/12       1:56.4  29   A Macdonald     41.35   A Macdonald\n8   Takeyourbreathaway          7    7/10    7@/11   7/8T    7/11H    7/13H      1:57    28.1 C Christoforou  46.75   B Macintosh\n4   Somemoneysomewhere          SCRATCHED - VET(SICK)                                                                 \nTime: 28.4, 58.3, 1:27, 1:54.2 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Somemoneysomewhere-VET\n\n1st  Candlelight Dinner  (b,f,2 - American Ideal-Time N Again-Jate Lobell)\n                         Owner: Mac T Nichol,Burlington,ON-Let It Ride Stables Inc,Boca Raton,FL-Howard A Taylor,Philadelphia,PA\n2nd  Black Jack Pat      (b,f,2 - Well Said-Mrs Noce-Camluck)\n                         Owner: Dave Van Camp,Hamilton,ON\n3rd  Moment To Ponder    (b,f,2 - Ponder-Breathtacular-No Pan Intended)\n                         Owner: Robert McIntosh Stables Inc,Windsor-Max J Newham,Merlin,ON\n3\n2-Inner Drive               3.50   2.30   2.20     22219\n6-Hab Faith                        2.80   2.70      6844\n5-Parkhill Nocredit                       3.10      2684\n\n$2 EXACTOR (2-6) paid 12.80, pool 23873\n$1 SUPERFECTA (2-6-5-1) paid 77.50, pool 20137\n$2 TRIACTOR (2-6-5) paid 32.70, pool 26953\n$1 PICK 3 (5-6-2) paid 9.60, pool 8164\n\n1 MILE, TROT, PURSE $18,000.\nONTARIO SIRES STAKES - GRASSROOTS - 2 YEAR OLD FILLIES.\nSTARTING FEE $350.00\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Inner Drive                 2    2/1T    2/T     2/1T    2/1H     1/NK       1:59.4  30.1 P Macdonell      0.75*  R Mcintosh\n6   Hab Faith=                  5    4/6Q    1@/T    1/1T    1/1H     2/NK       1:59.4  30.3 D Mcnair         1.90   R Mcnair\n5   Parkhill Nocredit           4    1/1T    3/3     3/4     3/4      3/2Q       2:00.1  30.1 S Byron          9.30   J Bax\n1   Sunnyday Kash               1    3/4Q    4/5T    4/10T   4/14H    4/19       2:03.3  32.1 Da Wall         86.05   L Gibbons\n8   Oh Miss Sophie              7    6/10T   X6X/10Q 6/29    6/30     5/23H      2:04.2  29.2 Ra Waples        5.50   Ro Waples Jr\n7   Ticket To Seattle           6    5/8H    5/7T    X5X/16Q 5/28     6/23H      2:04.2  32   Ja Macdonald    36.15   M Steacy\n3   Duet Seelster=              3    X7/19H  7/DIS   7/DIS   7/DIS    7/DIS                   R Holliday      74.70   R Maclean\n4   Blink Shes Gone=            SCRATCHED - JUDGES(TRANSPORTATION)                                                    \nTime: 29.4, 1:00, 1:29.1, 1:59.4 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Duet Seelster-BREAKS\n\n1st  Inner Drive         (b,f,2 - Kadabra-Urge To Splurge-Cash Hall)\n                         Owner: Robert McIntosh Stables Inc,Windsor,ON-C S X Stables,Liberty Center,OH-Dave A Boyle,Bowmanville,ON\n2nd  Hab Faith           (b,f,2 - Kadabra-Sweetmarie Ofgrace-Berndt Hanover)\n                         Owner: Gwendolyn L McNair,Walkerton-R Gregg McNair,Guelph,ON\n3rd  Parkhill Nocredit   (b,f,2 - Federal Flex-Harlequin Seelster-Duke Of York)\n                         Owner: Bax Stable,Campbellville-Marshall Bax,Hamilton,ON\n4\n9-Three Rivers Dell        18.50   6.20   3.80     25943\n6-Mayfield Duke                   12.80   6.00      8203\n5-Jack Rackham                            2.70      4415\n\n$2 EXACTOR (9-6) paid 133.90, pool 24982\n$1 SUPERFECTA (9-6-5-4) paid 741.60, pool 16884\n$2 TRIACTOR (9-6-5) paid 497.00, pool 22269\n$1 PICK 3 (6-4-9) paid 14.75, pool 4448\n\n1 MILE, PACE, PURSE $17,000.\n4 YEAR OLDS & YOUNGER, NW 2 RACES OR $20,000 LIFETIME.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n9   Three Rivers Dell(L)        9    1/NK    2/1H    3/2     2/Q      1/1        1:53.3  28.2 S Filion         8.25   R Fellows\n6   Mayfield Duke               6    4/3H    4/5H    7/5T    6/3      2/1        1:53.4  27.4 M Saftic        14.05   J Green\n5   Jack Rackham                5    8/11T   8@/10   6@/4H   4/1H     3/2        1:54    28.2 Trev Henry       1.30*  A Montini\n4   Archangel Three             4    7/10    6@/8Q   4@/2T   1/Q      4/2Q       1:54    28.3 Ri Zeron         3.85   K Benn\n2   To His Credit               2    5/6     5@/6H   2@/1    5/2      5/7        1:55    30   J Jamieson       2.50   C Jamieson\n1   Corsica Hall(L)             1    3/1T    3/3Q    5/3T    7/3H     6/9H       1:55.2  29.4 J Drury         27.35   C Auciello\n7   Rose Run Ranger             7    9/13T   9/12H   8@/8Q   8/7T     7/12H      1:56    29.3 R Holliday      89.60   J Pentland\n10  Chalk Player                10   2@/NK   1/1H    1/1     3X/H     8/12T      1:56.1  31.2 D Mcnair        19.80   J Ritchie\n8   Einhorn(L)                  8    10/16Q  10/17   10/14H  10/13    9/14T      1:56.3  29   Ja Macdonald   106.65   M Rogers\n3   Jet Black Cadillac          3    6/8Q    7/8T    9/8T    9/11H    10/23H     1:58.1  31.3 S Condren      110.60   Alan W Fair\nTime: 27.1, 55.4, 1:24.4, 1:53.3 (Temperature: 29, Condition: FT, Variant: 0)\n\n1st  Three Rivers Dell   (b,g,4 - Mach Three-Tug River Dell-Abercrombie)\n                         Owner: Synerco Ventures Inc,Toronto,ON\n2nd  Mayfield Duke       (b,g,3 - Santanna Blue Chip-Pindar Blue Chip-Jennas Beach Boy)\n                         Owner: James A Green,Britt-Carman J Emery,Point Au Baril,ON\n3rd  Jack Rackham        (b,c,3 - Bettors Delight-Fionavar Hanover-The Panderosa)\n                         Owner: Dale C Towle,Leamington,ON\n5\n6-Monopoly                 23.70   9.50   5.70     32244\n2-Agent Dinozzo                    3.90   3.20     11335\n7-Silky Flashy Nfast                      2.90      5705\n\n$2 EXACTOR (6-2) paid 89.00, pool 32008\n$1 SUPERFECTA (6-2-7-9) paid 669.55, pool 22494\n$2 TRIACTOR (6-2-7) paid 345.90, pool 30976\n$1 PICK 3 (2-9-6) paid 471.60, pool 5259\n$1 P5 5,6,2,9,6 $1416.15 POOL 47966\n\n1 MILE, TROT, PURSE $14,000.\n4 YEAR OLDS & YOUNGER, NW 1 RACE OR $7,000 LIFETIME. NO ALLOWANCES.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Monopoly                    6    2/1H    2/1H    2/1H    1/T      1/4        1:56.2  29.3 Trev Henry      10.85   G Cicero\n2   Agent Dinozzo=              2    6/13T   6@/10T  6@@/7   4/4H     2/4        1:57.1  29.1 S Young          1.10*  V Hayter\n7   Silky Flashy Nfast          7    3/3H    3/3T    3/3Q    3/2Q     3/5Q       1:57.2  30.1 M Baillargeon    2.65   B Baillargeon\n9   Rose Run Rudi               9    1@/1H   1/1H    1/1H    2/T      4/7Q       1:57.4  31.1 S Byron          7.35   D Byron\n1   Uf Musclemass Star          1    4/6Q    4/5T    4/5Q    5/6      5/11Q      1:58.3  31   S Filion         9.45   R Moreau\n10  Archery=                    10   8/19Q   7@/13H  7/7Q    6/7      6/11T      1:58.4  30.4 D Mcnair        57.30   R Mcnair\n8   Scotties Spirit=            8    5/10T   5/8Q    5@/6T   7/7T     7/16Q      1:59.3  31.3 C Christoforou  18.85   M Brethour\n3   Copper Blues=               3    7/17H   8/18    8/16T   8/18H    8/26H      2:01.3  31.3 C Steacy        70.15   M Steacy\n4   Deuce Deuce Deuce           4X   9/26    9/35    9/33T   9/33     9/35       2:03.2  30   J Moiseyev      13.35   J Moiseyev\n5   Stormont Viceroy=           X5   10/DIS  10/DIS  10/DIS  10/DIS   10/DIS                  Ja Macdonald    91.95   N Jones\nTime: 28, 57.1, 1:26.3, 1:56.2 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Deuce Deuce Deuce-BREAKS, Stormont Viceroy-BREAKS\n\n1st  Monopoly            (b,g,3 - Muscle Mass-Pretty Pepi-Angus Hall)\n                         Owner: Gino Cicero-Marlene V Heath,Melancthon,ON\n2nd  Agent Dinozzo       (b,c,3 - Manofmanymissions-Danae-Andover Hall)\n                         Owner: Joann M Hayter,Stratford,ON\n3rd  Silky Flashy Nfast  (b,f,3 - Kadabra-Silky Celine-Angus Hall)\n                         Owner: Benoit O Baillargeon,Guelph-Diane N Ingham,Mount Pleasant,ON\n6\n5-Powerful Mission          6.60   3.80   3.50     23403\n8-Man Shes Hot                     3.10   2.40      6623\n2-Whole Lot Of Sugar                      2.50      3508\n\n$2 EXACTOR (5-8) paid 26.90, pool 25616\n$1 SUPERFECTA (5-8-2-4) paid 130.80, pool 17130\n$2 TRIACTOR (5-8-2) paid 77.60, pool 23840\n$.20 W3 9,6,5, $405.66 POOL 2696\n\n1 MILE, TROT, PURSE $18,000.\nONTARIO SIRES STAKES - GRASSROOTS - 2 YEAR OLD FILLIES.\nSTARTING FEE $350.00\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Powerful Mission            4    3/5Q    3/4     2@/1    1/Q      1/3        1:59.2  28.4 Ph Hudon         2.30   K St Charles\n8   Man Shes Hot                7    4/7     4/6     4@/2T   3/2Q     2/3        2:00    29   C Christoforou   1.85*  D Fontaine\n2   Whole Lot Of Sugar          1    1/2T    1/2     1/1     2/Q      3/3        2:00    29.3 J Jamieson       3.30   G Demers\n4   You Cant Afford Me          3    6/10H   6/10T   6/7T    6/6T     4/5Q       2:00.2  28.2 R Mayotte        6.75   S Mceneny\n3   Warrawee Storm              2    5/8H    5/8Q    5/5H    5/6T     5/9H       2:01.1  29.4 W Henry         40.15   W Henry\n6   Hopeswishesndreams          5    2/2T    2/2     3/2Q    4/3H     6/12T      2:02    31.1 D Mcnair         6.90   R Mcnair\n7   Majestic Wanda              6    X7@/18  7/25    7/DIS   7/DIS    7/DIS                   P Macdonell     21.10   J Bax\n1   Rare Ruby                   SCRATCHED - VET(SICK)                                                                 \nTime: 29.2, 1:00, 1:30.2, 1:59.2 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Majestic Wanda-BREAKS, Rare Ruby-VET\n\n1st  Powerful Mission    (br,f,2 - Manofmanymissions-The Power Of Magic-Kadabra)\n                         Owner: E C S Racing LLC,Rockford,MI\n2nd  Man Shes Hot        (b,f,2 - Manofmanymissions-No Sugar Tonight-Angus Hall)\n                         Owner: Dany Fontaine,Lachenaie-Ecurie Gaetan Bono Inc,Montreal-Marco Manna,Laval-Jean Francois Reid,Anjou,QC\n3rd  Whole Lot Of Sugar  (b,f,2 - Windsong Espoir-Maple Sugar-Malabar Maple)\n                         Owner: Les Ecuries GLD Inc,St-Andre-Avelin-La Ferme Tag Inc,Papineauville-Jean Roch Marois,St-Joachim-De-Shefford,QC\n
135	16	0721	\n7\n1-Give Em Heck              3.60   2.70   2.10     22283\n2-P L Dangerous                    6.70   3.50      8541\n8-Maracasso                               3.30      4254\n\n$2 EXACTOR (1-2) paid 27.90, pool 27055\n$1 SUPERFECTA (1-2-8-5) paid 479.40, pool 18512\n$2 TRIACTOR (1-2-8) paid 113.60, pool 24793\n$1 PICK 3 (6-5-1) paid 694.35, pool 5935\n$1 PICK 4 (9-6-5-1) paid 4534.00, pool 53319\n\n1 MILE, PACE, PURSE $8,000.\nCLAIMING $8,000. ALLOWANCES FOR AGE & SEX.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Give Em Heck(L)             1    1/1T    1/1H    1/1T    1/1H     1/1H       1:54    29   Trev Henry       0.80*  M Weller\n2   P L Dangerous               2    5/8Q    5@/6H   4@@/3   2/1H     2/1H       1:54.1  28.3 Ja Macdonald    10.35   B Gibson\n8   Maracasso(L)                8    2/1T    2/1H    2/1T    3/2H     3/3H       1:54.3  29.1 Ra Waples        3.45   N Gallucci\n5   Rolandale Buster            5    3/4     3@/3Q   3@/1T   4/3Q     4/5Q       1:55    29.3 G Ketros        33.20   G Ketros\n6   Evening Job(L)              6    4/6     4/4T    5/3Q    5/4T     5/5T       1:55.1  29.3 Ph Hudon        21.50   T Riley\n7   Big Harold(L)               7    8/17Q   7@/9H   7@@/5Q  6/4T     6/8Q       1:55.3  29.3 S Filion         9.95   J Libby\n4   Highland Boreas             4    6/11Q   6/8H    6/5     7/5H     7/19       1:57.4  31.4 J Jamieson      15.40   M Fine\n3   Twin B Sportsman            3    7/15    8@/11H  8@/8    8/10Q    8/19       1:57.4  31.1 S Byron         69.30   C Campbell\n9   Hp Black Shadow(L)          9X   9/DIS   9/DIS   9/DIS   9/DIS    9/DIS                   D Mcnair         8.35   V Puddy\nTime: 26.4, 55.4, 1:25, 1:54 (Temperature: 29, Condition: FT, Variant: 0)\nGIVE EM HECK claimed for $8,000 by Copley Stables, Jody Sanderson, Dean R Larkin.\n\n1st  Give Em Heck        (br,g,5 - Perfect Union-Tristar Valerie-Camluck)\n                         Owner: Mike Weller,Georgetown,ON\n2nd  P L Dangerous       (b,g,9 - Cam Dunc-Gently Hanover-Abercrombie)\n                         Owner: William C Gibson,Kingston,ON\n3rd  Maracasso           (b,g,4 - Lis Mara-Miss Picasso-Real Artist)\n                         Owner: Bruno Didiomede,Hamilton,ON\n8\n2-Golden Son                2.90   2.80   2.40     28153\n5-Mostinterestingman               4.90   3.20      7516\n6-French Bastille                         5.30      3792\n\n$2 EXACTOR (2-5) paid 16.40, pool 29499\n$1 SUPERFECTA (2-5-6-9) paid 489.85, pool 21642\n$2 TRIACTOR (2-5-6) paid 94.50, pool 28196\n$1 PICK 3 (5-1-2) paid 36.05, pool 6699\n\n1 MILE, TROT, PURSE $17,000.\n4 YEAR OLDS & YOUNGER, NW 2 (FM 3) RACES OR $20,000 (FM $25,000) LIFETIME.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Golden Son                  2    1/1T    1/1T    1/1H    1/2H     1/4        1:55.2  28.3 S Filion         0.45*  R Moreau\n5   Mostinterestingman=         5    4/5H    4/5H    3@/4H   2/2H     2/4        1:56.1  28.3 S Condren       10.35   M Dupuis\n6   French Bastille=            6    6/10H   6/9     6@/7H   4/5T     3/4        1:56.1  28   Ja Macdonald    24.85   M Steacy\n9   I Want Kandy(L)             9    2/1T    2/1T    2/1H    3/2H     4/7H       1:56.4  29.4 Ph Hudon        57.20   A Montini\n3   Dewtiful Lass=              3    5/8Q    5/7Q    5/6T    6/7Q     5/10Q      1:57.2  29.1 Ra Waples      118.15   B Macdonald\n1   Stormont Esquire=(L)        1    3/3T    3/3H    4/4T    5/7Q     6/13H      1:58    30.1 J Jamieson      46.45   K Benn\n10  Moonlight Cocktail          10   8/15T   8/14H   8@/14T  7/14     7/13T      1:58.1  28.2 P Macdonell     23.35   J Bax\n7   Dewy Dont Cheat             7    7/14Q   7/12H   7/13Q   8/16     8/17H      1:58.4  29.2 Ri Zeron         2.45   Ri Zeron\n8   Dynamic Edge                X8X  10/37T  9/24H   9/22H   9/27T    9/32       2:01.4  30.3 D Mcnair        52.05   R Mcnair\n4   Classical Son=              4X   X9X/17  10/DIS  10/DIS  10/DIS   10/DIS                  M Baillargeon  143.40   S Larocque\nTime: 28.1, 58.1, 1:26.4, 1:55.2 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Classical Son-BREAKS\n\n1st  Golden Son          (b,g,3 - Majestic Son-Dawn Dream-Enjoy Lavec)\n                         Owner: Gary P & Fay E Clark,Oriskany Falls,NY\n2nd  Mostinterestingman  (b,g,3 - Manofmanymissions-No Sugar Tonight-Angus Hall)\n                         Owner: Twenty Five Seventeen,Campbellville,ON\n3rd  French Bastille     (b,g,3 - Kadabra-Brigham Dream-Kaisy Dream)\n                         Owner: Landmark 8 Racing Stable,Kingston,ON-Hudson Standrdbrd Stb Inc,Hudson,QC-Bridle Path Stables Ltd,Ossining,NY\n9\n6-Ideal Wheel               2.70   2.40   2.10     25714\n9-Darlings Dragon                  3.50   3.20      7865\n3-Woodacudashuda                          5.70      4678\n\n$2 EXACTOR (6-9) paid 9.20, pool 27480\n$1 SUPERFECTA (6-9-3-7) paid 103.25, pool 23465\n$2 TRIACTOR (6-9-3) paid 72.70, pool 26796\n$1 PICK 3 (1-2-6) paid 6.75, pool 5823\n\n1 MILE, PACE, PURSE $14,000.\n2 YEAR OLDS, NW $5,000 LIFETIME.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n6   Ideal Wheel                 5    3/3H    3/3     2@/H    1/1T     1/2H       1:54    28   J Drury          0.35*  C Coleman\n9   Darlings Dragon             8    1/2     2/1H    3/2Q    3/2      2/2H       1:54.2  28   D Dupont         4.30   M Dupont\n3   Woodacudashuda              2    5/6T    5/6T    4/4Q    5/6      3/7Q       1:55.2  28.3 D Mcnair        21.70   J Morrison\n7   One Source                  6    4/5Q    4/4T    5@/4T   4/5Q     4/7T       1:55.3  28.3 S Filion         9.00   R Moreau\n5   Rock This Way               4    2/2     1/1H    1/H     2/1T     5/8T       1:55.4  29.4 M Baillargeon    8.90   B Baillargeon\n8   Heza Big Dealer             7    8/11T   7/13T   7@/11Q  6/12T    6/9H       1:55.4  27.3 Ph Hudon        30.40   M Brethour\n1   Word Game                   1    6/8     6/9     6/9T    7/17T    7/29       1:59.4  31.4 M Saftic       101.65   R Mcnair\n4   Mavericks A Terror          3    7/10Q   X8/18T  8/22H   8/30T    8/35       2:01    30.3 Ja Macdonald    81.90   S Mceneny\n2   Southwind General           SCRATCHED - VET(SICK)                                                                 \nTime: 28.1, 57.3, 1:26, 1:54 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Mavericks A Terror-BREAKS, Southwind General-VET\n\n1st  Ideal Wheel         (b,c,2 - American Ideal-Bet On Luck-Bettors Delight)\n                         Owner: Mac T Nichol,Burlington,ON\n2nd  Darlings Dragon     (br,c,2 - Dragon Again-Darling Angel-Artsplace)\n                         Owner: Marie B Dupont,Campbellville,ON\n3rd  Woodacudashuda      (b,c,2 - Well Said-Binions-Bettors Delight)\n                         Owner: Equus Standardbreds Inc,Hamilton-Alan M Alber,Thornhill,ON-Liv With Autism Stables LLC,Dickson City,PA\n10\n7-Anikadabra               22.70   8.20   2.50     24146\n5-P C Pipe Dream                   3.40   2.30      7150\n3-Late Shift                              2.60      3701\n\n$2 EXACTOR (7-5) paid 77.70, pool 25487\n$1 SUPERFECTA (7-5-3-2) paid 556.10, pool 19920\n$2 TRIACTOR (7-5-3) paid 147.85, pool 24301\n$1 PICK 3 (2-2-7) paid 28.75, pool 2509\n\n1 MILE, TROT, PURSE $18,000.\nONTARIO SIRES STAKES - GRASSROOTS - 2 YEAR OLD FILLIES.\nSTARTING FEE $350.00\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Anikadabra                  7    1/3Q    1/1T    1/2     1/1T     1/3        1:59.3  29.4 Ri Zeron        10.35   R Fellows\n5   P C Pipe Dream              5    6/12T   5@/9    3@/3T   3/2H     2/3        2:00.1  29.3 C Clements       1.40*  P Clements\n3   Late Shift=                 3    2/3Q    2/1T    2/2     2/1T     3/4H       2:00.2  30.1 Ja Macdonald     7.75   M Steacy\n2   Tymal Declan                2    3/6Q    3/4H    4/4Q    4/5T     4/5T       2:00.4  30.1 S Byron          6.00   J Bax\n6   Kendras Coco                X6   7/17Q   7@/10T  6/9Q    5X/8H    X5/10Q     2:01.3  30   D Boughton       1.75   J Drennan\n4   Judy Judy Judy=             4    5/10H   4/8     5/6H    6/9T     6/19Q      2:03.2  32.2 S Filion        20.60   K Jones\n1   Ionia=                      1    4/8     X6X/10H 7/24    7/28H    7/DIS                   Ra Waples       21.20   Colin Johnson\nTime: 28.4, 59.2, 1:29.4, 1:59.3 (Temperature: 29, Condition: FT, Variant: 0)\nJudges List: Kendras Coco-BREAKS, Ionia-BREAKS\n\n1st  Anikadabra          (b,f,2 - Kadabra-Anikawiesahalee-Credit Winner)\n                         Owner: Edward W Wilson,Seagrave,ON-Michael L Pozefsky,Saratoga Springs,NY\n2nd  P C Pipe Dream      (b,f,2 - Cornaro Dasolo-P C Dreams-Incredible Abe)\n                         Owner: Peter W Clements,Dobbinton,ON\n3rd  Late Shift          (br,f,2 - Majestic Son-Mississippi Dream-Dream Vacation)\n                         Owner: Landmark 9 Racing Stable,Kingston-David K Reid,Glenburnie-Stephen Klunowski,North York-Claus A Jorgensen,Etobicoke,ON\n11\n7-Mystic Deuce              5.10   3.20   3.00     32952\n5-Hemingway                        7.80   4.70     12264\n10-Highland Tartan                        5.90      6532\n\n$2 EXACTOR (7-5) paid 54.40, pool 35254\n$1 SUPERFECTA (7-5-10-6) paid 802.15, pool 24836\n$2 TRIACTOR (7-5-10) paid 358.20, pool 32942\n$1 PICK 3 (6-7-7) paid 52.70, pool 5007\n$1 PICK 4 (2-6-7-7) paid 111.80, pool 46737\nDD 7 7 $39.80, $1 HF 7,5,10,6,8 $1453.05 C/O 78178.55\n\n1 MILE, PACE, PURSE $9,000.\nCLAIMING HANDICAP $10,000 TO $12,000. ALLOWANCES FOR AGE & SEX.\nENTER IN MULTIPLES OF $1,000.\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n7   Mystic Deuce(L)             7    5/11    5/10H   6/7H    5/4Q     1/NK       1:52.4  28.4 C Christoforou   1.55*  N Gallucci\n5   Hemingway(L)                5    6/13H   7/12H   7@/8T   4/3T     2/NK       1:52.4  28.2 Trev Henry       9.65   R Moffatt\n10  Highland Tartan             10   1@/1T   1/1T    1/3H    1/1H     3/T        1:53    30.2 J Drury          8.55   M Fine\n6   Better Art(L)               6    7/15H   6@/12H  5@/6H   3/2H     4/1        1:53    29.1 S Filion         4.75   E Laybourne\n8   Velocity Headlight(L)       8    4/8T    4/8H    3@/4H   2/1H     5/3Q       1:53.2  30   D Mcnair         5.20   L Bako\n4   Stimulus Spending           4    10/21H  10/20T  10@/14  9/9      6/6T       1:54.1  28.4 Ja Macdonald    33.75   K Di Cenzo\n3   Highland Bogart             3    3/6Q    3/5     4/5H    7/6H     7/12Q      1:55.1  31.3 M Saftic        43.70   S Friend\n1   Never Been Told             1    2/1T    2/1T    2/3H    6/5T     8/12Q      1:55.1  32   Ph Hudon         4.35   A Montini\n2   P L Inferno                 2    9/19Q   9@/17H  8@@/10Q 8/7T     9/19Q      1:56.3  32   S Young         32.85   J Libby\n9   Sky Guy                     9    8@/17H  8/15H   9/13H   10/16H   10/24H     1:57.3  32.2 A Macdonald     49.15   A Macdonald\nTime: 26, 54, 1:22.3, 1:52.4 (Temperature: 29, Condition: FT, Variant: 0)\nBETTER ART claimed for $11,000 by Krista Thomas.\n\n1st  Mystic Deuce        (b,h,6 - Armbro Deuce-Cannes Festival-Artiscape)\n                         Owner: Jack & Ferne Frydman-Howard A Dinetz,Thornhill,ON\n2nd  Hemingway           (b,g,5 - Well Said-L Dees Val-Dream Away)\n                         Owner: Rickey R Moffatt,London,ON\n3rd  Highland Tartan     (br,g,5 - Major In Art-Htf Cocoa-Jate Lobell)\n                         Owner: Highland Thoroughbred FRM,Inglewood-Marty W Fine,North York,ON\nTotal Purse:  $161,000\nTotal Handle: $1,495,891\n(Not Official CPMA Information)\n\n
147	23	0723	\n1\n2-Cam Crazy                 9.20   3.90   5.20       202\n1-Windemere Johny                  2.60   2.90        62\n5-Woodmere Terror                         5.50        83\n\n$2 EXACTOR (2-1) paid 60.80, pool 134\n$2 TRIACTOR (2-1-5) paid 77.60, pool 605\n\n1 MILE, PACE, PURSE $2,500.\nATLANTIC SIRES STAKE 3 YR OLD PACING COLTS\n"B" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Cam Crazy                   2    3/2     2/1H    2/1H    2/1Q     1/H        1:59.4  30.4 M Bradley        3.60   M Bradley\n1   Windemere Johny             1    1/1     1/1H    1/1H    1/1Q     2/H        1:59.4  31   D Romo           3.95   E Watts\n5   Woodmere Terror             5    4/4     4/3H    4/2H    3/2H     3/1T       2:00.1  31   G Barrieau       4.45   A Maclean\n4   Mystic Cruiser              4    2@/1    3@/2H   3@/2H   4/4      4/8        2:01.2  32.1 E Laffin         0.30*  F Saunders\n3   Deacon Brodie               SCRATCHED - JUDGES                                                                    \nTime: 28.4, 58, 1:28.4, 1:59.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Cam Crazy           (b,g,3 - Camystic-Handful Of Success-Western Success)\n                         Owner: Paul D Walker,Vernon Bridge-Tanya Routledge,Charlottetown,PE\n2nd  Windemere Johny     (b,g,3 - Carnivore-Art Blanche-Artiscape)\n                         Owner: Windemere Farms,North Wiltshire,PE-Claude Poirier,Havre-Aux-Maisons,QC\n3rd  Woodmere Terror     (b,c,3 - Articulator-Woodmere Teardrop-Drop Off)\n                         Owner: Andrew J Maclean-Julie M Mac Pherson,Inverness,NS\n2\n1-A Bs Future              20.40   7.10   4.50       126\n5-Coasttocoastshark                3.70   2.80        68\n4-J Gs Willie                             3.80        58\n\n$2 EXACTOR (1-5) paid 41.20, pool 100\n$2 TRIACTOR (1-5-4) paid 85.40, pool 564\n\n1 MILE, PACE, PURSE $2,500.\nATLANTIC SIRES STAKE 3 YR OLD PACING COLTS\n"B" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   A Bs Future                 1X   2/1H    3/2     3/2     3/1T     1/NK       2:00    29.3 M Macdonald      9.20   B Macdonald\n5   Coasttocoastshark           5    3/2T    5/4     5/3Q    5/3      2/NK       2:00    29.2 C Macpherson     1.25*  J Wallace\n4   J Gs Willie                 4    1/1H    1/1     1/1     1/1H     3/1        2:00.1  30.1 D Spence         6.25   A Maclean\n3   J K Cowboy                  3    5@/5    2@/1    2@/1    2/1H     4/7T       2:01.3  31.2 R Perrot         1.35   R Perrot\n2   Sugar Crisp+                2    X4/4    4@/3    4/2Q    4/3      5/10T      2:02.1  31.4 K Arsenault      2.70   M Mcguigan\nTime: 29.3, 1:00.2, 1:30, 2:00 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  A Bs Future         (br,c,3 - Driven To Win-Trudys Future-Falcons Future)\n                         Owner: GG And Mac Stables,Port Hood,NS\n2nd  Coasttocoastshark   (b,c,3 - Coastocoast Yankee-Sassy Little Shark-Cams Card Shark)\n                         Owner: Shirley E Wallace,Alberton,PE\n3rd  J Gs Willie         (br,c,3 - Brandons Cowboy-Abby Best-Cambest)\n                         Owner: Angus A Maclean,Port Hood,NS\n3\n3-Sauble Liz               19.70   4.60   3.80       170\n8-Mach Vegas                       3.80   3.70        71\n4-Djs Kocakolacowboy                      2.10        69\n\n$2 DAILY DOUBLE (1-3) paid 24.50, pool 36\n$2 EXACTOR (3) paid 22.50, pool 66\n$2 TRIACTOR (3-8-4) paid 431.40, pool 633\nEX PD 3 ALL 22.50 $1 TR PD 3 8 4 431.40\n\n1 MILE, PACE, PURSE $950.\nNON WINNERS $250 L5 OR $97 PS L10 OR IN 2015-16 (MIN 10 STS)\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Sauble Liz                  3    1/1Q    1/1     2/Q     2/1Q     1/1        2:01.3  31.4 K Parris         8.85   C Covin\n8   Mach Vegas                  8    2/1Q    3/2Q    3/1T    3/2H     2/1        2:01.4  31.3 R Ellis          4.25   R Chase\n4   Djs Kocakolacowboy          4    3@/1T   2@/1    1@/Q    1/1Q     3/2T       2:02.1  32.2 H Smallwood      2.05*  H Smallwood\n5   Pick N Scoop                5    7/6     7/8H    6@/4T   4/3H     4/3        2:02.1  31.2 C Macdonald      6.05   C Macdonald\n2   Metro Man                   2    4/3     5/4T    5/3T    5/4Q     5/3H       2:02.1  31.3 D Crowe          8.55   K Gillis\n6   Bizzy Izzy                  6    8/7H    8@/9H   8/6T    7/5T     6/6Q       2:02.4  31.3 E Laffin        14.55   N White\n1   Glenview Natalie            1    5@/3H   4@/3Q   4@/2T   6/4Q     7/8Q       2:03.1  32.4 D Spence         4.90   A Johnson\n7   Rosa Santanna               7    6@/5T   6@/7H   7@/6H   8/5T     8/11       2:03.4  32.4 G Barrieau       2.65   D Ellis\nTime: 30, 59.3, 1:29.4, 2:01.3 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Sauble Liz          (b,m,6 - L H Stryker-Noble Duchess-Astreos)\n                         Owner: CC Stables,Middle Sackville,NS\n2nd  Mach Vegas          (b,g,8 - Mach Three-Vegas Strip-Keystone Raider)\n                         Owner: Bailey J Chase Merner,Truro-Max Roderick Sehl,Port Morien,NS\n3rd  Djs Kocakolacowboy  (blk,g,6 - Force Of Life-Glacier Fire-Harrods)\n                         Owner: Cyril P Harvey,Elmsdale,NS\n4\n1-Magical Cowboy            4.60   2.80   2.60       290\n5-Howmacsblackjack                 4.40   3.30       149\n6-Silverhill Storm                        9.90       107\n\n$2 EXACTOR (1-5) paid 14.10, pool 120\n$2 TRIACTOR (1-5-6) paid 86.60, pool 1178\n\n1 MILE, PACE, PURSE $7,020.\nATLANTIC SIRES STAKE 3 YR OLD PACING COLTS\n"A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n1   Magical Cowboy              1    2/1Q    2/1Q    2/1Q    2/1Q     1/H        1:58.1  29   C Macpherson     1.30*  R Gass\n5   Howmacsblackjack            5    1/1Q    1/1Q    1/1Q    1/1Q     2/H        1:58.1  29.1 A Smith          2.70   A Smith\n6   Silverhill Storm            6    5/6H    5/8T    4@/2T   3/1Q     3/2        1:58.3  29   J Hughes        14.15   J Hughes\n3   Abner The Great             3    3/3H    3/4Q    3/2T    4/2H     4/3H       1:58.4  29.1 G Barrieau       2.15   E Watts\n2   Keen Edge                   2    4/5     4/7H    5/4     5/3T     5/7        1:59.3  29.4 D Romo           9.60   D Romo\n4   Ic A Life Force             X4X  6/DIS   6/DIS   6/DIS   6/DIS    6/DIS                   K Arsenault      4.15   J Smith\nTime: 29.1, 59.1, 1:29, 1:58.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Magical Cowboy      (b,g,3 - Brandons Cowboy-Meridian Magic-Largo)\n                         Owner: Barry M Martin,Sydney,NS-Stephen R Gass,Cornwall,PE\n2nd  Howmacsblackjack    (br,c,3 - Articulator-Howmacs Dragon-Dragon Again)\n                         Owner: Peter M Smith,Charlottetown-Donald A Smith,Pownal-Gerald W Morrissey,Vernon River-Larry S Chappell,Marshfield,PE\n3rd  Silverhill Storm    (b,g,3 - Proven Lover-Southwind Miranda-Artsplace)\n                         Owner: Donald G Mac Rae,Vernon Bridge,PE\n5\n2-Burkes Bandit             3.70   2.20   2.30       340\n3-Oppies Artist                    5.40   3.30        91\n6-Four Starz Hold Em                      6.80       106\n\n$2 EXACTOR (2-3) paid 22.00, pool 129\n$2 TRIACTOR (2-3-6) paid 170.70, pool 1127\n\n1 MILE, PACE, PURSE $1,000.\nNON WINNERS $401 L5 OR $128 PS L10 OR IN 2015-16 (MIN 10 STS) AE: NON\nWINNERS 4 PM RACES OR $2500 LIFETIME\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Burkes Bandit               2    5@/9H   4@/4T   2@/1Q   2/NS     1/H        1:57.1  30   C Macpherson     0.85*  T Hicken\n3   Oppies Artist               3    1/2     1/2     1/1Q    1/NS     2/H        1:57.1  30.1 A Campbell       8.75   A Campbell\n6   Four Starz Hold Em          6    2/2     2/2     3/2Q    3/3Q     3/7T       1:58.4  31.2 D Spence        18.15   N White\n8   Djnorthernstar              8    8@/12T  7@/10   6@@/4T  5/4H     4/9H       1:59    31   R Ellis          3.10   D Jackson\n5   Pride Of Paradise           5    6/10T   5@/8Q   5@/4Q   6/5      5/10T      1:59.2  31.3 H Smallwood     10.40   H Smallwood\n4   Neigh Monster               4    3/3Q    3/3T    4/4Q    4/4H     6/12H      1:59.3  31.4 R Laffin         3.45   D Gillis\n7   Pi Hanover                  7    7@/11Q  8/11    8@/10T  8/15H    7/20T      2:01.2  32.1 R Perrot        13.65   R Perrot\n1   Go With It                  1    4/8Q    6/8T    7/9T    7/15     8/21T      2:01.3  32.3 B Mccallum      15.35   G Mccabe\nTime: 28.1, 57.4, 1:27, 1:57.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Burkes Bandit       (b,c,3 - Santanna Blue Chip-Twilight Lady-Artsplace)\n                         Owner: Perry R Burke,Grosse-Ile,QC\n2nd  Oppies Artist       (br,g,8 - Modern Art-Armbro Opponent-Direct Scooter)\n                         Owner: Andrew H Campbell,New Waterford,NS\n3rd  Four Starz Hold Em  (b,g,10 - Western Hanover-Four Starzzzz Hope-Cams Card Shark)\n                         Owner: Sarah Bruce,Truro,NS\n6\n2-Dusty Lane Arby           8.10   2.80   2.10       308\n4-Jackson K Down                   2.20   2.10       107\n6-Lukes Cowboy                            2.10       125\n\n$2 EXACTOR (2-4) paid 22.80, pool 150\n$2 TRIACTOR (2-4-6) paid 48.10, pool 1412\n\n1 MILE, PACE, PURSE $7,020.\nATLANTIC SIRES STAKE 3 YR OLD PACING COLTS\n"A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n2   Dusty Lane Arby             2    5/5H    5@/4T   4@/2Q   4/3      1/1H       1:57.1  29   C Macpherson     3.05   R Gass\n4   Jackson K Down              4    1/1Q    1/1T    1/1     1/1Q     2/1H       1:57.2  29.3 G Barrieau       0.60*  S Mason\n6   Lukes Cowboy                6    2/1Q    2/1T    3/1Q    2/1Q     3/1H       1:57.2  29.2 K Arsenault      3.70   K Arsenault\n3   J J Jodster                 3    3/2H    3/3     5/2T    5/3      4/3Q       1:57.4  29.2 D Romo          23.15   E Watts\n1   Elm Grove Kaboom+           1    4/4Q    4@/3Q   2@/1    3/2      5/3T       1:58    30   A Smith          9.20   A Smith\n5   Pictonian Power             5    6/6T    6/8T    6@/4Q   6/4H     6/4Q       1:58    29.2 M Macdonald      5.60   M Macdonald\nTime: 28.1, 59, 1:27.4, 1:57.1 (Temperature: 24, Condition: FT, Variant: 0)\nJudges List: Elm Grove Kaboom-PAPERS NOT IN ORDER\n\n1st  Dusty Lane Arby     (b,g,3 - Brandons Cowboy-Tara Artiste-Mach Three)\n                         Owner: Dale S Rennie-Ronnie G Rennie,Elmsdale-Shelley D Gass,Cornwall,PE\n2nd  Jackson K Down      (b,g,3 - Camystic-Village Jericho-Dexter Nukes)\n                         Owner: Downey Stables,Quispamsis,NB\n3rd  Lukes Cowboy        (b,g,3 - Brandons Cowboy-Philotes Nourrir-Dragon Again)\n                         Owner: Philip T Valley,Vernon River,PE-Jeffery E Ruch,Innisfil-Glenn E Bechtel,Kingston,ON\n
148	23	0723	\n7\n4-Icandothat                4.50   2.80   2.10       263\n1-Lifeinthecountry                 3.20   2.40        77\n3-Modern Best                             2.80       103\n\n$2 EXACTOR (4-1) paid 11.00, pool 162\n$2 TRIACTOR (4-1-3) paid 40.30, pool 103\n\n1 MILE, PACE, PURSE $4,500.\nWILSONS HOME HEATING FILLIES AND MARES SERIES\nFINAL\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Icandothat                  4    1/1H    1/2H    1/1H    1/1      1/H        2:00.3  30.4 R Ellis          1.25*  R Ellis\n1   Lifeinthecountry            1    2/1H    3/2H    3/1T    3/2      2/H        2:00.3  30.2 G Barrieau       2.70   J Ramsay Jr\n3   Modern Best                 3    4/4Q    4@/3H   4@/2T   4/2      3/H        2:00.3  30.1 K Parris         3.55   C Covin\n2   C L La Rousse               2    3/3     2@/2H   2@/1H   2/1      4/T        2:00.4  30.4 M Macdonald      2.80   L Parker\n7   Kendal Courageous           7    6/6T    5/4H    5/3Q    5/3      5/1H       2:00.4  30.2 C Stevens       37.40   C Stevens\n5   Just Lovey                  5    5/5H    6@/5Q   6@/4Q   6/3Q     6/3T       2:01.2  30.4 D Spence        16.45   N White\n6   Mattadors Rose              6    8@/8H   8@/7Q   8/6H    8/5T     7/6T       2:02    31   J Lilley        31.00   J Lilley\n8   Charlottes Style            8    7/8     7/6Q    7/5     7/4H     8/10T      2:02.4  32   D Carey         15.10   D Oconnor\nTime: 29.3, 1:00.1, 1:29.4, 2:00.3 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Icandothat          (b,m,6 - No Pan Intended-Done Like A Dinner-Northern Luck)\n                         Owner: Danica Ellis,Brookfield,NS\n2nd  Lifeinthecountry    (b,m,6 - N Xample-Gracie Allen-Life Sign)\n                         Owner: James E Ramsay Jr-Linda Ramsay,Truro,NS\n3rd  Modern Best         (br,m,8 - Modern Art-Terinas Best-Cambest)\n                         Owner: Ian D Macdonald,Lower Sackville-CC Stables,Middle Sackville,NS\n8\n4-Offshore Cowboy           8.10   3.10   2.50       327\n2-Heart And Soul                   2.10   2.10       139\n1-Wishiwasagigolo                         4.10       166\n\n$2 EXACTOR (4-2) paid 11.00, pool 167\n$2 TRIACTOR (4-2-1) paid 54.30, pool 1882\n\n1 MILE, PACE, PURSE $7,020.\nATLANTIC SIRES STAKE 3 YR OLD PACING COLTS\n"A" DIVISION\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n4   Offshore Cowboy             4    3/2H    2@/H    1@/H    1/H      1/H        1:57.1  28.1 J Hughes         3.05   D Milligan\n2   Heart And Soul              2    1/1Q    1/H     2/H     2/H      2/H        1:57.1  28.1 M Macdonald      0.55*  M Macdonald\n1   Wishiwasagigolo             1    2/1Q    3/1H    3/1T    3/1T     3/2        1:57.3  28.1 M Bradley       12.80   A Smith\n3   Mister Pibb                 3    4/4     5/4     6/4Q    6/4Q     4/6Q       1:58.2  28.3 D Romo           8.55   D Romo\n6   K D Overdrive               6    6/6H    6@/4Q   5@/4    5/4      5/7        1:58.3  28.4 G Barrieau       6.55   S Mason\n5   Beaus Cowboy                5    5/5Q    4@/2H   4@/2    4/2T     6/8H       1:58.4  29.2 C Cheverie       4.50   R Gass\nTime: 30, 1:00.1, 1:29, 1:57.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Offshore Cowboy     (b,g,3 - Brandons Cowboy-Charlottes Candy-Rustler Hanover)\n                         Owner: Kent Williams,Ellerslie-Lyndon K Hardy,Coleman,PE\n2nd  Heart And Soul      (br,g,3 - Western Paradise-Mighty Sassy-Arcane Hanover)\n                         Owner: Earith B Riley-George H Riley,Kensington,PE\n3rd  Wishiwasagigolo     (b,g,3 - Ameripan Gigolo-West Wishes-Western Hanover)\n                         Owner: David P Lund,Moncton,NB\n9\n5-Ramblinglily              5.50   2.40   2.10       326\n4-Best Risque                      5.00   2.20       122\n1-Shadows Mystery                         2.10       262\n\n$2 EXACTOR (5-4) paid 16.10, pool 133\n$2 TRIACTOR (5-4-1) paid 44.70, pool 1308\n\n1 MILE, PACE, PURSE $6,040.\nATLANTIC AGED PACING MARES SERIES\nSECOND LEG\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   Ramblinglily                5    2/1H    3/1T    2/1Q    2/1Q     1/HD       1:55.1  28.3 C Cheverie       1.75   A Jones\n4   Best Risque                 4    1/1H    1/1Q    1/1Q    1/1Q     2/HD       1:55.1  28.4 J Hughes         8.60   B Ladner\n1   Shadows Mystery             1    3/3H    5/3     3/4     3/2T     3/4        1:56    28.4 G Barrieau       1.35*  J Matheson\n3   Grins Little Flirt          3    7/10Q   7@/7Q   5/5H    4/4H     4/6        1:56.2  29   R Doucet        10.65   R Mac Leod\n6   Miss Oromocto               6    8/11H   8@/9Q   7@/6T   5/6      5/8T       1:57    29.1 M Haig          11.90   M Land\n8   All Chocolate               8    4@/4H   2@/1Q   4@/5    6/6H     6/13H      1:57.4  30.2 C Macpherson     8.55   T Hicken\n7   Barona Lilac                7    5/5H    4@/2T   6@@/5T  7/7H     7/20Q      1:59.1  31.3 D Crowe          5.15   D Crowe\n2   Sendmeasign                 2    6/9     6/7     8/10T   8/11H    8/22       1:59.3  31   K Arsenault     18.00   M Sobey\nTime: 28.1, 57.3, 1:26.2, 1:55.1 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Ramblinglily        (b,m,6 - Articulator-Crafty Jewel-Drop Off)\n                         Owner: Allan B Jones,Riverview-Normand O Leger,Shediac,NB\n2nd  Best Risque         (b,m,9 - Cammibest-Risque Business-Albert Albert)\n                         Owner: Lillian E Ladner-Kevin J Ladner-Brian C Ladner,Charlottetown,PE\n3rd  Shadows Mystery     (b,m,5 - Shadow Play-Myrnas Jackpot-Cams Card Shark)\n                         Owner: Gordon A Ford,Yoho,NB\n10\n5-D Gs Camme                3.70   2.20   2.10       489\n1-Big Surf                         2.60   4.70       164\n3-Midnight Play                           3.70       128\n\n$2 DAILY DOUBLE (5-5) paid 8.30, pool 98\n$2 EXACTOR (5-1) paid 7.60, pool 169\n$2 TRIACTOR (5-1-3) paid 57.70, pool 1465\n\n1 MILE, PACE, PURSE $7,500.\nEXHIBITION CUP INVITATIONAL\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n5   D Gs Camme                  5    1/1Q    1/1     1/1H    1/1T     1/3        1:53.2  28.2 G Barrieau       0.85*  J Matheson\n1   Big Surf                    1    2/1Q    3/2Q    2/1H    2/1T     2/3        1:54    28.4 C Macpherson     3.45   T Hicken\n3   Midnight Play               3    4/4     4/5T    4/3     3/3T     3/6        1:54.3  29   M Macdonald      4.00   T Hicken\n6   Jeb                         6    6/6H    6/8H    6@@/4H  6/5      4/9        1:55.1  29.2 K Arsenault      8.40   J Hughes\n4   His Boy Elroy               4    5/4Q    5/7     5@/4    5/5      5/9Q       1:55.1  29.2 B Mccallum       5.10   B Mccallum\n2   Ok Galahad                  2    3/2H    2@/1    3@/2    4/4      6/10Q      1:55.2  30   J Hughes         5.75   J Hughes\nTime: 28, 56.4, 1:25, 1:53.2 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  D Gs Camme          (br,g,6 - Blissfull Hall-Cam Me Kindly-Cams Card Shark)\n                         Owner: Quentin H Bevan-Hal Bevan-C Tom Clark-Ronald I Matheson,Charlottetown,PE\n2nd  Big Surf            (b,g,5 - Somebeachsomewhere-Skinny Dip-Western Ideal)\n                         Owner: Robin F Burke,Ten Mile House,PE-Perry R Burke,Grosse-Ile,QC-Luke Burke,Pleasant Grove,PE\n3rd  Midnight Play       (ch,g,4 - Shadow Play-Midnight Art-Artsplace)\n                         Owner: Aiden Hicken,Mt Stewart,PE\nTotal Handle: $17,849\n(Not Official CPMA Information)\n\n
151	23	0724	\n1\n\n1 MILE, PACE.QUALIFIER\n                                                                                         Last\nHorse                       HV PP    1/4     1/2     3/4     Stretch  Finish     Time    1/4  Driver           Odds   Trainer\n3   Aaronel                     2    1/2T    1/4H    1/6     1/5      1/4H       2:03.4  30.3 E Laffin             NB P Langille\n2   Southwind Oasis             1    2/2T    2/4H    2/6     2/5      2/4H       2:04.3  30.1 C Isenor             NB W Mcneil\n4   Meetmeatthebeach            3    3/6Q    3/8Q    3/9     3/10     3/13Q      2:06.2  31.2 M Macdonald          NB T Hardy\nTime: 31.4, 1:03, 1:33.1, 2:03.4 (Temperature: 24, Condition: FT, Variant: 0)\n\n1st  Aaronel             (b,c,3 - Brandons Cowboy-No Foolin Me-I Am A Fool)\n                         Owner: Rosanne M Langille,Lower Onslow,NS\n2nd  Southwind Oasis     (br,f,3 - Sportswriter-Its Only Rocknroll-Rocknroll Hanover)\n                         Owner: Saulsbrook Stables Inc,Windsor,NS-Laverne T Turnbull,Kitchener,ON\n3rd  Meetmeatthebeach    (b,m,4 - Force Of Life-Beach Bud-Jennas Beach Boy)\n                         Owner: Todd G & Trish A Hardy,Windsor,NS\n
\.


--
-- Data for Name: race_details; Type: TABLE DATA; Schema: public; Owner: colin
--

COPY race_details (id, race_id, race_number, horse_number, horse, hv, pp, quarter, half, thirdq, stretch, finish, finish_parsed, "time", lastq, driver, odds, trainer) FROM stdin;
1	7	1	5	 Audreys Dream         	    	   5 	 1/1   	 2/1H  	 1/2   	 1/8   	 1/9    	1	 1:53.3 	 28.1	 E Hensley     	0.35	 A Hensley
2	7	1	4	 Get Thereovernight    	    	   4 	 5/4Q  	 5/6   	 4/4H  	 3/9H  	 2/9    	2	 1:55.2 	 29.1	 K Hoerdt      	13.00	 K Hoerdt
3	7	1	3	 Son Of Anarchy        	    	   3 	 4/2T  	 4/4H  	 5@/4T 	 4/11  	 3/9T   	3	 1:55.3 	 29.1	 D A Kelly     	15.00	 G Manning
4	7	1	2	 Spinfiniti            	    	   2 	 2@/1  	 1/1H  	 3/2H  	 2/8   	 4/11   	4	 1:55.4 	 30  	 T Bowman      	20.05	 A Hensley
5	7	1	1	 Nobettorplacetobe     	    	   1 	 3/1Q  	 3/3   	 2@/2  	 5/14  	 5/23T  	5	 1:58.2 	 32.3	 T Cullen      	2.25	 T Cullen
6	7	2	2	 Smoke Eater           	    	   2 	 3/3H  	 3/4   	 3/2   	 3/1H  	 1/2H   	1	 1:57.2 	 28.4	 D Hudon       	4.05	 Q Schneider
7	7	2	3	 Da Magician           	    	   3 	 1/1H  	 1/1   	 1/1   	 1/HD  	 2/2H   	2	 1:57.4 	 29.3	 S Masse       	3.75	 S Masse
8	7	2	4	 Secrets Mystery       	    	   4 	 4/5H  	 4/5H  	 2@/1  	 2/HD  	 3/2T   	3	 1:58   	 29.3	 E Hensley     	3.75	 A Goertzen
9	7	2	7	 Outlaw Kismet         	    	   7 	 5/7   	 5/7   	 4/3H  	 4/3H  	 4/5Q   	4	 1:58.2 	 29.3	 J Gray        	2.75	 J Ratchford
10	7	2	5	 Pocket Novel          	    	   5X	 6/13  	 6/9   	 6/6   	 5/8H  	 5/14   	5	 2:00.1 	 30.4	 G Hudon       	22.00	 P Giesbrech
11	7	2	1	 Courageous C          	    	   X1	 7/16  	 7/12  	 7/8H  	 6/10H 	 6/15Q  	6	 2:00.2 	 30.3	 T Redwood     	2.75	 T Redwood
12	7	2	6	 Trustee               	    	   6 	 2/1H  	 2@/1  	 5/5H  	 7/14  	 7/21   	7	 2:01.3 	 32.2	 R Starkewski  	13.25	 R Starkewsk
13	7	3	3	 Retros Mystery        	    	   3 	 1@/1  	 1/1   	 1/1H  	 1/2   	 1/T    	1	 2:00.4 	 30.2	 R Starkewski  	2.50	 R Starkewsk
14	7	3	8	 Murder Mystery        	    	   8 	 2/1   	 3/1H  	 4/2T  	 2/2   	 2/T    	2	 2:01   	 30  	 R Hennessy    	22.35	 R Hennessy
15	7	3	6	 Charge And Go         	    	   6 	 4/7   	 6/5   	 5@@/3Q	 4/7   	 3/2Q   	3	 2:01.1 	 30.1	 K Clark       	1.95	 K Clark
16	7	3	2	 Tap Man               	    	   2 	 6/11H 	 2@/1  	 2/1H  	 3/4   	 4/3    	4	 2:01.2 	 30.4	 M Hennessy    	4.50	 R Hennessy
17	7	3	4	 Fanchastic            	    	   4 	 7X/13 	 8/12  	 7@/6Q 	 7/10  	 5/6T   	5	 2:02.1 	 30.3	 J Gray        	5.60	 A Arsenault
18	7	3	1	 Burntisland Billy     	    	   1 	 5/10  	 5@/3H 	 3@/2H 	 6/9   	 6/10T  	6	 2:03   	 32.1	 B Watt        	9.45	 P Giesbrech
19	7	3	5	 Fescue                	    	   5 	 3/3   	 4/3   	 6/5Q  	 5X/8  	 7/11H  	7	 2:03   	 31.3	 Jb Campbell   	11.50	 S Johnson
20	7	3	7	 Bring It In           	    	   7 	 8/16  	 7/8   	 8/12Q 	 8/17  	 8/23   	8	 2:05.2 	 32.3	 G Hudon       	19.75	 G Hudon
21	7	4	4	 Lifeimittatesart      	    	   4 	 4/5   	 3@/1T 	 2@/HD 	 1/HD  	 1/NS   	1	 1:55.4 	 28.3	 E Hensley     	0.95	 A Hensley
22	7	4	3	 Who Doesnt            	    	   3 	 1/2   	 1/1H  	 1/HD  	 2/HD  	 2/NS   	2	 1:55.4 	 28.3	 T Cullen      	1.60	 T Cullen
23	7	4	7	 Sterling Cooper       	    	   7 	 7/9H  	 7/6Q  	 3@@/H 	 3/NK  	 3/NK   	3	 1:55.4 	 28.3	 Jb Campbell   	20.80	 Jb Campbell
24	7	4	5	 Blue Eyed Cowboy      	    	   5 	 5/6H  	 5@/3Q 	 5@/1Q 	 5/4Q  	 4/1H   	4	 1:56   	 28.3	 T Bowman      	8.15	 R Starkewsk
25	7	4	1	 Cool Cowboy           	    	   1 	 2/2   	 2/1H  	 4/1   	 4/2Q  	 5/2T   	5	 1:56.2 	 29  	 K Hoerdt      	25.10	 K Hoerdt
26	7	4	2	 Premium Attaction     	    	   2 	 3/3H  	 4/2T  	 6/2Q  	 6/5T  	 6/3    	6	 1:56.2 	 28.4	 G Hudon       	10.60	 G Hudon
27	7	4	6	 Johnny Gun            	    	   6 	 6/8   	 6@/4T 	 7@/2T 	 7/7T  	 7/6T   	7	 1:57.1 	 29.2	 K Clark       	18.95	 H Haining
28	7	5	5	 Counter Strike        	    	   5 	 5/5   	 4@/2Q 	 2@@/1 	 1/3   	 1/3Q   	1	 1:54   	 28  	 T Cullen      	0.85	 T Cullen
29	7	5	7	 Drake                 	    	   7 	 7/8   	 6@/4T 	 4@/2  	 2/3   	 2/3Q   	2	 1:54.3 	 28.2	 E Hensley     	19.50	 A Hensley
30	7	5	1	 Big Time Sunrise      	    	   1 	 X1@/H 	 1/HD  	 3/1H  	 4/7   	 3/8    	3	 1:55.3 	 29.3	 K Clark       	3.35	 A Arsenault
31	7	5	2	 Rain Gauge            	    	   2 	 3/2   	 2@/HD 	 1@/1  	 3/5   	 4/8    	4	 1:55.3 	 29.4	 R Cullen      	4.85	 T Cullen
32	7	5	4	 Silent Rescue         	    	   4 	 4/3H  	 5/3T  	 6/4H  	 6/9   	 5/9H   	5	 1:55.4 	 29.1	 G Clark       	15.70	 G Clark
33	7	5	3	 Royal Renegade        	    	   3 	 2/H   	 3/1T  	 5@/3  	 5/8   	 6/9T   	6	 1:56   	 29.3	 R Hennessy    	14.55	 R Hennessy
34	7	5	6	 Mister Hat            	    	   6 	 6/6H  	 7/6Q  	 8/7   	 7/10  	 7/11Q  	7	 1:56.1 	 29  	 J Gagne       	26.80	 M Dumont
35	7	5	8	 Outlaw Deacon Jim     	    	   8 	 8/9H  	 8@/6T 	 7@/5  	 8/10H 	 8/12   	8	 1:56.2 	 29.3	 M Hennessy    	12.70	 R Hennessy
36	7	6	1	 Raging Fingers        	    	   1 	 1@/H  	 1/1H  	 1/H   	 1/H   	 1/NK   	1	 1:55.4 	 30.2	 T Cullen      	0.55	 T Cullen
37	7	6	4	 Captain Hazardous     	    	   4 	 5/5   	 3@/3  	 2@/H  	 2/H   	 2/NK   	2	 1:55.4 	 30.2	 D Hudon       	4.10	 D Hudon
38	7	6	3	 Lizard King           	    	   3 	 2/H   	 2/1H  	 3@/2  	 3/3H  	 3/1T   	3	 1:56.1 	 30.2	 T Redwood     	5.15	 T Redwood
39	7	6	2	 Somewhereinmexico     	    	   2 	 4/3H  	 5/4T  	 5/7H  	 4/6H  	 4/2Q   	4	 1:56.1 	 29.2	 D A Kelly     	19.70	 D A Kelly
40	7	6	6	 Cowboys Dirtyboots    	    	   5 	 6/6H  	 7/6T  	 6@@/7T	 6/10  	 5/7H   	5	 1:57.1 	 30.1	 R Grundy      	13.25	 D Crick
41	7	6	8	 Medicine Hat          	    	   7 	 3/2   	 4/3Q  	 4/6   	 5/9H  	 6/9H   	6	 1:57.3 	 31  	 K Hoerdt      	22.55	 K Hoerdt
42	7	6	7	 Karate King+          	    	   6 	 7/8   	 6@/5Q 	 7/8   	 7/14  	 7/21   	7	 2:00   	 33  	 K Clark       	15.10	 D Stout
43	7	6	5	 Full Moon Dodger      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
44	8	1	1	 Watch My Luck         	    	   1 	 4/6   	 4@/3H 	 2@/HD 	 2/HD  	 1/T    	1	 1:56.1 	 29.1	 J Gagne       	4.00	 M Dumont
45	8	1	5	 Jet Hot Stuff         	    	   5 	 6/9H  	 6@/5Q 	 4@/2H 	 3/1T  	 2/T    	2	 1:56.2 	 29  	 E Hensley     	1.60	 A Hensley
46	8	1	8	 Remember Terror       	    	   8 	 7/11  	 7/6T  	 6@/4Q 	 4/4T  	 3/4T   	3	 1:57.1 	 29.2	 S Masse       	19.20	 S Masse
47	8	1	3	 Phoenician Gal        	    	   3 	 1/1H  	 1/1H  	 1/HD  	 1/HD  	 4/5Q   	4	 1:57.1 	 30.1	 T Cullen      	1.65	 T Cullen
48	8	1	2	 Blue Star Texas       	    	   2 	 3/4H  	 3/3   	 5/4   	 5/6T  	 5/5H   	5	 1:57.1 	 29.2	 Jb Campbell   	11.05	 Jb Campbell
49	8	1	4	 Scarlet V             	    	   4 	 5/8   	 5/5   	 7/5T  	 7/9T  	 6/11H  	6	 1:58.2 	 30.1	 D Hudon       	21.10	 Q Schneider
50	8	1	7	 Mozelle Hanover       	    	   7 	 2/1H  	 2/1H  	 3/2Q  	 6/8T  	 7/21   	7	 2:00.2 	 33  	 J Gray        	30.55	 G Lutz
51	8	1	6	 Miss Hoozzitz         	    	   6X	 X8/25 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 T Bowman      	17.20	 D Lamont
52	8	2	4	 Ninetymile Hanover    	    	   4 	 6/9Q  	 6/8   	 6/3H  	 3/2Q  	 1/1    	1	 1:58.1 	 30.3	 D Hudon       	14.30	 D Hudon
53	8	2	3	 Make It So            	    	   3 	 5/5Q  	 5/3   	 4@@/2 	 1/2   	 2/1    	2	 1:58.2 	 31  	 T Cullen      	3.50	 T Cullen
54	8	2	7	 Acesndeuces           	    	   7 	 8/13T 	 7@/11 	 5@/3  	 4/2T  	 3/3Q   	3	 1:58.4 	 31.1	 N Sobey       	6.25	 S Johnson
55	8	2	2	 Hale Street           	    	   2 	 2@/Q  	 2@/H  	 2@/HD 	 2/2   	 4/6T   	4	 1:59.3 	 32.3	 T Bowman      	6.55	 D Cutting
56	8	2	8	 Upfront Cosmo         	    	   X8	 9/15T 	 9/15  	 8/7   	 7/6Q  	 5/7Q   	5	 1:59.3 	 31.1	 T Redwood     	33.70	 T Redwood
57	8	2	1	 Western Fortune       	    	   1 	 3/1T  	 3/1H  	 3/1H  	 6/5Q  	 6/8    	6	 1:59.4 	 32.3	 D A Kelly     	3.25	 C Reid
58	8	2	6	 Regina Beach          	    	   6 	 7/12Q 	 8/12  	 7/6H  	 8/6T  	 7/10Q  	7	 2:00.1 	 32  	 Jb Campbell   	5.70	 Jb Campbell
59	8	2	5	 Lone Rider            	    	   5 	 1/Q   	 1/H   	 1/HD  	 5/4T  	 8BE/12T	8	 2:00.4 	 33.4	 S Masse       	7.70	 S Arsenault
60	8	2	9	 Little Bit Faster     	    	   9 	 4/3Q  	 4@/2  	 X9@@/7	 9/DIS 	 9/DIS  	9	        	     	 M Hennessy    	6.15	 H Haining
61	8	3	3	 Vow To Win            	    	   3 	 6/6H  	 7@/8T 	 7@@/8H	 5/3   	 1/H    	1	 1:59   	 31.4	 J Gagne       	20.10	 Q Schneider
62	8	3	4	 Classy Artist         	    	   4 	 7/8   	 8@/10Q	 8@@/10	 2/2   	 2/H    	2	 1:59   	 31.2	 R Starkewski  	12.75	 R Starkewsk
63	8	3	6	 Ptsmagicmark          	    	   6 	 2@/1  	 3/5   	 3/4H  	 4/2H  	 3/2    	3	 1:59.2 	 33  	 K Ducharme    	15.55	 L Ducharme
64	8	3	2	 Red Tornado           	    	   2 	 4/3H  	 4/7   	 4/6H  	 3/2Q  	 4/2H   	4	 1:59.2 	 32.3	 M Hennessy    	4.30	 R Hennessy
65	8	3	1	 Man Of Many Arts      	    	   1 	 1/1   	 2/1   	 1/H   	 1/2   	 5/3H   	5	 1:59.3 	 34  	 T Bowman      	3.25	 D Lamont
66	8	3	5	 Iwontdothatagain      	    	   5 	 8/9H  	 6/8H  	 6/8Q  	 8/6H  	 6/3H   	6	 1:59.3 	 32.2	 J Gray        	15.15	 J Ratchford
67	8	3	7	 Broadview Bridge      	    	   7 	 5/5   	 5@/7H 	 5@/8  	 6/5   	 7/4H   	7	 1:59.4 	 32.3	 T Cullen      	1.75	 T Cullen
68	8	3	9	 Its Eds Idea          	    	   9 	 3/2   	 1@/1  	 2@/H  	 7/5H  	 8/5    	8	 2:00   	 34.2	 S Masse       	4.50	 S Masse
69	8	3	8	 Rare Breed            	    	   8 	 9/11  	 9/11T 	 9/15  	 9/11H 	 9/16   	9	 2:02.1 	 33.3	 G Hudon       	71.20	 D Sifert
70	8	4	3	 Greek Ruler           	    	   3 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/NR   	1	 1:57.4 	 30.1	 M Hennessy    	1.10	 C Lancaster
71	8	4	7	 Sonic Spark           	    	   7 	 7/9   	 5@/3H 	 4@/2  	 4/2Q  	 2/NR   	2	 NR     	     	 T Bowman      	29.60	 H Haining
72	8	4	9	 Rock Shooter          	    	   9 	 3/3   	 4/3   	 5/3   	 5/3T  	 3/NR   	3	 NR     	     	 T Cullen      	4.00	 T Cullen
73	8	4	2	 Lightning Legs        	    	   2 	 2/1H  	 2/1H  	 3/1H  	 3/1T  	 4/NR   	4	 NR     	     	 E Hensley     	5.30	 A Hensley
74	8	4	6	 Steal The Diamonds    	    	   6 	 6/7H  	 3@/2  	 2@/H  	 2/1H  	 5/NR   	5	 NR     	     	 D A Kelly     	14.55	 G Manning
75	8	4	4	 B R Money Matters     	    	   4 	 4/4H  	 6/5   	 6/6   	 6/5T  	 6/NR   	6	 NR     	     	 J Gray        	8.65	 A Jensen
76	8	4	5	 Cowboy Mathis         	    	   5 	 5/6   	 8/6T  	 8/9   	 7/9T  	 7/NR   	7	 NR     	     	 K Clark       	16.50	 K Clark
77	8	4	8	 Promise To Lynette    	    	   8 	 8/10H 	 7@/5Q 	 7@/7  	 8/12T 	 8/NR   	8	 NR     	     	 G Hudon       	10.05	 G Hudon
78	8	4	1	 You And Tequila       	    	   1X	 FELL  	       	       	       	 DNF    	\N	        	     	 T Redwood     	24.65	 T Redwood
79	9	1	5	 Appellate             	    	   5 	 6/13  	 6/15H 	 3/7H  	 3/3Q  	 1/H    	1	 1:58.4 	 28.4	 K Clark       	\N	 K Clark
80	9	1	3	 Whisper Well          	    	   3 	 2/4   	 2/1H  	 1/1H  	 1/3   	 2/H    	2	 1:58.4 	 30.1	 B Watt        	\N	 B Watt
81	9	1	6	 Hollywood Redneck     	    	   6 	 1/4   	 1/1H  	 2/1H  	 2/3   	 3/4Q   	3	 1:59.3 	 30.4	 G Hudon       	\N	 G Hudon
82	9	1	4	 A Wish For Wings      	    	   4 	 5/11  	 5/11H 	 5/15H 	 5/15T 	 4/16Q  	4	 2:02   	 30.2	 J Gray        	\N	 S Crump
83	9	1	1	 Speed Shift           	    	   1 	 3/6   	 3/6H  	 4/14H 	 4/15Q 	 5/20   	5	 2:02.4 	 31.2	 M Hennessy    	\N	 K Read
84	9	1	2	 Fast Lane Denali      	    	   2 	 4/8   	 4/9H  	 6/16H 	 6/19T 	 6/25T  	6	 2:04   	 32.1	 N Sobey       	\N	 T Tracey
85	9	2	4	 Lil Bit O Jingle      	    	   4 	 2@/HD 	 1/1H  	 1/1H  	 1/2   	 1/6    	1	 2:02.1 	 29.4	 T Cullen      	\N	 T Cullen
86	9	2	6	 Latestngreatest       	    	   6 	 1/HD  	 2/1H  	 2/1H  	 2/2   	 2/6    	2	 2:03.2 	 30.4	 K Clark       	\N	 K Clark
87	9	2	3	 Blue Star Cascade     	    	   3 	 5/6Q  	 5/12H 	 5/10H 	 3/8   	 3/8H   	3	 2:03.4 	 29.2	 G Hudon       	\N	 G Hudon
88	9	2	8	 Heated Exchange       	    	   8 	 7/11Q 	 7/17H 	 6@/12H	 5/10  	 4/9T   	4	 2:04.1 	 29.2	 R Cullen      	\N	 T Cullen
89	9	2	1	 Cenalta Cougar        	    	   1 	 3/2Q  	 3/7H  	 3/7H  	 4/9   	 5/11Q  	5	 2:04.2 	 30.3	 T Redwood     	\N	 D Stout
90	9	2	2	 Make Some Smiles      	    	   2 	 4/4Q  	 4/10H 	 4/9H  	 6/10H 	 6/11T  	6	 2:04.3 	 30.2	 K Hoerdt      	\N	 K Hoerdt
91	9	2	5	 Starry Eyes           	    	   5 	 6/8T  	 6/15H 	 7/14  	 7/16H 	 7/20T  	7	 2:06.2 	 31.1	 D Sifert      	\N	 D Sifert
92	9	2	7	 Orangevale Gazette    	    	   X7	 8/15Q 	 8/22H 	 8/24  	 8/29  	 8/36H  	8	 2:09.2 	 32.1	 M Bourgeois   	\N	 M Bourgeois
93	9	3	5	 Capitol Hill          	    	   5 	 4/4H  	 4/7   	 3@/2Q 	 2/HD  	 1/2    	1	 2:03.2 	 30  	 G Clark       	\N	 S Crump
94	9	3	4	 Formula D M           	    	   4 	 1/1H  	 1/2   	 1/2   	 1/HD  	 2/2    	2	 2:03.4 	 30.4	 G Hudon       	\N	 K Read
95	9	3	6	 Lilmessinaround       	    	   6 	 5/6   	 5/10  	 5@/5T 	 4/5T  	 3/4H   	3	 2:04.1 	 30  	 R Schneider   	\N	 R Schneider
96	9	3	2	 The Insinerator       	    	   2 	 2/1H  	 2/2   	 2/2   	 3/5Q  	 4/12   	4	 2:05.4 	 32.2	 D Hudon       	\N	 G Abbott
97	9	3	1	 Ganymeda Gold         	    	   1 	 3/3   	 3/5H  	 4/5Q  	 5/9T  	 5/18Q  	5	 2:07   	 33  	 N Sobey       	\N	 N Sobey
98	9	3	3	 El Capone             	    	   3X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 T Tracey      	\N	 T Tracey
99	10	1	5	 Audreys Dream         	    	   5 	 1/1   	 2/1H  	 1/2   	 1/8   	 1/9    	1	 1:53.3 	 28.1	 E Hensley     	0.35	 A Hensley
100	10	1	4	 Get Thereovernight    	    	   4 	 5/4Q  	 5/6   	 4/4H  	 3/9H  	 2/9    	2	 1:55.2 	 29.1	 K Hoerdt      	13.00	 K Hoerdt
101	10	1	3	 Son Of Anarchy        	    	   3 	 4/2T  	 4/4H  	 5@/4T 	 4/11  	 3/9T   	3	 1:55.3 	 29.1	 D A Kelly     	15.00	 G Manning
102	10	1	2	 Spinfiniti            	    	   2 	 2@/1  	 1/1H  	 3/2H  	 2/8   	 4/11   	4	 1:55.4 	 30  	 T Bowman      	20.05	 A Hensley
103	10	1	1	 Nobettorplacetobe     	    	   1 	 3/1Q  	 3/3   	 2@/2  	 5/14  	 5/23T  	5	 1:58.2 	 32.3	 T Cullen      	2.25	 T Cullen
104	10	2	2	 Smoke Eater           	    	   2 	 3/3H  	 3/4   	 3/2   	 3/1H  	 1/2H   	1	 1:57.2 	 28.4	 D Hudon       	4.05	 Q Schneider
105	10	2	3	 Da Magician           	    	   3 	 1/1H  	 1/1   	 1/1   	 1/HD  	 2/2H   	2	 1:57.4 	 29.3	 S Masse       	3.75	 S Masse
106	10	2	4	 Secrets Mystery       	    	   4 	 4/5H  	 4/5H  	 2@/1  	 2/HD  	 3/2T   	3	 1:58   	 29.3	 E Hensley     	3.75	 A Goertzen
107	10	2	7	 Outlaw Kismet         	    	   7 	 5/7   	 5/7   	 4/3H  	 4/3H  	 4/5Q   	4	 1:58.2 	 29.3	 J Gray        	2.75	 J Ratchford
108	10	2	5	 Pocket Novel          	    	   5X	 6/13  	 6/9   	 6/6   	 5/8H  	 5/14   	5	 2:00.1 	 30.4	 G Hudon       	22.00	 P Giesbrech
109	10	2	1	 Courageous C          	    	   X1	 7/16  	 7/12  	 7/8H  	 6/10H 	 6/15Q  	6	 2:00.2 	 30.3	 T Redwood     	2.75	 T Redwood
110	10	2	6	 Trustee               	    	   6 	 2/1H  	 2@/1  	 5/5H  	 7/14  	 7/21   	7	 2:01.3 	 32.2	 R Starkewski  	13.25	 R Starkewsk
111	10	3	3	 Retros Mystery        	    	   3 	 1@/1  	 1/1   	 1/1H  	 1/2   	 1/T    	1	 2:00.4 	 30.2	 R Starkewski  	2.50	 R Starkewsk
112	10	3	8	 Murder Mystery        	    	   8 	 2/1   	 3/1H  	 4/2T  	 2/2   	 2/T    	2	 2:01   	 30  	 R Hennessy    	22.35	 R Hennessy
113	10	3	6	 Charge And Go         	    	   6 	 4/7   	 6/5   	 5@@/3Q	 4/7   	 3/2Q   	3	 2:01.1 	 30.1	 K Clark       	1.95	 K Clark
114	10	3	2	 Tap Man               	    	   2 	 6/11H 	 2@/1  	 2/1H  	 3/4   	 4/3    	4	 2:01.2 	 30.4	 M Hennessy    	4.50	 R Hennessy
115	10	3	4	 Fanchastic            	    	   4 	 7X/13 	 8/12  	 7@/6Q 	 7/10  	 5/6T   	5	 2:02.1 	 30.3	 J Gray        	5.60	 A Arsenault
116	10	3	1	 Burntisland Billy     	    	   1 	 5/10  	 5@/3H 	 3@/2H 	 6/9   	 6/10T  	6	 2:03   	 32.1	 B Watt        	9.45	 P Giesbrech
117	10	3	5	 Fescue                	    	   5 	 3/3   	 4/3   	 6/5Q  	 5X/8  	 7/11H  	7	 2:03   	 31.3	 Jb Campbell   	11.50	 S Johnson
118	10	3	7	 Bring It In           	    	   7 	 8/16  	 7/8   	 8/12Q 	 8/17  	 8/23   	8	 2:05.2 	 32.3	 G Hudon       	19.75	 G Hudon
119	10	4	4	 Lifeimittatesart      	    	   4 	 4/5   	 3@/1T 	 2@/HD 	 1/HD  	 1/NS   	1	 1:55.4 	 28.3	 E Hensley     	0.95	 A Hensley
120	10	4	3	 Who Doesnt            	    	   3 	 1/2   	 1/1H  	 1/HD  	 2/HD  	 2/NS   	2	 1:55.4 	 28.3	 T Cullen      	1.60	 T Cullen
121	10	4	7	 Sterling Cooper       	    	   7 	 7/9H  	 7/6Q  	 3@@/H 	 3/NK  	 3/NK   	3	 1:55.4 	 28.3	 Jb Campbell   	20.80	 Jb Campbell
122	10	4	5	 Blue Eyed Cowboy      	    	   5 	 5/6H  	 5@/3Q 	 5@/1Q 	 5/4Q  	 4/1H   	4	 1:56   	 28.3	 T Bowman      	8.15	 R Starkewsk
123	10	4	1	 Cool Cowboy           	    	   1 	 2/2   	 2/1H  	 4/1   	 4/2Q  	 5/2T   	5	 1:56.2 	 29  	 K Hoerdt      	25.10	 K Hoerdt
124	10	4	2	 Premium Attaction     	    	   2 	 3/3H  	 4/2T  	 6/2Q  	 6/5T  	 6/3    	6	 1:56.2 	 28.4	 G Hudon       	10.60	 G Hudon
125	10	4	6	 Johnny Gun            	    	   6 	 6/8   	 6@/4T 	 7@/2T 	 7/7T  	 7/6T   	7	 1:57.1 	 29.2	 K Clark       	18.95	 H Haining
126	10	5	5	 Counter Strike        	    	   5 	 5/5   	 4@/2Q 	 2@@/1 	 1/3   	 1/3Q   	1	 1:54   	 28  	 T Cullen      	0.85	 T Cullen
127	10	5	7	 Drake                 	    	   7 	 7/8   	 6@/4T 	 4@/2  	 2/3   	 2/3Q   	2	 1:54.3 	 28.2	 E Hensley     	19.50	 A Hensley
128	10	5	1	 Big Time Sunrise      	    	   1 	 X1@/H 	 1/HD  	 3/1H  	 4/7   	 3/8    	3	 1:55.3 	 29.3	 K Clark       	3.35	 A Arsenault
129	10	5	2	 Rain Gauge            	    	   2 	 3/2   	 2@/HD 	 1@/1  	 3/5   	 4/8    	4	 1:55.3 	 29.4	 R Cullen      	4.85	 T Cullen
130	10	5	4	 Silent Rescue         	    	   4 	 4/3H  	 5/3T  	 6/4H  	 6/9   	 5/9H   	5	 1:55.4 	 29.1	 G Clark       	15.70	 G Clark
131	10	5	3	 Royal Renegade        	    	   3 	 2/H   	 3/1T  	 5@/3  	 5/8   	 6/9T   	6	 1:56   	 29.3	 R Hennessy    	14.55	 R Hennessy
132	10	5	6	 Mister Hat            	    	   6 	 6/6H  	 7/6Q  	 8/7   	 7/10  	 7/11Q  	7	 1:56.1 	 29  	 J Gagne       	26.80	 M Dumont
133	10	5	8	 Outlaw Deacon Jim     	    	   8 	 8/9H  	 8@/6T 	 7@/5  	 8/10H 	 8/12   	8	 1:56.2 	 29.3	 M Hennessy    	12.70	 R Hennessy
134	10	6	1	 Raging Fingers        	    	   1 	 1@/H  	 1/1H  	 1/H   	 1/H   	 1/NK   	1	 1:55.4 	 30.2	 T Cullen      	0.55	 T Cullen
135	10	6	4	 Captain Hazardous     	    	   4 	 5/5   	 3@/3  	 2@/H  	 2/H   	 2/NK   	2	 1:55.4 	 30.2	 D Hudon       	4.10	 D Hudon
136	10	6	3	 Lizard King           	    	   3 	 2/H   	 2/1H  	 3@/2  	 3/3H  	 3/1T   	3	 1:56.1 	 30.2	 T Redwood     	5.15	 T Redwood
137	10	6	2	 Somewhereinmexico     	    	   2 	 4/3H  	 5/4T  	 5/7H  	 4/6H  	 4/2Q   	4	 1:56.1 	 29.2	 D A Kelly     	19.70	 D A Kelly
138	10	6	6	 Cowboys Dirtyboots    	    	   5 	 6/6H  	 7/6T  	 6@@/7T	 6/10  	 5/7H   	5	 1:57.1 	 30.1	 R Grundy      	13.25	 D Crick
139	10	6	8	 Medicine Hat          	    	   7 	 3/2   	 4/3Q  	 4/6   	 5/9H  	 6/9H   	6	 1:57.3 	 31  	 K Hoerdt      	22.55	 K Hoerdt
140	10	6	7	 Karate King+          	    	   6 	 7/8   	 6@/5Q 	 7/8   	 7/14  	 7/21   	7	 2:00   	 33  	 K Clark       	15.10	 D Stout
141	10	6	5	 Full Moon Dodger      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
142	11	1	1	 Watch My Luck         	    	   1 	 4/6   	 4@/3H 	 2@/HD 	 2/HD  	 1/T    	1	 1:56.1 	 29.1	 J Gagne       	4.00	 M Dumont
143	11	1	5	 Jet Hot Stuff         	    	   5 	 6/9H  	 6@/5Q 	 4@/2H 	 3/1T  	 2/T    	2	 1:56.2 	 29  	 E Hensley     	1.60	 A Hensley
144	11	1	8	 Remember Terror       	    	   8 	 7/11  	 7/6T  	 6@/4Q 	 4/4T  	 3/4T   	3	 1:57.1 	 29.2	 S Masse       	19.20	 S Masse
145	11	1	3	 Phoenician Gal        	    	   3 	 1/1H  	 1/1H  	 1/HD  	 1/HD  	 4/5Q   	4	 1:57.1 	 30.1	 T Cullen      	1.65	 T Cullen
146	11	1	2	 Blue Star Texas       	    	   2 	 3/4H  	 3/3   	 5/4   	 5/6T  	 5/5H   	5	 1:57.1 	 29.2	 Jb Campbell   	11.05	 Jb Campbell
147	11	1	4	 Scarlet V             	    	   4 	 5/8   	 5/5   	 7/5T  	 7/9T  	 6/11H  	6	 1:58.2 	 30.1	 D Hudon       	21.10	 Q Schneider
148	11	1	7	 Mozelle Hanover       	    	   7 	 2/1H  	 2/1H  	 3/2Q  	 6/8T  	 7/21   	7	 2:00.2 	 33  	 J Gray        	30.55	 G Lutz
149	11	1	6	 Miss Hoozzitz         	    	   6X	 X8/25 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 T Bowman      	17.20	 D Lamont
150	11	2	4	 Ninetymile Hanover    	    	   4 	 6/9Q  	 6/8   	 6/3H  	 3/2Q  	 1/1    	1	 1:58.1 	 30.3	 D Hudon       	14.30	 D Hudon
151	11	2	3	 Make It So            	    	   3 	 5/5Q  	 5/3   	 4@@/2 	 1/2   	 2/1    	2	 1:58.2 	 31  	 T Cullen      	3.50	 T Cullen
152	11	2	7	 Acesndeuces           	    	   7 	 8/13T 	 7@/11 	 5@/3  	 4/2T  	 3/3Q   	3	 1:58.4 	 31.1	 N Sobey       	6.25	 S Johnson
153	11	2	2	 Hale Street           	    	   2 	 2@/Q  	 2@/H  	 2@/HD 	 2/2   	 4/6T   	4	 1:59.3 	 32.3	 T Bowman      	6.55	 D Cutting
154	11	2	8	 Upfront Cosmo         	    	   X8	 9/15T 	 9/15  	 8/7   	 7/6Q  	 5/7Q   	5	 1:59.3 	 31.1	 T Redwood     	33.70	 T Redwood
155	11	2	1	 Western Fortune       	    	   1 	 3/1T  	 3/1H  	 3/1H  	 6/5Q  	 6/8    	6	 1:59.4 	 32.3	 D A Kelly     	3.25	 C Reid
156	11	2	6	 Regina Beach          	    	   6 	 7/12Q 	 8/12  	 7/6H  	 8/6T  	 7/10Q  	7	 2:00.1 	 32  	 Jb Campbell   	5.70	 Jb Campbell
157	11	2	5	 Lone Rider            	    	   5 	 1/Q   	 1/H   	 1/HD  	 5/4T  	 8BE/12T	8	 2:00.4 	 33.4	 S Masse       	7.70	 S Arsenault
158	11	2	9	 Little Bit Faster     	    	   9 	 4/3Q  	 4@/2  	 X9@@/7	 9/DIS 	 9/DIS  	9	        	     	 M Hennessy    	6.15	 H Haining
159	11	3	3	 Vow To Win            	    	   3 	 6/6H  	 7@/8T 	 7@@/8H	 5/3   	 1/H    	1	 1:59   	 31.4	 J Gagne       	20.10	 Q Schneider
160	11	3	4	 Classy Artist         	    	   4 	 7/8   	 8@/10Q	 8@@/10	 2/2   	 2/H    	2	 1:59   	 31.2	 R Starkewski  	12.75	 R Starkewsk
161	11	3	6	 Ptsmagicmark          	    	   6 	 2@/1  	 3/5   	 3/4H  	 4/2H  	 3/2    	3	 1:59.2 	 33  	 K Ducharme    	15.55	 L Ducharme
162	11	3	2	 Red Tornado           	    	   2 	 4/3H  	 4/7   	 4/6H  	 3/2Q  	 4/2H   	4	 1:59.2 	 32.3	 M Hennessy    	4.30	 R Hennessy
163	11	3	1	 Man Of Many Arts      	    	   1 	 1/1   	 2/1   	 1/H   	 1/2   	 5/3H   	5	 1:59.3 	 34  	 T Bowman      	3.25	 D Lamont
164	11	3	5	 Iwontdothatagain      	    	   5 	 8/9H  	 6/8H  	 6/8Q  	 8/6H  	 6/3H   	6	 1:59.3 	 32.2	 J Gray        	15.15	 J Ratchford
165	11	3	7	 Broadview Bridge      	    	   7 	 5/5   	 5@/7H 	 5@/8  	 6/5   	 7/4H   	7	 1:59.4 	 32.3	 T Cullen      	1.75	 T Cullen
166	11	3	9	 Its Eds Idea          	    	   9 	 3/2   	 1@/1  	 2@/H  	 7/5H  	 8/5    	8	 2:00   	 34.2	 S Masse       	4.50	 S Masse
167	11	3	8	 Rare Breed            	    	   8 	 9/11  	 9/11T 	 9/15  	 9/11H 	 9/16   	9	 2:02.1 	 33.3	 G Hudon       	71.20	 D Sifert
168	11	4	3	 Greek Ruler           	    	   3 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/NR   	1	 1:57.4 	 30.1	 M Hennessy    	1.10	 C Lancaster
169	11	4	7	 Sonic Spark           	    	   7 	 7/9   	 5@/3H 	 4@/2  	 4/2Q  	 2/NR   	2	 NR     	     	 T Bowman      	29.60	 H Haining
170	11	4	9	 Rock Shooter          	    	   9 	 3/3   	 4/3   	 5/3   	 5/3T  	 3/NR   	3	 NR     	     	 T Cullen      	4.00	 T Cullen
171	11	4	2	 Lightning Legs        	    	   2 	 2/1H  	 2/1H  	 3/1H  	 3/1T  	 4/NR   	4	 NR     	     	 E Hensley     	5.30	 A Hensley
172	11	4	6	 Steal The Diamonds    	    	   6 	 6/7H  	 3@/2  	 2@/H  	 2/1H  	 5/NR   	5	 NR     	     	 D A Kelly     	14.55	 G Manning
173	11	4	4	 B R Money Matters     	    	   4 	 4/4H  	 6/5   	 6/6   	 6/5T  	 6/NR   	6	 NR     	     	 J Gray        	8.65	 A Jensen
174	11	4	5	 Cowboy Mathis         	    	   5 	 5/6   	 8/6T  	 8/9   	 7/9T  	 7/NR   	7	 NR     	     	 K Clark       	16.50	 K Clark
175	11	4	8	 Promise To Lynette    	    	   8 	 8/10H 	 7@/5Q 	 7@/7  	 8/12T 	 8/NR   	8	 NR     	     	 G Hudon       	10.05	 G Hudon
176	11	4	1	 You And Tequila       	    	   1X	 FELL  	       	       	       	 DNF    	\N	        	     	 T Redwood     	24.65	 T Redwood
177	12	1	5	 Appellate             	    	   5 	 6/13  	 6/15H 	 3/7H  	 3/3Q  	 1/H    	1	 1:58.4 	 28.4	 K Clark       	\N	 K Clark
178	12	1	3	 Whisper Well          	    	   3 	 2/4   	 2/1H  	 1/1H  	 1/3   	 2/H    	2	 1:58.4 	 30.1	 B Watt        	\N	 B Watt
179	12	1	6	 Hollywood Redneck     	    	   6 	 1/4   	 1/1H  	 2/1H  	 2/3   	 3/4Q   	3	 1:59.3 	 30.4	 G Hudon       	\N	 G Hudon
180	12	1	4	 A Wish For Wings      	    	   4 	 5/11  	 5/11H 	 5/15H 	 5/15T 	 4/16Q  	4	 2:02   	 30.2	 J Gray        	\N	 S Crump
181	12	1	1	 Speed Shift           	    	   1 	 3/6   	 3/6H  	 4/14H 	 4/15Q 	 5/20   	5	 2:02.4 	 31.2	 M Hennessy    	\N	 K Read
182	12	1	2	 Fast Lane Denali      	    	   2 	 4/8   	 4/9H  	 6/16H 	 6/19T 	 6/25T  	6	 2:04   	 32.1	 N Sobey       	\N	 T Tracey
183	12	2	4	 Lil Bit O Jingle      	    	   4 	 2@/HD 	 1/1H  	 1/1H  	 1/2   	 1/6    	1	 2:02.1 	 29.4	 T Cullen      	\N	 T Cullen
184	12	2	6	 Latestngreatest       	    	   6 	 1/HD  	 2/1H  	 2/1H  	 2/2   	 2/6    	2	 2:03.2 	 30.4	 K Clark       	\N	 K Clark
185	12	2	3	 Blue Star Cascade     	    	   3 	 5/6Q  	 5/12H 	 5/10H 	 3/8   	 3/8H   	3	 2:03.4 	 29.2	 G Hudon       	\N	 G Hudon
186	12	2	8	 Heated Exchange       	    	   8 	 7/11Q 	 7/17H 	 6@/12H	 5/10  	 4/9T   	4	 2:04.1 	 29.2	 R Cullen      	\N	 T Cullen
187	12	2	1	 Cenalta Cougar        	    	   1 	 3/2Q  	 3/7H  	 3/7H  	 4/9   	 5/11Q  	5	 2:04.2 	 30.3	 T Redwood     	\N	 D Stout
188	12	2	2	 Make Some Smiles      	    	   2 	 4/4Q  	 4/10H 	 4/9H  	 6/10H 	 6/11T  	6	 2:04.3 	 30.2	 K Hoerdt      	\N	 K Hoerdt
189	12	2	5	 Starry Eyes           	    	   5 	 6/8T  	 6/15H 	 7/14  	 7/16H 	 7/20T  	7	 2:06.2 	 31.1	 D Sifert      	\N	 D Sifert
190	12	2	7	 Orangevale Gazette    	    	   X7	 8/15Q 	 8/22H 	 8/24  	 8/29  	 8/36H  	8	 2:09.2 	 32.1	 M Bourgeois   	\N	 M Bourgeois
191	12	3	5	 Capitol Hill          	    	   5 	 4/4H  	 4/7   	 3@/2Q 	 2/HD  	 1/2    	1	 2:03.2 	 30  	 G Clark       	\N	 S Crump
192	12	3	4	 Formula D M           	    	   4 	 1/1H  	 1/2   	 1/2   	 1/HD  	 2/2    	2	 2:03.4 	 30.4	 G Hudon       	\N	 K Read
193	12	3	6	 Lilmessinaround       	    	   6 	 5/6   	 5/10  	 5@/5T 	 4/5T  	 3/4H   	3	 2:04.1 	 30  	 R Schneider   	\N	 R Schneider
194	12	3	2	 The Insinerator       	    	   2 	 2/1H  	 2/2   	 2/2   	 3/5Q  	 4/12   	4	 2:05.4 	 32.2	 D Hudon       	\N	 G Abbott
195	12	3	1	 Ganymeda Gold         	    	   1 	 3/3   	 3/5H  	 4/5Q  	 5/9T  	 5/18Q  	5	 2:07   	 33  	 N Sobey       	\N	 N Sobey
196	12	3	3	 El Capone             	    	   3X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 T Tracey      	\N	 T Tracey
197	13	1	5	 Cowboys Dirtyboots    	    	   5 	 4/5   	 4/5   	 4/4H  	 5/5H  	 1/H    	1	 1:57.4 	 29.1	 R Grundy      	7.60	 D Crick
198	13	1	2	 Hollywood Redneck     	    	   2 	 2/1H  	 2/1H  	 2/1H  	 2/2   	 2/H    	2	 1:57.4 	 29.4	 G Hudon       	9.75	 G Hudon
199	13	1	4	 Vow To Win            	    	   4 	 3/3H  	 3/3H  	 3/3   	 3/3   	 3/1    	3	 1:58   	 29.3	 D Hudon       	8.15	 Q Schneider
200	13	1	1	 Rock Shooter          	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 4/1Q   	4	 1:58   	 30.1	 T Cullen      	0.30	 T Cullen
201	13	1	6	 Rare Breed            	    	   6 	 5/6H  	 5/6H  	 5/6   	 4/5   	 5/4    	5	 1:58.3 	 29.3	 M Hennessy    	15.65	 D Sifert
202	13	1	3	 Swing N Ace           	    	   X3	 6/DIS 	 6/35  	 6/35  	 6/30  	 6/27H  	6	 2:03.1 	 28.2	 E Hensley     	9.15	 A Hensley
203	13	2	6	 Cenalta Jade          	    	   6 	 5@/3T 	 4@/2Q 	 2@/HD 	 2/2   	 1/NK   	1	 2:02   	 32.3	 Jb Campbell   	2.05	 M Roy
204	13	2	1	 Awhimaway             	    	   1 	 1/1H  	 1/HD  	 1/HD  	 1/2   	 2/NK   	2	 2:02   	 32.3	 K Clark       	4.95	 K Clark
205	13	2	4	 Minettas Highball     	    	   4 	 6/4T  	 6/5Q  	 5/5   	 4/6H  	 3/1H   	3	 2:02.1 	 31.4	 K Ducharme    	4.95	 L Ducharme
206	13	2	3	 Barbarela Rose        	    	   3 	 4/3Q  	 5@/4Q 	 6@@/5H	 I5/8  	 5P4/3T 	5	 2:02.4 	 32.2	 T Redwood     	3.45	 A Arsenault
207	13	2	7	 Nevada                	    	   7 	 8/7T  	 8/7T  	 7@@/7 	 IX6/9H	 6P5/4Q 	6	 2:02.4 	 32  	 N Sobey       	24.35	 K Clark
208	13	2	5	 Showmesomeemotion     	    	   5 	 7/6Q  	 7@/6Q 	 4@/3H 	 3/4H  	 4P6/2  	4	 2:02.2 	 32.2	 G Hudon       	4.35	 P Giesbrech
209	13	2	2	 Forever Feisty        	    	   2 	 2/1H  	 3/1Q  	 3/3Q  	 7/10H 	 7/11T  	7	 2:04.2 	 34.2	 P Shaw        	42.50	 D Shaw
210	13	2	8	 Exclusive             	    	   8 	 3@/1T 	 2@/HD 	 8/8   	 8/23  	 8/35H  	8	 2:09   	 38  	 D Hudon       	10.30	 S Arsenault
211	13	3	2	 Mystery Mania         	    	   2 	 3/3H  	 3/3   	 1@/1  	 1/4   	 1/2T   	1	 2:00.1 	 31.1	 K Clark       	2.00	 K Clark
212	13	3	5	 Whysantanna           	    	   5 	 7/10H 	 7/9   	 6/4H  	 8/8T  	 2/2T   	2	 2:00.4 	 31  	 M Hennessy    	3.80	 R Hennessy
213	13	3	6	 Mystery Affair        	    	   6 	 8/12  	 8/10H 	 8@@/5H	 7/8Q  	 3/4H   	3	 2:01   	 31  	 G Hudon       	5.30	 P Giesbrech
214	13	3	1	 Formula D M           	    	   1 	 4/5   	 4/4H  	 4@/2T 	 3/4Q  	 4/4T   	4	 2:01.1 	 31.3	 D Hudon       	19.20	 K Read
215	13	3	4	 Brendons Eileen       	    	   4 	 6/9   	 6/7H  	 7@/5  	 6/7T  	 5/6Q   	5	 2:01.2 	 31.2	 P Shaw        	6.45	 D Sifert
216	13	3	7	 Moon Struct           	    	   7 	 2/1H  	 2/1H  	 3/2H  	 5/6T  	 6/7    	6	 2:01.3 	 32.1	 N Sobey       	12.65	 G Lutz
217	13	3	3	 Emmas Big Girl        	    	   3 	 5/7   	 5/6   	 5@@/4Q	 4/5T  	 7/7    	7	 2:01.3 	 31.4	 Jb Campbell   	3.35	 D Shaw
218	13	3	8	 My Glorifly           	    	   8 	 1/1H  	 1/1H  	 2/1   	 2/4   	 8/8T   	8	 2:02   	 32.4	 R Grundy      	23.60	 D Crick
219	13	4	3	 Mystic Messenger      	    	   3 	 1/4   	 1/1H  	 1/1H  	 1/2   	 1/2    	1	 1:57.4 	 29.1	 T Bowman      	4.30	 V Sifert
220	13	4	1	 Heart N Hustle        	    	   1 	 2/4   	 2/1H  	 2/1H  	 2/2   	 2/2    	2	 1:58.1 	 29.2	 Jb Campbell   	4.25	 M Roy
221	13	4	8	 Caliscape             	    	   8 	 5/8H  	 5@/5  	 5@@/3H	 6/7H  	 3/8    	3	 1:59.2 	 30.1	 T Cullen      	3.10	 T Cullen
222	13	4	6	 Avonlee Knight        	    	   6 	 4/7   	 4@/3H 	 4@/3Q 	 5/7   	 4/9    	4	 1:59.3 	 30.2	 N Sobey       	6.05	 G Lutz
223	13	4	4	 Coliseum Hanover      	    	   4 	 6/10  	 6/5H  	 6/4H  	 4I/6  	 6P5/9T 	6	 1:59.4 	 30.2	 R Cullen      	7.40	 T Cullen
224	13	4	2	 Mister Meister        	    	   2 	 3/5H  	 3/3   	 3/3   	 3/4   	 5P6/9Q 	5	 1:59.3 	 30.2	 R Grundy      	8.90	 R Grundy
225	13	4	5	 Promise We Can        	    	   5 	 7/11H 	 7@/6H 	 7@/5  	 7/8H  	 7/10T  	7	 2:00   	 30.2	 K Clark       	9.10	 G Lutz
226	13	4	7	 Thisboycanfinish      	    	   7 	 8/13  	 8/7H  	 8@/6H 	 8/10  	 8/11H  	8	 2:00   	 30.1	 G Clark       	6.15	 S Crump
227	13	5	8	 Mods Mystery          	    	   8 	 4/4H  	 4/4H  	 3@/1Q 	 1/Q   	 1/5Q   	1	 2:01.2 	 32  	 A Arsenault   	22.80	 A Arsenault
228	13	5	3	 Crash My Party        	    	   3 	 1/1H  	 1/1H  	 2/1   	 4/2   	 2/5Q   	2	 2:02.2 	 33  	 G Hudon       	1.15	 G Hudon
229	13	5	5	 Lissie Borden         	    	   5 	 2@/1H 	 2/1H  	 1@/1  	 2/Q   	 3/6H   	3	 2:02.3 	 33.2	 T Cullen      	2.25	 D Lamont
230	13	5	4	 Hf Princess Peach     	    	   4 	 6/9   	 7/8   	 6@/5Q 	 3/1T  	 4/6H   	4	 2:02.3 	 32.2	 M Hennessy    	17.30	 H Haining
231	13	5	1	 Starry Eyes           	    	   1 	 5/7H  	 5/6H  	 7/7Q  	 7/6H  	 5/7H   	5	 2:02.4 	 32.1	 D Sifert      	11.95	 D Sifert
232	13	5	6	 Is Santa Real         	    	   X6	 8/12H 	 6@/7H 	 4@/4Q 	 5/4   	 6/8Q   	6	 2:03   	 33  	 N Sobey       	6.25	 N Sobey
233	13	5	7	 Fast Lane Denali      	    	   7 	 7/11  	 8/9H  	 8/9Q  	 8/8   	 7/8H   	7	 2:03   	 32  	 T Tracey      	23.20	 T Tracey
234	13	5	2	 Miss Bojangles        	    	   2 	 3/3   	 3/3   	 5/4T  	 6/6   	 8/10Q  	8	 2:03.2 	 33.1	 K Clark       	8.40	 J Ratchford
235	13	6	1	 Dickies Motel         	    	   1 	 2/1H  	 3/1H  	 3@/2  	 3/1T  	 1/1H   	1	 1:58.1 	 31.1	 Jb Campbell   	6.70	 R Schneider
236	13	6	3	 Viola                 	    	   3 	 3/3   	 2@/H  	 1/1H  	 1/1H  	 2/1H   	2	 1:58.2 	 31.4	 J Hudon       	5.15	 J Hudon
237	13	6	9	 P L Impressive        	    	   9 	 4/4H  	 5@/4  	 4/7   	 4/3T  	 3/2Q   	3	 1:58.3 	 30.3	 E Hensley     	4.80	 A Hensley
238	13	6	5	 Happy Promise         	    	   5 	 1/1H  	 1/H   	 2/1H  	 2/1H  	 4/3Q   	4	 1:58.4 	 32  	 G Clark       	8.15	 G Clark
239	13	6	7	 Royal Classic         	    	   7 	 8/13  	 8/8T  	 5/9   	 5/5T  	 5/4T   	5	 1:59.1 	 30.4	 D Hudon       	18.55	 Q Schneider
240	13	6	6	 Wigesjet              	    	   6 	 7/11  	 7@/8H 	 6/10H 	 6/9T  	 6/10   	6	 2:00.1 	 31.3	 T Cullen      	4.55	 J Marchment
241	13	6	8	 Hoofenanny            	    	   8 	 9/14H 	 9/10Q 	 7/13H 	 7/12T 	 7/11Q  	7	 2:00.2 	 31.1	 M Hennessy    	16.35	 D Cutting
242	13	6	2	 Club Dreams           	    	   2 	 6/9   	 4/3H  	 X8/23H	 8/17T 	 8DQ/14T	8	 2:01.1 	 30  	 D A Kelly     	7.80	 R Parish
243	13	6	4	 Terra True            	    	   4 	 5/7H  	 6@/5H 	 IX9/DI	 FELL  	 DNF    	\N	        	     	 G Hudon       	3.05	 G Hudon
244	14	1	5	 Sudden Storm          	    	   5 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/T    	1	 1:58.2 	 29.3	 T Bowman      	4.40	 D Sifert
245	14	1	6	 Outlaw This Is It     	    	   6 	 6@/8  	 5@/3H 	 2@/H  	 2/1H  	 2/T    	2	 1:58.3 	 29.4	 T Redwood     	6.15	 D Stout
246	14	1	7	 Canelo                	    	   7 	 2/1H  	 3/1T  	 3/2   	 3/3H  	 3/3H   	3	 1:59   	 29.4	 T Cullen      	2.70	 T Cullen
247	14	1	9	 Scrappy Fella         	    	   9 	 8/10H 	 7@/5H 	 4@/4  	 4/6H  	 4/4H   	4	 1:59.1 	 29.3	 M Hennessy    	4.45	 R Hennessy
248	14	1	4	 Cenalta Eclipse       	    	   4 	 7/9   	 8/7   	 6/5H  	 5/8H  	 5/4T   	5	 1:59.2 	 29.3	 R Goulet      	2.95	 G Empey
249	14	1	1	 Shyloh Sage           	    	   1 	 3/3   	 4/3Q  	 5/5   	 6/9H  	 6/8T   	6	 2:00.1 	 30.2	 A Arsenault   	10.55	 A Arsenault
250	14	1	3	 Thisboyisonfire       	    	   3 	 5/7H  	 6/5   	 7/7   	 7/13H 	 7/18   	7	 2:02   	 31.4	 Jb Campbell   	22.55	 Jb Campbell
251	14	1	2	 Speed Shift           	    	   2 	 4/4H  	 2@/1H 	 8@/7H 	 8/17H 	 8/21T  	8	 2:02.4 	 32.3	 G Hudon       	15.20	 K Read
252	14	1	8	 Sayitlikeyoumeanit    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
253	14	2	6	 Kim Chee              	    	   6 	 4/4H  	 4@/3T 	 3@/2H 	 2/2   	 1/NK   	1	 1:58.2 	 30  	 N Sobey       	3.00	 G Lutz
254	14	2	4	 Shes A Ladro          	    	   4 	 1/1H  	 1/2   	 1/2   	 1/2   	 2/NK   	2	 1:58.2 	 30.2	 B Gray        	13.10	 B Gray
255	14	2	9	 Yanotherhos           	    	   9 	 5/6   	 5@/5Q 	 5@/3T 	 4/4H  	 3/1    	3	 1:58.3 	 29.4	 T Bowman      	2.70	 J Waltenbur
256	14	2	1	 Fast Lane Ferrari     	    	   1 	 2/1H  	 2/2   	 2/2   	 3/3H  	 4/3T   	4	 1:59.1 	 30.4	 D Hudon       	6.20	 D Hudon
257	14	2	8	 Triple Action         	    	   8 	 9/12  	 9/9H  	 7@@/6H	 5/9H  	 5/8T   	5	 2:00.1 	 31  	 G Hudon       	17.60	 J Ratchford
258	14	2	3	 Run And Tell          	    	   3 	 7/9   	 7/7T  	 9@@/8T	 9/11  	 6/9H   	6	 2:00.1 	 30.2	 T Tracey      	5.55	 T Tracey
259	14	2	5	 Three Wishes          	    	   5 	 8/10H 	 8@/8  	 6@/6Q 	 8/10H 	 7/10T  	7	 2:00.3 	 31.2	 T Cullen      	4.25	 K Howard
260	14	2	7	 Little Sister         	    	   7 	 3/3   	 3@/2Q 	 4/3H  	 6/9T  	 8/14   	8	 2:01.1 	 32.3	 T Redwood     	13.70	 A Macleod
261	14	2	2	 Market For Romance    	    	   2 	 6/7H  	 6/5T  	 8/6T  	 7/10Q 	 9/16T  	9	 2:01.4 	 32.2	 K Ducharme    	31.20	 K Ducharme
262	16	1	1	 All The Weapons       	    	   1 	 2/1H  	 2/1T  	 2/2   	 2/1Q  	 1/3    	1	 2:00   	 29.4	 Bri Macphee   	3.20	 A Mc Guigan
263	16	1	6	 Caughtfoolinaround    	    	   6 	 1/1H  	 1/1T  	 1/2   	 1/1Q  	 2/3    	2	 2:00.3 	 30.4	 K Murphy      	1.30	 R Reynolds
264	16	1	8	 Twin B Macho          	    	   7 	 4/4H  	 4@/3H 	 3/3T  	 3/2T  	 3/5T   	3	 2:01.1 	 30.3	 K Arsenault   	5.30	 P Morrison
265	16	1	4	 Bumpsandbruises       	    	   4 	 6/7T  	 7@/7  	 4@@/6 	 4/4H  	 4/6    	4	 2:01.1 	 30.1	 R Neill       	2.50	 L Neill
266	16	1	5	 Canadian Rocket       	    	   5 	 7/10  	 6/6H  	 7/8T  	 6/8H  	 5/9    	5	 2:01.4 	 30.1	 M Cullen      	7.45	 G Macdougal
267	16	1	2	 Hopedale Paris        	    	   2 	 5/6   	 5@/5Q 	 5@/7  	 5/6T  	 6/9T   	6	 2:02   	 30.4	 Jy Pineau     	13.20	 Jy Pineau
268	16	1	3	 St Lads Coach         	    	   3 	 3/2T  	 3/3Q  	 6/7H  	 7/10H 	 7/22   	7	 2:04.2 	 33.1	 K Wilkie      	25.30	 K Wilkie
269	16	1	7	 Sparky Bayama         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
270	16	2	5	 Neal                  	    	   4 	 1@/1Q 	 1/1H  	 1/1T  	 1/1T  	 1/3T   	1	 2:02.1 	 29.3	 B Andrew      	0.85	 B Andrew
271	16	2	4	 Howmacs Pride         	    	   3 	 2/1Q  	 2/1H  	 2/1T  	 2/1T  	 2/3T   	2	 2:03   	 30  	 K Arsenault   	1.75	 K Arsenault
272	16	2	1	 Dusty Lane Jacob      	    	   1 	 3/3   	 3/3   	 3/3H  	 3/3Q  	 3/8H   	3	 2:03.4 	 30.3	 W Murphy      	7.55	 C Mac Donal
273	16	2	3	 Tymal Tyme            	    	   X2	 X5/7  	 4@/4  	 5/11  	 5/14  	 5P4/27 	5	 2:07.3 	 32.4	 Bri Macphee   	7.55	 C Mac Donal
274	16	2	6	 High Flying=          	    	   5 	 4/5Q  	 5/4H  	 4@X/4H	 4/4H  	 4P5/19 	4	 2:06   	 32.3	 G Hennessey   	3.65	 G Hennessey
275	16	2	2	 Job Well Done         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
276	16	3	5	 Anianne Hanover       	    	   5 	 3@/2H 	 3@/1T 	 2@/1  	 2/H   	 1/NK   	1	 2:00.4 	 29.4	 T Walsh       	1.30	 T Walsh
277	16	3	4	 Smart N Articulate    	    	   4 	 1/1T  	 1/1H  	 1/1   	 1/H   	 2/NK   	2	 2:00.4 	 30  	 K Arsenault   	2.60	 J Smith
278	16	3	8	 Scoot Out Of Here     	    	   7 	 5/5T  	 5@/6Q 	 4/3Q  	 4/2T  	 3/2    	3	 2:01.1 	 29.4	 V Doyle       	3.40	 V Doyle
279	16	3	1	 Outrageous Belle      	    	   1 	 2/1T  	 2/1H  	 3/1H  	 3/1T  	 4/3    	4	 2:01.2 	 30.2	 R Matheson    	10.25	 J Matheson
280	16	3	6	 Silverhill Midnite    	    	   6 	 6/7H  	 6@/8  	 5/7H  	 5/8   	 5/14   	5	 2:03.3 	 31.2	 P Lanigan     	15.90	 W Lanigan
281	16	3	3	 New Boss In Town      	    	   3 	 7/9   	 7/12  	 6/13  	 6/14  	 6/21   	6	 2:05   	 31.3	 G Chappell    	4.70	 E Watts
282	16	3	2	 Popa Was A Gigolo     	    	   2 	 4/3T  	 4/5T  	 7/17  	 7/25  	 7/DIS  	7	        	     	 K Sorrie      	11.40	 J Clarey
283	16	3	7	 Baby Picka            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
284	16	4	5	 Caliban Hanover       	    	   5 	 5/5   	 6@/6Q 	 5@/2T 	 3/1Q  	 1/3    	1	 2:02.3 	 30.1	 A Merner      	3.45	 R Gass
285	16	4	4	 Parkhill Jugernaut=   	    	   4 	 3/2   	 3@/3  	 1@/Q  	 1/Q   	 2/3    	2	 2:03.1 	 31.2	 A Campbell    	6.05	 A Campbell
286	16	4	7	 Tyne Valley=          	    	   7 	 6/7Q  	 4@/4H 	 3@/1H 	 4/1H  	 3/4    	3	 2:03.2 	 31.2	 C Cheverie    	1.45	 W Roloson
287	16	4	3	 Hopedale Dora         	    	   3 	 1/T   	 2/1T  	 4/1T  	 5/1T  	 4/4T   	4	 2:03.3 	 31.2	 Jy Pineau     	5.95	 Jy Pineau
288	16	4	6	 Majian Dillon=        	    	   6 	 2@/T  	 1/1T  	 2/Q   	 2/Q   	 5/4T   	5	 2:03.3 	 31.4	 J Ripley      	12.95	 J Ripley
289	16	4	2	 Phantom Beau=         	    	   2 	 7/10H 	 7/9H  	 7/6Q  	 7/5H  	 6/5T   	6	 2:03.4 	 30.4	 K Arsenault   	2.55	 T Weatherbi
290	16	4	1	 Diamond Mine          	    	   1 	 4/3H  	 5/4T  	 6/3H  	 6/4   	 7/7Q   	7	 2:04   	 31.3	 W Murphy      	11.95	 C Mac Donal
291	16	5	5	 J J Dream Chasin      	    	   5 	 2/Q   	 1/1Q  	 1/1Q  	 1/1Q  	 1/1    	1	 2:01.2 	 30  	 G Chappell    	0.60	 G Chappell
292	16	5	6	 Dustlanemissmolly     	    	   6 	 1@/Q  	 2/1Q  	 3/1H  	 2/1Q  	 2/1    	2	 2:01.3 	 30  	 A Merner      	5.70	 R Gass
293	16	5	3	 Gangnam Style         	    	   3 	 3/3H  	 3/3   	 5/3   	 3/3Q  	 3/1Q   	3	 2:01.3 	 29.3	 G Hennessey   	8.00	 J Matheson
294	16	5	4	 Mileysgotthepower     	    	   4 	 6/8Q  	 6@/5H 	 4@/2T 	 5/5   	 4/6H   	4	 2:02.3 	 30.3	 R Neill       	4.90	 J Noye
295	16	5	2	 Victory Cry           	    	   2 	 5/6H  	 4@/3Q 	 2@/1Q 	 4/3H  	 5/9T   	5	 2:03.2 	 31.4	 K Arsenault   	4.35	 K Arsenault
296	16	5	1	 Camtizzy              	    	   1 	 4/5   	 5/4Q  	 6/5   	 6/8   	 6/18   	6	 2:05   	 32.3	 R Matheson    	8.90	 J Matheson
297	16	6	5	 Freddie=              	    	   5 	 5/8T  	 4@/3Q 	 1@/T  	 1/4   	 1/6T   	1	 1:59   	 28.4	 R Desroche    	0.60	 Ma Campbell
298	16	6	2	 Wedgewood=            	    	   2 	 3/3T  	 3/3   	 4@/2T 	 3/4Q  	 2/6T   	2	 2:00.2 	 29.3	 G Chappell    	5.65	 G Claybourn
299	16	6	6	 Majian Chester        	    	   6 	 4/6H  	 5/4H  	 5@/4T 	 5/6T  	 3/9    	3	 2:00.4 	 29.3	 J Ripley      	27.45	 J Ripley
300	16	6	4	 I Aint No Lady        	    	   4 	 1/1H  	 1/1H  	 2/T   	 2/4   	 4/9Q   	4	 2:00.4 	 30.2	 Bri Macphee   	13.75	 G Cole
301	16	6	1	 Holy Molie Maggie=    	    	   1 	 2/1H  	 2/1H  	 3/2H  	 4/5Q  	 5/10H  	5	 2:01   	 30.2	 Jy Pineau     	13.15	 J Holmes
302	16	6	3	 Frill Seeker=         	    	   X3	 6/10H 	 6/6   	 6/6   	 6/7H  	 6/12   	6	 2:01.2 	 30  	 K Arsenault   	1.45	 K Arsenault
303	17	1	1	 Pictonian Zena+       	    	   1 	 1/Q   	 1/1H  	 1/3H  	 1/4Q  	 1/5    	1	 1:59.3 	 30.3	 S Bernard     	1.00	 S Bernard
304	17	1	3	 South Cove Pearl      	    	   3 	 4/4T  	 4/5   	 4@/5  	 3/4H  	 2/5    	2	 2:00.3 	 30.3	 K Arsenault   	7.65	 J Arsenault
305	17	1	2	 Briannas Angel        	    	   2 	 3/3Q  	 3/3Q  	 2@/3H 	 2/4Q  	 3/5Q   	3	 2:00.3 	 31  	 C Cheverie    	1.40	 T Wilkie
306	17	1	4	 A Littlegirlsdream    	    	   4 	 5/6Q  	 5/6H  	 5@/6Q 	 4/6Q  	 4/6Q   	4	 2:00.4 	 30.3	 R Phillips    	6.80	 R Phillips
307	17	1	7	 M D Caseys Charm      	    	   7 	 2@/Q  	 2/1H  	 3/4T  	 5/7H  	 5/12   	5	 2:02   	 32  	 S Ford        	21.05	 S Ford
308	17	1	5	 R Es Kate             	    	   5 	 6/10  	 6/8H  	 6/8H  	 6/10  	 6/13H  	6	 2:02.1 	 31.3	 R Neill       	9.30	 L Neill
309	17	1	6	 G Js Winning Fool     	    	   6 	 7/12H 	 7/13  	 7/15  	 7/16  	 7/17   	7	 2:03   	 31  	 R Desroche    	22.85	 K Wilkie
310	17	2	2	 Female Finesse        	    	   2 	 2/1H  	 2/1T  	 2/1H  	 2/1Q  	 1/1H   	1	 1:58.4 	 29  	 G Chappell    	3.50	 W White
311	17	2	3	 Outrageous Spirit     	    	   3 	 1/1H  	 1/1T  	 1/1H  	 1/1Q  	 2/1H   	2	 1:59   	 29.2	 G Hennessey   	0.50	 K Peters
312	17	2	5	 Julep Hanover         	    	   5 	 4/5   	 4/4T  	 4@/3Q 	 4/2T  	 3/4H   	3	 1:59.3 	 29.2	 W Myers       	8.75	 W Myers
313	17	2	1	 Starlight Violet      	    	   1 	 5/7Q  	 5/6H  	 5/4T  	 6/4Q  	 4/5    	4	 1:59.4 	 29.1	 K Murphy      	12.70	 M Bradley
314	17	2	4	 Gramercy Hanover      	    	   4 	 3/3Q  	 3/3Q  	 3@/2  	 3/1T  	 5/5T   	5	 2:00   	 30  	 B Webster     	4.45	 B Macleod
315	17	2	6	 Bettim Jenny          	    	   6 	 6/9T  	 6/8T  	 6@/5T 	 5/3Q  	 6/6    	6	 2:00   	 29.1	 J Lilley      	20.35	 J Lilley
316	17	2	7	 Yankee No More        	    	   7 	 7/12  	 7/11H 	 7/7Q  	 7/6   	 7/9T   	7	 2:00.4 	 29.4	 D Mac Neill   	15.35	 D Smith
317	17	3	5	 Jetta Flys+           	    	   5 	 1/1T  	 1/1H  	 1/1Q  	 1/1Q  	 1/2H   	1	 1:59.4 	 28.3	 S Quinn       	5.25	 S Quinn
318	17	3	2	 Van Zant              	    	   2 	 2/1T  	 2/1H  	 3/1H  	 2/1Q  	 2/2H   	2	 2:00.1 	 28.4	 R Matheson    	0.80	 J Matheson
319	17	3	3	 Cloudy Bay            	    	   3 	 4/5   	 5/4Q  	 6/4Q  	 4/5   	 3/8H   	3	 2:01.2 	 29.2	 A Merner      	2.00	 A Merner
320	17	3	1	 Ok Gladiator          	    	   1 	 3/3Q  	 3/3   	 4/2T  	 3/3H  	 4/9T   	4	 2:01.4 	 30  	 V Doyle       	15.15	 V Doyle
321	17	3	6	 Incredible Mike       	    	   6 	 6/11  	 6@/5  	 5@/3  	 6/6Q  	 5/11H  	5	 2:02   	 30.1	 K Murphy      	12.00	 G Macdougal
322	17	3	4	 Textually Active      	    	   4 	 5/9   	 4@/3H 	 2@/1Q 	 5/5T  	 6/13   	6	 2:02.2 	 31  	 G Chappell    	10.70	 P Gregory
323	17	3	7	 P H Littlecam         	    	   7 	 7/13H 	 7/7   	 8/5T  	 7/7   	 7/14   	7	 2:02.3 	 30.1	 Bri Macphee   	27.00	 B Webster
324	17	3	8	 Avid Yankee           	    	   8 	 8/16  	 8/8Q  	 7@/4H 	 8/7H  	 8/15   	8	 2:02.4 	 30.4	 M Mcguigan    	27.20	 A Ramsay
325	17	4	6	 Windemere Stanley     	    	   5 	 4/3T  	 3@/3  	 2@/HD 	 2/Q   	 1/1H   	1	 1:58   	 30.4	 A Merner      	6.50	 K Gillis
326	17	4	8	 Every Day             	    	   7 	 2@/1  	 2/1T  	 3/2Q  	 3/2Q  	 2/1H   	2	 1:58.1 	 30.3	 B Andrew      	13.90	 B Andrew
327	17	4	2	 Astronomical Union    	    	   2 	 1/1   	 1/1T  	 1/HD  	 1/Q   	 3/1T   	3	 1:58.2 	 31.1	 M Mcguigan    	1.20	 J Matheson
328	17	4	1	 Jamantha              	    	   1 	 3/2Q  	 4/3H  	 4/4Q  	 4/4Q  	 4/4Q   	4	 1:58.4 	 30.4	 D Mac Neill   	3.45	 D Macneill
329	17	4	4	 C J Bluefin+          	    	   4 	 6/7T  	 6/6   	 6/6   	 6/5H  	 5/4T   	5	 1:59   	 30.3	 N Bambrick    	14.70	 N Bambrick
330	17	4	7	 Miramonttogo          	    	   6 	 7/9H  	 7@/6T 	 7@/6Q 	 5/5Q  	 6/7H   	6	 1:59.2 	 31  	 G Neill       	25.45	 G Neill
331	17	4	3	 Howmac Royale         	    	   3 	 5/6   	 5@/5Q 	 5@/5  	 7/5T  	 7/13H  	7	 2:00.3 	 32.2	 K Arsenault   	1.70	 B Mullen
332	17	4	5	 Million Teen          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
333	17	5	6	 Smiley Bayama         	    	   6 	 3/2T  	 2@/1Q 	 1@/Q  	 1/T   	 1/1H   	1	 1:56.1 	 29  	 A Merner      	2.35	 R Gass
334	17	5	3	 Bazillion             	    	   3 	 2/1H  	 3/1H  	 3/1T  	 3/1H  	 2/1H   	2	 1:56.2 	 28.4	 Bri Macphee   	0.45	 T Hicken
335	17	5	1	 My Lucky Killean      	    	   1 	 1/1H  	 1/1Q  	 2/Q   	 2/T   	 3/5T   	3	 1:57.2 	 30.1	 K Murphy      	11.25	 C Murphy
336	17	5	4	 Nogreatmischief       	    	   4 	 4/4Q  	 4@/3Q 	 X7@/9 	 7/8   	 4/7H   	4	 1:57.3 	 28.3	 C Cheverie    	7.05	 C Cheverie
337	17	5	7	 Perfect Escape+       	    	   7 	 7/9H  	 7/7   	 6/6T  	 6/7Q  	 5/8    	5	 1:57.4 	 29.1	 R Matheson    	23.85	 J Matheson
338	17	5	2	 Whosurwinner          	    	   2 	 5/6Q  	 5/4T  	 4/5Q  	 4/6   	 6/8Q   	6	 1:57.4 	 29.3	 M Mcguigan    	16.25	 D Clow
339	17	5	5	 Tempo Seelster        	    	   5 	 6/8   	 6@/5  	 5@/6H 	 5/6T  	 7/8T   	7	 1:58   	 29.3	 T Walsh       	15.45	 V Poulton
340	17	6	7	 Windsun Rebel         	    	   7 	 8/15  	 8/6T  	 7@/9Q 	 7/5H  	 1/NK   	1	 1:58.2 	 28.1	 V Doyle       	16.40	 V Doyle
341	17	6	4	 Idealic Life          	    	   4 	 6/9H  	 5@/4  	 5@/5T 	 5/4Q  	 2/NK   	2	 1:58.2 	 28.4	 K Sorrie      	2.20	 T Hicken
342	17	6	6	 I D K                 	    	   6 	 1/1H  	 1/1T  	 1/2T  	 1/2H  	 3/NK   	3	 1:58.2 	 30  	 A Merner      	3.90	 D Clow
343	17	6	3	 Jersey Joe            	    	   3 	 4/5H  	 3@/2H 	 3@/4Q 	 3/2T  	 4/T    	4	 1:58.3 	 29.2	 V Poulton     	1.65	 D Clow
344	17	6	2	 Artners In Crime      	    	   2 	 2/1H  	 2/1T  	 2/2T  	 2/2H  	 5/1Q   	5	 1:58.3 	 29.3	 R Matheson    	4.60	 J Matheson
345	17	6	1	 Someone Like You      	    	   1 	 3/3   	 4/3H  	 4/4H  	 4/4   	 6/1H   	6	 1:58.3 	 29.2	 M Mcguigan    	8.05	 R Ferguson
346	17	6	8	 Superbo Hanover       	    	   8 	 5/7Q  	 6/5Q  	 6/7Q  	 6/5Q  	 7/3Q   	7	 1:59   	 29.1	 G Hennessey   	24.70	 G Hennessey
347	17	6	5	 Daylyn Horizon        	    	   5 	 7@/13 	 7@/6Q 	 8@@/10	 8/11  	 8/13   	8	 2:01   	 30.3	 G Chappell    	13.50	 B Campbell
348	18	1	2	 Rewind Again          	    	   2 	 3/5H  	 3/4   	 1/8   	 1/11  	 1/14   	1	 2:02   	 30  	 K Murphy      	\N	 C Murphy
349	18	1	3	 Ic Brandonscowgirl    	    	   3 	 4/9   	 4/10  	 3@/11 	 3/12  	 2/14   	2	 2:04.4 	 30.3	 A Merner      	\N	 A Merner
350	18	1	4	 Gypsy Queen           	    	   4 	 1/3H  	 1/2   	 2/8   	 2/11  	 3/18H  	3	 2:05.3 	 32  	 N Myers       	\N	 M Macdonald
351	18	1	1	 Monastery             	    	   1 	 2/3H  	 2/2   	 4/14  	 4/DIS 	 4/DIS  	4	        	     	 K Arsenault   	\N	 K Arsenault
352	18	2	4	 Oceanview Pancho=     	    	   4 	 2/2H  	 2/2   	 2/2H  	 2/2H  	 1/H    	1	 2:06.4 	 30.3	 P Larrabee    	\N	 P Larrabee
353	18	2	3	 B J Classic=          	    	   3 	 1/2H  	 1/2   	 1/2H  	 1/2H  	 2/H    	2	 2:06.4 	 31  	 Bri Macphee   	\N	 B Honkoop
354	18	2	5	 Glencove Carter=      	    	   5 	 X3X/9 	 5/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 H Shepherd    	\N	 C Bagnall
355	18	2	1	 Sanctified=           	    	   X1	 5/DIS 	 4/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 B Andrew      	\N	 B White
356	18	2	2	 Glencove Zsa Zsa      	    	   2X	 4/DIS 	 3/DIS 	 5X/DIS	 X5/DIS	 5/DIS  	5	        	     	 K Arsenault   	\N	 C Bagnall
357	18	3	3	 Mick Dundee           	    	   3 	 1/2   	 1/1T  	 1/2   	 1/H   	 1/T    	1	 2:01.4 	 29.1	 D Mac Neill   	\N	 D Mac Neill
358	18	3	1	 Ascaryone Hanover     	    	   1 	 2/2   	 2/1T  	 2/2   	 2/H   	 2/T    	2	 2:02   	 29  	 K Murphy      	\N	 C Murphy
359	18	3	2	 Jamiesmilingcowboy    	    	   2 	 3/4   	 3/3H  	 3/3H  	 X3/8  	 3/21   	3	 2:06   	 32.4	 K Arsenault   	\N	 K Arsenault
360	18	4	1	 Sanchez Blue Chip     	    	   1 	 3/11  	 3/4Q  	 2@/1H 	 2/1H  	 1/1H   	1	 2:02   	 29.4	 V Poulton     	\N	 D Clow
361	18	4	4	 Zanzibar+             	    	   4 	 1/8   	 1/2H  	 1/1H  	 1/1H  	 2/1H   	2	 2:02.1 	 30.1	 P Morrison    	\N	 P Morrison
362	18	4	3	 Umiztagoodthing+      	    	   3 	 2/8   	 2/2H  	 3/2T  	 3/2T  	 3/2    	3	 2:02.2 	 29.4	 T Walsh       	\N	 T Walsh
363	18	4	2	 Prynne Hanover+       	    	   2 	 4/13H 	 4/6   	 4@/3H 	 4/4H  	 X4/7H  	4	 2:03.2 	 30.4	 A Campbell    	\N	 R Squires
364	21	1	5	 Retail                	    	   4 	 1/3H  	 1/6H  	 1/12  	 1/13H 	 1/12H  	1	 1:57.1 	 29.1	 D Mcnair      	1.45	 D Meekison 
365	21	1	1	 Jazzmo                	    	   1 	 2/3H  	 2/6H  	 2/12  	 2/13H 	 2/12H  	2	 1:59.3 	 29.1	 L House       	1.75	 F Schaeffer
366	21	1	6	 Slots Of Fun          	    	   5 	 5/8H  	 5/12H 	 5@/18 	 5/19Q 	 3/14T  	3	 2:00.1 	 28.3	 G Rooney      	3.40	 R Carroll
367	21	1	3	 Chevalier Semalu      	    	   3 	 4/6T  	 4/11  	 3@/16H	 3/16H 	 4/17Q  	4	 2:00.3 	 29.2	 B Mcclure     	16.20	 L Privett
368	21	1	2	 Lautner Seelster      	    	   2 	 3/5Q  	 3/9H  	 4/17  	 4/18Q 	 5/18H  	5	 2:00.4 	 29.2	 Ja Macdonald  	2.65	 F Maguire
369	21	1	4	 Goliath Reigns        	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
370	21	2	5	 Shanghai Sugar        	    	   5 	 4/5   	 2@/1H 	 1/2H  	 1/5   	 1/4H   	1	 2:00   	 29  	 Tra Henry     	5.80	 Tra Henry
371	21	2	4	 Odysseus              	    	   4 	 2/1T  	 3/1T  	 2@/2H 	 2/5   	 2/4H   	2	 2:00.4 	 29.2	 Ja Macdonald  	14.55	 T Macdonnel
372	21	2	1	 Lady Sherri           	    	   1 	 1/1T  	 1/1H  	 3/3H  	 3/9   	 3/7    	3	 2:01.2 	 29.4	 J Hudon Jr    	20.00	 J Hudon Jr
373	21	2	3	 Southern Heart        	    	   3 	 6/8H  	 5@/4H 	 5@/6T 	 4/10Q 	 4/9    	4	 2:01.4 	 29.2	 S Filion      	1.50	 Dr I Moore
374	21	2	6	 Loves Angel           	    	   6 	 5/6T  	 6/5T  	 6/6T  	 7/13T 	 5/9H   	5	 2:01.4 	 29.2	 D Mcnair      	3.60	 R Mcnair
375	21	2	2	 Miss Mary Luck        	    	   2 	 3/3H  	 4/3Q  	 4/5Q  	 5/11Q 	 6/12Q  	6	 2:02.2 	 30.2	 B Davis Jr    	9.15	 B Macintosh
376	21	2	7	 St Lads Glory Gal     	    	   7 	 7/10Q 	 7@/7  	 7@/8H 	 6/12T 	 7/12H  	7	 2:02.2 	 29.4	 B Mcclure     	29.20	 J Dupont
377	21	3	2	 Buttons               	    	   2 	 1/1H  	 1/1   	 1/2   	 1/3H  	 1/2    	1	 1:58.4 	 28.4	 N Steward     	0.90	 B Belore
378	21	3	7	 Charmbo Curiosity     	    	   7 	 4/5Q  	 4@/3H 	 4/4H  	 3/4Q  	 2/2    	2	 1:59.1 	 28.2	 Trev Henry    	7.20	 P Bissett
379	21	3	1	 No Atm Fee            	    	   1 	 2/1H  	 3/2   	 3/3   	 2/3H  	 3/2Q   	3	 1:59.1 	 28.3	 Br Richardson 	4.45	 R Elgie
380	21	3	3	 Poplar Duke           	    	   3 	 3/3H  	 2@/1  	 2@/2  	 4/6Q  	 4/7Q   	4	 2:00.1 	 29.4	 D Mcnair      	2.10	 V Vanstone
381	21	3	4	 Big Sport             	    	   4 	 5/7   	 5@/5H 	 5@/6  	 5/8   	 5/8H   	5	 2:00.2 	 29.1	 G Rooney      	10.50	 H Toll
382	21	3	6	 Band Of Luck          	    	   6 	 7/10T 	 6/6H  	 6/7   	 6/10H 	 6/10H  	6	 2:00.4 	 29.2	 L House       	19.50	 S Taylor
383	21	3	5	 Arts First Luck       	    	   5 	 6/8T  	 7@/7H 	 X7/DIS	 7/DIS 	 7/DIS  	7	        	     	 T Smith       	23.15	 J Walker
384	21	4	7	 Bradys Play           	    	   7 	 2/1H  	 2@/1  	 1/1T  	 1/1H  	 1/1H   	1	 2:01.2 	 30.3	 D Mcnair      	16.05	 C Blake
385	21	4	3	 Todays Sports         	    	   3 	 5/6H  	 5/4T  	 6@/5T 	 4/5   	 2/1H   	2	 2:01.3 	 29.3	 Trev Henry    	1.30	 R Mcintosh
386	21	4	5	 Acefourtyfourxman     	    	   5 	 4/5   	 4@/2T 	 2@/1T 	 2/1H  	 3/3    	3	 2:02   	 30.4	 N Steward     	4.35	 G Durbano
387	21	4	4	 Kingsley B            	    	   4 	 6/8H  	 6/6Q  	 8/7T  	 6/8T  	 4/5T   	4	 2:02.3 	 30.1	 Mi Horner     	22.95	 O Bock
388	21	4	8	 Our Real Lady         	    	   8 	 7/10Q 	 7@/7Q 	 4@/3T 	 3/4   	 5/6    	5	 2:02.3 	 31  	 L House       	9.40	 G Arnold
389	21	4	6	 Rumour Has It Eh      	    	   6 	 8/12T 	 8/9Q  	 7@@/6T	 5/6Q  	 6/6Q   	6	 2:02.3 	 30.2	 Ja Macdonald  	17.60	 T Macdonnel
390	21	4	2	 Vinmara               	    	   2 	 3/3Q  	 3/2T  	 5/4T  	 7/11Q 	 7/9H   	7	 2:03.1 	 31.2	 G Rooney      	5.10	 A Shelton
391	21	4	1	 Raiders Hall          	    	   1 	 1/1H  	 1/1   	 3/2T  	 8/12Q 	 8/28Q  	8	 2:07   	 35.3	 Br Richardson 	2.45	 S Bell
392	21	5	5	 Red Leaf Morgan       	    	   5 	 5/6T  	 2@/1H 	 1@/T  	 1/4H  	 1/5Q   	1	 2:01.1 	 29  	 D Mcnair      	2.30	 J Watt
393	21	5	1	 Riverwalk             	    	   1 	 4/5Q  	 6/4Q  	 4@@/3Q	 3/4H  	 2/5Q   	2	 2:02.1 	 29.2	 G Rooney      	8.70	 G Jacklin
394	21	5	3	 Albergetty            	    	   3 	 2/1T  	 3/1H  	 3/2Q  	 4/6   	 3/5H   	3	 2:02.1 	 29.3	 C Steacy      	8.70	 D Walters
395	21	5	4	 Jiffyson              	    	   4 	 3/3H  	 4/3   	 5@/4Q 	 5/7   	 4/6H   	4	 2:02.2 	 29.2	 Trev Henry    	5.35	 P Bissett
396	21	5	2	 Lucky Beach           	    	   2 	 1/1T  	 1/1H  	 2/T   	 2/4H  	 5/7    	5	 2:02.3 	 30.1	 L House       	1.55	 S Taylor
397	21	5	6	 Lmc Nukular Stryke    	    	   6 	 6/8H  	 5@/3  	 6/9T  	 6/17  	 6/28Q  	6	 2:06.4 	 32.3	 N Steward     	2.75	 G Durbano
398	21	6	5	 Treasures Pearl       	    	   4 	 2/1H  	 3/1H  	 3/1T  	 3/2Q  	 1/H    	1	 1:59.4 	 28.3	 S Filion      	0.85	 R Adams
399	21	6	1	 The Joy Luck Club     	    	   1 	 3/3   	 2@/NS 	 2@/1Q 	 2I/1Q 	 3P2/2T 	3	 2:00.2 	 29.2	 Mi Horner     	3.65	 Ma Horner
400	21	6	3	 Shewearsthepants      	    	   3 	 1/1H  	 1/NS  	 1/1Q  	 1/1Q  	 2P3/H  	2	 1:59.4 	 29  	 D Mcnair      	1.70	 R Mcnair
401	21	6	2	 Artistic Style        	    	   2 	 4/4T  	 4/3H  	 4@@/2Q	 4/4Q  	 4/6Q   	4	 2:01   	 29.4	 Trev Henry    	3.95	 R Mcintosh
402	21	6	4	 Mach On               	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
403	21	6	6	 Casimir Qt            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
404	22	1	1	 Jet Airliner          	    	   1 	 1/1T  	 1/1Q  	 1/HD  	 1/1   	 1/H    	1	 1:58.4 	 29  	 D Mcnair      	1.20	 J Watt
405	22	1	6	 Jackstan              	    	   6 	 2/1T  	 3/2Q  	 3/1H  	 3/2   	 2/H    	2	 1:58.4 	 28.4	 Ja Macdonald  	10.45	 F Maguire
406	22	1	2	 Kinmundys Stryker     	    	   2 	 3/3T  	 2@/1Q 	 2@/HD 	 2/1   	 3/1Q   	3	 1:59   	 29.1	 Br Richardson 	3.70	 C Schneider
407	22	1	3	 B N Bad               	    	   3 	 4/5H  	 4@/3H 	 4@/1H 	 4/3   	 4/1T   	4	 1:59.1 	 29.1	 Tra Henry     	4.25	 Tra Henry
408	22	1	7	 Stonebridge Scout     	    	   7 	 7/10  	 7/7T  	 7/4H  	 7/7   	 5/4T   	5	 1:59.4 	 29.1	 L House       	35.80	 A Hardy
409	22	1	5	 Haute Couture         	    	   5 	 6/8H  	 6@/6H 	 6@/3Q 	 6/5T  	 6/5T   	6	 2:00   	 29.3	 G Rooney      	22.40	 A Shelton
410	22	1	4	 Pacific Oak           	    	   4 	 5/7   	 5/5Q  	 5/3   	 5/4T  	 7/5T   	7	 2:00   	 29.3	 Kn Oliver     	19.45	 Kn Oliver
411	22	1	8	 Baddestnbestest       	    	   X8	 8/25  	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 B Mcclure     	2.85	 J Dupont
412	22	2	1	 Kennairnlaughaloud    	    	   1 	 2@/1Q 	 1/1H  	 1/1H  	 1/1H  	 1/2    	1	 1:58.2 	 29.1	 Ja Macdonald  	1.15	 J Riehl
413	22	2	2	 Regal Again           	    	   2 	 3/3   	 4/3Q  	 3@/2T 	 3/1H  	 2/2    	2	 1:58.4 	 29  	 B Mcclure     	8.65	 De Morrisse
414	22	2	5	 Acton O So Royal      	    	   5 	 1/1Q  	 2/1H  	 2/1H  	 2/1H  	 3/2H   	3	 1:58.4 	 29.2	 Trev Henry    	2.40	 D Beatson
415	22	2	8	 Cantcountmeout        	    	   8 	 5/6T  	 6/5   	 4/4Q  	 4/3H  	 4/4    	4	 1:59.1 	 29.1	 A Macdonald   	6.25	 A Macdonald
416	22	2	4	 Sure Please           	    	   4 	 7/10T 	 8/7   	 8/7Q  	 6/7H  	 5/10Q  	5	 2:00.2 	 29.4	 Br Richardson 	44.50	 R Campbell
417	22	2	6	 Twin B Shadow         	    	   6 	 4/5   	 3@/2T 	 5@/4H 	 5/6H  	 6/10H  	6	 2:00.2 	 30.2	 C Steacy      	24.25	 H Wilson
418	22	2	3	 Artistic Cruiser      	    	   3 	 6/8T  	 5@/4H 	 6@@/4T	 7/8   	 7/12Q  	7	 2:00.4 	 30.3	 N Steward     	3.75	 G Robinson
419	22	2	7	 Its Machademic        	    	   7 	 8/12H 	 7@/6H 	 7@@/6Q	 8/9H  	 8/13H  	8	 2:01   	 30.3	 L House       	17.95	 C Schneider
420	22	3	3	 Ok Jewel              	    	   3 	 4/7   	 4/5T  	 4@/3Q 	 3/2H  	 1/H    	1	 2:00.3 	 29.2	 B Mcclure     	7.50	 T Jacobson
421	22	3	1	 P L Kaleidoscope      	    	   1 	 2/1H  	 1/1H  	 1/1   	 1/1   	 2/H    	2	 2:00.3 	 30  	 Trev Henry    	1.35	 M Dupuis
422	22	3	2	 Menagerie             	    	   2 	 3/4H  	 3/4   	 2@/1  	 2/1   	 3/T    	3	 2:00.4 	 30  	 A Macdonald   	5.40	 A Macdonald
423	22	3	4	 Twin B Cheeks         	    	   4 	 1/1H  	 2/1H  	 3/2Q  	 4/2T  	 4/4H   	4	 2:01.2 	 30.2	 D Mcnair      	1.65	 R Adams
424	22	3	6	 P L Kahluaa           	    	   6 	 6/13  	 6/11  	 6/6T  	 5/7Q  	 5/8Q   	5	 2:02.1 	 30.1	 M Morel       	4.45	 P Richer
425	22	3	5	 Three Secrets         	    	   5 	 5/9H  	 5/7H  	 5@/5T 	 6/7H  	 6/12   	6	 2:03   	 31.1	 C Steacy      	13.40	 B Macdonald
426	22	4	3	 Zinfandart            	    	   3 	 1/1H  	 1/1Q  	 1/1   	 1/1   	 1/2    	1	 2:02   	 29.1	 Trev Henry    	1.35	 G Mcclure
427	22	4	2	 Life On The Links     	    	   2 	 2/1H  	 3/1T  	 4/2Q  	 3/2   	 2/2    	2	 2:02.2 	 29.1	 A Macdonald   	8.30	 E Lock
428	22	4	7	 Play Ground           	    	   7 	 6@/6  	 4@/3  	 2@@/1 	 2/1   	 3/3H   	3	 2:02.3 	 29.3	 D Mcnair      	4.20	 G Bishop
429	22	4	8	 Lady With A Weapon    	    	   I8	 7/7   	 8@/6T 	 7@@/5Q	 5/6   	 4/4Q   	4	 2:02.4 	 29  	 G Rooney      	\N	 D Vleeming
430	22	4	1	 Anamazingdream Esa    	    	   X1	 8@/8  	 6@/4H 	 5@@/4 	 4/5   	 5/5Q   	5	 2:03   	 29.2	 N Steward     	1.50	 G Robinson
431	22	4	4	 Ocean Of Motion       	    	   4 	 3/3   	 5/3H  	 6IX/4Q	 6/8H  	 6/20H  	6	 2:06   	 32.2	 N Mac Innis   	15.10	 N Mac Innis
432	22	4	6	 Zenobia Blue Chip     	    	   6 	 4@/4  	 2@/1Q 	 3@IX/1	 ACC   	 DNF    	\N	        	     	 Br Richardson 	9.05	 J Kerr
433	22	4	5	 Windsong Ivory        	    	   5 	 5/5   	 7/5H  	 8IX/6Q	 ACC   	 DNF    	\N	        	     	 L House       	25.75	 K Pollard
434	23	1	4	 Catch A Lucky Star    	    	   4 	 3/3T  	 3/3H  	 3/3H  	 3/2T  	 1/HD   	1	 2:00.3 	 29.2	 C Steacy      	\N	 J Watt
435	23	1	3	 Rocket Art            	    	   3 	 1/2   	 1/1T  	 1/1T  	 1/1Q  	 2/HD   	2	 2:00.3 	 30  	 G Rooney      	\N	 D Meekison 
436	23	1	2	 Watt A Funny Face     	    	   2 	 2/2   	 2/1T  	 2/1T  	 2/1Q  	 3/1    	3	 2:00.4 	 29.4	 C German      	\N	 J Watt
437	23	1	1	 Shanghai Noodle       	    	   1 	 4/5T  	 4/5Q  	 4/5Q  	 4/4T  	 4/6    	4	 2:01.4 	 30.1	 G Mcclure     	\N	 G Mcclure
438	24	1	2	 Sweet Caldonia        	    	   2 	 3/2Q  	 3@/2Q 	 1@/NS 	 1/H   	 1/1Q   	1	 2:00.4 	 31.1	 C Johnston    	2.25	 T Bain
439	24	1	5	 B R Lucky Lady        	    	   5 	 1@/H  	 1/1T  	 2/NS  	 3/1   	 2/1Q   	2	 2:01   	 31.2	 B Forward     	2.15	 R Myers
440	24	1	6	 Jazzie Crombie        	    	   6 	 6/7T  	 6@/7  	 5@@/3 	 2/H   	 3/1Q   	3	 2:01   	 30.4	 A Lilley      	4.65	 J Graham
441	24	1	4	 Birkdale              	    	   4 	 5/5T  	 5/6Q  	 6/5   	 5/4   	 4/4Q   	4	 2:01.3 	 31  	 D Rankin Jr   	16.05	 R Spitzig
442	24	1	1	 Acton Real Foolish    	    	   1 	 2/H   	 2/1T  	 4/2   	 4/3   	 5/4T   	5	 2:01.4 	 31.4	 J Coke        	7.50	 D Pearson
443	24	1	7	 Wallet Sniffer        	    	   7 	 7/9H  	 7/10  	 7/6T  	 7/11  	 6/11T  	6	 2:03.1 	 32.1	 T Borth       	9.00	 T Bain
444	24	1	8	 Larjon Emma           	    	   8 	 4/4   	 4@/4Q 	 3@/2  	 6/10  	 7/13   	7	 2:03.2 	 33.2	 M Williams    	4.65	 L Lane
445	24	1	3	 Hrrn                  	    	   X3	 8/24H 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 D Duford      	41.65	 S Roberts
446	24	2	2	 My Greek Princess     	    	   2 	 2/5   	 2/4   	 1@/HD 	 1/4   	 1/NK   	1	 2:02.4 	 30.4	 T Borth       	0.75	 C Gaudreau
447	24	2	5	 Jimini Top            	    	   5 	 3/6T  	 3/5T  	 3/1T  	 2/4   	 2/NK   	2	 2:02.4 	 30.2	 C Johnston    	4.15	 T Bain
448	24	2	1	 Larjon Laney          	    	   1 	 6/12T 	 6/11Q 	 4@@/3T	 4/6   	 3/3H   	3	 2:03.2 	 30.3	 B Forward     	6.45	 L Lane
449	24	2	6	 Incredible Dutches    	    	   6 	 1/5   	 1/4   	 2/HD  	 3/5   	 4/8T   	4	 2:04.3 	 32.3	 A Moore       	7.65	 D Kenney
450	24	2	4	 Onimpulse             	    	   4 	 4/8T  	 4/7T  	 5@/4Q 	 5/9   	 5/9T   	5	 2:04.4 	 32  	 M Williams    	7.35	 T Bain
451	24	2	3	 Shadow Way            	    	   3 	 5/10T 	 5/9H  	 6/4Q  	 6/10  	 6/13T  	6	 2:05.3 	 32.4	 J Coke        	5.75	 D Pearson
452	24	3	6	 P J Lucky Lass        	    	   5 	 7/13Q 	 7/9H  	 4@/4  	 2/1   	 1/H    	1	 2:01   	 29.1	 A Moore       	1.60	 R Griffiths
453	24	3	1	 News Stand            	    	   1 	 2/1   	 1/1T  	 1/1T  	 1/1   	 2/H    	2	 2:01   	 30  	 T Borth       	3.25	 M Carther
454	24	3	4	 Perfect Poser         	    	   4 	 6/8Q  	 6@/7H 	 5/5   	 4/3T  	 3/1T   	3	 2:01.2 	 29.2	 B Forward     	3.70	 M Rogers
455	24	3	7	 Four Decades          	    	   6 	 1@/1  	 2/1T  	 3/2   	 3/2   	 4/4    	4	 2:01.4 	 30.2	 A Lilley      	8.90	 R Maclean
456	24	3	8	 Justins Deere         	    	   8 	 3/2T  	 3/3T  	 6/6T  	 6/5   	 5/7    	5	 2:02.2 	 30  	 D Rankin Jr   	7.15	 I Hyatt
457	24	3	3	 Regal Beagle          	    	   3 	 5/6H  	 4@/4T 	 2@/1T 	 5/4Q  	 6/7T   	6	 2:02.3 	 31.1	 C Johnston    	9.70	 D Currie
458	24	3	2	 Mister Fantastic      	    	   2 	 4/4T  	 5/6H  	 7@/7T 	 7/7   	 7/13Q  	7	 2:03.3 	 31  	 M Williams    	6.70	 L Mansfield
459	24	3	5	 Lyons Jewels          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
460	24	4	1	 Casimir Preist        	    	   1 	 1/1T  	 1/1H  	 1/1   	 1/1   	 1/1    	1	 2:01.4 	 30.4	 D Rankin Jr   	2.60	 T Spitzig
461	24	4	3	 Stonebridge Sting     	    	   3 	 2/1T  	 2/1H  	 2@/1  	 2/1   	 2/1    	2	 2:02   	 30.4	 C Johnston    	3.85	 J Sims
462	24	4	2	 Our Whosur            	    	   2 	 3/3T  	 3/3H  	 3/3   	 3/2   	 3/1Q   	3	 2:02   	 30.2	 Da Wall       	7.70	 De Wall
463	24	4	7	 Next Of Cam           	    	   7 	 7/14Q 	 I7@/8Q	 5@/4T 	 5/4   	 4/2    	4	 2:02.1 	 30.1	 T Borth       	3.15	 D Belan
464	24	4	4	 Dreamfair Hughie      	    	   4 	 4/5T  	 4/5Q  	 6/5   	 4/4   	 5/3H   	5	 2:02.2 	 30.2	 A Lilley      	8.90	 L Mansfield
465	24	4	6	 Play Like A Pro       	    	   6 	 6/12H 	 X5@/6Q	 4@/3  	 6/5   	 6/3H   	6	 2:02.2 	 30.4	 D Dowling     	7.30	 D Dowling
466	24	4	5	 Sweet Queen Cole      	    	   5 	 5/10T 	 6/7Q  	 7/7   	 7/7   	 7/5H   	7	 2:02.4 	 30.2	 M Williams    	3.60	 M Williams
467	24	5	1	 Laugh Amile           	    	   1 	 3/2   	 3/3H  	 2@/H  	 2/1   	 1/H    	1	 2:04   	 31.1	 T Borth       	6.10	 D Mcfadden
468	24	5	3	 Outside Chance        	    	   3 	 1/1   	 2/1T  	 3/1H  	 3/2   	 2/H    	2	 2:04   	 31  	 A Moore       	1.40	 A Moore
469	24	5	4	 Total Rebellion       	    	   4 	 2@/1  	 1/1T  	 1/H   	 1/1   	 3/T    	3	 2:04.1 	 31.2	 D Rankin Jr   	6.50	 R Maclean
470	24	5	7	 Ncutsnbutsncocants    	    	   7 	 I6/15T	 7/16Q 	 6@@/12	 5/9   	 4/4Q   	4	 2:04.4 	 29.3	 D Duford      	7.50	 M Carther
471	24	5	5	 Master Emerson        	    	   5 	 I7/16T	 5@/14H	 5@/11Q	 6/10  	 5/7H   	5	 2:05.2 	 30.2	 J Hahn        	15.45	 M Lariviere
472	24	5	6	 Royal Exposure        	    	   6 	 I4/12 	 4/6H  	 4/3Q  	 4/8   	 6/8H   	6	 2:05.3 	 32.1	 B Forward     	2.50	 B Sinclair
473	24	5	2	 Better Be Said        	    	   2 	 I5/14 	 6/14H 	 7/12H 	 7/18  	 7/26T  	7	 2:09.2 	 34.1	 M Williams    	12.15	 L Mansfield
474	24	5	8	 Jacob Too Too         	    	   8 	 X8/22T	 8@/17Q	 8/14H 	 8/19  	 8/27   	8	 2:09.2 	 33.4	 J Coke        	20.95	 D Pearson
475	24	6	1	 Capitol Trip          	    	   1 	 2/1   	 3/2   	 4/2H  	 4/1   	 1/H    	1	 2:02   	 29.2	 D Spitzig     	2.05	 D Spitzig
476	24	6	3	 Howdy Partner         	    	   3 	 1/1   	 1/1   	 1/1   	 1/NS  	 2/H    	2	 2:02   	 29.4	 D Rankin Jr   	5.85	 M Rogers
477	24	6	5	 Passionate Pete       	    	   5 	 6/6H  	 6@/5T 	 3@@/2 	 3/H   	 3/1    	3	 2:02.1 	 29.3	 D Dowling     	16.75	 D Dowling
478	24	6	8	 Julio Lauxmont        	    	   8 	 5/4T  	 5/4   	 7/4H  	 6/5   	 4/1    	4	 2:02.1 	 29.1	 A Lilley      	6.70	 L Bako
479	24	6	2	 Plain Easy            	    	   2 	 4/3   	 4@/3  	 5@/3  	 5/2   	 5/1Q   	5	 2:02.1 	 29.2	 M Williams    	3.55	 D Mcfadden
480	24	6	4	 Unchained Desire      	    	   4 	 3@/2  	 2@/1  	 2@/1  	 2/NS  	 6/1T   	6	 2:02.2 	 30  	 B Forward     	3.50	 L Johnson
481	24	6	6	 Unique Shuffle        	    	   6 	 7/8Q  	 7/6T  	 8/6Q  	 7/6   	 7/5H   	7	 2:03   	 29.3	 T Borth       	12.10	 G Mcdonnell
482	24	6	7	 Big Is Better         	    	   7 	 8/10Q 	 8@/8  	 6@@/4 	 8/9   	 8/9Q   	8	 2:03.4 	 30.4	 A Moore       	9.05	 A Moore
483	25	1	4	 Fantastic Flirt       	    	   4 	 3/2T  	 2/1H  	 3/1T  	 2/1   	 1/4H   	1	 2:00.3 	 30.3	 B Forward     	3.00	 J Rankin
484	25	1	2	 El Diablo Rojo        	    	   2 	 4/8T  	 3@/2  	 1@/NS 	 1/1   	 2/4H   	2	 2:01.2 	 31.4	 D Duford      	1.60	 A Duford
485	25	1	1	 Riversathome          	    	   1 	 1/1T  	 1/1H  	 2/NS  	 3/1   	 3/6T   	3	 2:02   	 32.2	 J Hahn        	9.55	 M Lariviere
486	25	1	3	 Terrain Seelster      	    	   3 	 5/10H 	 5@/4H 	 4/3T  	 4/6   	 4/13   	4	 2:03.1 	 32.4	 D Rankin Jr   	2.80	 A Deleersny
487	25	1	5	 Schrodinger=          	    	   5 	 2@/1T 	 4/4   	 5/5H  	 5/10  	 5/19T  	5	 2:04.3 	 34  	 D Spitzig     	11.70	 D Spitzig
488	25	1	6	 Weskey                	    	   6 	 6/12H 	 6/7H  	 6/7H  	 6/14  	 6/24H  	6	 2:05.2 	 34.2	 T Borth       	3.85	 T Borth
489	25	2	1	 Dex The Land          	    	   1 	 1/H   	 1/8   	 1/3   	 1/2   	 1/1    	1	 2:00   	 32.1	 T Borth       	1.00	 C Gaudreau
490	25	2	3	 Dont Yank My Chain    	    	   3 	 3/4H  	 2/8   	 2/3   	 2/2   	 2/1    	2	 2:00.1 	 31.4	 A Lilley      	4.55	 A Lilley
491	25	2	5	 Charlie Hustle        	    	   4 	 4/6H  	 3/10  	 3/4T  	 3/3   	 3/2H   	3	 2:00.2 	 31.3	 C Johnston    	10.80	 I Hyatt
492	25	2	2	 Payback               	    	   2X	 5/31H 	 5/30  	 5/22T 	 5/23  	 4/22Q  	4	 2:04.2 	 32  	 Da Wall       	9.25	 De Wall
493	25	2	6	 Isitfridayyet         	    	   5 	 2@X/H 	 4/20  	 4/19T 	 4/23  	 5/24H  	5	 2:04.4 	 33  	 M Williams    	1.40	 L Mansfield
494	25	2	4	 Barbies Belle         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
495	25	3	2	 Ground Shaker         	    	   2 	 2/1H  	 3/3H  	 4@@/5H	 2/H   	 1/2T   	1	 2:00   	 29.1	 B Forward     	3.25	 L Johnson
496	25	3	4	 Gorgiouseverytyme     	    	   4 	 4/6   	 4@/4  	 2@/5  	 1/H   	 2/2T   	2	 2:00.3 	 29.4	 A Lilley      	4.65	 J Lester
497	25	3	7	 Blissfullannmarie     	    	   6 	 6/9H  	 6/9T  	 5/7H  	 5/6   	 3/7H   	3	 2:01.2 	 30.1	 T Borth       	1.75	 C Gaudreau
498	25	3	1	 St Lads Sundance      	    	   1 	 1/1H  	 2/1T  	 3/5   	 4/4Q  	 4/8Q   	4	 2:01.3 	 30.4	 A Moore       	1.65	 R Duford
499	25	3	6	 America Rocks         	    	   5 	 5/7T  	 5/8   	 6/9H  	 6/8   	 5/13H  	5	 2:02.3 	 31  	 C Johnston    	19.05	 G Mcdonnell
500	25	3	3	 Peekaboo Toni         	    	   3 	 3/3   	 1/1T  	 1/5   	 3/2H  	 6/14   	6	 2:02.4 	 33  	 D Dowling     	12.75	 D Dowling
501	25	3	5	 Southwind Illusion    	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
502	25	4	6	 Kelly Rae             	    	   6 	 3/3H  	 3@/2H 	 1/1   	 1/1   	 1/H    	1	 2:00.2 	 30.4	 T Borth       	1.60	 J Lester
503	25	4	5	 Big Diva              	    	   5 	 4/5Q  	 4@/4Q 	 2@/1  	 2/1   	 2/H    	2	 2:00.2 	 30.3	 B Forward     	2.35	 M Rogers
504	25	4	1	 Primary Pick          	    	   1 	 2/1H  	 2/1H  	 5@/3H 	 3/2   	 3/1T   	3	 2:00.4 	 30.3	 J Hahn        	12.30	 C Gaudreau
505	25	4	3	 Release The Magic+    	    	   3 	 6/8Q  	 5@/6  	 4@@/3 	 4/3   	 4/2T   	4	 2:01   	 30.4	 A Hamlin      	3.20	 T Myers
506	25	4	4	 Stellar Steel         	    	   4 	 5@/7Q 	 6/6H  	 6@@/4H	 5/5   	 5/7    	5	 2:01.4 	 31.2	 C Johnston    	3.35	 D Currie
507	25	4	2	 Richlyn Ombretta      	    	   2 	 1/1H  	 1/1H  	 3/2   	 6/5H  	 6/10T  	6	 2:02.3 	 32.3	 A Moore       	17.10	 R Griffiths
508	26	1	3	 Make Some Memories    	    	   3 	 3/10  	 3/7   	 3/1T  	 1/HD  	 1/2T   	1	 2:03   	 29.3	 A Hamlin      	\N	 T Myers
509	26	1	2	 Beer And A Haircut    	    	   2 	 1/8   	 1/5   	 2/NS  	 2/HD  	 2/2T   	2	 2:03.3 	 30.3	 B Forward     	\N	 S Roberts
510	26	1	5	 Dear Wee Mel          	    	   5 	 4/12  	 2/5   	 1@/NS 	 3/5   	 3/10H  	3	 2:05   	 32  	 M Williams    	\N	 L Mansfield
511	26	1	4	 Twelve Apaches        	    	   4 	 5/14  	 4/13  	 4/7T  	 4/11  	 4/34   	4	 2:09.4 	 35.1	 A Lilley      	\N	 A Lilley
512	26	1	1	 Hall Oak              	    	   1 	 2EX/8 	 PULLED	UP     	       	 DNF    	\N	        	     	 A Moore       	\N	 W Durbridge
513	26	2	5	 Stock Losses          	    	   3 	 2/2H  	 2/1T  	 1@/1  	 1/5   	 1/7H   	1	 2:02.1 	 29.1	 A Hamlin      	\N	 
514	26	2	3	 Acefortyfouramanda    	    	   X2	 3/4Q  	 3/3H  	 3/3   	 2/5   	 2/7H   	2	 2:03.3 	 30  	 A Lilley      	\N	 L Bako
515	26	2	1	 Foreigner             	    	   1 	 1/2H  	 1/1T  	 2/1   	 3/6   	 3/16   	3	 2:05.2 	 32.1	 B Forward     	\N	 D Dowling
516	28	1	2	 R Es Miss Eliza       	    	   2 	 1/5   	 1/5   	 1/10  	 1/12  	 1/15   	1	 2:09.4 	 32.4	 S Trites      	\N	 C Miles
517	28	1	3	 The Pita              	    	   3 	 2/5   	 2/5   	 2/10  	 2/12  	 2/15   	2	 2:12.4 	 33.4	 C Miles       	\N	 C Miles
518	28	1	1	 Elm Grove Lynarush+   	    	   X1	 X3/DIS	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 G Wright      	\N	 G Wright
519	28	2	2	 Windsong Leo          	    	   2 	 1/3H  	 1/12  	 1/15  	 1/18  	 1/26   	1	 1:59   	 28.3	 S Trites      	\N	 P Jones
520	28	2	1	 Choco Du Ruisseau     	    	   1 	 2/3H  	 2/12  	 2/15  	 2/18  	 2/26   	2	 2:04.1 	 30.4	 T Trites      	\N	 T Dunphy
521	29	1	5	 Mach Messier          	    	   5 	 4/6H  	 3@/1H 	 2@/2  	 2/1H  	 1/1T   	1	 1:55   	 28.3	 J Ryan        	1.85	 M Bishop
522	29	1	3	 My Old Master         	    	   3 	 3/3H  	 1@/HD 	 1/2   	 1/1H  	 2/1T   	2	 1:55.2 	 29.2	 B Davis Jr    	1.20	 B Macintosh
523	29	1	6	 Toy Cop               	    	   6 	 5/8H  	 5@/3H 	 4@/4  	 3/2H  	 3/3T   	3	 1:55.4 	 29  	 A Carroll     	3.25	 K Bodz
524	29	1	1	 Santanna Sam          	    	   1 	 2/1H  	 4/2   	 5/5H  	 4/12  	 4/15Q  	4	 1:58   	 31  	 P Mackenzie   	8.95	 R Jarvis
525	29	1	7	 Oforpetesake          	    	   7 	 6/10  	 6/4H  	 7/7   	 6/14  	 5/15Q  	5	 1:58   	 30.3	 R Doyle       	27.90	 J Hastie
526	29	1	4	 Big Dylan             	    	   4 	 7/11H 	 7/6   	 6@X/6 	 7/15H 	 6/15T  	6	 1:58.1 	 31  	 S Young       	17.95	 M Brealey
527	29	1	2	 Well Played Out       	    	   2 	 1/1H  	 2/HD  	 3/3H  	 5/12H 	 7/26   	7	 2:00.1 	 33.3	 T Moore       	8.05	 J Copley
528	29	2	1	 Thrift Shop           	    	   1 	 3/3H  	 3/3H  	 2@/1H 	 1/HD  	 1/1T   	1	 1:56.3 	 30  	 S Byron       	1.70	 J Holding
529	29	2	5	 Buttercup Baby        	    	   4 	 1/1H  	 1/1H  	 1/1H  	 2/HD  	 2/1T   	2	 1:57   	 30.3	 J Ryan        	6.55	 K Reibeling
530	29	2	3	 Justabitevil+         	    	   2 	 2/1H  	 2/1H  	 3/2H  	 3/2H  	 3/3H   	3	 1:57.1 	 30.2	 A Byron       	11.30	 T Knight
531	29	2	6	 Come On Eileen        	    	   5 	 4/5   	 4/5   	 4/4H  	 4/5Q  	 4/9T   	4	 1:58.3 	 31.2	 P Mackenzie   	3.20	 M Brethour
532	29	2	4	 Orch Vicky            	    	   3 	 X5/6H 	 5/11H 	 5/17  	 5/21H 	 5/20Q  	5	 2:00.3 	 30.4	 S Young       	0.90	 G Remmen
533	29	2	2	 Notebookandtablet     	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
534	29	3	1	 Missus Big            	    	   1 	 1/1H  	 1/1H  	 1/1Q  	 1/1T  	 1/3Q   	1	 1:57.1 	 28.1	 B Mcclure     	1.40	 D Tyrrell
535	29	3	2	 Miss Print            	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1T  	 2/3Q   	2	 1:57.4 	 28.3	 N Steward     	1.30	 A Mccabe
536	29	3	3	 Classic Comedy        	    	   3 	 3/3   	 3/3   	 2@/1Q 	 3/3H  	 3/4T   	3	 1:58.1 	 29  	 Tra Henry     	9.70	 C Auciello
537	29	3	4	 Casimir Pardon Me     	    	   4 	 4/4H  	 4/4H  	 4/4H  	 4/5   	 4/5T   	4	 1:58.2 	 28.3	 S Byron       	4.85	 K Reibeling
538	29	3	6	 Badlands Delight      	    	   5 	 5/6   	 5/6   	 5/6H  	 5/6Q  	 5/6    	5	 1:58.2 	 28.1	 A Carroll     	3.45	 D Lehan
539	29	3	5	 Total Knockout(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
540	29	4	4	 Im A Gift             	    	   4 	 3/3   	 4@/3H 	 2@/1H 	 2/Q   	 1/H    	1	 1:53.3 	 28.3	 D Dupont      	1.05	 M Dupont
541	29	4	5	 Skyway Boomer         	    	   5 	 4/4H  	 5@/4H 	 4@/3H 	 3/2Q  	 2/H    	2	 1:53.3 	 28.1	 T Moore       	2.95	 J Copley
542	29	4	3	 Lively Freddie        	    	   3 	 6/7H  	 7@/6H 	 6@/5H 	 5/4H  	 3/2    	3	 1:54   	 28.1	 B Mcclure     	2.35	 D Nixon
543	29	4	1	 Surf Report           	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/Q   	 4/3H   	4	 1:54.1 	 29.2	 A Carroll     	9.15	 M Etsell
544	29	4	6	 Stature Seelster(L)   	    	   6 	 7/9   	 6/5   	 7/6   	 6/5   	 5/4T   	5	 1:54.3 	 28.3	 P Mackenzie   	32.85	 M Isabel
545	29	4	7	 Sporty Mercedes       	    	   7 	 5/6   	 3/3   	 5/4   	 7/6Q  	 6/7T   	6	 1:55.1 	 29.3	 B Davis Jr    	25.20	 B Macintosh
546	29	4	2	 Singhampton Kenny     	    	   2 	 2/1H  	 2/1H  	 3/3   	 4/3   	 7/12   	7	 1:56   	 30.3	 Tra Henry     	6.35	 L Fuller
547	29	5	1	 Mckinney              	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1   	 1/1Q   	1	 1:52.1 	 28.3	 B Mcclure     	1.30	 Corey Johns
548	29	5	2	 American Rock         	    	   2 	 2/1H  	 3/2Q  	 3/2Q  	 3/2H  	 2/1Q   	2	 1:52.2 	 28.2	 A Carroll     	1.80	 R Moreau
549	29	5	6	 Lets Wait And See     	    	   6 	 6/7H  	 2@/1H 	 2@/1  	 2/1   	 3/1T   	3	 1:52.3 	 28.4	 N Steward     	17.50	 S Friend
550	29	5	4	 Thorn In Your Side(L) 	    	   4 	 3/3   	 4/3H  	 5/4   	 4/4   	 4/2Q   	4	 1:52.3 	 28.1	 Tra Henry     	3.55	 C Auciello
551	29	5	3	 Buddha Blue Chip      	    	   3 	 4/4H  	 7/6   	 7/6   	 5/4H  	 5/2T   	5	 1:52.4 	 28  	 P Mackenzie   	5.65	 J Dupont
552	29	5	7	 Sports Lightning      	    	   7 	 7/9   	 5@/4  	 4@/3H 	 6/6   	 6/5T   	6	 1:53.2 	 29.1	 S Young       	25.90	 M Brealey
553	29	5	5	 Haydens Little Man(L) 	    	   5 	 5/6   	 6@/5H 	 6@/5H 	 7/7H  	 7/7    	7	 1:53.3 	 29  	 J Ryan        	11.40	 J Ryan
554	29	6	5	 St Lads Lotto(L)      	    	   5 	 1/1H  	 1/1H  	 1/1H  	 1/4   	 1/2Q   	1	 1:52.4 	 29.2	 J Ryan        	0.75	 J Ryan
555	29	6	7	 Arrived Late(L)       	    	   7 	 7/9   	 7/9   	 7@/5T 	 6/6Q  	 2/2Q   	2	 1:53.1 	 28.3	 B Mcclure     	12.05	 C Gilmour
556	29	6	4	 A Marcou Story        	    	   4 	 5/6   	 5/6   	 5@/4H 	 4/5   	 3/2H   	3	 1:53.1 	 29  	 R Jones       	3.20	 R Jones
557	29	6	3	 Crafty Master         	    	   3 	 4/4H  	 4/4H  	 3@/2Q 	 3/4H  	 4/7H   	4	 1:54.1 	 30.2	 A Carroll     	4.45	 V Puddy
558	29	6	1	 Mac Raider            	    	   1 	 2/1H  	 2/1H  	 2/1H  	 2/4   	 5/8Q   	5	 1:54.2 	 30.4	 B Davis Jr    	9.70	 L Fuller
559	29	6	6	 Corsica Hall(L)       	    	   6 	 3/3   	 3/3   	 4/3Q  	 5/5H  	 6/8Q   	6	 1:54.2 	 30.2	 Tra Henry     	11.20	 C Auciello
560	29	6	2	 My Friend Diaz        	    	   2 	 6/7H  	 6/7H  	 6/5   	 7X/6T 	 X7/12H 	7	 1:55.1 	 30.4	 S Byron       	9.00	 D Lever
561	30	1	6	 Lisvinnie(L)          	    	   6 	 9/13Q 	 7@/9H 	 5@@/4H	 4/2H  	 1/1H   	1	 1:53.2 	 28.3	 D St Pierre   	2.20	 Corey Johns
562	30	1	5	 Sword Ofthe Spirit    	    	   5 	 1/3   	 1/2H  	 1/Q   	 1/1Q  	 2/1H   	2	 1:53.3 	 29.3	 R Jones       	10.30	 R Jones
563	30	1	2	 Mach On The Beach     	    	   2 	 2/3   	 2/2H  	 3/1H  	 3/2   	 3/1T   	3	 1:53.4 	 29.3	 S Byron       	6.60	 D Fontaine
564	30	1	3	 Smack Talk            	    	   3 	 7/10H 	 8/11  	 7@@/5H	 6/4H  	 4/1T   	4	 1:53.4 	 28.4	 B Mcclure     	4.70	 J Williamso
565	30	1	4	 Chosen Hombre         	    	   4 	 6/9   	 6/8   	 8/7   	 8/7Q  	 5/5    	5	 1:54.2 	 29  	 P Mackenzie   	19.05	 M Brethour
566	30	1	8	 Soaking Up The Sun    	    	   8 	 3/4H  	 3/4   	 2@/Q  	 2/1Q  	 6/5T   	6	 1:54.3 	 30.3	 Tra Henry     	11.90	 R Moreau
567	30	1	9	 Calgary Seelster(L)   	    	   9 	 5/7H  	 5/7H  	 6@/5  	 5/4   	 7/6T   	7	 1:54.4 	 29.4	 N Steward     	2.15	 A Mccabe
568	30	1	1	 Canadian Edition(L)   	    	   1 	 4/6   	 4/6   	 4/4   	 7/6   	 8/6T   	8	 1:54.4 	 30  	 A Carroll     	6.85	 V Puddy
569	30	1	7	 One Warrawee          	    	   7 	 8/12  	 9/12H 	 9/8Q  	 9/8T  	 9/12T  	9	 1:56   	 30.2	 A Byron       	17.30	 E Galinski
570	30	2	1	 The Illuminator       	    	   1 	 1/1H  	 2/1H  	 2/1H  	 2/T   	 1/T    	1	 1:54   	 28.3	 B Mcclure     	2.75	 Ri Zeron
571	30	2	5	 Terror Hall           	    	   5 	 5/8   	 5/10H 	 5@/5  	 4/4H  	 2/T    	2	 1:54.1 	 28  	 A Carroll     	3.10	 R Moreau
572	30	2	2	 Spirit Shadow         	    	   2 	 2/1H  	 1/1H  	 1/1H  	 1/T   	 3/2T   	3	 1:54.3 	 29.2	 P Mackenzie   	0.45	 J Dupont
573	30	2	4	 Lissilas              	    	   4 	 4/6H  	 4/7H  	 4@/3H 	 3/4   	 4/3T   	4	 1:54.4 	 29  	 D St Pierre   	71.00	 Colin Johns
574	30	2	9	 Cool Jack             	    	   8 	 8/12H 	 8/15  	 8/8H  	 5/6   	 5/5    	5	 1:55   	 28.1	 N Steward     	36.75	 J Copley
575	30	2	6	 Winning Drive         	    	   6 	 6/9H  	 6/12  	 6@/5H 	 6/6H  	 6/7T   	6	 1:55.3 	 29.2	 T Moore       	29.50	 R Howie
576	30	2	3	 Whiskey Wisdom        	    	   3 	 3/3H  	 3/4H  	 3/3   	 7/7   	 7/8H   	7	 1:55.3 	 29.4	 T Smith       	33.40	 J Walker
577	30	2	8	 Master Smile          	    	   7 	 7/11  	 7/13H 	 7/7   	 8/8H  	 8/14Q  	8	 1:56.4 	 30.1	 B Davis Jr    	29.15	 J Mcginnis
578	30	2	7	 Barefoot Bluejeans    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
579	30	3	2	 Kona(L)               	    	   2 	 4/4H  	 5/4Q  	 4@/1H 	 3/1H  	 1/1Q   	1	 2:00   	 31.2	 D St Pierre   	1.90	 Colin Johns
580	30	3	1	 Deck The Halls        	    	   1 	 2/1H  	 3/1H  	 3/1H  	 4/1T  	 2/1Q   	2	 2:00.1 	 31.3	 N Steward     	4.60	 P Belanger 
581	30	3	4	 L H Fillybuster       	    	   4 	 1/1H  	 1/1   	 1/NK  	 2/HD  	 3/3H   	3	 2:00.3 	 32.1	 A Carroll     	1.20	 W Budd
582	30	3	5	 Ken U Sing=(L)        	    	   5 	 5/6   	 2@/1  	 2@/NK 	 1/HD  	 4/5Q   	4	 2:01   	 32.3	 D Bowins      	2.55	 D Bowins
583	30	3	3	 Protege Seelster(L)   	    	   3 	 3/3   	 4/3   	 5/8H  	 5/11H 	 5/23T  	5	 2:04.4 	 34.4	 B Davis Jr    	12.90	 P Shepherd
584	30	4	5	 Twomacsonemach(L)     	    	   4 	 4/5H  	 4@/3H 	 2@/1  	 2/1   	 1/HD   	1	 1:55.2 	 27.2	 A Carroll     	3.90	 V Puddy
585	30	4	3	 P L Jackson           	    	   2 	 1/1H  	 1/1H  	 1/1   	 1/1   	 2/HD   	2	 1:55.2 	 27.3	 B Mcclure     	0.35	 R Mcmillan
586	30	4	4	 Day Trade Hanover     	    	   3 	 2/1H  	 2/1H  	 3/1H  	 3/2H  	 3/2Q   	3	 1:55.4 	 27.4	 R Jones       	3.60	 R Jones
587	30	4	9	 Relish                	    	   7 	 7/10  	 7@/7Q 	 6@I/5 	 5/7   	 4/9H   	4	 1:57.1 	 28.2	 P Mackenzie   	31.40	 R Mackenzie
588	30	4	8	 Sippen Whisky         	    	   6 	 6/8H  	 5@/5H 	 4@I/3Q	 4/6H  	 5/11H  	5	 1:57.3 	 29.1	 Tra Henry     	10.55	 C Fuller
589	30	4	7	 Wawanosh Wave         	    	   5 	 5/7   	 6/6   	 7I/5T 	 6/9H  	 6/14H  	6	 1:58.1 	 29.1	 T Smith       	64.00	 J Walker
590	30	4	1	 Lil Richie            	    	   1 	 3/3   	 3/3   	 5X/3H 	 7/16  	 7/DIS  	7	        	     	 A Byron       	17.80	 D Nixon
591	30	4	2	 Only Half Bad         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
592	30	4	6	 Six Flags             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
593	31	1	6	 Heza Workof Art       	    	   5 	 5/5H  	 4@/3  	 2@/1  	 1/NS  	 1/NS   	1	 1:54.2 	 29.1	 B Mcclure     	0.85	 J Watt
594	31	1	7	 Wine Shark            	    	   6 	 1/1   	 1/1   	 1/1   	 2/NS  	 2/NS   	2	 1:54.2 	 29.2	 J Ryan        	2.40	 J Ryan
595	31	1	2	 Arnold Dick           	    	   2 	 4/4   	 5/3H  	 5/7H  	 3/10  	 3/12   	3	 1:56.4 	 30.2	 P Mackenzie   	6.30	 P Mackenzie
596	31	1	3	 Highpoint Chip        	    	   3 	 6/7   	 6/5   	 6@/8H 	 5/12  	 4/17H  	4	 1:57.4 	 31.1	 L House       	41.40	 P Roberts
597	31	1	1	 Roan Bruiser(L)       	    	   1 	 3/2H  	 2@/1  	 4@/7  	 7/14  	 5/17T  	5	 1:58   	 31.3	 Tra Henry     	6.40	 S Halkes
598	31	1	8	 Amillionbucks         	    	   7 	 7/8H  	 7/6H  	 7/9Q  	 6/12H 	 6/18T  	6	 1:58.1 	 31.2	 S Byron       	24.05	 G Cicero
599	31	1	5	 Windsun Cheyenne(L)   	    	   4 	 2/1   	 3/1H  	 3/6H  	 4/11H 	 7/22H  	7	 1:58.4 	 32.3	 N Steward     	5.15	 D Tackoor
600	31	1	4	 Jimmy Be Good         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
601	31	1	9	 Hot Rock Star         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
602	31	2	1	 Classic Bolt          	    	   1 	 2/1H  	 2/1H  	 2/3H  	 2/3   	 2P1/2  	2	 1:57   	 28.4	 J Ryan        	2.60	 C Gilmour
603	31	2	6	 Silversmith           	    	   6 	 1/1H  	 1/1H  	 1/3H  	 1/3   	 3P2/2T 	3	 1:57.1 	 29.3	 P Mackenzie   	1.25	 A Macdonald
604	31	2	3	 Screenwriter          	    	   3 	 4/4H  	 3@/2  	 3@/4  	 3/3T  	 4P3/6Q 	4	 1:57.4 	 29.2	 B Mcclure     	10.80	 C Fuller
605	31	2	4	 Machcellerator        	    	   4 	 5/6   	 5/5   	 6I/7H 	 6/8   	 5P4/9Q 	5	 1:58.2 	 29.2	 S Young       	11.70	 T Stein
606	31	2	2	 Tea With Ms Mcgill    	    	   2 	 3/3   	 4/3H  	 4X/5H 	 4/5   	 1P5/2  	1	 TDIS   	     	 A Macdonald   	1.75	 A Macdonald
607	31	2	7	 Home James            	    	   7 	 7/9   	 6@/5H 	 5@/7  	 5/7H  	 6/9H   	6	 1:58.2 	 29.2	 Tra Henry     	15.05	 Tra Henry
608	31	2	5	 Hazamenaz             	    	   5 	 6/7H  	 7/7   	 7@/8  	 7/12  	 7/22   	7	 2:01   	 31.4	 R Holliday    	36.10	 C Fuller
609	31	3	5	 Go Get Bruce          	    	   5 	 6/6Q  	 4@/5T 	 3@/3  	 3/2Q  	 1/2    	1	 1:58.4 	 30  	 B Forward     	1.65	 S Charlton
610	31	3	2	 Rainbow View          	    	   2 	 2/H   	 1@/H  	 1/1Q  	 1/1   	 2/2    	2	 1:59.1 	 31  	 A Haughan     	5.20	 M Crone
611	31	3	4	 Tyrone Zoey           	    	   4 	 5/4T  	 2@/H  	 2@/1Q 	 2/1   	 3/5Q   	3	 1:59.4 	 31.2	 B Mcclure     	1.50	 J Watt
612	31	3	3	 Burst Hanover         	    	   3 	 4/3Q  	 6/7H  	 5@/8Q 	 5/8H  	 4/9T   	4	 2:00.4 	 31  	 L House       	7.40	 P Roberts
613	31	3	1	 Murs Son=             	    	   1 	 3/1T  	 5/6T  	 6/8T  	 6/9   	 5/10   	5	 2:00.4 	 30.4	 A Carroll     	9.50	 C Carss
614	31	3	6	 Fashion Star=(L)      	    	   6 	 1@/H  	 3/4H  	 4/6Q  	 4/6H  	 6/10H  	6	 2:00.4 	 31.2	 A Macdonald   	3.70	 A Macdonald
615	31	4	2	 Scotty Mach N         	    	   2 	 2/1   	 1/1H  	 1/1H  	 1/1   	 1/H    	1	 1:55.2 	 29.2	 P Mackenzie   	5.05	 G Way
616	31	4	4	 Shootin To Kill       	    	   4 	 3/2H  	 3@/2  	 2@/1H 	 2/1   	 2/H    	2	 1:55.2 	 29.1	 B Mcclure     	0.95	 J Copley
617	31	4	6	 Attaboyaaron          	    	   6 	 4/4   	 5@/4  	 4@/3H 	 3/1H  	 3/H    	3	 1:55.2 	 28.4	 N Steward     	9.50	 J Watt
618	31	4	1	 Acefortyfourtalon     	    	   1 	 5/5H  	 4/3H  	 5/4   	 4/2H  	 4/1H   	4	 1:55.3 	 28.4	 J Ryan        	3.10	 G Durbano
619	31	4	9	 Jolted                	    	   8 	 8/10  	 8/7H  	 8/7H  	 7/5H  	 5/1T   	5	 1:55.4 	 28.2	 Tra Henry     	10.20	 I Darveau
620	31	4	8	 Twang Twang           	    	   7 	 7/8H  	 7@/6  	 7@/6  	 8/6H  	 6/2Q   	6	 1:55.4 	 28.3	 K Sheppard    	17.35	 K Sheppard
621	31	4	3	 Beach Boy             	    	   3 	 6/7   	 6/5H  	 6/5H  	 6/4   	 7/5H   	7	 1:56.2 	 29.2	 R Holliday    	7.45	 S Pryjma
622	31	4	5	 Vijayscam             	    	   5 	 1/1   	 2/1H  	 3/2   	 5/3Q  	 8/6H   	8	 1:56.3 	 30.1	 A Macdonald   	15.40	 D Graham
623	31	4	7	 Regally Magnified     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
624	31	5	1	 Billiondolarsecret    	    	   1 	 2/1H  	 2/1H  	 3/2   	 2/1H  	 1/NS   	1	 1:57.2 	 28.3	 Tra Henry     	18.85	 S Doyle
625	31	5	2	 Bettor Feather        	    	   2 	 1/1H  	 1/1H  	 1/1H  	 1/1H  	 2/NS   	2	 1:57.2 	 29  	 A Carroll     	0.60	 R Moreau
626	31	5	8	 Braonach              	    	   6 	 6/9   	 6/7H  	 5@/5Q 	 3/4   	 3/3Q   	3	 1:58   	 28.3	 A Macdonald   	3.95	 A Macdonald
627	31	5	7	 Skittle Hanover       	    	   5 	 5/7H  	 5/6   	 6/6   	 6/7H  	 4/4T   	4	 1:58.2 	 28.4	 A Haughan     	35.55	 J Williamso
628	31	5	3	 A Royal Hanover       	    	   3 	 3/3   	 3/3   	 4/3H  	 5/6   	 5/8T   	5	 1:59.1 	 30.1	 B Davis Jr    	50.70	 B Macintosh
629	31	5	9	 The Camel Express     	    	   7 	 7/10H 	 7/9   	 7/10  	 7/11H 	 6/10H  	6	 1:59.2 	 29  	 R Holliday    	5.95	 L Joyce
630	31	5	5	 Big Chute             	    	   4 	 4/4H  	 4/4H  	 2@/1H 	 4/4H  	 7/12H  	7	 1:59.4 	 31.1	 P Mackenzie   	2.60	 M Brethour
631	31	5	4	 Crazy Alice           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
632	31	5	6	 Im Stunning           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
633	31	6	4	 Severus Hanover=      	    	   4 	 2/1H  	 3/3   	 2@/1H 	 2/Q   	 1/1T   	1	 1:56.4 	 29.3	 B Mcclure     	10.60	 D Frey
634	31	6	3	 Covert Operative=(L)  	    	   3 	 3/3   	 1/1H  	 1/1H  	 1/Q   	 2DH/1T 	2	 1:57.1 	 30.1	 N Steward     	0.95	 P Henriksen
635	31	6	6	 Utopia=               	    	   6 	 6/8   	 6/7H  	 4@/3  	 4/2   	 2DH/1T 	2	 1:57.1 	 29.3	 J Ryan        	6.10	 J Ryan
636	31	6	5	 Chuckalo Caden        	    	   5 	 1/1H  	 2/1H  	 3/1H  	 3/1H  	 4/2T   	4	 1:57.2 	 30.1	 S Young       	10.90	 C Thompson
637	31	6	2	 Tortola Sunrise=      	    	   2 	 5/6H  	 5/6   	 7/5H  	 7/5   	 5/3H   	5	 1:57.2 	 29.2	 A Macdonald   	1.55	 A Macdonald
638	31	6	1	 Class Me Nice=(L)     	    	   1 	 4/4H  	 4/4H  	 5/3H  	 5/3H  	 6/3H   	6	 1:57.2 	 29.4	 R Holliday    	15.10	 B Weinholdt
639	31	6	7	 Amoureuse Hanover     	    	   7 	 7/9H  	 7/9   	 6@/5  	 6/4   	 7/5    	7	 1:57.4 	 29.4	 A Carroll     	15.50	 B Peterson
640	31	6	8	 Early Hit             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
641	32	1	9	 Dixie Lullaby         	    	   9 	 9/12  	 9@/11 	 8@/6H 	 5/4Q  	 1/1    	1	 1:55.1 	 29  	 B Forward     	6.75	 R Fellows
642	32	1	5	 Rockin Sockem         	    	   5 	 2/1H  	 2/1H  	 2/1H  	 2/1   	 2/1    	2	 1:55.2 	 30.1	 P Mackenzie   	13.95	 T Stokes
643	32	1	4	 Deucette              	    	   4 	 6/7H  	 6@/6H 	 6@/5  	 3/2   	 3/1T   	3	 1:55.3 	 29.3	 B Mcclure     	1.20	 T Jacobson
644	32	1	2	 Jens Credit           	    	   2 	 4/4H  	 4@/4H 	 4@/3  	 4/2H  	 4/3    	4	 1:55.4 	 30.1	 A Carroll     	4.85	 V Puddy
645	32	1	8	 P L Jasmine           	    	   8 	 1/1H  	 1/1H  	 1/1H  	 1/1   	 5/4    	5	 1:56   	 31  	 R Holliday    	11.90	 R Mcmillan
646	32	1	6	 Radar Trap            	    	   6 	 7/9   	 7/8H  	 7/5H  	 8/7H  	 6/4H   	6	 1:56   	 30  	 J Ryan        	29.25	 C Barss
647	32	1	3	 Casimir Overthetop    	    	   3 	 5/6   	 5/5   	 5/3H  	 6/4H  	 7/4T   	7	 1:56.1 	 30.3	 G Large       	12.20	 G Large
648	32	1	7	 Ima Holy Terror       	    	   7 	 8/10H 	 8/9   	 9/14  	 9/12  	 8/12T  	8	 1:57.4 	 30  	 C Steacy      	46.35	 R Hughes
649	32	1	1	 Imacutiepatootie      	    	   1 	 3/3   	 3/3   	 3@/2H 	 7/6   	 9/13   	9	 1:57.4 	 32.2	 M Whelan      	2.25	 A Colville
650	32	2	7	 Lady Crazy            	    	   7 	 2@/1  	 2@/HD 	 2@/H  	 2/HD  	 1/1    	1	 1:56.1 	 30.1	 Tra Henry     	4.50	 C Bradshaw
651	32	2	5	 Jiminey Three         	    	   5 	 1/1   	 1/HD  	 1/H   	 1/HD  	 2/1    	2	 1:56.2 	 30.2	 A Carroll     	2.40	 R Moreau
652	32	2	2	 Bad At Redhot         	    	   2 	 5/4H  	 5@/5H 	 4@/2  	 4/2   	 3/1Q   	3	 1:56.2 	 30  	 R Holliday    	4.45	 W Dunn
653	32	2	4	 Frankies First Luv    	    	   4 	 6/6   	 6/6   	 5@@/3H	 3/1H  	 4DH/1H 	4	 1:56.2 	 29.4	 B Mcclure     	5.45	 J Marsden
654	32	2	8	 Northern Prima        	    	   8 	 8/9   	 8/8H  	 8/6   	 7/5H  	 4DH/1H 	4	 1:56.2 	 29.1	 P Mackenzie   	14.15	 M Brethour
655	32	2	3	 Flower Bomb           	    	   3 	 4/3   	 4/4   	 6/4   	 8/6H  	 6/2H   	6	 1:56.3 	 29.4	 B Forward     	2.70	 B Macintosh
656	32	2	6	 Warrawee Rocket       	    	   6 	 7/7H  	 7/7   	 7@/4H 	 6/4   	 7/2T   	7	 1:56.4 	 30  	 B Davis Jr    	9.95	 T Stein
657	32	2	1	 Inexplicable Ruby     	    	   1 	 3/1H  	 3/3H  	 3/1H  	 5/3H  	 8/4    	8	 1:57   	 30.4	 N Steward     	9.70	 J Copley
658	32	3	1	 Par Intended          	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1H  	 1/H    	1	 1:56   	 28.4	 A Carroll     	3.00	 V Puddy
659	32	3	2	 Markathy              	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1H  	 2/H    	2	 1:56   	 28.3	 N Steward     	6.00	 P Belanger 
660	32	3	3	 E L Spartacus         	    	   3 	 3/3   	 4/3H  	 5/3H  	 4/3   	 3/1H   	3	 1:56.1 	 28.2	 B Mcclure     	7.40	 J Watt
661	32	3	4	 Panedictine(L)        	    	   4 	 4/4H  	 3@/2  	 2@/1  	 3/1H  	 4/2Q   	4	 1:56.2 	 29  	 B Davis Jr    	6.80	 T Stein
662	32	3	6	 Cruizin K C           	    	   6 	 6/7H  	 6@/5H 	 6@/4H 	 7/7   	 5/5Q   	5	 1:57   	 29  	 P Mackenzie   	1.45	 P Coleman
663	32	3	5	 Connery Blue Chip     	    	   5 	 5/6   	 5@/4  	 4@/3  	 5/4H  	 6/7Q   	6	 1:57.2 	 29.3	 C Steacy      	12.55	 P Shepherd
664	32	3	7	 Amble Over Hanover(L) 	    	   7 	 7/9   	 7@/6H 	 7@@/5 	 6/6   	 7/7T   	7	 1:57.3 	 29.2	 Tra Henry     	5.25	 L Fuller
665	32	3	8	 Gunpowder             	    	   8 	 8/10H 	 8/7H  	 8/6Q  	 8/8H  	 8/7T   	8	 1:57.3 	 29.1	 B Forward     	17.95	 M Rain
666	32	4	1	 Platoon Seelster      	    	   1 	 3/3   	 1/1H  	 1/1   	 1/1H  	 1/1    	1	 1:56.2 	 28.4	 R Holliday    	0.90	 D Holliday
667	32	4	7	 Big Rich=(L)          	    	   7 	 1/1H  	 2/1H  	 3/1H  	 3/2   	 2/1    	2	 1:56.3 	 28.4	 B Davis Jr    	5.55	 R Moreau
668	32	4	9	 Delcrest Massy=(L)    	    	   9 	 5/6   	 5/4   	 4@/3  	 2/1H  	 3/1H   	3	 1:56.3 	 28.2	 A Carroll     	29.35	 V Puddy
669	32	4	8	 In Secret=(L)         	    	   8 	 9/12  	 9/10  	 9/7Q  	 7/6   	 4/1H   	4	 1:56.3 	 27.3	 B Mcclure     	11.20	 P Henriksen
670	32	4	3	 Doubledown Gass       	    	   3 	 2/1H  	 3/3   	 5/3H  	 5/4   	 5/1T   	5	 1:56.4 	 28.3	 R Gassien     	4.40	 R Gassien
671	32	4	4	 Call Me Richard       	    	   4 	 7/9   	 6/5H  	 6@/4H 	 6/5H  	 6/3    	6	 1:57   	 28.3	 P Mackenzie   	4.65	 C Bradshaw
672	32	4	2	 Domedomedome(L)       	    	   2 	 6/7H  	 7/7   	 7/6   	 9/7H  	 7/3T   	7	 1:57.1 	 28.2	 Jo Kovacs     	14.05	 J Moiseyev
673	32	4	5	 R Choochoo Charlie=(L)	)   	   5 	 8/10H 	 8@/8H 	 8@/6H 	 8/7   	 8/6H   	8	 1:57.3 	 28.4	 Tra Henry     	15.20	 C Auciello
674	32	4	6	 Warrawee Proton       	    	   6 	 4/4H  	 4/3H  	 2@/1  	 4X/3T 	 9/22   	9	 2:00.4 	 33  	 B Forward     	17.90	 T Langille
675	35	1	1	 Big Yellow(L)         	    	   1 	 2/2   	 2/5   	 1/1   	 1/2   	 1/1H   	1	 1:55.2 	 30.1	 S Young       	2.90	 B Wallace
676	35	1	2	 Upgrade Valley        	    	   2 	 4/4   	 4@/8  	 2/1   	 2/2   	 2/1H   	2	 1:55.3 	 30.1	 P Mackenzie   	5.55	 P Smith
677	35	1	5	 Emperor               	    	   5 	 8/12  	 7/12  	 4@/5  	 3/6   	 3/5H   	3	 1:56.2 	 30.1	 A Carroll     	1.70	 R Mcintosh
678	35	1	8	 The Avenger           	    	   8 	 3@/3  	 3/7   	 3/4   	 4/8   	 4/10   	4	 1:57.2 	 31.2	 B Davis Jr    	36.55	 W Robinson
679	35	1	6	 Stonebridge Marvel    	    	   6 	 9/14  	 8/14  	 7/8   	 6/11  	 5/12T  	5	 1:58   	 31.1	 N Steward     	16.80	 J Belliveau
680	35	1	9	 Zetlan Rocket         	    	   9 	 5/6   	 5/9H  	 5/6   	 5/10  	 6/16H  	6	 1:58.3 	 32.1	 T Smith       	86.05	 J Walker
681	35	1	3	 Wild Chance           	    	   3 	 6/8   	 6@/10 	 8/10  	 7/15  	 7/21   	7	 1:59.3 	 32.2	 B Mcclure     	4.65	 W Whebby
682	35	1	7	 Derby Dale            	    	   7 	 1/2   	 1/5   	 6/7   	 8/17  	 8/30   	8	 2:01.2 	 34.4	 B Forward     	7.40	 V Puddy
683	35	1	4	 Rockstar Drums        	    	   4 	 7X/10 	 9/17  	 9/18  	 9/25  	 9/34   	9	 2:02.1 	 33.2	 L Ouellette   	24.35	 J Morrison
684	35	2	1	 Trishas Wish          	    	   1 	 2/2   	 2/1   	 3/2   	 3/1   	 1/H    	1	 1:58.4 	 30.3	 R Battin      	9.50	 R Battin
685	35	2	5	 Ginger                	    	   5 	 1/2   	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:58.4 	 31  	 B Forward     	7.45	 L Johnson
686	35	2	3	 Blazinhart Hanover    	    	   3 	 6/10  	 6/6H  	 6/5   	 5/2H  	 3/2    	3	 1:59.1 	 30.2	 T Moore       	24.05	 J Wright
687	35	2	2	 Lady Santana          	    	   2 	 5/7   	 5@/3H 	 4@/2H 	 4/1H  	 4/2Q   	4	 1:59.1 	 31  	 B Davis Jr    	2.70	 J Pereira
688	35	2	4	 Mach Of The Town      	    	   4 	 3/4   	 4/3   	 5@/3H 	 6/3   	 5/4Q   	5	 1:59.3 	 31.1	 N Steward     	1.60	 G Robinson
689	35	2	8	 Shanghai Nights       	    	   8 	 9/16  	 9/11  	 8/6H  	 7/3H  	 6/5T   	6	 2:00   	 31  	 P Mackenzie   	12.15	 L Mansfield
690	35	2	9	 Hussys Sport          	    	   9 	 4/5H  	 3@/1H 	 2@/H  	 2/H   	 7/6Q   	7	 2:00   	 32.1	 L House       	9.90	 S Mcniven
691	35	2	7	 On The Rise           	    	   7 	 8/14  	 8@/9  	 9/7H  	 9/5H  	 8/7T   	8	 2:00.2 	 31.1	 R Holliday    	76.15	 W Durbridge
692	35	2	6	 Jinglewriter(L)       	    	   6 	 7/12  	 7@/7  	 7@/5H 	 8/4H  	 9/12   	9	 2:01.1 	 32.2	 A Carroll     	7.35	 B Treen
693	35	3	5	 Unce Hanover          	    	   4 	 4/4H  	 3@/2  	 2@/1  	 2/1   	 1/NS   	1	 2:02.1 	 30  	 A Carroll     	2.95	 C Coleman
694	35	3	4	 Hands Up For Luck     	    	   3 	 2/1   	 1/1   	 1/1   	 1/1   	 2/NS   	2	 2:02.1 	 30.1	 B Davis Jr    	0.65	 A Macdonald
695	35	3	3	 Cam Engine            	    	   2 	 6/7H  	 5@/4  	 3@@/2 	 3/1H  	 3/1    	3	 2:02.2 	 30  	 P Mackenzie   	15.70	 M Rivest
696	35	3	7	 Chalky                	    	   6 	 1/1   	 2/1   	 4/3H  	 4/2H  	 4/1Q   	4	 2:02.2 	 29.4	 Mi Horner     	12.05	 Ma Horner
697	35	3	8	 Flying Solo           	    	   7 	 7/9   	 7@/6  	 5@/4H 	 6/4H  	 5/3T   	5	 2:03   	 30.1	 Tra Henry     	22.10	 V Cochrane
698	35	3	9	 All Access            	    	   9 	 5/6   	 6/5   	 7@/6H 	 7/5H  	 6/4T   	6	 2:03.1 	 30  	 N Boyd        	22.90	 J Dean
699	35	3	1	 Best Of Luck Bilbo    	    	   1 	 3/3   	 4/3   	 6/5H  	 5/4   	 7/5    	7	 2:03.1 	 30.1	 S Hudon       	22.00	 K Gangell
700	35	3	6	 Little Johnny         	    	   5 	 8/10  	 8/7H  	 8/8H  	 8/8H  	 8/7H   	8	 2:03.3 	 30  	 B Forward     	9.15	 N Liadis
701	35	3	2	 About A Boy           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
702	35	4	1	 Gia Diamond(L)        	    	   1 	 1/1H  	 1/1   	 1/1H  	 1/3   	 1/7T   	1	 1:57.1 	 29  	 J Ryan        	3.20	 J Ryan
703	35	4	6	 Squeeze This          	    	   6 	 5/5   	 6@/5  	 5@@/4 	 4/4H  	 2/7T   	2	 1:58.4 	 29.4	 Tra Henry     	0.85	 D Lindsey
704	35	4	9	 Shes Dignified        	    	   9 	 2/1H  	 2/1   	 2/1H  	 2/3   	 3/8    	3	 1:58.4 	 30.2	 P Mackenzie   	22.55	 S Gillard
705	35	4	3	 All The Ladies        	    	   3 	 4/4   	 5@/3H 	 3@@/2H	 3/3H  	 4/9H   	4	 1:59   	 30.2	 A Haughan     	38.00	 M Crone
706	35	4	2	 Sportsonthebeach      	    	   2 	 3/3   	 3@/2  	 6@/5  	 6/7   	 5/11H  	5	 1:59.2 	 30.1	 A Carroll     	10.00	 G Mcdonnell
707	35	4	4	 Casimir Lucky Lady    	    	   4 	 6/6   	 4/3   	 4/3H  	 5/6H  	 6/15H  	6	 2:00.1 	 31.2	 B Mcclure     	17.70	 B Kempton
708	35	4	7	 Blushing Promise      	    	   7 	 8/9H  	 8/8H  	 8/6H  	 8/9   	 7/15T  	7	 2:00.2 	 31  	 C Brown       	40.25	 G Laurignan
709	35	4	8	 Mach Shark            	    	   8 	 9/11  	 9/11  	 9/7H  	 9/10H 	 8/16   	8	 2:00.2 	 30.4	 G Rooney      	41.55	 V Mcmurren
710	35	4	5	 Mighty Mouse          	    	   5 	 7/8   	 7@/7  	 7@@/5H	 7/7H  	 9/16H  	9	 2:00.2 	 31.1	 N Steward     	4.50	 J Watt
711	35	5	9	 Littlebitaswagger     	    	   9 	 4/3   	 4/3   	 6/4   	 4/2H  	 1/H    	1	 1:56.3 	 29  	 Tra Henry     	24.60	 J Harris
712	35	5	2	 Blue Zombie           	    	   2 	 1/1H  	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:56.3 	 29.4	 A Carroll     	1.10	 C Coleman
713	35	5	3	 Adore Him             	    	   3 	 5/4H  	 5@/3H 	 2@@/H 	 2/H   	 3/H    	3	 1:56.3 	 29.4	 N Steward     	1.85	 C Blake
714	35	5	1	 Deseronto(L)          	    	   1 	 2/1H  	 2/1   	 3/2   	 3/1H  	 4/1T   	4	 1:57   	 29.4	 R Holliday    	9.65	 D Lindsey
715	35	5	4	 Another Great Pick    	    	   4 	 6/6H  	 6/5   	 8/6   	 5/4   	 5/3    	5	 1:57.1 	 29.1	 R Battin      	18.85	 R Battin
716	35	5	5	 Art Again             	    	   5 	 3@/2  	 3@/1H 	 4@/2H 	 6/4H  	 6/6    	6	 1:57.4 	 30.3	 B Mcclure     	6.15	 G Mcdonnell
717	35	5	7	 Distinctiv Sean       	    	   7 	 8/9   	 9/7H  	 9/8   	 7/6   	 7/6H   	7	 1:57.4 	 29.2	 G Rooney      	62.60	 V Mcmurren
718	35	5	8	 Harbourlite Jerry     	    	   8 	 9/10H 	 8@/6H 	 7@/5  	 8/6H  	 8/8    	8	 1:58.1 	 30.2	 B Forward     	189.35	 J Rankin
719	35	5	6	 Mr Irresistible       	    	   6 	 7/7H  	 7@/5H 	 5@/3H 	 9/7   	 9/10H  	9	 1:58.3 	 31.1	 P Mackenzie   	24.00	 M Etsell
720	35	6	2	 Youths Awesome(L)     	    	   2 	 4/4   	 5/4   	 5@/3H 	 5/3   	 1/NS   	1	 1:57.1 	 30  	 R Battin      	15.40	 R Battin
721	35	6	6	 Here Comes William    	    	   6 	 6@/5H 	 4@/2H 	 4@/2H 	 3/1H  	 2/NS   	2	 1:57.1 	 30.1	 D Dupont      	0.75	 M Dupont
722	35	6	9	 Goldstar Badlands     	    	   9 	 3/2   	 2@/H  	 2@/H  	 1/1   	 3/1Q   	3	 1:57.2 	 30.4	 G Rooney      	9.70	 H Toll
723	35	6	3	 Evasive Card Shark    	    	   3 	 2/1   	 3/2   	 3/2   	 4/2   	 4/1Q   	4	 1:57.2 	 30.2	 D St Pierre   	9.55	 T Staley
724	35	6	7	 Monster In Law        	    	   7 	 9/9H  	 9/8   	 7/5H  	 6/4H  	 5/1H   	5	 1:57.2 	 29.4	 N Steward     	47.40	 D Beatson
725	35	6	1	 Intrigued Intended    	    	   1 	 1/1   	 1/H   	 1/H   	 2/1   	 6/3T   	6	 1:58   	 31.2	 R Holliday    	13.55	 G Weatherbe
726	35	6	5	 Grits N Gravy         	    	   5 	 7/7   	 7@/6H 	 8@/6  	 7/5   	 7/3T   	7	 1:58   	 30.1	 B Mcclure     	8.80	 W Hamm
727	35	6	8	 Big Moment            	    	   8 	 8@/7H 	 8/7   	 9/8   	 8/6   	 8/4    	8	 1:58   	 29.4	 A Carroll     	13.85	 R Mcintosh
728	35	6	4	 Relleno Hanover(L)    	    	   4 	 5/5   	 6@/4H 	 6@/4H 	 9/7   	 9/4H   	9	 1:58   	 30.3	 B Forward     	6.50	 G Mcdonnell
729	36	1	1	 Dreydl Hanover        	    	   1 	 1/H   	 1/1H  	 1/1H  	 1/4   	 1/4H   	1	 1:57.1 	 30.2	 A Haughan     	1.10	 G Remmen
730	36	1	9	 Bugger Max            	    	   9 	 3/2   	 3@/2  	 2@/1H 	 2/4   	 2/4H   	2	 1:58   	 31  	 N Steward     	4.30	 D Beatson
731	36	1	6	 St Lads Zeke          	    	   6 	 9/10  	 9/13  	 7@/5H 	 7/7   	 3/5    	3	 1:58.1 	 30.2	 S Young       	13.85	 G Wain
732	36	1	3	 Kendal Fresco         	    	   3 	 2@/H  	 2/1H  	 4/3   	 3/4H  	 4/5Q   	4	 1:58.1 	 30.4	 L House       	11.40	 S Mcniven
733	36	1	4	 Hussys Blu Boy        	    	   4 	 6/6   	 6@/5H 	 5@/3H 	 5/5H  	 5/6    	5	 1:58.2 	 31  	 B Mcclure     	3.00	 S Mcniven
734	36	1	5	 Boysgotfever          	    	   5 	 7/7   	 7@/7  	 8/6H  	 6/6H  	 6/6Q   	6	 1:58.2 	 30.2	 T Moore       	20.50	 M Macri
735	36	1	2	 The Kop               	    	   2 	 5/4H  	 5/5   	 6@/4H 	 8/7H  	 7/10T  	7	 1:59.2 	 31.4	 R Holliday    	20.55	 F Maguire
736	36	1	7	 Terra Cotta Lad       	    	   7 	 4@/3  	 4@/3  	 3@@/2 	 4/5   	 8/13T  	8	 2:00   	 32.4	 B Forward     	26.25	 G Mcdonnell
737	36	1	8	 Machme To The Moon    	    	   8 	 8/8H  	 8/12  	 9/10  	 9/12  	 9/17T  	9	 2:00.4 	 32  	 A Carroll     	42.50	 W Robinson
738	36	2	9	 Spartan Victory       	    	   9 	 5/4   	 3@/1H 	 3@/1H 	 2/NS  	 1/1Q   	1	 2:00.3 	 28.3	 R Holliday    	2.10	 K Di Cenzo
739	36	2	7	 Thundering Ovation    	    	   7 	 1@/1  	 1/1   	 1/1   	 1/NS  	 2/1Q   	2	 2:00.4 	 29  	 P Mackenzie   	1.50	 G Sloan
740	36	2	4	 Sonny With Achance    	    	   4 	 3/2   	 4/2H  	 4/3   	 4/4   	 3/5H   	3	 2:01.3 	 29.1	 J Obrien      	38.05	 J Obrien
741	36	2	2	 Stolen Goods          	    	   2 	 2/1   	 2/1   	 2/1   	 3/2H  	 4/5H   	4	 2:01.3 	 29.3	 B Forward     	13.35	 J Rankin
742	36	2	5	 Flexie                	    	   5 	 4@/3  	 6/4H  	 7/5H  	 6/5H  	 5/6Q   	5	 2:01.4 	 29  	 Tra Henry     	26.35	 M Giles
743	36	2	6	 Lexus Rocky           	    	   6 	 7/6   	 7@/5H 	 6@/4H 	 7/6H  	 6/7Q   	6	 2:02   	 29.2	 A Carroll     	5.15	 D Sinclair
744	36	2	3	 Majestic Mystic=      	    	   3 	 6/5   	 5@/3H 	 5@/3H 	 5/4H  	 7/8T   	7	 2:02.2 	 30  	 G Ketros      	38.25	 G Ketros
745	36	2	8	 Bambino Hall(L)       	    	   8 	 8/8   	 8/6H  	 8@/6H 	 8/7H  	 8/10   	8	 2:02.3 	 29.3	 J Ryan        	5.00	 J Ryan
746	36	2	1	 Piscean(L)            	    	   X1	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 B Mcclure     	\N	 C Beelby
747	36	3	6	 Argyle Alberwhosur    	    	   6 	 6/7   	 2@/1  	 2@/H  	 1/3   	 1/7    	1	 1:59   	 30.2	 B Forward     	5.00	 J Pedden
748	36	3	3	 Gossip Model          	    	   3 	 3/3   	 4@/3  	 5@/3H 	 3/3H  	 2/7    	2	 2:00.2 	 31.1	 Tra Henry     	0.90	 K Di Cenzo
749	36	3	2	 Noodles               	    	   2 	 1/1H  	 1/1   	 1/H   	 2/3   	 3/8H   	3	 2:00.3 	 32  	 N Steward     	4.75	 R Mitchell
750	36	3	4	 Flysantanna           	    	   4 	 2/1H  	 3/2   	 3/2   	 4/4   	 4/9H   	4	 2:00.4 	 31.4	 P Mackenzie   	5.65	 Alan W Fair
751	36	3	1	 Maritime Girl         	    	   1 	 4/4H  	 5/4   	 4/3   	 5/4H  	 5/10   	5	 2:01   	 31.4	 S Young       	15.85	 J Wright
752	36	3	7	 Impatient Lady        	    	   7 	 7/8   	 6@/5  	 6@/5  	 7/6   	 6/10T  	6	 2:01.1 	 31.3	 T Moore       	25.00	 R Duld
753	36	3	5	 Acefourtyfouramber    	    	   5 	 5/6   	 7/6H  	 8/6H  	 8/7   	 7/10T  	7	 2:01.1 	 31.2	 J Ryan        	38.45	 S Peacock
754	36	3	8	 Sportsillustrator     	    	   8 	 8/9   	 8@/7  	 7@@/5H	 6/5H  	 8/11H  	8	 2:01.1 	 31.3	 B Mcclure     	13.65	 R Mcneill
755	36	4	1	 B Fast Eddie          	    	   1 	 1/1   	 1/1   	 1/H   	 1/1H  	 1/2Q   	1	 1:57.1 	 29  	 B Mcclure     	1.75	 B Baillarge
756	36	4	5	 The Big Beast         	    	   5 	 3/2   	 3/2   	 3/2   	 2/1H  	 2/2Q   	2	 1:57.3 	 29  	 L Ouellette   	5.65	 M Ouimet
757	36	4	4	 Preppy Art            	    	   4 	 6/5   	 6/4H  	 6/4H  	 4/3H  	 3/3Q   	3	 1:57.4 	 28.4	 T Fritz       	31.25	 T Fritz
758	36	4	2	 Sutton Seelster       	    	   2 	 2/1   	 2/1   	 2@/H  	 3/2   	 4/3H   	4	 1:57.4 	 29.3	 T Moore       	1.50	 Dr I Moore
759	36	4	3	 Mister Big Top        	    	   3 	 5/4   	 5@/3H 	 5@@/4 	 5/4   	 5/5H   	5	 1:58.1 	 29.1	 Tra Henry     	44.90	 J Byron
760	36	4	7	 Shaker                	    	   7 	 7/6   	 7/5H  	 7/6   	 6/6   	 6/5T   	6	 1:58.2 	 29  	 B Forward     	33.30	 P Shakes
761	36	4	6	 Rough Trade           	    	   6 	 8/7H  	 9/7H  	 9/8H  	 7/8   	 7/7T   	7	 1:58.4 	 29  	 P Mackenzie   	14.10	 F Hincks
762	36	4	8	 Cams Lucky Sam(L)     	    	   8 	 9/9   	 8@/6  	 8@/6H 	 8/10  	 8/9    	8	 1:59   	 29.3	 J Ryan        	13.15	 N Gallucci
763	36	4	9	 Invinceable B         	    	   9 	 4/3   	 4@/2H 	 4@/3H 	 9/12  	 9/20   	9	 2:01.1 	 32.2	 G Rooney      	11.65	 K Campbell
764	37	1	1	 Rosberg               	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1   	 1/T    	1	 2:01.3 	 29.4	 J Moiseyev    	0.60	 J Walker
765	37	1	4	 Zorgwijk Rocket=      	    	   4 	 2/1H  	 2/1   	 2/1   	 2/1   	 2/T    	2	 2:01.4 	 29.4	 J Hudon Jr    	3.30	 J Hudon Jr
766	37	1	6	 Mr Marshmellow=       	    	   6 	 3/3   	 3/2H  	 3/2   	 3/2   	 3/3H   	3	 2:02.1 	 30  	 O Gois        	5.50	 O Gois
767	37	1	7	 Many A Man            	    	   7 	 6/9   	 6@/7  	 5/5   	 5/4   	 4/5    	4	 2:02.3 	 29.4	 A Carroll     	40.60	 R Mcintosh
768	37	1	2	 Yo Yo Mass=           	    	   2 	 5/7H  	 5@/5H 	 4/3H  	 4/3   	 5/6    	5	 2:02.4 	 30.2	 B Mcclure     	6.85	 K Reibeling
769	37	1	3	 Stonebridge Brass     	    	   3 	 4/6   	 4/5   	 6/10  	 6/16  	 6/27   	6	 2:07   	 33.1	 S Byron       	63.65	 J Bax
770	37	1	5	 Adventure Ahead=      	    	   5 	 X7X/24	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 A Macdonald   	24.55	 A Macdonald
771	37	2	4	 Kitarro               	    	   4 	 3/3   	 3/2   	 3@/1  	 3/1H  	 1/8H   	1	 2:03.2 	 30.1	 P Mackenzie   	4.60	 K Reibeling
772	37	2	3	 Northern Dazzle       	    	   3 	 1/H   	 2/1   	 4/4   	 4/7   	 2/8H   	2	 2:05   	 31.1	 D Mcnair      	19.30	 R Mcnair
773	37	2	2	 Critical Mass=        	    	   2 	 2@/H  	 1/1   	 1/H   	 1I/H  	 3/11T  	3	 2:05.4 	 32.4	 B Mcclure     	0.55	 D Menary
774	37	2	5	 My Big Kadillac       	    	   5 	 4/5   	 4/3   	 2@/H  	 2IX/H 	 4/12H  	4	 2:05.4 	 32.4	 A Carroll     	2.90	 R Mcintosh
775	37	2	1	 Laminin               	    	   1X	 5/12  	 5/13  	 5X/14 	 5X/19 	 5/22   	5	 2:07.4 	 32  	 C Jamieson    	11.40	 C Jamieson
776	37	2	6	 Bourne=               	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
777	37	2	7	 More Than Majestic=   	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
778	37	3	1	 Clear Idea            	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:59.2 	 29.2	 B Davis Jr    	1.90	 B Macintosh
779	37	3	4	 Cousin Mary           	    	   4 	 4/5   	 4@/3  	 3@@/1H	 2/1   	 2/H    	2	 1:59.2 	 29.1	 R Holliday    	1.40	 J Kerr
780	37	3	3	 Michelles Hattrick    	    	   3 	 3/3   	 2@/1  	 2@/1  	 3/1H  	 3/2    	3	 1:59.4 	 29.3	 Trev Henry    	2.85	 J Pereira
781	37	3	2	 Dirt On My Skirt      	    	   2 	 2/1   	 3/2   	 4/2   	 4/2   	 4/2H   	4	 1:59.4 	 29.2	 S Young       	15.25	 C Flanigan
782	37	3	6	 Fading Shadow         	    	   6 	 6/8   	 6@/5  	 5@/3H 	 5/3   	 5/3Q   	5	 2:00   	 29.2	 D Mcnair      	11.85	 J Darling
783	37	3	5	 Lyons Moonlight       	    	   5 	 5/6H  	 5/4H  	 6/4H  	 6/5   	 6/4    	6	 2:00.1 	 29.2	 A Haughan     	68.10	 B Goit
784	37	3	7	 Dancing Shadows K     	    	   7 	 8/10H 	 7@/6H 	 7@/5  	 7/6   	 7/7H   	7	 2:00.4 	 29.4	 Ja Macdonald  	47.65	 P Reid
785	37	3	9	 Uncool                	    	   9 	 7/9H  	 8/9H  	 8/11  	 8/14  	 8/23   	8	 2:04   	 31.4	 N Steward     	80.65	 Alan W Fair
786	37	3	8	 Lady Oxford           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
787	37	4	2	 Prettyndangerous      	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:55.2 	 30  	 J Ryan        	2.30	 B Curran
788	37	4	3	 Moon Lake(L)          	    	   2 	 2/1   	 2/1   	 2/1   	 2/1   	 2/H    	2	 1:55.2 	 29.4	 B Forward     	9.50	 D Lehan
789	37	4	7	 Romance In Camelot(L) 	    	   6 	 6/7   	 5/4H  	 3/2H  	 3/2   	 3/3Q   	3	 1:56   	 30.1	 R Holliday    	35.35	 M Rivest
790	37	4	8	 St Lads Pixie         	    	   7 	 7/9   	 7/6H  	 5/4H  	 4/3H  	 4/4T   	4	 1:56.2 	 30.1	 B Mcclure     	20.95	 J Watt
791	37	4	4	 Cyndalianne Duc       	    	   3 	 4/4   	 4@/3  	 6@/5  	 6/4H  	 5/5Q   	5	 1:56.2 	 30  	 N Steward     	4.55	 G Robinson
792	37	4	6	 Good Luck Kathy       	    	   5 	 5/5   	 6@/5H 	 7/6   	 7/6H  	 6/5H   	6	 1:56.2 	 29.4	 A Carroll     	9.40	 S Rose
793	37	4	5	 Little Anna Mae(L)    	    	   4 	 3/2   	 3@/2  	 4@/3  	 5/4   	 7/5T   	7	 1:56.3 	 30.3	 Trev Henry    	1.15	 L Lalonde J
794	37	4	1	 Twilight Katie        	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
795	37	5	4	 Themanofmydreams      	    	   3 	 2/1   	 1/1H  	 1/1H  	 1/1H  	 1/2T   	1	 2:03.3 	 30  	 D St Pierre   	0.45	 T Staley
796	37	5	5	 Little Lion Man       	    	   4 	 1/1   	 2/1H  	 2/1H  	 2/1H  	 2/2T   	2	 2:04.1 	 30.2	 Trev Henry    	6.85	 R Moreau
797	37	5	2	 Lexus Gilmore=        	    	   1 	 3/2   	 3/2H  	 4/3   	 3/3   	 3/6    	3	 2:04.4 	 30.3	 L House       	28.35	 N Dunstan
798	37	5	8	 Smoking Mass          	    	   7 	 6/7H  	 6/6H  	 6/5   	 5/4H  	 4/7T   	4	 2:05.1 	 30.3	 D Dupont      	35.90	 M Dupont
799	37	5	7	 A J Ricochet          	    	   6 	 5/6   	 5/5H  	 5@/4  	 6/5   	 5/8Q   	5	 2:05.1 	 30.4	 A Carroll     	31.25	 A Dimmers
800	37	5	3	 Motown Jackpot        	    	   2 	 4/4H  	 4/4   	 3@/2  	 4/3H  	 6/9    	6	 2:05.2 	 31.2	 M Baillargeon 	3.25	 B Baillarge
801	37	5	6	 Lmc Mass Gem          	    	   5X	 7/10  	 X7/7  	 7/25  	 7/30  	 7/42   	7	 2:12   	 33.2	 P Mackenzie   	11.35	 K Reibeling
802	37	5	1	 Majestic Streak       	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
803	37	6	5	 Coherent=             	    	   5 	 6@/4H 	 3@/2  	 2@/H  	 2/H   	 1/NK   	1	 2:02.4 	 30.3	 R Jenkins Jr  	10.80	 F Marion
804	37	6	4	 Tinas War             	    	   4 	 3/2   	 4/3   	 4/3H  	 4/2H  	 2/NK   	2	 2:02.4 	 30  	 G Mcknight    	8.45	 G Mcknight
805	37	6	3	 Shes All Muscle       	    	   3 	 1/1   	 1/1   	 1/H   	 1/H   	 3/1    	3	 2:03   	 30.4	 J Ryan        	2.40	 J Wilson
806	37	6	9	 Angel Assault=        	    	   9 	 5/4   	 8/7   	 7/6   	 5/3H  	 4/2Q   	4	 2:03.1 	 29.4	 M Whelan      	6.45	 W Whelan
807	37	6	2	 Tymal Bolt            	    	   2 	 2/1   	 2/1   	 3/2   	 3/2   	 5/3Q   	5	 2:03.2 	 30.4	 T Borth       	7.80	 F Baker Jr
808	37	6	6	 Its Easy To Dance     	    	   6 	 7/6   	 5@/4  	 5@/4  	 7/6   	 6/11H  	6	 2:05   	 32  	 R Shepherd    	2.85	 P Shepherd
809	37	6	8	 Zorgwijk Priority=    	    	   7 	 8/7H  	 7@/6  	 6@/5  	 EX6/4H	 7BE/26 	7	 2:08   	 34.4	 P Mackenzie   	32.15	 T Mckibbin
810	37	6	1	 Scorr Again           	    	   1 	 4/3   	 6/5H  	 X8/16 	 8/26  	 8/DIS  	8	        	     	 Do Brown      	4.30	 Do Brown
811	37	6	7	 Whatdreamsrmadeof     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
812	38	1	1	 Tauriel               	    	   1 	 1/1   	 1/1   	 1/1   	 1/1H  	 1/1    	1	 1:57.1 	 28.3	 B Forward     	3.65	 J Barton
813	38	1	3	 Greystone Ladyluck    	    	   3X	 2/1   	 2/1   	 3/2   	 2/1H  	 2/1    	2	 1:57.2 	 28.2	 B Davis Jr    	1.30	 B Belore
814	38	1	9	 Life Groove           	    	   9 	 5/5H  	 3@/2  	 2/1   	 3/2   	 3/2H   	3	 1:57.3 	 28.4	 P Mackenzie   	6.25	 R Laarman
815	38	1	2	 Alliwannadoisplay     	    	   2 	 4/4H  	 5/4H  	 5/4   	 4/4H  	 4/6T   	4	 1:58.3 	 29.1	 R Shepherd    	25.45	 G Adair
816	38	1	5	 On A Cloud            	    	   5 	 6/7   	 6/6   	 7/6   	 6/6H  	 5/7Q   	5	 1:58.3 	 28.4	 Ja Macdonald  	4.60	 T Bain
817	38	1	6	 Boyur Attractive      	    	   6 	 7/8   	 7@/6H 	 6@/4H 	 7/7H  	 6/9T   	6	 1:59.1 	 29.4	 Trev Henry    	14.80	 R Steward
818	38	1	7	 Tz Tizzy              	    	   7 	 8/9   	 8/7H  	 8@/6H 	 8/8   	 7/10   	7	 1:59.1 	 29.2	 L House       	28.00	 S Mcniven
819	38	1	4	 Evas Best Girl        	    	   4 	 3/2H  	 4@/3  	 4@/3  	 5/5   	 8/12   	8	 1:59.3 	 30.2	 N Steward     	8.45	 P Core
820	38	1	8	 Lady London           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
821	38	2	2	 St Lads Moonwalk      	    	   2 	 4@/3  	 1/1H  	 1/1H  	 1/1H  	 1/2H   	1	 1:53.4 	 28.1	 D Mcnair      	0.75	 J Darling
822	38	2	3	 Newbie                	    	   3 	 1@/1  	 2/1H  	 2/1H  	 2/1H  	 2/2H   	2	 1:54.1 	 28.2	 B Davis Jr    	2.05	 I Hyatt
823	38	2	6	 Rockabella            	    	   5 	 6/9   	 6/7H  	 6/5   	 4/4   	 3/8    	3	 1:55.2 	 28.4	 Trev Henry    	8.45	 T Stein
824	38	2	8	 Raylan Givens(L)      	    	   7 	 2/1   	 3/3   	 4/3H  	 3/3   	 4/8T   	4	 1:55.3 	 29.2	 C Steacy      	89.55	 J Morrison
825	38	2	7	 Rock N Roll Legacy(L) 	    	   6 	 8/11  	 8/9H  	 8/7   	 7/6H  	 5/9Q   	5	 1:55.3 	 28.3	 G Rooney      	29.15	 R Marriage
826	38	2	1	 Ciona Bromach(L)      	    	   1 	 5/6   	 5/6   	 5@/4  	 5/4H  	 6/9Q   	6	 1:55.3 	 29.1	 A Haughan     	25.60	 D Obrienmor
827	38	2	4	 Two Of Clubs          	    	   4 	 3/2H  	 4/4   	 3@/2  	 6/5   	 7/17   	7	 1:57.1 	 31.1	 S Young       	13.00	 G Rivest
828	38	2	9	 Kid Galahad N         	    	   9 	 7/10  	 7@/8  	 7@/6  	 8/7   	 8/17   	8	 1:57.1 	 30.2	 L House       	15.15	 S Taylor
829	38	2	5	 Mister X              	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
830	38	3	1	 Tougher Than Ever=    	    	   1 	 3/2H  	 3/3   	 2@/H  	 2/H   	 1/2Q   	1	 2:02.2 	 30.3	 Ja Macdonald  	2.75	 R Norman
831	38	3	5	 Warrawee Shipshape=   	    	   5 	 2/1   	 2/1H  	 3/2   	 3/2   	 2/2Q   	2	 2:02.4 	 30.3	 A Green       	2.00	 A Green
832	38	3	7	 Dontcrampmystyle=     	    	   7 	 1@/1  	 1/1H  	 1/H   	 1/H   	 3/3Q   	3	 2:03   	 31.1	 Trev Henry    	2.15	 A Mccabe
833	38	3	4	 Jack In My Coke=      	    	   4 	 6/12  	 5@/6H 	 4/3H  	 4/3   	 4/6H   	4	 2:03.3 	 31.1	 J Maguire     	7.00	 J Maguire
834	38	3	3	 Charmbo Chrome        	    	   3 	 5/11  	 6/8   	 5/6H  	 5/6   	 5/7T   	5	 2:04   	 31  	 A Hamilton    	38.05	 J Rier
835	38	3	6	 Piston Popper         	    	   6 	 7/15  	 7/12  	 6/9   	 6/11  	 6/16   	6	 2:05.3 	 32  	 G Rivest      	47.70	 G Rivest
836	38	3	2	 Airborne Seelster     	    	   2 	 4/8   	 4/5H  	 X7/18 	 7/18  	 7/24   	7	 2:07.1 	 31.4	 D Mcnair      	7.15	 R Mcnair
837	38	4	2	 Top Of The Morning(L) 	    	   2 	 3/2   	 3@/1H 	 2@/H  	 2/H   	 1/NK   	1	 1:58.1 	 30.4	 T Moore       	2.85	 T Moore
838	38	4	7	 Nor Star Renegade     	    	   7 	 2@/1  	 1/1   	 1/H   	 1/H   	 2/NK   	2	 1:58.1 	 30.4	 D Mcnair      	6.80	 R Lindenfie
839	38	4	9	 Kablooie(L)           	    	   9 	 6/7H  	 6@/5  	 5@/3H 	 5/3   	 3/2Q   	3	 1:58.3 	 30.3	 B Mcclure     	3.65	 D Lagace
840	38	4	3	 Star Struck Luck      	    	   3 	 7/8H  	 7@/6H 	 6@/5  	 7/4H  	 4/3Q   	4	 1:58.4 	 30.2	 Br Richardson 	9.55	 E Laybourne
841	38	4	5	 Joeys Kidd            	    	   5 	 8/10  	 9@/8H 	 7@/6  	 6/3H  	 5/3H   	5	 1:58.4 	 30.1	 P Mackenzie   	64.20	 V Cochrane
842	38	4	1	 Bandicoot             	    	   1 	 4/4H  	 4@/3H 	 4/3   	 3/2   	 6/5    	6	 1:59.1 	 31.1	 Trev Henry    	2.50	 M Stoikopou
843	38	4	4	 Rocknroll Band        	    	   4 	 5/6   	 5/4H  	 8/7   	 8/6H  	 7/6    	7	 1:59.2 	 30.3	 N Steward     	7.15	 P Belanger 
844	38	4	6	 Jackson Killean(L)    	    	   6 	 1/1   	 2/1   	 3/2   	 4/2H  	 8/7    	8	 1:59.3 	 31.4	 B Forward     	14.85	 L Privett
845	38	4	8	 Two Face(L)           	    	   8 	 9/11H 	 8/8   	 9@/8  	 9/7   	 9/7H   	9	 1:59.3 	 30.3	 M Whelan      	39.85	 F Soyka
846	39	1	4	 Ms Medusa=            	    	   4 	 2/1   	 2/1H  	 3/2   	 3/1H  	 1/H    	1	 2:01.1 	 29.4	 P Henriksen   	6.65	 P Henriksen
847	39	1	2	 Willie Wonka=         	    	   2 	 3/6   	 3/4   	 2@/1  	 2/1   	 2/H    	2	 2:01.1 	 30  	 A Carroll     	8.70	 R Mcintosh
848	39	1	1	 Hilarious Hero=       	    	   1 	 1/1   	 1/1H  	 1/1   	 1/1   	 3/1Q   	3	 2:01.2 	 30.2	 B Mcclure     	2.25	 T Macdonnel
849	39	1	6	 Moon Dance            	    	   6 	 5/9   	 5/8   	 4@/3  	 4/3   	 4/2H   	4	 2:01.3 	 30  	 T Durand      	2.25	 T Durand
850	39	1	3	 Prince Of Minto       	    	   3 	 4/8   	 4/7   	 5/4   	 5/6   	 5/5H   	5	 2:02.1 	 30.2	 M Baillargeon 	3.35	 B Baillarge
851	39	1	9	 Whos Cheatin Who=     	    	   9 	 6/10H 	 6/11  	 6/5   	 X6/8  	 X6/18H 	6	 2:04.4 	 32.4	 R Shepherd    	18.55	 D Sinclair
852	39	1	7	 Style Spotlight       	    	   7 	 7/12H 	 7/16  	 7/17  	 7/20  	 7/31   	7	 2:07.2 	 33  	 P Walker      	69.55	 P Walker
853	39	1	5	 South Win Bax         	    	   5 	 9/16  	 9/23  	 8@/18 	 8/21  	 8/32   	8	 2:07.3 	 33  	 J Bax         	18.70	 J Bax
854	39	1	8	 Jungle Gem            	    	   8 	 8/14  	 8/19  	 9/20  	 9/24  	 9/37   	9	 2:08.3 	 33.3	 D Fritz       	33.35	 D Fritz
855	39	2	1	 J J Mystic Storm      	    	   1 	 1/1H  	 1/1   	 1/1   	 1/2   	 1/2T   	1	 1:57.2 	 29  	 P Mackenzie   	1.80	 S Charlton
856	39	2	5	 Southwind Jagger      	    	   5 	 2/1H  	 2/1   	 2/1   	 2/2   	 2/2T   	2	 1:58   	 29.2	 T Moore       	6.60	 R Ellis
857	39	2	4	 Catch Twenty Two      	    	   4 	 5/5H  	 3@/1H 	 3@/1H 	 3/3   	 3/7H   	3	 1:58.4 	 30.1	 B Mcclure     	8.40	 S Friend
858	39	2	6	 Hes Got Style         	    	   6 	 6/6H  	 5@/3  	 4@/3  	 4/4   	 4/7H   	4	 1:58.4 	 29.4	 L House       	11.55	 S Mcniven
859	39	2	2	 Jansen Hanover        	    	   2 	 3/3   	 4/2H  	 5/4   	 5/5H  	 5/7T   	5	 1:59   	 29.4	 Br Richardson 	1.35	 E Laybourne
860	39	2	7	 Moot Court            	    	   7 	 7/7H  	 7/5   	 6/5   	 6/7   	 6/16   	6	 2:00.3 	 31.1	 R Holliday    	16.75	 R Mcnair
861	39	2	3	 Spaniard              	    	   3 	 4@/4H 	 6/4H  	 7/12  	 7/19  	 7/31   	7	 2:03.3 	 32.4	 A Carroll     	17.65	 M Etsell
862	39	3	1	 Life Strikes          	    	   1 	 1/3   	 1/1H  	 1/1H  	 1/1H  	 1/T    	1	 2:00.4 	 31.4	 M Baillargeon 	1.25	 M Robitaill
863	39	3	7	 Summajestic           	    	   5 	 4/6   	 4/4H  	 3@/2  	 3/2   	 2/T    	2	 2:01   	 31.3	 S Byron       	5.95	 D Byron
864	39	3	5	 P L Jade=             	    	   3 	 2/3   	 2/1H  	 2/1H  	 2/1H  	 3/1H   	3	 2:01   	 31.4	 M Dupuis      	1.75	 M Dupuis
865	39	3	9	 Shes All Magic        	    	   9 	 3/4   	 3/3   	 4/3H  	 4/3H  	 4/3    	4	 2:01.2 	 31.4	 P Henriksen   	7.45	 P Henriksen
866	39	3	4	 Relevant=             	    	   2 	 5/8   	 5/6   	 5/9H  	 5/9H  	 5/14T  	5	 2:03.4 	 33  	 G Macdonald   	23.75	 L Privett
867	39	3	8	 Tala Seelster         	    	   6 	 X6/12 	 6/12  	 6/11  	 6/11  	 6/15   	6	 2:03.4 	 32.3	 B Mcclure     	20.05	 W Budd
868	39	3	6	 Moxie Begonia         	    	   4X	 7/24  	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Harris      	18.50	 G Oliver
869	39	3	2	 Shezastrikin Loral    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
870	39	3	3	 Daytrooper            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
871	39	4	1	 Marina Desbi          	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/2    	1	 1:57.3 	 29.3	 L House       	1.55	 M Paulic
872	39	4	2	 Lucky                 	    	   2 	 3/2H  	 3@/1H 	 2@/1  	 2/1   	 2/2    	2	 1:58   	 29.4	 Tra Henry     	5.80	 M Fitzgeral
873	39	4	3	 Twin B Amour          	    	   3 	 2/1   	 2/1   	 3/2   	 3/2   	 3/5    	3	 1:58.3 	 30.1	 J Harris      	3.05	 J Harris
874	39	4	4	 The Prophet Mary(L)   	    	   4 	 4/4   	 4/3   	 4/3H  	 4/3   	 4/5T   	4	 1:58.4 	 30.1	 N Steward     	4.35	 J Watt
875	39	4	8	 Im A Debutant+(L)     	    	   8 	 7@/7  	 7@/5H 	 7@/6  	 7/5H  	 5/6Q   	5	 1:58.4 	 29.3	 T Moore       	14.35	 L Privett
876	39	4	6	 Lotteria              	    	   6 	 8/8   	 8/6H  	 8@/7  	 8/6   	 6/8    	6	 1:59.1 	 29.4	 B Mcclure     	14.30	 G Laurignan
877	39	4	9	 Alibi Terror          	    	   9 	 5/5   	 5@/3H 	 5@/4  	 5/3H  	 7/8    	7	 1:59.1 	 30.2	 R Holliday    	26.40	 T Schlatman
878	39	4	5	 Mach Denali           	    	   5 	 6/6   	 6/5   	 6/5H  	 6/5   	 8/8Q   	8	 1:59.1 	 30.1	 A Carroll     	20.60	 M Etsell
879	39	4	7	 Oh Chute              	    	   7 	 9/9   	 9/7   	 9@/8  	 9/9   	 9/16   	9	 2:00.4 	 31.1	 P Mackenzie   	38.50	 Alan W Fair
880	39	5	2	 Wilma C               	    	   2 	 3/6   	 2/1   	 2@/H  	 2/H   	 1/1    	1	 2:01.3 	 31.1	 K Sheppard    	0.95	 K Sheppard
881	39	5	9	 T C Sno Massive=      	    	   9 	 4/7   	 4@/3  	 3@/1H 	 3/1   	 2/1    	2	 2:01.4 	 31.1	 B Mcclure     	9.75	 Ri Zeron
882	39	5	5	 Clone The Tone        	    	   5 	 2/1   	 3/2   	 4/2H  	 4/2H  	 3/1T   	3	 2:02   	 31.1	 R Shepherd    	44.75	 S Weber
883	39	5	6	 Zorgwijk Queen        	    	   6 	 1/1   	 1/1   	 1/H   	 1/H   	 4/2    	4	 2:02   	 31.3	 T Borth       	17.40	 R Wade
884	39	5	10	 Vimy Ridge Vesta      	    	   1 	 X6/11 	 6/6   	 6/7   	 5/5H  	 5/10   	5	 2:03.3 	 31.4	 L House       	9.20	 S Loughran
885	39	5	7	 Stonebridge Peace     	    	   X7	 7/19  	 7/13  	 7/13  	 7/11  	 6/14H  	6	 2:04.2 	 31.2	 T Moore       	7.80	 J Copley
886	39	5	4	 Beer Before Noon=     	    	   4X	 X8/24 	 8/19  	 8/14  	 8/13  	 7/16H  	7	 2:04.4 	 31.3	 A Carroll     	6.10	 P Lawrence
887	39	5	8	 Don Jarvis            	    	   8 	 5/9   	 5/4H  	 5/5H  	 6/7H  	 8/16T  	8	 2:05   	 33.3	 R Holliday    	47.95	 M Giles
888	39	5	3	 Lovin Karma           	    	   X3	 X9/DIS	 X9/DIS	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 P Mackenzie   	5.40	 C Yates
889	39	5	1	 Citizen Hall          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
890	39	6	2	 Let Em Bounce         	    	   2 	 2/1   	 1/1   	 1/1   	 1/1   	 1/T    	1	 1:57.3 	 29.4	 B Mcclure     	1.90	 W Budd
891	39	6	7	 Heza Workof Art       	    	   7 	 1@/1  	 2/1   	 2/1   	 2/1   	 2/T    	2	 1:57.4 	 29.4	 J Harris      	20.00	 J Watt
892	39	6	5	 Whim Roader           	    	   5 	 7/7   	 5/11  	 3@/4  	 3/2   	 3/3    	3	 1:58.1 	 29.3	 B Forward     	37.20	 L Privett
893	39	6	9	 Sports Vision         	    	   9 	 6/5H  	 4/10  	 4/5   	 4/4   	 4/8T   	4	 1:59.2 	 30.3	 A Carroll     	7.60	 S Friend
894	39	6	8	 Casimir Obama         	    	   8 	 9/10  	 7/13  	 5/6H  	 5/5   	 5/10H  	5	 1:59.3 	 30.3	 L House       	68.30	 R Deacon
895	39	6	6	 Gotameeting           	    	   6 	 8/8H  	 6/12  	 6/8   	 6/7   	 6/12   	6	 2:00   	 30.3	 P Mackenzie   	39.35	 J Loosemore
896	39	6	4	 Sharks Play           	    	   4 	 5/4   	 8/23  	 7/12  	 7/13  	 7/30   	7	 2:03.3 	 33.2	 N Steward     	15.90	 P Shepherd
897	39	6	3	 Jet Er Done(L)        	    	   3 	 3/2   	 3/7   	 8/17  	 8/25  	 8CH/DIS	8	        	     	 T Moore       	35.90	 T Moore
898	39	6	1	 Master Smile          	    	   1 	 4/3   	 9/DIS 	 PULLED	UP     	 DNF    	\N	        	     	 Tra Henry     	2.85	 J Mcginnis
899	40	1	1	 Whosgoingtocatchus    	    	   1 	 1/1   	 1/H   	 1/1   	 1/1   	 1/1Q   	1	 1:59.1 	 30.1	 A Carroll     	1.00	 J Pond
900	40	1	2	 Tymal Wizard=         	    	   2 	 2/1   	 3/1H  	 3/1H  	 2/1   	 2/1Q   	2	 1:59.2 	 30.1	 P Mackenzie   	4.55	 Alan W Fair
901	40	1	6	 Howie=                	    	   6 	 3@/1H 	 2@/H  	 2@/1  	 3/1H  	 3/3H   	3	 1:59.4 	 30.3	 R Shepherd    	5.45	 C Yates
902	40	1	4	 Irish Thunder         	    	   4 	 4/3   	 4/2H  	 4/2H  	 4/2H  	 4/4    	4	 2:00   	 30.3	 L House       	14.00	 P Brickman
903	40	1	5	 Windsun Hugo          	    	   5 	 6/6   	 6@/5  	 5@/3  	 5/3   	 5/4Q   	5	 2:00   	 30.2	 R Holliday    	14.25	 K Di Cenzo
904	40	1	9	 William Star          	    	   9 	 5/5   	 5/4   	 6@/4  	 6/3H  	 6/4Q   	6	 2:00   	 30.1	 J Maguire     	16.20	 J Maguire
905	40	1	7	 Allies Gift           	    	   7 	 8/8   	 8@X/8 	 7@@/4H	 7/4   	 7/4H   	7	 2:00   	 30.1	 B Mcclure     	7.85	 L Ouellette
906	40	1	3	 Hot Stikynsweet       	    	   3 	 7/7   	 7/7H  	 8/6   	 8/5   	 8/5H   	8	 2:00.1 	 30  	 S Young       	36.25	 G Carachi
907	40	1	8	 All Out Henry         	    	   8 	 9/9   	 9/9   	 9@/6H 	 9/6   	 9/5T   	9	 2:00.2 	 30.1	 Do Brown      	20.60	 P Forgie
908	40	2	1	 Rain Cloud Hanover    	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1H  	 1/T    	1	 1:55.1 	 28.3	 P Mackenzie   	3.05	 C Nicol
909	40	2	2	 Tilikum               	    	   2 	 2/1H  	 2/1   	 3/1H  	 2/1H  	 2/T    	2	 1:55.2 	 28.3	 D St Pierre   	1.85	 T Staley
910	40	2	6	 Doo Wee Rusty(L)      	    	   6 	 7/8   	 3@/1H 	 2@/1  	 3/2   	 3/5Q   	3	 1:56.1 	 29.2	 J Harris      	4.15	 J Harris
911	40	2	3	 Miss Brandi K         	    	   3 	 3/3   	 4/3   	 5/3H  	 4/3   	 4/6Q   	4	 1:56.2 	 29.1	 R Shepherd    	8.40	 D Obrien
912	40	2	4	 Fast Flyin Mach       	    	   4 	 4/4H  	 6/5   	 6@/4H 	 6/4H  	 5/8    	5	 1:56.4 	 29.2	 D Fritz       	27.45	 D Fritz
913	40	2	7	 Island Blue           	    	   7 	 8/9H  	 5@/3H 	 4@/2  	 5/3H  	 6/8T   	6	 1:57   	 30  	 L House       	58.95	 S Mcniven
914	40	2	9	 Cards That Count      	    	   9 	 6/7   	 8@/6H 	 8@/7  	 8/8   	 7/14   	7	 1:58   	 30  	 R Holliday    	16.80	 P Core
915	40	2	5	 Emerald Rihanna       	    	   5 	 5/6   	 7/6   	 7/6H  	 7/7   	 8/16   	8	 1:58.2 	 30.3	 N Steward     	3.95	 C Schneider
916	40	2	8	 Winning Matrimony     	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
917	40	3	3	 Spy Flex=             	    	   3 	 1/1   	 1/1   	 1/H   	 1/1   	 1/NK   	1	 2:01.1 	 30.3	 G Rooney      	4.15	 F Drouillar
918	40	3	4	 Don Luigi             	    	   4 	 2/1   	 2/1   	 3/1H  	 2/1   	 2/NK   	2	 2:01.1 	 30.2	 J Harris      	6.70	 R Griffiths
919	40	3	1	 Toss It Back          	    	   1 	 4/4H  	 4/2H  	 4/3   	 4/3   	 3/1    	3	 2:01.2 	 30.1	 P Mackenzie   	4.65	 P Hunt
920	40	3	7	 Talbotcreek Suzie=    	    	   7 	 3/2   	 3@/1H 	 2@/H  	 3/1H  	 4/5    	4	 2:02.1 	 31.3	 G Mcknight    	5.85	 G Mcknight
921	40	3	6	 Nashville             	    	   6 	 5/6H  	 5@/3  	 5@/3H 	 5/3H  	 5/7Q   	5	 2:02.3 	 31.2	 R Holliday    	3.60	 N Elliott
922	40	3	8	 Dead Red Hitter=      	    	   8 	 7/9H  	 7/6   	 7/5H  	 6/5   	 6/7T   	6	 2:02.4 	 31.1	 A Carroll     	71.55	 M Giles
923	40	3	9	 Tiz                   	    	   9 	 6/8   	 6@/5  	 6@/4H 	 7/5H  	 7/8    	7	 2:02.4 	 31.2	 B Forward     	18.25	 J Pedden
924	40	3	5	 Holiday Bro           	    	   5I	 8/10H 	 8/8   	 8/6H  	 8/7   	 8/10T  	8	 2:03.2 	 31.3	 T Moore       	5.60	 I Gallant
925	40	3	10	 Leroys Dream=         	    	   2X	 9/12  	 9/9   	 9/8H  	 9/11  	 9/20   	9	 2:05.1 	 33  	 A Macdonald   	6.95	 A Macdonald
926	40	3	2	 La Bella Rosa         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
927	40	4	4	 Lady Caterina=        	    	   4 	 2/1   	 2/1H  	 2/1   	 3/1H  	 1/NS   	1	 2:00.1 	 31  	 N Steward     	6.45	 Alan D Fair
928	40	4	1	 Chewey=               	    	   1 	 1@/1  	 1/1H  	 1/1   	 1/H   	 2/NS   	2	 2:00.1 	 31.1	 B Mcclure     	1.30	 E Galinski
929	40	4	9	 Noble Power           	    	   9 	 3/2   	 3@/2  	 3@/1H 	 2/H   	 3/1    	3	 2:00.2 	 31.1	 P Mackenzie   	10.10	 S Kerwood
930	40	4	6	 Excellence            	    	   6 	 4/3   	 5/4   	 4/2   	 4/3   	 4/1T   	4	 2:00.3 	 31.1	 J Harris      	8.00	 I Downey
931	40	4	2	 Increditable(L)       	    	   2 	 5/4   	 4@/3  	 5@/3  	 5/3H  	 5/2T   	5	 2:00.4 	 31.1	 R Shepherd    	3.85	 J Dupont
932	40	4	7	 Incredable Frank(L)   	    	   7 	 8/7H  	 8/7H  	 8/7   	 7/6   	 6/3H   	6	 2:00.4 	 30.2	 A Carroll     	7.35	 R Moreau
933	40	4	10	 Mr Putter             	    	   5 	 7/6   	 7/6H  	 6/5   	 6/4H  	 7/4H   	7	 2:01   	 31  	 R Holliday    	18.85	 T Genoe
934	40	4	3	 Lima Playtime         	    	   3 	 6/5   	 6@/5  	 7/6   	 8/8   	 8/6T   	8	 2:01.3 	 31.2	 S Barrington  	24.40	 Ri Zeron
935	40	4	8	 Nomad=(L)             	    	   8 	 9/9   	 9@/8  	 9/8H  	 9/9   	 9/9    	9	 2:02   	 31.2	 Do Brown      	34.10	 L Jonasson
936	40	4	5	 Lady Dynamite=(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
937	45	1	6	 What A Promise        	    	   6 	 2/2   	 I1/3H 	 1/13  	 1/3   	 2P1/1H 	2	 2:14.2 	 35.3	 R Remillard   	4.45	 B Mcnaughto
938	45	1	5	 Heartland Spark       	    	   5 	 5@/11 	 I4/5  	 3/13Q 	 3/12  	 3P2/18H	3	 2:17.4 	 36.2	 M Fillion     	0.95	 M Fillion
939	45	1	4	 Trishas Fancy         	    	   4 	 3/6   	 IX6/15	 5/20  	 4/19  	 4P3/24 	4	 2:19   	 36.1	 K Rogers      	4.45	 K Rogers
940	45	1	2	 Margies Candy         	    	   2 	 4/10  	 I3/3T 	 4/18  	 5/DIS 	 5P4/DIS	5	        	     	 R Rey         	\N	 R Rey
941	45	1	7	 Dont Chud Me          	    	   7 	 6/12  	 IX5/8H	 6/25  	 6/DIS 	 6P5/DIS	6	        	     	 C Manning     	9.95	 C Manning
942	45	1	3	 Luvn The Life         	    	   3 	 1/2   	 X2@/3H	 2@/13 	 2/3   	 1P6/1H 	1	 2:14.1 	 32.4	 D Rey         	0.95	 D Rey
943	45	1	1	 Cordees Whitesocks    	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
944	45	2	3	 Gold Star Sonata      	    	   3 	 1/1H  	 1/Q   	 2/H   	 2/2   	 1/NS   	1	 2:04.1 	 32  	 D Howlett     	3.45	 T Williams
945	45	2	4	 Wild Chic             	    	   4 	 2/1H  	 2@/Q  	 1@/H  	 1/2   	 2/NS   	2	 2:04.1 	 32  	 R Remillard   	1.20	 R Remillard
946	45	2	2	 Smoky Moon            	    	   2 	 4/5   	 3@/4H 	 3/6   	 3/13  	 3/13   	3	 2:06.4 	 33.2	 M Fillion     	1.40	 K Hildebran
947	45	2	5	 Gottaluckydeal+       	    	   5 	 X6/14 	 6/9H  	 6@/11 	 4/18  	 4/21   	4	 2:08.2 	 34  	 C Manning     	\N	 C Manning
948	45	2	1	 Come On Kathryn       	    	   1 	 3/3   	 4/4T  	 4/7H  	 5/19  	 5/25   	5	 2:09.1 	 35.3	 T Grundy      	5.65	 C Manning
949	45	2	6	 Freedom Forever       	    	   6 	 5/7   	 5/7   	 5/10  	 6/37  	 6/39   	6	 2:12   	 37.4	 M Rey         	3.45	 M Rey Clark
950	45	3	1	 Good Chemistry        	    	   1 	 2/1H  	 2/2H  	 2/2   	 3/1H  	 1/1    	1	 2:09.2 	 32  	 D Howlett     	2.50	 T Williams
951	45	3	4	 Diggin A Trench       	    	   4 	 3/3   	 3/4H  	 3@/3  	 1/H   	 2/1    	2	 2:09.3 	 32  	 M Rey         	3.10	 R Rey
952	45	3	5	 Home Matters          	    	   5 	 1/1H  	 1/2H  	 1/2   	 2/H   	 3/3    	3	 2:10   	 33  	 D Rey         	3.10	 R Rey
953	45	3	3	 Redonkulous           	    	   3 	 4/4H  	 4/6H  	 4/5   	 4/11  	 4/12   	4	 2:11.4 	 33.4	 R Rey         	0.45	 R Rey
954	45	3	2	 Mixed Blessings+      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
955	46	1	5	 Eastcoast Lizzy       	    	   5 	 4/5   	 4/5Q  	 4/4   	 3/H   	 1/Q    	1	 2:04.1 	 28.4	 S Macdonald   	2.45	 S Macdonald
956	46	1	3	 Rez Rampage           	    	   3 	 2/1H  	 2/1H  	 2@/1  	 2/Q   	 2/Q    	2	 2:04.1 	 29.2	 A Macquarrie  	0.60	 L Macisaac
957	46	1	2	 Our Ryall Flush       	    	   2 	 1/1H  	 1/1H  	 1/1   	 1/Q   	 3/1Q   	3	 2:04.2 	 29.4	 K Bailey      	10.60	 K Bailey
958	46	1	4	 Cheyenne Nixon        	    	   4 	 3/3Q  	 3/3Q  	 3@/2  	 4/1T  	 4/2H   	4	 2:04.3 	 29.3	 T Gillis      	10.60	 T Gillis
959	46	1	1	 Tymal Torrance        	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
960	46	2	4	 Woodmere Terror       	    	   4 	 3@/2  	 3/2H  	 4/3   	 2/Q   	 1/NS   	1	 2:04.1 	 31  	 A Maclean     	4.85	 A Maclean
961	46	2	2	 B Catastic            	    	   2 	 7/6   	 7/8H  	 6@@/3T	 3/T   	 2/NS   	2	 2:04.1 	 30.4	 R Gillis      	1.55	 T Maclean
962	46	2	1	 Camco Tyler           	    	   1 	 4/3   	 5/4Q  	 5@/3Q 	 5/1T  	 3/1T   	3	 2:04.3 	 31.2	 C Fraser      	6.15	 F Fraser
963	46	2	5	 Warrawee Raven        	    	   5 	 5@/3Q 	 2/1H  	 2/1H  	 4/1H  	 4/2H   	4	 2:04.3 	 31.4	 R Campbell    	1.90	 J Copley
964	46	2	6	 A Bs Future           	    	   6 	 1/1H  	 1/1H  	 1/1H  	 1/Q   	 5/3T   	5	 2:05   	 32.2	 A Mac Donald  	5.40	 B Macdonald
965	46	2	3	 Aint Shesoshy         	    	   3 	 2/1H  	 4/3Q  	 3@/1H 	 6/6   	 6/10T  	6	 2:06.2 	 33.3	 K Passerini   	15.10	 K Passerini
966	46	2	8	 J Gs Waylon           	    	   8 	 6/4T  	 6/7   	 7/7   	 7/10  	 7/16T  	7	 2:07.3 	 33.3	 J Kennedy     	8.20	 T Maclean
967	46	2	7	 Redwood Origional     	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
968	46	3	5	 Liams Dynesty         	    	   5 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 1/1    	1	 2:02   	 30.4	 C Kelly       	3.85	 C Ryan
969	46	3	3	 Im Indigo             	    	   3 	 2/1H  	 3/1T  	 3/1T  	 2/2   	 2/1    	2	 2:02.1 	 30.3	 J Poirier     	30.80	 J Poirier
970	46	3	1	 Business Time         	    	   1 	 3/2H  	 4/3Q  	 4/3   	 3/4   	 3/3    	3	 2:02.3 	 30.4	 J Macdonald   	6.95	 W Macdonald
971	46	3	6	 Scootin Mcardle       	    	   6 	 4@/3  	 2@/1H 	 2@/1H 	 4/5   	 4/4    	4	 2:02.4 	 31.2	 K Passerini   	14.90	 K Passerini
972	46	3	8	 Valid Appeal          	    	   8 	 8/7H  	 6@/5  	 6@/4Q 	 5/5H  	 5/5T   	5	 2:03.1 	 31.1	 S Miller      	3.70	 K Macdonald
973	46	3	7	 Take The Chance       	    	   7 	 6/5H  	 7/5H  	 7/4H  	 6/6H  	 6/6    	6	 2:03.1 	 31.1	 R Campbell    	4.75	 E Campbell
974	46	3	4	 Dans Ideal            	    	   4 	 5/4H  	 5@/3Q 	 5@/3Q 	 7/7H  	 7/6H   	7	 2:03.1 	 31.2	 A Macquarrie  	0.80	 A Beaton
975	46	3	2	 Miss All Fun          	    	   2 	 7/6H  	 8/6T  	 8/5H  	 8/8Q  	 8/7T   	8	 2:03.3 	 31.2	 R Gillis      	6.95	 L Beaton
976	46	4	5	 Likeathunderbolt      	    	   5 	 6/4H  	 6/4Q  	 3@/1Q 	 2/Q   	 1/Q    	1	 2:01.3 	 30  	 C Kelly       	3.15	 J Mac Donal
977	46	4	3	 Iona Katie            	    	   3 	 4/2T  	 4/2T  	 1@/T  	 1/Q   	 2/Q    	2	 2:01.3 	 30.1	 J Poirier     	3.65	 J Poirier
978	46	4	4	 Allamerican Baller    	    	   4 	 5@/3H 	 2@/1Q 	 4/2   	 3/Q   	 3/1H   	3	 2:01.4 	 30  	 R Campbell    	3.65	 E Beaton
979	46	4	1	 Rachel Alesandra      	    	   1 	 3/1H  	 5/3Q  	 5/3T  	 4/6   	 4/6H   	4	 2:02.4 	 30.3	 K Bailey      	4.30	 K Bailey
980	46	4	6	 Overcard              	    	   6 	 2@/1  	 1/1Q  	 2/T   	 5/9   	 5/10Q  	5	 2:03.3 	 32  	 K Passerini   	2.65	 J Poirier
981	46	4	2	 Spectacular Future    	    	   2 	 1/1   	 3/1T  	 6/4T  	 6/22  	 6/24H  	6	 2:06.2 	 34  	 L Hanscombe   	3.15	 G Mac Lean
982	46	5	3	 Oppies Lifes Line     	    	   3 	 1/1H  	 1/1   	 1/H   	 1/1   	 1/HD   	1	 2:02.2 	 30.4	 J Poirier     	2.50	 J Poirier
983	46	5	2	 Eastcoast Cruiser     	    	   2 	 3/2H  	 2@/1  	 2@/H  	 2/1   	 2/HD   	2	 2:02.2 	 30.4	 R Gillis      	1.90	 T Sutherlan
984	46	5	1	 Orillia Santina       	    	   1 	 4/3H  	 5/3H  	 4/2   	 3/2   	 3/2    	3	 2:02.4 	 30.4	 K Passerini   	10.65	 K Passerini
985	46	5	4	 Remember The Night    	    	   4 	 2/1H  	 3/1T  	 3@/2  	 4/3H  	 4/4Q   	4	 2:03.1 	 31.1	 A Macquarrie  	3.90	 A Macquarri
986	46	5	5	 Ramadawn              	    	   5 	 5@/4  	 4@/2H 	 6@/3  	 5/3H  	 5/4Q   	5	 2:03.1 	 31  	 C Fraser      	4.40	 F Fraser
987	46	5	7	 Grayland Astrid       	    	   7 	 6/4H  	 7/5Q  	 7/3H  	 6/4   	 6/4H   	6	 2:03.1 	 31  	 J Macdonald   	6.75	 S Harper Jr
988	46	5	6	 Locky                 	    	   6 	 7/5H  	 6@/4  	 5@@/2T	 7/10  	 7/11   	7	 2:04.3 	 32.2	 J Kennedy     	6.75	 L Macisaac
989	46	6	1	 Western Bandit        	    	   1 	 1/1H  	 1/1H  	 1/4   	 1/8   	 1/9    	1	 1:59.1 	 29.2	 R Campbell    	1.70	 R Mullins
990	46	6	5	 D E Harkness          	    	   5 	 2/1H  	 3/1H  	 2/4   	 2/8   	 2/9    	2	 2:01   	 30.2	 A Mac Neil    	6.85	 A Mac Neil
991	46	6	6	 You Gotta See This    	    	   6 	 5/6H  	 4@/3Q 	 4@@/4Q	 3/8Q  	 3/9    	3	 2:01   	 30.2	 C Kelly       	4.15	 S Harper Jr
992	46	6	2	 Nephin                	    	   2 	 X4@/6 	 2@/1H 	 3@/4Q 	 4/10  	 4/10   	4	 2:01.1 	 30.3	 J Macdonald   	3.45	 W Macdonald
993	46	6	4	 Twisted Frisco        	    	   4 	 3/5   	 5/4Q  	 5/5H  	 5/10Q 	 5/11   	5	 2:01.2 	 30.3	 S Macdonald   	2.80	 S Macdonald
994	46	6	3	 Benny Rabbit          	    	   3 	 6/7H  	 6/5   	 6@/6H 	 6/15  	 6/16T  	6	 2:02.3 	 31.3	 R Gillis      	4.15	 E Campbell
995	47	1	4	 Surrealist            	    	   4 	 4/4H  	 4@/4  	 1/H   	 1/8   	 1/8H   	1	 1:55.3 	 29  	 C Kelly       	0.95	 R Mullins
996	47	1	3	 Schooner              	    	   3 	 1/1H  	 1/1T  	 2/H   	 2/8   	 2/8H   	2	 1:57.1 	 30.3	 A Macquarrie  	2.20	 A Beaton
997	47	1	5	 Rambling Gambler      	    	   5 	 5/5H  	 5/6   	 4/3   	 3/8H  	 3/9    	3	 1:57.2 	 30.1	 R Gillis      	4.20	 D Beaton
998	47	1	1	 Grins Little Flirt    	    	   1 	 2/1H  	 2/1T  	 3/2H  	 4/9   	 4/9H   	4	 1:57.2 	 30.2	 R Campbell    	2.30	 R Mac Leod
999	47	1	2	 Kennairn Fame         	    	   2 	 3/3   	 3/4   	 5/10  	 5/15  	 5/16H  	5	 1:58.4 	 30.1	 J Poirier     	17.30	 D Mac Lella
1000	47	2	4	 Danny William         	    	   4 	 1/1H  	 1/1H  	 1/1H  	 1/1   	 1/H    	1	 1:59.4 	 28.4	 A Mac Neil    	1.10	 A Mac Neil
1001	47	2	3	 Tiger Town            	    	   3 	 4/4   	 4@/3T 	 4@@/2 	 2/1   	 2/H    	2	 1:59.4 	 28.2	 A Macdonell   	3.85	 M Maceachen
1002	47	2	1	 My Tie Wind           	    	   1 	 2/1H  	 2/1H  	 3/1H  	 3/4   	 3/4T   	3	 2:00.4 	 29.3	 J Kennedy     	7.90	 D Kennedy
1003	47	2	2	 Macnamarra            	    	   2 	 3/2H  	 3@/2  	 2@/1H 	 4/5   	 4/5    	4	 2:00.4 	 29.3	 J Mac Dougall 	8.15	 R Smith
1004	47	2	5	 Boswell Hanover       	    	   5 	 5/5H  	 5/5   	 5/3H  	 5/6   	 5/5T   	5	 2:01   	 29.2	 C Kelly       	3.45	 J Mac Donal
1005	47	2	6	 Imbadimnationwide     	    	   6 	 6/6H  	 6@/6  	 6/4T  	 6/7   	 6/8    	6	 2:01.2 	 29.2	 R Campbell    	4.15	 R Copley
1006	48	1	2	 Great Luck            	    	   2 	 2/2H  	 2/2T  	 2/2H  	 2/1   	 1/Q    	1	 2:06.1 	 30.3	 R Gillis      	\N	 J Murphy
1007	48	1	1	 P H Showboat          	    	   1 	 1/2H  	 1/2T  	 1/2H  	 1/1   	 2/Q    	2	 2:06.1 	 31  	 A Macdonell   	\N	 A Macdonell
1008	49	1	1	 Bay Win               	    	   1 	 1/NR  	 1/NR  	 1/NR  	 1/NR  	 1/NR   	1	 2:07.3 	 31.1	 R Gillis      	\N	 D Beaton
1009	52	1	1	 Jolts Prayer          	    	   1 	 3/2Q  	 4/3T  	 5@@/2Q	 2/H   	 1/H    	1	 1:54.3 	 29.3	 J Jamieson    	17.30	 D Lamy
1010	52	1	2	 Tarahumara            	    	   2 	 2@/1Q 	 1/H   	 1/H   	 1/H   	 2/H    	2	 1:54.3 	 30  	 S Filion      	0.80	 R Fellows
1011	52	1	3	 Sophie Blu            	    	   3 	 5/5   	 6/6Q  	 6/3T  	 6/2H  	 3/T    	3	 1:54.4 	 29.2	 Ph Hudon      	39.10	 G Laurignan
1012	52	1	4	 Big Tsunami           	    	   4 	 6/7Q  	 5@/5Q 	 3@@/T 	 3/T   	 4/2    	4	 1:55   	 30.1	 J Moiseyev    	19.25	 R Montgomer
1013	52	1	9	 Lissoy                	    	   9 	 9/14H 	 9/12T 	 9/5H  	 7/3Q  	 5/2    	5	 1:55   	 29.2	 D Mcnair      	49.40	 R Fellows
1014	52	1	7	 Hex                   	    	   7 	 4@/2T 	 2@/H  	 2/H   	 4/1Q  	 6/2H   	6	 1:55   	 30.2	 Ja Macdonald  	2.75	 D Nixon
1015	52	1	8	 Business As Usual(L)  	    	   8 	 8/12  	 8/9T  	 8@@/5H	 8/3H  	 7/4Q   	7	 1:55.2 	 29.4	 M Baillargeon 	13.15	 M Rogers
1016	52	1	6	 Woodmere Articblue    	    	   6 	 1/1Q  	 3/1T  	 4/1H  	 5/2Q  	 8/7H   	8	 1:56   	 31.1	 Trev Henry    	6.75	 J Belliveau
1017	52	1	5	 Squirt                	    	   5 	 7/9Q  	 7@/7H 	 7@/4H 	 9/4H  	 9/8Q   	9	 1:56.1 	 30.4	 P Macdonell   	24.55	 H Dinning
1018	52	2	7	 On A Sunny Day        	    	   7 	 1@/H  	 1/1H  	 1/Q   	 1/1   	 1/1H   	1	 1:57.2 	 29.1	 S Filion      	0.95	 L Blais
1019	52	2	5	 Literally             	    	   5 	 5/10Q 	 5@/8Q 	 2@/Q  	 2/1   	 2/1H   	2	 1:57.3 	 29.2	 R Jones       	1.55	 R Jones
1020	52	2	6	 Tropicana As          	    	   6 	 2/H   	 2/1H  	 3/2   	 3/3Q  	 3/3Q   	3	 1:58   	 29.2	 J Jamieson    	9.10	 A Lorentzon
1021	52	2	1	 Holiday Promise       	    	   1 	 7/13Q 	 6@/10H	 4@/3H 	 4/5T  	 4/4T   	4	 1:58.2 	 29.3	 J Moiseyev    	19.75	 P Reid
1022	52	2	4	 Magic Maddy           	    	   4 	 4/8Q  	 4/6T  	 6@/6H 	 5/9T  	 5/6Q   	5	 1:58.3 	 29.1	 Ja Macdonald  	34.35	 M Steacy
1023	52	2	2	 Janderson             	    	   2 	 X6X/10	 7/25T 	 7/21T 	 7/22H 	 6/19   	6	 2:01.1 	 28.3	 P Macdonell   	6.60	 M Keeling
1024	52	2	3	 Paradise Image=       	    	   3 	 3/3H  	 3/4H  	 5/6   	 6/12H 	 7/20   	7	 2:01.2 	 32  	 M Johnson     	133.45	 M Johnson
1025	52	3	2	 Winter Sweet Frost    	    	   2 	 2/1T  	 1/3T  	 1/2   	 1/1H  	 1/2H   	1	 1:58.2 	 29.2	 D Mcnair      	0.85	 P Reid
1026	52	3	1	 Gravitator            	    	   1 	 3/4   	 2/3T  	 2/2   	 2/1H  	 2/2H   	2	 1:58.4 	 29.2	 S Filion      	3.45	 L Blais
1027	52	3	5	 Expose Yourself       	    	   5 	 4/5T  	 4/6Q  	 4/4   	 3/3Q  	 3/3Q   	3	 1:59   	 29.1	 W Henry       	68.55	 W Henry
1028	52	3	6	 Stormont Royalty      	    	   6 	 5/7Q  	 5/9H  	 3@/3T 	 4/3H  	 4/3T   	4	 1:59.1 	 29.2	 Ri Zeron      	5.95	 K Benn
1029	52	3	4	 Royal Witch           	    	   4X	 X7/35T	 6/33T 	 5/22T 	 5/20H 	 5/20   	5	 2:02.2 	 28.4	 M Baillargeon 	4.05	 B Baillarge
1030	52	3	3	 Mrstery Bear=         	    	   3X	 X6/26H	 7X/36 	 6/DIS 	 6X/DIS	 6/DIS  	6	        	     	 J Jamieson    	17.40	 D Menary
1031	52	3	7	 Mass Psychology       	    	   7 	 1/1T  	 X3X/5H	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 C Christoforou	27.40	 J Macmillan
1032	52	4	8	 Talbot Chanel         	    	   8 	 8/14Q 	 7@/12Q	 5/6   	 5/6H  	 1/NK   	1	 1:57.1 	 27.3	 S Filion      	5.25	 L Blais
1033	52	4	3	 Maching Me Zilly      	    	   3 	 4/5H  	 4/6   	 4@/5  	 3/4Q  	 2/NK   	2	 1:57.1 	 27.4	 Ph Hudon      	13.80	 M Brethour
1034	52	4	7	 Amulet Seelster       	    	   7 	 1@/T  	 1/2   	 1/1T  	 1/2Q  	 3/H    	3	 1:57.1 	 28.4	 D Mcnair      	1.20	 R Mcnair
1035	52	4	5	 Fashion Writer        	    	   5 	 2/T   	 2/2   	 2/1T  	 2/2Q  	 4/1H   	4	 1:57.2 	 28.3	 J Jamieson    	10.25	 S Gillard
1036	52	4	4	 Lotus Seelster        	    	   4 	 3/2T  	 3/4   	 3@/3T 	 4/5   	 5/1T   	5	 1:57.3 	 28.2	 Trev Henry    	3.60	 S Mceneny
1037	52	4	1	 Windsong Natalie      	    	   1 	 5/7   	 5/8   	 6/7Q  	 6/7H  	 6/3    	6	 1:57.4 	 28  	 Ra Waples     	49.55	 W Robinson
1038	52	4	6	 All Is Well           	    	   6 	 7/12  	 8/12H 	 7@/8Q 	 7/8H  	 7/3H   	7	 1:57.4 	 27.4	 P Macdonell   	15.15	 R Mcintosh
1039	52	4	9	 Miss Mittzie Bee      	    	   9 	 9/16H 	 9@/15H	 9/11T 	 9/11T 	 8/4T   	8	 1:58.1 	 27.2	 C Christoforou	84.05	 S Arsenault
1040	52	4	2	 Show Me Some Magic    	    	   2 	 6/9Q  	 6/10H 	 8/9Q  	 8/10H 	 9/5    	9	 1:58.1 	 28  	 Ja Macdonald  	6.45	 T Gillespie
1041	52	5	1	 Secretcode Hanover=(L)	)   	   1 	 6/7T  	 5@/6T 	 4@/2  	 2/H   	 1/1    	1	 1:55.4 	 28.3	 M Vanderkemp  	54.45	 M Vanderkem
1042	52	5	6	 Pennies From Above    	    	   5 	 7/9T  	 7@/8T 	 5@/3H 	 3/2Q  	 2/1    	2	 1:56   	 28.3	 R Jones       	2.05	 R Jones
1043	52	5	4	 Mission Man           	    	   4 	 5/6   	 3@/4T 	 2@/NK 	 1/H   	 3/3    	3	 1:56.2 	 29.3	 Ph Hudon      	9.50	 R Bax
1044	52	5	10	 Windsong Luxury       	    	   9 	 1@/Q  	 2/3   	 3/1T  	 5/2H  	 4/4Q   	4	 1:56.3 	 29.2	 J Jamieson    	13.95	 C Auciello
1045	52	5	3	 Bow Ties N Bourbon=   	    	   3 	 3/2   	 1/3   	 1/NK  	 4/2Q  	 5/7    	5	 1:57.1 	 30.2	 M Saftic      	11.75	 M Barrieau
1046	52	5	9	 Hills Angel           	    	   8 	 2/Q   	 4/5   	 6/3T  	 6/4T  	 6/8H   	6	 1:57.2 	 29.4	 P Macdonell   	5.30	 J Bax
1047	52	5	2	 Franniegetyourgun=(L) 	    	   2 	 4/4   	 6/7Q  	 7/6T  	 7/7H  	 7/12T  	7	 1:58.2 	 30.1	 C Christoforou	73.40	 H Holland
1048	52	5	7	 Frankly Speaking(L)   	    	   6 	 8/11T 	 8/10T 	 8/8H  	 8/10H 	 8/15   	8	 1:58.4 	 30.2	 S Filion      	29.55	 R Moreau
1049	52	5	8	 Unicum Bi=            	    	   7X	 X9/DIS	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 Ja Macdonald  	1.40	 P Henriksen
1050	52	5	5	 Asterix=              	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1051	52	6	6	 Rose Run Speedster=   	    	   5 	 3/4   	 1/1T  	 1/2   	 1/3Q  	 1/H    	1	 1:58.4 	 28.3	 Ja Macdonald  	0.55	 A Macdonald
1052	52	6	2	 Northern Major=       	    	   2 	 2/2Q  	 3/3T  	 3/3T  	 3/4   	 2/H    	2	 1:58.4 	 27.4	 J Moiseyev    	11.85	 R Fellows
1053	52	6	1	 Jake=                 	    	   1 	 1/2Q  	 2/1T  	 2/2   	 2/3Q  	 3/2T   	3	 1:59.2 	 28.4	 S Filion      	1.95	 L Blais
1054	52	6	8	 Soho Hanover=         	    	   7 	 5/8T  	 5/8Q  	 5/8   	 4/10Q 	 4/8T   	4	 2:00.3 	 28.4	 D Mcnair      	10.30	 R Mcnair
1055	52	6	5	 Dressed To Impress    	    	   4 	 4/6Q  	 4/6   	 4X/6Q 	 X5/13T	 5/11H  	5	 2:01   	 29.3	 R Jones       	28.10	 R Jones
1056	52	6	7	 Magic Night           	    	   6X	 X6/28Q	 6/20H 	 6/13T 	 6/18  	 6/19   	6	 2:02.3 	 29.3	 W Henry       	80.10	 W Henry
1057	52	6	3	 Blurred               	    	   3X	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 P Macdonell   	43.15	 J Bax
1058	52	6	4	 Lucys Man             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1059	53	1	3	 The Wayfaring Man(L)  	    	   3 	 1@/1H 	 1/2   	 1/1H  	 1/2   	 1/1T   	1	 1:51.2 	 28.1	 M Saftic      	0.20	 N Comegna
1060	53	1	7	 They Call Me Gordy    	    	   7 	 2/1H  	 2/2   	 2/1H  	 2/2   	 2/1T   	2	 1:51.4 	 28.2	 D Mcnair      	56.15	 J Wilson
1061	53	1	2	 Blissfull Years       	    	   2 	 4/5H  	 4/6Q  	 5/5T  	 3/6   	 3/2T   	3	 1:52   	 27.3	 S Filion      	9.95	 R Adams
1062	53	1	6	 Waltzking Hanover(L)  	    	   6 	 5/7Q  	 6/8H  	 7/7H  	 6/8   	 4/3    	4	 1:52   	 27.2	 J Jamieson    	16.90	 C Mcguire
1063	53	1	4	 Curator               	    	   4 	 7/11  	 7@/9Q 	 6@/6  	 5/6T  	 5/5    	5	 1:52.2 	 28  	 Trev Henry    	7.25	 J Copley
1064	53	1	8	 Sir Machalot          	    	   8 	 8/14Q 	 8@/11T	 8@/8Q 	 7/9   	 6/6T   	6	 1:52.4 	 28  	 C Christoforou	31.90	 L Macarthur
1065	53	1	1	 Statesman N(L)        	    	   1 	 3/3H  	 3/4Q  	 3/3T  	 4/6   	 7/7    	7	 1:52.4 	 28.4	 Do Brown      	32.05	 Do Brown
1066	53	1	9	 Tomitta Bayama        	    	   9 	 9/16H 	 9/13  	 9/9T  	 10/10T	 8/9T   	8	 1:53.2 	 28.1	 Ja Macdonald  	75.25	 T Hamm
1067	53	1	10	 Jimmys Secret(L)      	    	   10	 10/18 	 10@/14	 10@/10	 9/10H 	 9/10Q  	9	 1:53.2 	 28.1	 Ph Hudon      	98.45	 W Preszcato
1068	53	1	5	 Good Friday Three     	    	   5 	 6/9   	 5@/6T 	 4@/4H 	 8/9T  	 10/15  	10	 1:54.2 	 30.2	 Ra Waples     	29.90	 W Robinson
1069	53	2	5	 Magic Presto=         	    	   5 	 4/6T  	 3/3H  	 2/1T  	 2/1T  	 1/1    	1	 1:57.2 	 27.3	 Trev Henry    	5.35	 R Norman
1070	53	2	3	 Sweet Of My Heart     	    	   3 	 1/4T  	 1/1T  	 1/1T  	 1/1T  	 2BE/1  	2	 1:57.3 	 28.1	 C Christoforou	0.75	 P Reid
1071	53	2	6	 Lady Justice          	    	   6 	 2@/4T 	 2/1T  	 3/3T  	 3/5H  	 3/8Q   	3	 1:59   	 28.4	 W Henry       	10.55	 W Henry
1072	53	2	7	 Majestic Kat          	    	   7 	 5/9H  	 4/5H  	 4@/4H 	 4/5T  	 4/9Q   	4	 1:59.1 	 29  	 Ja Macdonald  	30.50	 M Steacy
1073	53	2	4	 Hudsons Ya Ya         	    	   4 	 3X/5Q 	 5/9Q  	 X5/13H	 5/24  	 5/31   	5	 2:03.3 	 31.3	 S Byron       	68.30	 J Bax
1074	53	2	1	 Dixies Dream Girl     	    	   1 	 X6/13Q	 6/13  	 X6/19Q	 6/DIS 	 6/DIS  	6	        	     	 Ri Zeron      	2.85	 T Osullivan
1075	53	2	2	 Ladydabra             	    	   2X	 X7/DIS	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Jamieson    	10.35	 H Okusko Jr
1076	53	3	1	 Big Place             	    	   1 	 4/3Q  	 1@/1T 	 1/2H  	 1/5T  	 1/3H   	1	 1:53.2 	 28.3	 D Mcnair      	2.40	 R Mcnair
1077	53	3	7	 Bugger Jerry          	    	   7 	 1/1H  	 3/3H  	 4/4Q  	 3/6Q  	 2/3H   	2	 1:54   	 28.2	 Ja Macdonald  	4.45	 C Auciello
1078	53	3	3	 Carolina Hurricane    	    	   3 	 5/5H  	 4@/4  	 3@/4  	 4/6H  	 3/4    	3	 1:54.1 	 28.3	 Ri Zeron      	0.90	 R Adams
1079	53	3	6	 Four Card Major       	    	   6 	 8/11H 	 8/12  	 7@@/7 	 5/7T  	 4/6Q   	4	 1:54.3 	 28.2	 Ra Waples     	15.60	 Corey Johns
1080	53	3	8	 The Loan Ranger       	    	   8 	 3@/2H 	 2/1T  	 2/2H  	 2/5T  	 5/6T   	5	 1:54.4 	 29.3	 Trev Henry    	38.15	 P Core
1081	53	3	4	 Century Churchill     	    	   4 	 7/9T  	 6@/8H 	 5@/5T 	 7/9Q  	 6/9T   	6	 1:55.2 	 29.2	 J Hudon Jr    	26.25	 J Hudon Jr
1082	53	3	5	 Give Em Back          	    	   5 	 2/1H  	 5/5T  	 6/6   	 6/9   	 7/10Q  	7	 1:55.2 	 29.2	 Ph Hudon      	12.00	 B Sinclair
1083	53	3	2	 Crusing Charlie       	    	   2 	 6/7T  	 7/9   	 8/8H  	 8/12T 	 8/15   	8	 1:56.2 	 30  	 C Christoforou	67.05	 G Kingshott
1084	53	4	1	 Tom Hill              	    	   1 	 5/8Q  	 5@/7Q 	 4@/4T 	 2/1Q  	 1/3    	1	 1:51.2 	 26.2	 Ra Waples     	3.25	 T Alagna
1085	53	4	5	 Ok Iceman(L)          	    	   5 	 2/1T  	 2/2   	 3/1T  	 4/1H  	 2/3    	2	 1:52   	 27.3	 J Jamieson    	3.80	 M Steacy
1086	53	4	9	 Daylight Rush         	    	   8 	 1/1T  	 1/2   	 1/1   	 1/1Q  	 3/3T   	3	 1:52.1 	 28.1	 D Mcnair      	7.80	 B Macintosh
1087	53	4	2	 Some Gold             	    	   2 	 4/6   	 4@/5Q 	 2@/1  	 3/1Q  	 4/4Q   	4	 1:52.1 	 28  	 C Christoforou	1.00	 Dr I Moore
1088	53	4	7	 Tango Star            	    	   7 	 7/13H 	 7/10Q 	 8/8T  	 7/6T  	 5/4H   	5	 1:52.1 	 26.2	 M Baillargeon 	17.95	 M Lachance
1089	53	4	4	 King Of Sports        	    	   4 	 3/3H  	 3/4   	 5/5   	 5/5Q  	 6/6Q   	6	 1:52.3 	 27.3	 Ph Hudon      	65.35	 B Macdonald
1090	53	4	6	 Rock Power            	    	   6 	 6/10H 	 6/8Q  	 6/7   	 6/6   	 7/8T   	7	 1:53.1 	 27.4	 S Filion      	14.70	 T Osullivan
1091	53	4	10	 Micro Force(L)        	    	   9 	 8/16  	 8@/12Q	 7@/8Q 	 8/10  	 8/14T  	8	 1:54.2 	 28.4	 Trev Henry    	38.80	 M Weller
1092	53	4	3	 Rolling Rock          	    	   X3	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 M Saftic      	\N	 J Obrien
1093	53	4	8	 Blaise Mm Hanover     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1094	54	1	8	 Traceur Hanover       	    	   8 	 1/1T  	 2/1T  	 2/1T  	 3/2Q  	 1/NS   	1	 1:55.2 	 27.2	 S Filion      	\N	 R Moreau
1095	54	1	4	 Beast Mode            	    	   4 	 2/1T  	 1/1T  	 1/1T  	 1/1   	 2/NS   	2	 1:55.2 	 27.4	 Trev Henry    	\N	 C Nicol
1096	54	1	7	 Ideal Jet             	    	   7 	 3/4   	 3/3H  	 3/3H  	 2/1   	 3/H    	3	 1:55.2 	 27.1	 J Jamieson    	\N	 C Barss
1097	54	1	5	 Bringhome Theblue     	    	   5 	 4/6T  	 4/5H  	 4@/5Q 	 4/6T  	 4/6Q   	4	 1:56.3 	 28  	 C Auciello    	\N	 C Auciello
1098	54	1	2	 Homer Run             	    	   2 	 6/13H 	 6/12H 	 6@/11 	 6/13T 	 5/17   	5	 1:58.4 	 29  	 Dr J Flanigan 	\N	 Dr J Flanig
1099	54	1	1	 Passion Quizrace      	    	   1 	 5/10  	 5/8   	 5/9H  	 5/12H 	 6/19   	6	 1:59.1 	 29.4	 Ph Hudon      	\N	 K Gangell
1100	54	1	3	 Real Buzz             	    	   3 	 7/18  	 7/15H 	 7/12Q 	 7/16T 	 7/22   	7	 1:59.4 	 29.4	 Do Brown      	\N	 L Blais
1101	54	1	6	 Nicholas Ryan         	    	   6 	 8/21H 	 8/17  	 8/14H 	 8/20H 	 8/28   	8	 2:01   	 30.3	 J Drury       	\N	 C Auciello
1102	54	2	8	 Mister Herbie         	    	   8 	 2/1H  	 1/3   	 1/8H  	 1/8T  	 1/4Q   	1	 1:56.1 	 29.1	 J Jamieson    	\N	 J Gillis
1103	54	2	2	 Marquis Volo=         	    	   2 	 5/9H  	 5/11T 	 4@/11H	 2/8T  	 2/4Q   	2	 1:57   	 27.4	 P Henriksen   	\N	 P Henriksen
1104	54	2	3	 Way Outta Here=       	    	   3 	 6/11T 	 6/14T 	 5@/13Q	 4/12H 	 3/9Q   	3	 1:58   	 28.2	 M Vanderkemp  	\N	 M Vanderkem
1105	54	2	6	 Moonbeam Hall         	    	   6 	 4/7   	 4/9H  	 6/13H 	 6/15H 	 4/12   	4	 1:58.3 	 29  	 M Baillargeon 	\N	 B Baillarge
1106	54	2	7	 Little Stuie          	    	   7 	 1/1H  	 2/3   	 2/8H  	 3/11H 	 5/14Q  	5	 1:59   	 30.2	 Ph Hudon      	\N	 W Dunn
1107	54	2	1	 Joyous Hall           	    	   1 	 3/3T  	 3/5T  	 3/10Q 	 5/14  	 6/19   	6	 2:00   	 31  	 M Saftic      	\N	 B Bahr
1108	54	2	5	 Danielle Hall         	    	   5X	 X8/DIS	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 C Jamieson    	\N	 C Jamieson
1109	54	2	4	 April Breeze On By=   	    	   4X	 X7/DIS	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 J Renaud      	\N	 J Walker
1110	54	3	4	 Happy Hannah          	    	   4 	 2/H   	 1/4   	 1/3H  	 1/3H  	 1/8T   	1	 1:56.2 	 28.3	 Ra Waples     	\N	 M Steacy
1111	54	3	6	 Manhattan Play        	    	   6 	 8/13H 	 8/19  	 7/14T 	 7/12  	 2/8T   	2	 1:58.1 	 27.2	 M Saftic      	\N	 N Comegna
1112	54	3	5	 Dance Craze           	    	   5 	 5@/6H 	 5/10T 	 5/10  	 5/10Q 	 3/9T   	3	 1:58.2 	 28.3	 S Filion      	\N	 T Osullivan
1113	54	3	2	 Wicked Hill           	    	   2 	 3/2H  	 3/6T  	 3/5T  	 3/4T  	 4/10   	4	 1:58.2 	 29.2	 J Jamieson    	\N	 D Menary
1114	54	3	8	 B Fifteen             	    	   8 	 4@/4  	 4/8T  	 4/8Q  	 4/7H  	 5/10T  	5	 1:58.3 	 29.1	 C Christoforou	\N	 C Christofo
1115	54	3	7	 Little Hanover        	    	   7 	 1@/H  	 2/4   	 2/3H  	 2/3H  	 6/11   	6	 1:58.3 	 30.1	 Do Brown      	\N	 L Blais
1116	54	3	1	 Just Too Spoiled      	    	   1 	 6/7T  	 6/13H 	 6/13H 	 6/11T 	 7/11T  	7	 1:58.4 	 28.2	 D Mcnair      	\N	 P Reid
1117	54	3	3	 Two Hearted           	    	   3 	 7/10H 	 7/16  	 8@/15H	 8/17T 	 8/26   	8	 2:01.3 	 30.4	 Trev Henry    	\N	 P Hunt
1118	54	4	7	 Dunbar Hall=          	    	   7 	 2/2H  	 1/2H  	 1/3H  	 1/5H  	 1/8H   	1	 2:01   	 28.3	 J Jamieson    	\N	 C Jamieson
1119	54	4	4	 Kameran Hanover       	    	   4 	 3/7H  	 3/7T  	 3/5T  	 2/5H  	 2/8H   	2	 2:02.3 	 29  	 C Christoforou	\N	 C Christofo
1120	54	4	3	 Quadrangle            	    	   3 	 7/19Q 	 7/19H 	 6@/13H	 5/12H 	 3/12T  	3	 2:03.3 	 28.3	 J Moiseyev    	\N	 C Christofo
1121	54	4	8	 Upvote Hanover=       	    	   8 	 1/2H  	 2/2H  	 2/3H  	 3/6T  	 4/13H  	4	 2:03.3 	 30.3	 P Henriksen   	\N	 P Henriksen
1122	54	4	1	 Regal Hill            	    	   1 	 4/13  	 4/13H 	 4/7T  	 4/10T 	 5/14H  	5	 2:03.4 	 29.4	 G Peck        	\N	 G Peck
1123	54	4	5	 Whirlaway Hanover     	    	   5 	 6/16T 	 6/17  	 7/13T 	 6/13  	 6/15   	6	 2:04   	 28.4	 Ri Zeron      	\N	 N Bardier J
1124	54	4	6	 Persuaded=            	    	   6 	 5@/15T	 5@/15Q	 5/12  	 7/16T 	 7/18   	7	 2:04.3 	 29.4	 S Mahar       	\N	 S Mahar
1125	54	4	2	 Jd Luther             	    	   2X	 X8/28 	 8/27  	 8/22  	 8/31  	 8/39   	8	 2:08.4 	 32  	 Tra Henry     	\N	 Dr J Chandl
1126	54	5	3	 Ready Any Time=       	    	   3 	 3/5Q  	 3/4H  	 1@/1Q 	 1/3T  	 1/7T   	1	 1:57.1 	 28.4	 P Henriksen   	\N	 P Henriksen
1127	54	5	5	 Magic Missions=       	    	   5 	 2/2H  	 2/2   	 3/2T  	 2/3T  	 2/7T   	2	 1:58.4 	 29.4	 Ph Hudon      	\N	 W Budd
1128	54	5	8	 Sos Harddrive=        	    	   8 	 4/10T 	 4/7   	 4/8T  	 3/11H 	 3/16   	3	 2:00.2 	 30.1	 J Maguire     	\N	 J Maguire
1129	54	5	1	 Sass That Mass=       	    	   1 	 6/20  	 5@/14T	 5/12H 	 4/14H 	 4/18   	4	 2:00.4 	 30  	 J Renaud      	\N	 J Walker
1130	54	5	4	 Weve Had Enough       	    	   4X	 X7/25H	 7/20H 	 7/19T 	 6/18H 	 5/21   	5	 2:01.2 	 29  	 R Mayotte     	\N	 R Mayotte
1131	54	5	6	 Warrawee Rob          	    	   6 	 5/17T 	 6/15  	 6/16T 	 7/19  	 6/25   	6	 2:02.1 	 30.2	 M Baillargeon 	\N	 B Baillarge
1132	54	5	7	 Derivative=           	    	   7 	 1/2H  	 1/2   	 2/1Q  	 X5X/17	 7/DIS  	7	        	     	 T Burgess     	\N	 B Burgess
1133	54	5	2	 Work That Magic       	    	   X2	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 C Christoforou	\N	 S Charlton
1134	54	6	5	 Hurricane Beach       	    	   4 	 3/4   	 3/3T  	 3@/3  	 1/H   	 1/1T   	1	 1:57.4 	 28.3	 S Filion      	\N	 L Blais
1135	54	6	2	 Forrest Porsche       	    	   2 	 1/1T  	 1/1H  	 1/2H  	 2/H   	 2/1T   	2	 1:58.1 	 29.3	 D Graham      	\N	 D Graham
1136	54	6	6	 Beach Volley Ball     	    	   5 	 5/10H 	 5/8   	 5/8H  	 4/6   	 3/3    	3	 1:58.2 	 28.1	 Do Brown      	\N	 L Blais
1137	54	6	1	 Major Master Piece    	    	   1 	 2/1T  	 2/1H  	 2/2H  	 3/3H  	 4/4Q   	4	 1:58.3 	 29.3	 J Jamieson    	\N	 D Menary
1138	54	6	3	 East Bound Eddie      	    	   3 	 4/5T  	 4/5H  	 4/6H  	 5/10H 	 5/17   	5	 2:01.1 	 31.2	 A Macdonald   	\N	 A Macdonald
1139	55	1	1	 Timepiece=            	    	   1 	 5/16T 	 2@/1T 	 1/3H  	 1/3H  	 1/2Q   	1	 2:03.4 	 30.4	 A Macdonald   	\N	 A Macdonald
1140	55	1	6	 Irenes Love=          	    	   5 	 3/9   	 4/5Q  	 3/4T  	 2/3H  	 2/2Q   	2	 2:04.1 	 30.1	 M Saftic      	\N	 M Dowling
1141	55	1	8	 Stritch=              	    	   7 	 4/12T 	 5/9H  	 4/7H  	 4/6T  	 3/4    	3	 2:04.3 	 30.1	 C Steacy      	\N	 M Steacy
1142	55	1	2	 For A Reason          	    	   2 	 1/3H  	 1/1T  	 2/3H  	 3/6   	 4/9    	4	 2:05.3 	 32  	 J Jamieson    	\N	 V Cochrane
1143	55	1	7	 Kuil Deva=            	    	   6 	 2/3H  	 3/2H  	 X5/17H	 5/23  	 5/16   	5	 2:07   	 30.3	 J Whelan      	\N	 J Whelan
1144	55	1	5	 Sweet Kimmy=          	    	   4X	 7/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 Ra Waples     	\N	 B Maxwell
1145	55	1	4	 Da Miracle            	    	   X3	 6/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 Trev Henry    	\N	 P Hunt
1146	56	1	5	 Janettes Image        	    	   5 	 4/5T  	 4/5T  	 3@/2H 	 2/NK  	 1/H    	1	 1:54.3 	 27.3	 Ja Macdonald  	1.00	 D Nixon
1147	56	1	6	 Diamond Tested        	    	   6 	 6/10H 	 6/10H 	 5@/4H 	 3/2   	 2/H    	2	 1:54.3 	 27.1	 D Mcnair      	25.90	 M Brethour
1148	56	1	3	 Misty De Vie          	    	   3 	 5/8H  	 5/8Q  	 6/6   	 6/6H  	 3BE/2H 	3	 1:55   	 27.1	 C Christoforou	15.50	 G Hunt
1149	56	1	1	 Place To Rocknroll    	    	   1 	 1/1T  	 1/2Q  	 1/2Q  	 1/NK  	 4/2H   	4	 1:55   	 28.2	 S Filion      	0.85	 T Alagna
1150	56	1	2	 Nic Nac Patty Mach    	    	   2 	 3/3H  	 3/3H  	 4/3T  	 5/4T  	 5/3    	5	 1:55.1 	 27.4	 Ra Waples     	20.40	 C Mitchell
1151	56	1	4	 Electric Ponder       	    	   4 	 2/1T  	 2/2Q  	 2/2Q  	 4/3H  	 6/5H   	6	 1:55.3 	 28.3	 M Saftic      	44.80	 D Brewer
1152	56	1	7	 City Charm            	    	   7 	 7/12H 	 7/12H 	 7@/6H 	 7/7Q  	 7/12H  	7	 1:57   	 29.1	 J Drury       	67.00	 B Macintosh
1153	56	2	6	 Candlelight Dinner    	    	   5 	 3@/2  	 1/2   	 2@/H  	 1/2   	 1/6    	1	 1:54.2 	 27.2	 J Drury       	0.10	 C Coleman
1154	56	2	5	 Black Jack Pat        	    	   4 	 1/2   	 2/2   	 3/2H  	 3/3T  	 2/6    	2	 1:55.3 	 28.1	 J Jamieson    	12.25	 D Menary
1155	56	2	2	 Moment To Ponder      	    	   2 	 4/4   	 4/5T  	 6@/6  	 6/8Q  	 3/7Q   	3	 1:55.4 	 27.3	 Ra Waples     	16.85	 R Mcintosh
1156	56	2	7	 Touching Thought      	    	   6 	 6/7H  	 6@/8Q 	 1/H   	 2/2   	 4/7T   	4	 1:56   	 29  	 Trev Henry    	9.30	 R Mcintosh
1157	56	2	1	 Braida Hanover        	    	   1 	 2/2   	 3/4   	 5/4H  	 4/6H  	 5/7T   	5	 1:56   	 28.1	 Ph Hudon      	39.95	 Colin Johns
1158	56	2	3	 Ohello Blue Chip(L)   	    	   3 	 5/5T  	 5/8   	 4@/4Q 	 5/7H  	 6/12   	6	 1:56.4 	 29  	 A Macdonald   	41.35	 A Macdonald
1159	56	2	8	 Takeyourbreathaway    	    	   7 	 7/10  	 7@/11 	 7/8T  	 7/11H 	 7/13H  	7	 1:57   	 28.1	 C Christoforou	46.75	 B Macintosh
1160	56	2	4	 Somemoneysomewhere    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1161	56	3	2	 Inner Drive           	    	   2 	 2/1T  	 2/T   	 2/1T  	 2/1H  	 1/NK   	1	 1:59.4 	 30.1	 P Macdonell   	0.75	 R Mcintosh
1162	56	3	6	 Hab Faith=            	    	   5 	 4/6Q  	 1@/T  	 1/1T  	 1/1H  	 2/NK   	2	 1:59.4 	 30.3	 D Mcnair      	1.90	 R Mcnair
1163	56	3	5	 Parkhill Nocredit     	    	   4 	 1/1T  	 3/3   	 3/4   	 3/4   	 3/2Q   	3	 2:00.1 	 30.1	 S Byron       	9.30	 J Bax
1164	56	3	1	 Sunnyday Kash         	    	   1 	 3/4Q  	 4/5T  	 4/10T 	 4/14H 	 4/19   	4	 2:03.3 	 32.1	 Da Wall       	86.05	 L Gibbons
1165	56	3	8	 Oh Miss Sophie        	    	   7 	 6/10T 	 X6X/10	 6/29  	 6/30  	 5/23H  	5	 2:04.2 	 29.2	 Ra Waples     	5.50	 Ro Waples J
1166	56	3	7	 Ticket To Seattle     	    	   6 	 5/8H  	 5/7T  	 X5X/16	 5/28  	 6/23H  	6	 2:04.2 	 32  	 Ja Macdonald  	36.15	 M Steacy
1167	56	3	3	 Duet Seelster=        	    	   3 	 X7/19H	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 R Holliday    	74.70	 R Maclean
1168	56	3	4	 Blink Shes Gone=      	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1169	56	4	9	 Three Rivers Dell(L)  	    	   9 	 1/NK  	 2/1H  	 3/2   	 2/Q   	 1/1    	1	 1:53.3 	 28.2	 S Filion      	8.25	 R Fellows
1170	56	4	6	 Mayfield Duke         	    	   6 	 4/3H  	 4/5H  	 7/5T  	 6/3   	 2/1    	2	 1:53.4 	 27.4	 M Saftic      	14.05	 J Green
1171	56	4	5	 Jack Rackham          	    	   5 	 8/11T 	 8@/10 	 6@/4H 	 4/1H  	 3/2    	3	 1:54   	 28.2	 Trev Henry    	1.30	 A Montini
1172	56	4	4	 Archangel Three       	    	   4 	 7/10  	 6@/8Q 	 4@/2T 	 1/Q   	 4/2Q   	4	 1:54   	 28.3	 Ri Zeron      	3.85	 K Benn
1173	56	4	2	 To His Credit         	    	   2 	 5/6   	 5@/6H 	 2@/1  	 5/2   	 5/7    	5	 1:55   	 30  	 J Jamieson    	2.50	 C Jamieson
1174	56	4	1	 Corsica Hall(L)       	    	   1 	 3/1T  	 3/3Q  	 5/3T  	 7/3H  	 6/9H   	6	 1:55.2 	 29.4	 J Drury       	27.35	 C Auciello
1175	56	4	7	 Rose Run Ranger       	    	   7 	 9/13T 	 9/12H 	 8@/8Q 	 8/7T  	 7/12H  	7	 1:56   	 29.3	 R Holliday    	89.60	 J Pentland
1176	56	4	10	 Chalk Player          	    	   10	 2@/NK 	 1/1H  	 1/1   	 3X/H  	 8/12T  	8	 1:56.1 	 31.2	 D Mcnair      	19.80	 J Ritchie
1177	56	4	8	 Einhorn(L)            	    	   8 	 10/16Q	 10/17 	 10/14H	 10/13 	 9/14T  	9	 1:56.3 	 29  	 Ja Macdonald  	106.65	 M Rogers
1178	56	4	3	 Jet Black Cadillac    	    	   3 	 6/8Q  	 7/8T  	 9/8T  	 9/11H 	 10/23H 	10	 1:58.1 	 31.3	 S Condren     	110.60	 Alan W Fair
1179	56	5	6	 Monopoly              	    	   6 	 2/1H  	 2/1H  	 2/1H  	 1/T   	 1/4    	1	 1:56.2 	 29.3	 Trev Henry    	10.85	 G Cicero
1180	56	5	2	 Agent Dinozzo=        	    	   2 	 6/13T 	 6@/10T	 6@@/7 	 4/4H  	 2/4    	2	 1:57.1 	 29.1	 S Young       	1.10	 V Hayter
1181	56	5	7	 Silky Flashy Nfast    	    	   7 	 3/3H  	 3/3T  	 3/3Q  	 3/2Q  	 3/5Q   	3	 1:57.2 	 30.1	 M Baillargeon 	2.65	 B Baillarge
1182	56	5	9	 Rose Run Rudi         	    	   9 	 1@/1H 	 1/1H  	 1/1H  	 2/T   	 4/7Q   	4	 1:57.4 	 31.1	 S Byron       	7.35	 D Byron
1183	56	5	1	 Uf Musclemass Star    	    	   1 	 4/6Q  	 4/5T  	 4/5Q  	 5/6   	 5/11Q  	5	 1:58.3 	 31  	 S Filion      	9.45	 R Moreau
1184	56	5	10	 Archery=              	    	   10	 8/19Q 	 7@/13H	 7/7Q  	 6/7   	 6/11T  	6	 1:58.4 	 30.4	 D Mcnair      	57.30	 R Mcnair
1185	56	5	8	 Scotties Spirit=      	    	   8 	 5/10T 	 5/8Q  	 5@/6T 	 7/7T  	 7/16Q  	7	 1:59.3 	 31.3	 C Christoforou	18.85	 M Brethour
1186	56	5	3	 Copper Blues=         	    	   3 	 7/17H 	 8/18  	 8/16T 	 8/18H 	 8/26H  	8	 2:01.3 	 31.3	 C Steacy      	70.15	 M Steacy
1187	56	5	4	 Deuce Deuce Deuce     	    	   4X	 9/26  	 9/35  	 9/33T 	 9/33  	 9/35   	9	 2:03.2 	 30  	 J Moiseyev    	13.35	 J Moiseyev
1188	56	5	5	 Stormont Viceroy=     	    	   X5	 10/DIS	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 Ja Macdonald  	91.95	 N Jones
1189	56	6	5	 Powerful Mission      	    	   4 	 3/5Q  	 3/4   	 2@/1  	 1/Q   	 1/3    	1	 1:59.2 	 28.4	 Ph Hudon      	2.30	 K St Charle
1190	56	6	8	 Man Shes Hot          	    	   7 	 4/7   	 4/6   	 4@/2T 	 3/2Q  	 2/3    	2	 2:00   	 29  	 C Christoforou	1.85	 D Fontaine
1191	56	6	2	 Whole Lot Of Sugar    	    	   1 	 1/2T  	 1/2   	 1/1   	 2/Q   	 3/3    	3	 2:00   	 29.3	 J Jamieson    	3.30	 G Demers
1192	56	6	4	 You Cant Afford Me    	    	   3 	 6/10H 	 6/10T 	 6/7T  	 6/6T  	 4/5Q   	4	 2:00.2 	 28.2	 R Mayotte     	6.75	 S Mceneny
1193	56	6	3	 Warrawee Storm        	    	   2 	 5/8H  	 5/8Q  	 5/5H  	 5/6T  	 5/9H   	5	 2:01.1 	 29.4	 W Henry       	40.15	 W Henry
1194	56	6	6	 Hopeswishesndreams    	    	   5 	 2/2T  	 2/2   	 3/2Q  	 4/3H  	 6/12T  	6	 2:02   	 31.1	 D Mcnair      	6.90	 R Mcnair
1195	56	6	7	 Majestic Wanda        	    	   6 	 X7@/18	 7/25  	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 P Macdonell   	21.10	 J Bax
1196	56	6	1	 Rare Ruby             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1197	57	1	1	 Give Em Heck(L)       	    	   1 	 1/1T  	 1/1H  	 1/1T  	 1/1H  	 1/1H   	1	 1:54   	 29  	 Trev Henry    	0.80	 M Weller
1198	57	1	2	 P L Dangerous         	    	   2 	 5/8Q  	 5@/6H 	 4@@/3 	 2/1H  	 2/1H   	2	 1:54.1 	 28.3	 Ja Macdonald  	10.35	 B Gibson
1199	57	1	8	 Maracasso(L)          	    	   8 	 2/1T  	 2/1H  	 2/1T  	 3/2H  	 3/3H   	3	 1:54.3 	 29.1	 Ra Waples     	3.45	 N Gallucci
1200	57	1	5	 Rolandale Buster      	    	   5 	 3/4   	 3@/3Q 	 3@/1T 	 4/3Q  	 4/5Q   	4	 1:55   	 29.3	 G Ketros      	33.20	 G Ketros
1201	57	1	6	 Evening Job(L)        	    	   6 	 4/6   	 4/4T  	 5/3Q  	 5/4T  	 5/5T   	5	 1:55.1 	 29.3	 Ph Hudon      	21.50	 T Riley
1202	57	1	7	 Big Harold(L)         	    	   7 	 8/17Q 	 7@/9H 	 7@@/5Q	 6/4T  	 6/8Q   	6	 1:55.3 	 29.3	 S Filion      	9.95	 J Libby
1203	57	1	4	 Highland Boreas       	    	   4 	 6/11Q 	 6/8H  	 6/5   	 7/5H  	 7/19   	7	 1:57.4 	 31.4	 J Jamieson    	15.40	 M Fine
1204	57	1	3	 Twin B Sportsman      	    	   3 	 7/15  	 8@/11H	 8@/8  	 8/10Q 	 8/19   	8	 1:57.4 	 31.1	 S Byron       	69.30	 C Campbell
1205	57	1	9	 Hp Black Shadow(L)    	    	   9X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 D Mcnair      	8.35	 V Puddy
1206	57	2	2	 Golden Son            	    	   2 	 1/1T  	 1/1T  	 1/1H  	 1/2H  	 1/4    	1	 1:55.2 	 28.3	 S Filion      	0.45	 R Moreau
1207	57	2	5	 Mostinterestingman=   	    	   5 	 4/5H  	 4/5H  	 3@/4H 	 2/2H  	 2/4    	2	 1:56.1 	 28.3	 S Condren     	10.35	 M Dupuis
1208	57	2	6	 French Bastille=      	    	   6 	 6/10H 	 6/9   	 6@/7H 	 4/5T  	 3/4    	3	 1:56.1 	 28  	 Ja Macdonald  	24.85	 M Steacy
1209	57	2	9	 I Want Kandy(L)       	    	   9 	 2/1T  	 2/1T  	 2/1H  	 3/2H  	 4/7H   	4	 1:56.4 	 29.4	 Ph Hudon      	57.20	 A Montini
1210	57	2	3	 Dewtiful Lass=        	    	   3 	 5/8Q  	 5/7Q  	 5/6T  	 6/7Q  	 5/10Q  	5	 1:57.2 	 29.1	 Ra Waples     	118.15	 B Macdonald
1211	57	2	1	 Stormont Esquire=(L)  	    	   1 	 3/3T  	 3/3H  	 4/4T  	 5/7Q  	 6/13H  	6	 1:58   	 30.1	 J Jamieson    	46.45	 K Benn
1212	57	2	10	 Moonlight Cocktail    	    	   10	 8/15T 	 8/14H 	 8@/14T	 7/14  	 7/13T  	7	 1:58.1 	 28.2	 P Macdonell   	23.35	 J Bax
1213	57	2	7	 Dewy Dont Cheat       	    	   7 	 7/14Q 	 7/12H 	 7/13Q 	 8/16  	 8/17H  	8	 1:58.4 	 29.2	 Ri Zeron      	2.45	 Ri Zeron
1214	57	2	8	 Dynamic Edge          	    	   X8	 10/37T	 9/24H 	 9/22H 	 9/27T 	 9/32   	9	 2:01.4 	 30.3	 D Mcnair      	52.05	 R Mcnair
1215	57	2	4	 Classical Son=        	    	   4X	 X9X/17	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 M Baillargeon 	143.40	 S Larocque
1216	57	3	6	 Ideal Wheel           	    	   5 	 3/3H  	 3/3   	 2@/H  	 1/1T  	 1/2H   	1	 1:54   	 28  	 J Drury       	0.35	 C Coleman
1217	57	3	9	 Darlings Dragon       	    	   8 	 1/2   	 2/1H  	 3/2Q  	 3/2   	 2/2H   	2	 1:54.2 	 28  	 D Dupont      	4.30	 M Dupont
1218	57	3	3	 Woodacudashuda        	    	   2 	 5/6T  	 5/6T  	 4/4Q  	 5/6   	 3/7Q   	3	 1:55.2 	 28.3	 D Mcnair      	21.70	 J Morrison
1219	57	3	7	 One Source            	    	   6 	 4/5Q  	 4/4T  	 5@/4T 	 4/5Q  	 4/7T   	4	 1:55.3 	 28.3	 S Filion      	9.00	 R Moreau
1220	57	3	5	 Rock This Way         	    	   4 	 2/2   	 1/1H  	 1/H   	 2/1T  	 5/8T   	5	 1:55.4 	 29.4	 M Baillargeon 	8.90	 B Baillarge
1221	57	3	8	 Heza Big Dealer       	    	   7 	 8/11T 	 7/13T 	 7@/11Q	 6/12T 	 6/9H   	6	 1:55.4 	 27.3	 Ph Hudon      	30.40	 M Brethour
1222	57	3	1	 Word Game             	    	   1 	 6/8   	 6/9   	 6/9T  	 7/17T 	 7/29   	7	 1:59.4 	 31.4	 M Saftic      	101.65	 R Mcnair
1223	57	3	4	 Mavericks A Terror    	    	   3 	 7/10Q 	 X8/18T	 8/22H 	 8/30T 	 8/35   	8	 2:01   	 30.3	 Ja Macdonald  	81.90	 S Mceneny
1224	57	3	2	 Southwind General     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1225	57	4	7	 Anikadabra            	    	   7 	 1/3Q  	 1/1T  	 1/2   	 1/1T  	 1/3    	1	 1:59.3 	 29.4	 Ri Zeron      	10.35	 R Fellows
1226	57	4	5	 P C Pipe Dream        	    	   5 	 6/12T 	 5@/9  	 3@/3T 	 3/2H  	 2/3    	2	 2:00.1 	 29.3	 C Clements    	1.40	 P Clements
1227	57	4	3	 Late Shift=           	    	   3 	 2/3Q  	 2/1T  	 2/2   	 2/1T  	 3/4H   	3	 2:00.2 	 30.1	 Ja Macdonald  	7.75	 M Steacy
1228	57	4	2	 Tymal Declan          	    	   2 	 3/6Q  	 3/4H  	 4/4Q  	 4/5T  	 4/5T   	4	 2:00.4 	 30.1	 S Byron       	6.00	 J Bax
1229	57	4	6	 Kendras Coco          	    	   X6	 7/17Q 	 7@/10T	 6/9Q  	 5X/8H 	 X5/10Q 	5	 2:01.3 	 30  	 D Boughton    	1.75	 J Drennan
1230	57	4	4	 Judy Judy Judy=       	    	   4 	 5/10H 	 4/8   	 5/6H  	 6/9T  	 6/19Q  	6	 2:03.2 	 32.2	 S Filion      	20.60	 K Jones
1231	57	4	1	 Ionia=                	    	   1 	 4/8   	 X6X/10	 7/24  	 7/28H 	 7/DIS  	7	        	     	 Ra Waples     	21.20	 Colin Johns
1232	57	5	7	 Mystic Deuce(L)       	    	   7 	 5/11  	 5/10H 	 6/7H  	 5/4Q  	 1/NK   	1	 1:52.4 	 28.4	 C Christoforou	1.55	 N Gallucci
1233	57	5	5	 Hemingway(L)          	    	   5 	 6/13H 	 7/12H 	 7@/8T 	 4/3T  	 2/NK   	2	 1:52.4 	 28.2	 Trev Henry    	9.65	 R Moffatt
1234	57	5	10	 Highland Tartan       	    	   10	 1@/1T 	 1/1T  	 1/3H  	 1/1H  	 3/T    	3	 1:53   	 30.2	 J Drury       	8.55	 M Fine
1235	57	5	6	 Better Art(L)         	    	   6 	 7/15H 	 6@/12H	 5@/6H 	 3/2H  	 4/1    	4	 1:53   	 29.1	 S Filion      	4.75	 E Laybourne
1236	57	5	8	 Velocity Headlight(L) 	    	   8 	 4/8T  	 4/8H  	 3@/4H 	 2/1H  	 5/3Q   	5	 1:53.2 	 30  	 D Mcnair      	5.20	 L Bako
1237	57	5	4	 Stimulus Spending     	    	   4 	 10/21H	 10/20T	 10@/14	 9/9   	 6/6T   	6	 1:54.1 	 28.4	 Ja Macdonald  	33.75	 K Di Cenzo
1238	57	5	3	 Highland Bogart       	    	   3 	 3/6Q  	 3/5   	 4/5H  	 7/6H  	 7/12Q  	7	 1:55.1 	 31.3	 M Saftic      	43.70	 S Friend
1239	57	5	1	 Never Been Told       	    	   1 	 2/1T  	 2/1T  	 2/3H  	 6/5T  	 8/12Q  	8	 1:55.1 	 32  	 Ph Hudon      	4.35	 A Montini
1240	57	5	2	 P L Inferno           	    	   2 	 9/19Q 	 9@/17H	 8@@/10	 8/7T  	 9/19Q  	9	 1:56.3 	 32  	 S Young       	32.85	 J Libby
1241	57	5	9	 Sky Guy               	    	   9 	 8@/17H	 8/15H 	 9/13H 	 10/16H	 10/24H 	10	 1:57.3 	 32.2	 A Macdonald   	49.15	 A Macdonald
1242	58	1	4	 Lil Richie            	    	   4 	 1/1T  	 1/3H  	 1/2H  	 1/3   	 1/7H   	1	 1:56   	 30  	 B Mcclure     	\N	 D Nixon
1243	58	1	6	 Badlyinclined         	    	   6 	 2/1T  	 2/3H  	 2/2H  	 2/3   	 2/7H   	2	 1:57.2 	 31  	 M Saftic      	\N	 Alan D Fair
1244	58	1	1	 Norcross Blue Chip    	    	   1 	 4/5Q  	 5/11T 	 6/17  	 6/14H 	 3/14T  	3	 1:59   	 29.3	 D Megens      	\N	 D Megens
1245	58	1	7	 Pylater               	    	   7 	 7/10T 	 6@/13Q	 4@/15H	 3/10H 	 4/15   	4	 1:59   	 30  	 Ph Hudon      	\N	 K Mcmaster
1246	58	1	3	 Big Dylan             	    	   3 	 6@/8Q 	 3@/7T 	 3/14H 	 5/13H 	 5/16   	5	 1:59.1 	 30.2	 S Young       	\N	 M Brealey
1247	58	1	8	 Acefortyfouramanda    	    	   8 	 8/12T 	 8/16  	 8/18Q 	 7/17  	 6/16   	6	 1:59.1 	 29.3	 W Henry       	\N	 L Bako
1248	58	1	9	 Birdie                	    	   9 	 3/3T  	 4/11H 	 5@@/15	 4/12  	 7/17   	7	 1:59.2 	 30.1	 S Filion      	\N	 D Daigneaul
1249	58	1	2	 Fade Away             	    	   2 	 5/8   	 7/15T 	 7@/17H	 8/25  	 8/28   	8	 2:01.3 	 32.1	 Ja Macdonald  	\N	 R Muir
1250	58	1	5	 Brightside Gretel     	    	   5X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 J Jamieson    	\N	 W Reda
1251	58	2	5	 Noblecrest            	    	   3 	 2/2H  	 1/2H  	 1/2H  	 1/4   	 1/4Q   	1	 2:03   	 30.2	 J Jamieson    	\N	 V Hayter
1252	58	2	3	 Crazy Girl=           	    	   2 	 1/2H  	 2/2H  	 2/2H  	 2/4   	 2/4Q   	2	 2:03.4 	 30.4	 S Condren     	\N	 C Mitchell
1253	58	2	2	 Try To Resist         	    	   1 	 3/8   	 3/15  	 3/25  	 3/35  	 3/46   	3	 2:12.1 	 34.3	 M Saftic      	\N	 G Sloan
1254	58	3	2	 Real Lucky Day        	    	   2 	 2/4   	 2/1T  	 2/2H  	 2/2H  	 1/HD   	1	 1:59.3 	 30.2	 S Filion      	\N	 S Larocque
1255	58	3	1	 Magic Night           	    	   1 	 1/4   	 1/1T  	 1/2H  	 1/2H  	 2/HD   	2	 1:59.3 	 30.4	 W Henry       	\N	 W Henry
1256	58	3	4	 Victors Magic=        	    	   X4	 4/30  	 4/25  	 3/25  	 3/22  	 3/22   	3	 2:04   	 30.1	 J Jamieson    	\N	 J Darling
1257	58	3	3	 Jayport Sport=        	    	   X3	 3/25  	 3/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 M Saftic      	\N	 D Obrian
1258	58	4	2	 Gateway To Victory    	    	   2X	 5/7H  	 1@/1Q 	 1/2   	 1/3   	 1/H    	1	 1:56   	 29.1	 J Jamieson    	\N	 T Alagna
1259	58	4	6	 Rodeo Sports          	    	   6 	 2@/1Q 	 2/1Q  	 2/2   	 2/3   	 2/H    	2	 1:56   	 28.4	 J Drury       	\N	 C Coleman
1260	58	4	3	 Fade                  	    	   3 	 3/2T  	 4/5T  	 4/9   	 4/6T  	 3/2T   	3	 1:56.3 	 28  	 S Condren     	\N	 C Coleman
1261	58	4	1	 Pretty Angel Eyes     	    	   1 	 1/1Q  	 3/4   	 3/5H  	 3/5T  	 4/5Q   	4	 1:57   	 29.1	 R Mayotte     	\N	 R Mayotte
1262	58	4	5	 Treasure Mach         	    	   5 	 4/5H  	 5/8   	 5/10H 	 5/9   	 5/8H   	5	 1:57.3 	 28.4	 S Filion      	\N	 T Osullivan
1263	58	4	4	 Daenerys Hanover      	    	   4 	 6/11  	 6/11H 	 6/13T 	 6/11T 	 6/10Q  	6	 1:58   	 28.2	 P Macdonell   	\N	 S Mehlenbac
1264	58	5	3	 Anutherdynamic        	    	   3 	 1/3H  	 1/4   	 1/Q   	 1/3   	 1/4H   	1	 2:00.2 	 30  	 P Macdonell   	\N	 W Walters
1265	58	5	4	 Windshield=           	    	   4 	 3/5T  	 3/7Q  	 3/3T  	 3/5T  	 2/4H   	2	 2:01.1 	 30  	 Ja Macdonald  	\N	 G Graham
1266	58	5	2	 Thee Desperado=       	    	   2 	 2/3H  	 2/4   	 2@/Q  	 2/3   	 3/4H   	3	 2:01.1 	 30.4	 S Condren     	\N	 T Mckibbin
1267	58	5	1	 Results May Vary=     	    	   1 	 4/8   	 4/10T 	 4/6T  	 4/9T  	 4/12Q  	4	 2:02.4 	 31  	 M Saftic      	\N	 K Bodz
1268	60	1	1	 Goodmorning Ky        	    	   1 	 2/Q   	 1@/T  	 1@/1  	 1/2   	 1/2    	1	 2:05   	 31.1	 N Rogers      	\N	 N Rogers
1269	60	1	3	 Southfield Speedy     	    	   3 	 3/3   	 3/3H  	 3@/2Q 	 3/3   	 2/2    	2	 2:05.2 	 31.1	 T Gallant     	\N	 T Gallant
1270	60	1	2	 Myambrose             	    	   2 	 1@/Q  	 2/T   	 2/1   	 2/2   	 3/4Q   	3	 2:05.4 	 31.4	 G Chappell    	\N	 C Macdougal
1271	60	2	3	 R Es Nancy+           	    	   3 	 1/7H  	 1/14  	 1/23  	 1/25  	 1/29   	1	 1:59   	 29.2	 M Pezzarello  	\N	 D Sweet
1272	60	2	1	 Southfield Spirit     	    	   1 	 2/7H  	 2/14  	 2/23  	 2/25  	 2/29   	2	 2:04.4 	 30.3	 N Rogers      	\N	 T Mann
1273	60	2	2	 Elm Grove Kaptain     	    	   X2	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 J Hughes      	\N	 B Mckenna
1274	60	3	2	 Shouldabeenaclown     	    	   2 	 1/1T  	 2/1Q  	 2/2Q  	 2/1T  	 1/NK   	1	 2:11.1 	 31.4	 E Stewart     	\N	 E Stewart
1275	60	3	1	 Winny                 	    	   1 	 2/1T  	 1@/1Q 	 1/2Q  	 1/1T  	 2/NK   	2	 2:11.1 	 32.1	 N Rogers      	\N	 N Rogers
1276	60	3	3	 Ladies Gone Wild(T)   	    	   X3	 3BE/3T	 3/2T  	 3/4T  	 3/4T  	 3/5Q   	3	 2:12.1 	 32.1	 G Cole        	\N	 G Cole
1277	61	1	5	 Deacon Brodie         	    	   5 	 1/1H  	 1/1T  	 1/1Q  	 1/1H  	 1/1H   	1	 2:02   	 29  	 M Macdonald   	0.95	 M Macdonald
1278	61	1	4	 Sangria Seelster      	    	   4 	 2/1H  	 2/1T  	 2/1Q  	 2/1H  	 2/1H   	2	 2:02.1 	 29  	 P Langille    	6.50	 C Macdonald
1279	61	1	3	 Paper Lantern         	    	   3I	 5/6   	 5/7Q  	 5@/7  	 4/5H  	 3/8    	3	 2:03.3 	 29.1	 C Isenor      	5.95	 W Mcneil
1280	61	1	8	 Prime Time Cowboy     	    	   8 	 3/3   	 3/4   	 3/4   	 3/4H  	 4/9Q   	4	 2:03.4 	 30  	 D Romo        	6.80	 K Harper
1281	61	1	6	 Arrow Dramatic        	    	   6X	 7/17Q 	 7/11H 	 7I/11H	 7/10Q 	 5/19   	5	 2:05.4 	 30.3	 R Laffin      	6.80	 D Gillis
1282	61	1	2	 Brookdale Bruiser     	    	   2I	 4/4H  	 4/5H  	 4X/6  	 5/8T  	 6P7P6/2	6	 2:06.2 	 32.1	 B Mccallum    	2.95	 B Mccallum
1283	61	1	1	 P H Bossman           	    	   X1	 6/7Q  	 6/8H  	 6IX/8 	 6/9Q  	 7P6P7/2	7	 2:06.2 	 31.4	 T Trites      	12.20	 Dr T Shive
1284	61	1	7	 Craigmore Christy     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1285	61	2	3	 Eyebebuckntuff        	    	   3 	 3/5   	 2@/1  	 1/1Q  	 2/1   	 1/NS   	1	 2:00.1 	 31.2	 J Ramsay Jr   	1.30	 D Oconnor
1286	61	2	4	 N S Acadian           	    	   4 	 4/6Q  	 4@/3  	 2@/1Q 	 1/1   	 2/NS   	2	 2:00.1 	 31.1	 R Smallwood   	1.95	 H Smallwood
1287	61	2	6	 Putnams Force+        	    	   6 	 7/14T 	 6@/6Q 	 4@/2T 	 3/2Q  	 3/T    	3	 2:00.2 	 31  	 A Campbell    	5.40	 J Green
1288	61	2	5	 Metro Man             	    	   5 	 5/8H  	 5/5Q  	 7@/4  	 5/4T  	 4/4T   	4	 2:01.1 	 31.3	 D Crowe       	5.45	 K Gillis
1289	61	2	1	 Pick N Scoop          	    	   1 	 6/13H 	 7/8T  	 5@@/3 	 4/4Q  	 5/5    	5	 2:01.1 	 31.4	 P Langille    	7.35	 C Macdonald
1290	61	2	7	 Sauble Liz            	    	   7 	 1@/1  	 3/2   	 6/3T  	 7/6H  	 6/9H   	6	 2:02   	 32.2	 K Parris      	24.75	 C Covin
1291	61	2	2	 Milliondollarkevin    	    	   2 	 2/1   	 1/1   	 3/1T  	 6/5T  	 7/14   	7	 2:03   	 33.4	 S Dixon       	6.35	 S Dixon
1292	61	3	4	 Mystic Cruiser        	    	   4 	 1@/1Q 	 1/3H  	 1/3H  	 1/3Q  	 1/T    	1	 1:58.1 	 30.3	 E Laffin      	2.15	 F Saunders
1293	61	3	6	 Djnorthernstar        	    	   6 	 6@/6H 	 6@/9Q 	 5@@/5T	 2/3Q  	 2/T    	2	 1:58.2 	 29.3	 M Macdonald   	0.60	 D Jackson
1294	61	3	5	 Hog Aufray            	    	   5 	 5@/5  	 5@/7T 	 3@/5  	 4/3T  	 3/3H   	3	 1:58.4 	 30.1	 T Trites      	9.00	 N White
1295	61	3	7	 Oppies Artist         	    	   7 	 7@/7T 	 7@/10T	 6@/7T 	 6/5Q  	 4/5    	4	 1:59.1 	 30  	 A Campbell    	32.55	 A Campbell
1296	61	3	2	 Western Scot          	    	   2 	 2/1Q  	 2/3H  	 2/3H  	 3/3T  	 5/5Q   	5	 1:59.1 	 31  	 P Langille    	9.70	 D Gillis
1297	61	3	1	 Brookdale Buster      	    	   1 	 3/2H  	 3/5H  	 4/5H  	 5/5   	 6/5Q   	6	 1:59.1 	 30.3	 B Mccallum    	4.40	 B Mccallum
1298	61	3	3	 Lexilowguy            	    	   3 	 4/3T  	 4@/6H 	 7/8Q  	 7/7Q  	 7/7Q   	7	 1:59.3 	 30.2	 R Laffin      	3.25	 O Fletcher
1299	61	4	2	 Four Starz Hold Em    	    	   2 	 1/1Q  	 1/1   	 1/4   	 1/3H  	 1/5    	1	 1:58.4 	 30.1	 D Spence      	0.45	 N White
1300	61	4	3	 Djs Kocakolacowboy    	    	   3 	 5/5H  	 4@/3  	 2/4   	 2/3H  	 2/5    	2	 1:59.4 	 30.2	 H Smallwood   	3.05	 H Smallwood
1301	61	4	4	 Pictonians Derbie     	    	   4 	 4/2H  	 5/4   	 5/6Q  	 3/6Q  	 3/6T   	3	 2:00.1 	 30.2	 B Mccallum    	6.95	 B Mccallum
1302	61	4	7	 Fluid Motion          	    	   7 	 7/8   	 7/6T  	 6@/7  	 6/8   	 4/9Q   	4	 2:00.3 	 30.3	 D Carey       	14.10	 D Carey
1303	61	4	5	 Bo Butler             	    	   5 	 6/6T  	 6@/6Q 	 4@/5Q 	 4/7Q  	 5/12Q  	5	 2:01.1 	 31.3	 K Parris      	12.05	 C Covin
1304	61	4	1	 Nikitas Halo          	    	   1 	 2/1Q  	 3/2   	 3/5Q  	 5/7T  	 6/16T  	6	 2:02.1 	 32.3	 K Parker Jr   	8.50	 K Parker Jr
1305	61	4	6	 Flag Of Honor         	    	   6 	 3@/1H 	 2@/1  	 7/8Q  	 7/11H 	 7/19H  	7	 2:02.3 	 32.2	 J Ramsay Jr   	9.20	 D Settle
1306	61	5	1	 Modern Best           	    	   1 	 1/1Q  	 1/1   	 1/1H  	 1/2   	 1/6Q   	1	 1:58.3 	 29.4	 K Parris      	1.20	 C Covin
1307	61	5	6	 M M Lass              	    	   6 	 5@/5H 	 4@/2H 	 3/3   	 3/3Q  	 2/6Q   	2	 1:59.4 	 30.2	 D Carey       	2.80	 D Carey
1308	61	5	3	 Just Lovey            	    	   3 	 2/1Q  	 3/2   	 2/1H  	 2/2   	 3/6H   	3	 1:59.4 	 30.4	 D Spence      	4.60	 N White
1309	61	5	2	 Mattadors Rose        	    	   2 	 3/3Q  	 6/5Q  	 5/5Q  	 5/6   	 4/10Q  	4	 2:00.3 	 30.4	 J Lilley      	4.60	 J Lilley
1310	61	5	4	 Maiden Heaven         	    	   4 	 4@/4Q 	 2@/1  	 4@/3H 	 4/5T  	 5/13   	5	 2:01.1 	 31.4	 P Langille    	10.15	 P Langille
1311	61	5	7	 Dashwood Darling      	    	   7 	 6@/6T 	 5@/5  	 6/5T  	 6/8   	 6/16H  	6	 2:01.4 	 31.4	 J Ramsay Jr   	6.40	 T Ellis
1312	61	5	8	 Video Storage         	    	   8 	 7/8Q  	 7/9Q  	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 D Crowe       	11.35	 L Johnson
1313	61	5	5	 Scotian Lass          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1314	61	6	3	 Gwinning Gwen         	    	   3 	 1@/1  	 1/2   	 1/1   	 1/1   	 1/1H   	1	 1:58   	 31  	 R Ellis       	4.05	 G Rennison
1315	61	6	7	 Threestepstoheaven    	    	   7 	 7/10  	 7@/10T	 7@/7  	 5/4T  	 2/1H   	2	 1:58.1 	 29.4	 P Langille    	1.55	 G Rennison
1316	61	6	2	 Mr Rock               	    	   2 	 3/3H  	 3/4T  	 3/2H  	 3/2   	 3/2T   	3	 1:58.3 	 31.1	 M Macdonald   	10.40	 E Wilson
1317	61	6	5	 Saulsbrook Quick      	    	   5 	 5/6H  	 6@/8T 	 6@/7  	 7/6T  	 4/6Q   	4	 1:59.1 	 30.4	 J Ramsay Jr   	5.40	 J Green
1318	61	6	1	 Cavallo Frosty        	    	   1 	 2/1   	 2/2   	 2@/1  	 2/1   	 5/6H   	5	 1:59.1 	 32  	 D Crowe       	2.55	 D Crowe
1319	61	6	4	 Pride Of Paradise     	    	   4 	 4/5Q  	 4/7   	 4/5Q  	 4/4T  	 6/6T   	6	 1:59.2 	 31.2	 H Smallwood   	8.00	 H Smallwood
1320	61	6	6	 Sock It To Em         	    	   6 	 6/7T  	 5@/7Q 	 5@/5T 	 6/6   	 7/9H   	7	 1:59.4 	 31.3	 K Parker Jr   	5.70	 K Parker Jr
1321	62	1	5	 Distinctiv Rusty      	    	   5 	 2/1Q  	 3/2   	 2/1T  	 2/1   	 1/5    	1	 1:57.4 	 29.2	 R Ellis       	2.00	 G Rennison
1322	62	1	7	 Sharon The Moment     	    	   7 	 7/8   	 7/6T  	 6/7T  	 5/6T  	 2/5    	2	 1:58.4 	 29.1	 D Carey       	21.40	 D Carey
1323	62	1	3	 Dontstandinmyway      	    	   3 	 3/2H  	 5/4Q  	 3/6T  	 3/5H  	 3/5    	3	 1:58.4 	 29.2	 P Rogerson    	4.90	 P Rogerson
1324	62	1	2	 Neigh Monster         	    	   2 	 1/1Q  	 1/1   	 1/1T  	 1/1   	 4/5Q   	4	 1:58.4 	 30.4	 P Langille    	3.95	 D Gillis
1325	62	1	6	 Our Star              	    	   6 	 6/6T  	 6@/5H 	 5@@/7 	 4/5H  	 5/5H   	5	 1:58.4 	 29.2	 T Trites      	4.65	 G Rennison
1326	62	1	4	 Chief Exec Officer    	    	   4 	 5/5Q  	 4@/3Q 	 7/10  	 6/9   	 6/15Q  	6	 2:00.4 	 30.4	 E Mackay      	5.30	 T Mac Kay
1327	62	1	1	 Primeride             	    	   1 	 4/3T  	 2@/1  	 4@/7  	 7/10  	 7/26Q  	7	 2:03   	 33.3	 D Crowe       	2.45	 D Ellis Abb
1328	62	2	4	 Icandothat            	    	   4 	 1/2Q  	 1/3H  	 1/3   	 1/1Q  	 1/1H   	1	 1:58.2 	 30.1	 R Ellis       	2.60	 R Ellis
1329	62	2	5	 C L La Rousse         	    	   5I	 5/6Q  	 5@/7Q 	 4/4Q  	 3/2H  	 2/1H   	2	 1:58.3 	 29.3	 M Macdonald   	2.90	 L Parker
1330	62	2	2	 Kendal Courageous     	    	   2I	 3/3H  	 3/4T  	 3@/3  	 2/1Q  	 3/3Q   	3	 1:59   	 30.1	 C Stevens     	15.05	 C Stevens
1331	62	2	6	 Charlottes Style      	    	   6I	 6/7H  	 6@/8H 	 5@/5H 	 5/4Q  	 4/7T   	4	 2:00   	 30.4	 D Carey       	13.15	 D Oconnor
1332	62	2	1	 Lifeinthecountry      	    	   1I	 2/2Q  	 2/3H  	 2/3   	 4/4   	 5/9H   	5	 2:00.1 	 31.2	 J Ramsay Jr   	1.00	 J Ramsay Jr
1333	62	2	7	 Desir Dorleans        	    	   7 	 7/10T 	 7@/11T	 7@/8Q 	 6/8Q  	 6/13T  	6	 2:01.1 	 31.2	 H Graves      	8.00	 F Saunders
1334	62	2	3	 P H Powerful          	    	   3 	 4/4T  	 4/6   	 6/6T  	 7/9H  	 7/16   	7	 2:01.3 	 32  	 T Trites      	14.15	 H Mac Kay
1335	62	2	8	 Udine Bayama          	    	   8 	 8/12  	 8/12Q 	 8/9Q  	 8/11  	 8/17T  	8	 2:02   	 32  	 E Laffin      	30.80	 L Johnson
1336	62	3	4	 Gerries Beach         	    	   4 	 1/1Q  	 2/Q   	 1/1   	 1/1   	 1/HD   	1	 1:58   	 29.3	 D Romo        	2.65	 K Harper
1337	62	3	1	 Pasta Vera            	    	   1 	 4/3T  	 1@/Q  	 2@/1  	 2/1   	 2/HD   	2	 1:58   	 29.2	 D Crowe       	1.60	 P Moore
1338	62	3	5	 Threes A Crowd        	    	   5 	 5/5   	 5/3T  	 4@/2Q 	 3/2Q  	 3/T    	3	 1:58.1 	 29.2	 T Trites      	2.35	 Dr T Shive
1339	62	3	6	 Woodmere Dancenart    	    	   6 	 6/6Q  	 6@/4H 	 5@/3T 	 5/3T  	 4/4    	4	 1:58.4 	 29.3	 M Macdonald   	5.10	 M Macdonald
1340	62	3	3	 Walbert               	    	   3 	 3/2H  	 4@/2T 	 6@/5  	 6/6Q  	 5/6H   	5	 1:59.1 	 29.4	 K Parris      	12.00	 C Covin
1341	62	3	2	 Bagel Man             	    	   2 	 2/1Q  	 3/1T  	 3/2   	 4/2T  	 6/7    	6	 1:59.2 	 30.3	 E Laffin      	4.70	 R Collette
1342	62	4	3	 Big Kisser            	    	   3 	 1/1Q  	 1/3   	 1/1Q  	 1/1H  	 1/4T   	1	 1:58   	 29.4	 C Macdonald   	4.15	 C Macdonald
1343	62	4	8	 Shalara               	    	   8 	 3/2T  	 3@/3T 	 2@/1Q 	 2/1H  	 2/4T   	2	 1:59   	 30.3	 M Macdonald   	5.95	 M Macdonald
1344	62	4	1	 Preceptor             	    	   1 	 8/13T 	 8/14T 	 BE6@/6	 5/3H  	 3/7H   	3	 1:59.2 	 30  	 P Langille    	0.65	 P Langille
1345	62	4	4	 Gigs And Reels        	    	   4 	 6@/7  	 4@/7  	 4@/2H 	 4/3Q  	 4/8H   	4	 1:59.3 	 31  	 D Crowe       	7.80	 D Crowe
1346	62	4	5	 Pictonian Sylvia      	    	   5 	 2/1Q  	 2/3   	 3BE/2Q	 3/3Q  	 5/9Q   	5	 1:59.4 	 31.1	 E Mackay      	11.40	 T Mac Kay
1347	62	4	2	 Mrs Krabappel         	    	   2 	 4/5   	 5/9Q  	 5/5   	 6/5H  	 6/10H  	6	 2:00   	 30.4	 C Isenor      	6.80	 W Mcneil
1348	62	4	6	 Woodmere Costalot     	    	   6 	 7/10Q 	 7/12T 	 8/8T  	 8/7T  	 7/12   	7	 2:00.2 	 30.2	 D Romo        	16.35	 W Turner
1349	62	4	7	 Putnams Legacy+       	    	   7 	 5/6T  	 6@/10Q	 7/7   	 7/6H  	 8/12Q  	8	 2:00.2 	 30.4	 B Mccallum    	17.15	 B Mccallum
1350	63	1	2	 Rj Gigolo             	    	   2 	 1/2Q  	 1/3   	 1/2   	 1/1   	 1/2Q   	1	 2:05.1 	 30.3	 D Carey       	\N	 J Green
1351	63	1	3	 Howmacs Dragonator    	    	   3 	 3/4H  	 3/5H  	 3@/3  	 2/1   	 2/2Q   	2	 2:05.3 	 30.2	 B Mccallum    	\N	 B Mccallum
1352	63	1	1	 Bourbonstreet Lady+   	    	   1 	 2/2Q  	 2/3   	 2/2   	 3/2T  	 3/4Q   	3	 2:06   	 31  	 D Romo        	\N	 D Romo
1353	63	2	2	 Lucbobski             	    	   2 	 2@/2  	 1/4H  	 1/6   	 1/8H  	 1/19H  	1	 2:00.4 	 29.1	 D Romo        	\N	 D Romo
1354	63	2	4	 Secret Fantasy        	    	   4 	 1/2   	 2/4H  	 2/6   	 2/8H  	 2/19H  	2	 2:04.3 	 31.4	 R Ellis       	\N	 R Chase
1355	63	2	3	 Southwind Oasis       	    	   3 	 3/2Q  	 3/7T  	 3/13  	 3/13H 	 3/21   	3	 2:05   	 30.4	 C Isenor      	\N	 W Mcneil
1356	63	2	1	 Big Joe Doby          	    	   1 	 4/4   	 4/10H 	 4/15  	 4/15  	 4/23   	4	 2:05.2 	 30.4	 B Mccallum    	\N	 J Janega
1357	64	1	1	 Pappy Go Go           	    	   1 	 2@/2  	 1/3H  	 1/1T  	 1/1H  	 1/T    	1	 2:06.3 	 31.2	 Ma Campbell   	0.25	 Ma Campbell
1358	64	1	4	 Wicked Nick=          	    	   4 	 1/2   	 2/3H  	 2/1T  	 2/1H  	 2/T    	2	 2:06.4 	 31.1	 G Chappell    	20.50	 G Chappell
1359	64	1	3	 Howmacs Survivor      	    	   3 	 3/2T  	 3/6T  	 3/5Q  	 3/6H  	 3/9H   	3	 2:08.2 	 32.1	 T Gallant     	11.70	 T Gallant
1360	64	1	2	 Talk Of Windemere=    	    	   2 	 4/7T  	 4/10Q 	 4/10Q 	 4/13H 	 4/19   	4	 2:10.2 	 33.1	 K Murphy      	37.20	 J Pineau
1361	64	1	7	 Fireside Al=          	    	   7 	 6/10H 	 5/15Q 	 5/12  	 5/16  	 5/20T  	5	 2:10.4 	 33.1	 D Macdonald   	37.20	 D Macdonald
1362	64	1	6	 Hop Up                	    	   6 	 7/12  	 6/21Q 	 6/18  	 6/18H 	 6/21H  	6	 2:10.4 	 32  	 K Campbell    	\N	 K Campbell
1363	64	1	5	 Dusty Lane Min        	    	   5 	 5/9Q  	 X7/DIS	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Hughes      	7.45	 J Hughes
1364	64	2	4	 Mr Bower              	    	   4 	 3/2H  	 3/2H  	 2@/3H 	 2/1H  	 1/1H   	1	 2:02   	 31.1	 K Arsenault   	0.40	 K Arsenault
1365	64	2	1	 Oceanview Lefty=      	    	   1 	 1/1Q  	 1/1Q  	 1/3H  	 1/1H  	 2/1H   	2	 2:02.1 	 32  	 M Mcguigan    	5.50	 E Smallwood
1366	64	2	6	 Time Warp=            	    	   6 	 2/1Q  	 2/1Q  	 3/4Q  	 3/4Q  	 3/8Q   	3	 2:03.3 	 32.3	 D Macdonald   	15.25	 D Macdonald
1367	64	2	5	 Dunmore Ace=          	    	   5 	 4/7   	 4/6   	 4/10Q 	 4/7Q  	 4/8H   	4	 2:03.3 	 31.2	 J Panting     	10.05	 R Annear
1368	64	2	2	 Cardigan Jack         	    	   2 	 5/13  	 5/11  	 5/14T 	 5/11H 	 5/15   	5	 2:05   	 31.4	 C Macpherson  	7.10	 P Morrison
1369	64	2	3	 All Canadian=         	    	   3X	 6/33  	 6/26  	 6/29T 	 6/31H 	 6/29   	6	 2:07.4 	 31.3	 Ma Campbell   	3.15	 Ma Campbell
1370	64	3	1	 Bj Lorado=            	    	   1 	 2/Q   	 2/2Q  	 2/1Q  	 2/NS  	 1/NK   	1	 2:06.1 	 32.2	 P Lanigan     	16.55	 B Honkoop
1371	64	3	6	 Mary Leah             	    	   6 	 4/5T  	 4@/10Q	 3/2H  	 3/1Q  	 2/NK   	2	 2:06.1 	 32.1	 D Macdonald   	2.55	 D Macdonald
1372	64	3	3	 Majian Tango          	    	   3 	 3/3T  	 3/10Q 	 4/6Q  	 4/2H  	 3/1    	3	 2:06.2 	 31.3	 J Ripley      	14.85	 J Ripley
1373	64	3	4	 Windemerepartyman     	    	   4I	 1@/Q  	 1/2Q  	 1/1Q  	 1/NS  	 4/4    	4	 2:07   	 33.2	 J Panting     	4.10	 R Annear
1374	64	3	7	 Just A Little Tad=    	    	   7 	 5/8H  	 5@/13 	 5@/7Q 	 5/3T  	 5/7H   	5	 2:07.3 	 32.3	 C Macpherson  	5.45	 R Gass
1375	64	3	2	 Play Along=           	    	   2X	 X6/20H	 6/25  	 X6/27Q	 6/25T 	 6/24T  	6	 2:11.1 	 32.1	 T Easter      	0.90	 T Easter
1376	64	3	5	 Revenueofwindemere    	    	   5X	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 T Gallant     	9.80	 T Gallant
1377	64	4	2	 Glencove Zani         	    	   2 	 1/2Q  	 1/5   	 1/3T  	 1/2   	 1/4Q   	1	 2:03   	 30.2	 L Mcguigan    	1.30	 E Smallwood
1378	64	4	6	 Craigh Na Dun         	    	   6 	 2/2Q  	 2/5   	 2/3T  	 2/2   	 2/4Q   	2	 2:03.4 	 30.2	 J Hughes      	1.70	 N Oakes
1379	64	4	4	 Howmac Gypsy          	    	   X4	 6/9   	 5@/9  	 5@@/7T	 4/5Q  	 3/7H   	3	 2:04.2 	 30.1	 J Panting     	4.10	 R Annear
1380	64	4	1	 Unsinkableone=        	    	   1 	 3/3H  	 3/7   	 3/5Q  	 3/3T  	 4/8Q   	4	 2:04.3 	 31  	 C Macpherson  	4.00	 R Gass
1381	64	4	5	 Rustico Duchess       	    	   5 	 5@/8H 	 4@/7Q 	 4@/6T 	 5/6Q  	 5/14   	5	 2:05.4 	 31.4	 K Murphy      	7.90	 J Pineau
1382	64	4	3	 Silverhill Flame=     	    	   3 	 4/7Q  	 6/10Q 	 6/10H 	 6/12Q 	 6/23Q  	6	 2:07.3 	 33  	 R Neill       	16.15	 L Neill
1383	64	5	2	 Heres The Beach       	    	   2 	 1/4Q  	 1/6   	 1/5   	 1/2   	 1/1T   	1	 2:04.1 	 32  	 C Macpherson  	3.95	 C Macpherso
1384	64	5	4	 Livin The Moment      	    	   4 	 3/5H  	 3@/6Q 	 3@/5  	 2/2   	 2/1T   	2	 2:04.3 	 31.2	 J Hughes      	0.30	 J Hughes
1385	64	5	3	 Dreamy Honey          	    	   3 	 2/4Q  	 2/6   	 2/5   	 3/2Q  	 3/3T   	3	 2:05   	 31.4	 H Graves      	4.95	 K Arsenault
1386	64	5	5	 P H Stephanie         	    	   5 	 4/10H 	 4/9T  	 4/10  	 4/7Q  	 4/5T   	4	 2:05.2 	 31.1	 Dr T Shive    	3.15	 Dr T Shive
1387	64	5	1	 Doug Little Girl      	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1388	64	6	6	 Elektra Express       	    	   6 	 6@/8T 	 1@/H  	 1/1T  	 1/1H  	 1/3T   	1	 1:59.3 	 29.4	 Ma Campbell   	0.25	 Ma Campbell
1389	64	6	3	 Tobins Secret         	    	   3 	 1/1Q  	 2/H   	 2/1T  	 2/1H  	 2/3T   	2	 2:00.2 	 30.1	 A Smith       	7.00	 A Smith
1390	64	6	2	 Woodmere Finesse+     	    	   2 	 5@/7H 	 4@/3T 	 3@/3T 	 3/2T  	 3/4Q   	3	 2:00.2 	 29.4	 G Barrieau    	9.65	 J Arsenault
1391	64	6	1	 Magical Cowgirl       	    	   1 	 3/3T  	 5/5   	 5/5H  	 5/4Q  	 4/6Q   	4	 2:00.4 	 30  	 C Macpherson  	10.05	 R Gass
1392	64	6	4	 Gold Record           	    	   4 	 2@/1Q 	 3/3H  	 4/4Q  	 4/4   	 5/11   	5	 2:01.4 	 31.1	 B Mccallum    	16.65	 B Mccallum
1393	64	6	5	 Im Not Lisa           	    	   5 	 4/6Q  	 7/6H  	 7/7H  	 6/6H  	 6/15   	6	 2:02.3 	 31.2	 K Arsenault   	5.30	 K Arsenault
1394	64	6	7	 Saulsbrook Fresh      	    	   7 	 7/11H 	 6@/5H 	 6@/6H 	 7/12H 	 7/29   	7	 2:05.2 	 34.2	 R Campbell    	21.10	 N Fiander
1395	65	1	1	 Georgie Rose          	    	   1I	 4/6   	 3@/2  	 2@/H  	 2/Q   	 1/Q    	1	 2:03.1 	 30.2	 G Chappell    	7.50	 C Mackay
1396	65	1	4	 Not So Shy            	    	   4 	 5/8H  	 5@/3H 	 4@/2H 	 3/1Q  	 2/Q    	2	 2:03.1 	 30  	 G Barrieau    	1.40	 E Watts
1397	65	1	5	 Im On Schedule        	    	   5 	 6/9T  	 6@/5  	 5@/3T 	 5/2T  	 3/3T   	3	 2:04   	 30.2	 C Macpherson  	15.20	 D Wallace
1398	65	1	2	 Kiss My Sass          	    	   2I	 1@/1  	 2/1H  	 3/1H  	 4/1T  	 4/5    	4	 2:04.1 	 31.1	 D Spence      	3.20	 M Macinnis
1399	65	1	3	 Elm Grove Luck        	    	   3X	 3/3Q  	 1/1H  	 1/H   	 1/Q   	 5/6H   	5	 2:04.2 	 31.3	 R Ellis       	0.95	 J Baxter
1400	65	1	6	 Noras Little Rose     	    	   6 	 2/1   	 4/3Q  	 6/4T  	 6/10T 	 6/19T  	6	 2:07.1 	 33.2	 R Campbell    	29.65	 W Mcgean
1401	65	2	6	 Kinda Like Her        	    	   6 	 1/1Q  	 1/1   	 1/T   	 1/1H  	 1/7Q   	1	 2:00.1 	 28.4	 K Arsenault   	0.15	 R Dooley
1402	65	2	4	 Pictonian Dazzle      	    	   4 	 2/1Q  	 3/2   	 3/1T  	 2/1H  	 2/7Q   	2	 2:01.3 	 29.4	 B Mccallum    	35.70	 B Mccallum
1403	65	2	2	 Elm Grove Ladyluck    	    	   2 	 4/3T  	 4/4   	 5/3Q  	 5/3T  	 3/7H   	3	 2:01.3 	 29.3	 Ma Campbell   	9.10	 Ma Campbell
1404	65	2	7	 Imahawkchick          	    	   7 	 5/5Q  	 5@/5  	 4@/3  	 4/3H  	 4/9T   	4	 2:02.1 	 30.1	 D Romo        	5.35	 D Romo
1405	65	2	1	 Keep It Country       	    	   1 	 3/2H  	 2@/1  	 2@/T  	 3/2H  	 5/10H  	5	 2:02.1 	 30.3	 D Spence      	14.05	 P Biggar
1406	65	2	3	 Gulf Queen            	    	   3 	 6/6H  	 6/9   	 6@/4T 	 6/5T  	 6/11Q  	6	 2:02.2 	 30  	 M Haig        	25.80	 M Land
1407	65	2	5	 Glenview Paisley      	    	   5 	 7/8   	 7X/11Q	 7/14T 	 7/25T 	 7/33   	7	 2:06.4 	 32.2	 D Carey       	6.30	 D Carey
1408	65	3	2	 Positive Outcome      	    	   2 	 1/1Q  	 1/1   	 1/1Q  	 1/2   	 1/4T   	1	 2:04.2 	 29.2	 D Crowe       	1.00	 D Crowe
1409	65	3	3	 Putnams Fire          	    	   3 	 4/3T  	 5/4H  	 5/2T  	 5/3Q  	 2/4T   	2	 2:05.2 	 29.4	 B Mccallum    	17.55	 B Mccallum
1410	65	3	1	 Sweetgeorgia          	    	   1 	 2/1Q  	 3/1T  	 3/1Q  	 2/2   	 3/5    	3	 2:05.2 	 30.1	 K Murphy      	8.20	 N Oakes
1411	65	3	5	 Calabash              	    	   X5	 6/6T  	 4@/3  	 4@/2H 	 4/3Q  	 4/5T   	4	 2:05.3 	 30.1	 G Barrieau    	2.40	 E Mackay
1412	65	3	4	 Molly Vance           	    	   4 	 5/5H  	 6@/5  	 6@/4Q 	 6/4T  	 5/7T   	5	 2:06   	 30.1	 P Langille    	3.05	 P Langille
1413	65	3	6	 Glenview Pippa        	    	   6 	 3/2H  	 2@/1  	 2@/1Q 	 3/3Q  	 6/13H  	6	 2:07   	 31.4	 J Hughes      	4.70	 J Hughes
1414	65	4	6	 Woodmere Dreams       	    	   6 	 7@/10Q	 4@/6Q 	 2@/1  	 1/NS  	 1/H    	1	 2:00.1 	 29.3	 G Barrieau    	4.05	 K Wilkie
1415	65	4	1	 Shesaroyal Cowgirl    	    	   1 	 2/2Q  	 2/2   	 3/1T  	 3/1Q  	 2/H    	2	 2:00.1 	 29.2	 M Bradley     	1.80	 M Bradley
1416	65	4	5	 Filly Forty Seven     	    	   5 	 1/2Q  	 1/2   	 1/1   	 2/NS  	 3/T    	3	 2:00.2 	 30  	 Ma Campbell   	1.40	 Ma Campbell
1417	65	4	2	 Darn Quick            	    	   2 	 3/4T  	 3/5Q  	 4/3   	 4/2H  	 4/2H   	4	 2:00.3 	 29.3	 D Romo        	6.45	 D Romo
1418	65	4	4	 Woodmere Sandylu      	    	   4 	 6/9   	 7@/9T 	 5@/4  	 5/4   	 5/7T   	5	 2:01.4 	 30.3	 R Ellis       	8.25	 Ma Campbell
1419	65	4	7	 Putthecherryontop     	    	   7 	 4@/5T 	 5/7Q  	 6/5Q  	 6/5   	 6/9H   	6	 2:02   	 30.3	 M Haig        	19.35	 T Gunn
1420	65	4	3	 Oceanview Beemer      	    	   3 	 5/7   	 6@/7H 	 7@/6H 	 7/6Q  	 7/11   	7	 2:02.2 	 30.4	 A Smith       	8.35	 A Smith
1421	65	5	2	 N S Acadian           	    	   2 	 4/6   	 4@/3H 	 1/3H  	 1/5   	 1/4T   	1	 2:00   	 30.3	 H Smallwood   	9.75	 H Smallwood
1422	65	5	5	 A Regal Beauty        	    	   5 	 6/10  	 6/6H  	 4@/4H 	 3/5H  	 2/4T   	2	 2:01   	 30.4	 G Chappell    	3.35	 J Burton
1423	65	5	9	 Sauble Liz            	    	   4 	 5/8Q  	 5@/5H 	 2@/3H 	 2/5   	 3/5T   	3	 2:01.1 	 31.1	 C Isenor      	5.10	 C Covin
1424	65	5	1	 Flag Of Honor         	    	   1 	 3/3H  	 3/3   	 6@/6  	 4/7   	 4/9Q   	4	 2:01.4 	 31.1	 J Ramsay Jr   	6.55	 D Settle
1425	65	5	8	 Mach Vegas            	    	   8 	 8/12T 	 7@/7H 	 7@/7Q 	 6/10H 	 5/12Q  	5	 2:02.2 	 31.3	 R Ellis       	6.15	 R Chase
1426	65	5	7	 Western Scot          	    	   7 	 7/11H 	 8/9   	 8@/8H 	 7/11H 	 6/13   	6	 2:02.3 	 31.3	 P Langille    	13.10	 D Gillis
1427	65	5	6	 Electric Syl          	    	   6 	 1/2   	 1/1H  	 3/4H  	 5/10H 	 7/16   	7	 2:03.1 	 33  	 J Hughes      	1.05	 G Rennison
1428	65	5	3	 Bizzy Izzy            	    	   3 	 2/2   	 2/1H  	 5/6   	 8/14  	 8/24Q  	8	 2:04.4 	 34.1	 D Spence      	15.15	 N White
1429	65	5	4	 Intrepidus            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1430	66	1	3	 Video Storage         	    	   3 	 1/5   	 1/9   	 1/7   	 1/5   	 1/3    	1	 2:02   	 29.4	 D Crowe       	\N	 L Johnson
1431	66	1	2	 Maudail Mac           	    	   2 	 2/5   	 2/9   	 2/7   	 2/5   	 2/3    	2	 2:02.3 	 29  	 M Macdonald   	\N	 M Macdonald
1432	66	1	1	 Heads Up Hanover      	    	   1 	 3/6H  	 3/10T 	 3/9   	 3/6H  	 3/3H   	3	 2:02.3 	 28.3	 C Isenor      	\N	 W Mcneil
1433	67	1	7	 Gigs And Reels        	    	   7 	 7/8T  	 4@/1Q 	 1@/1H 	 1/1H  	 1/3H   	1	 2:01   	 30.2	 D Crowe       	3.65	 D Crowe
1434	67	1	8	 Putnams Legacy+       	    	   8 	 8/10  	 6@/3  	 4@@/2T	 3/2H  	 2/3H   	2	 2:01.3 	 30.2	 B Mccallum    	13.70	 B Mccallum
1435	67	1	3	 Flag Of Honor         	    	   3 	 2/1Q  	 3/1Q  	 3@/1T 	 2/1H  	 3/4T   	3	 2:02   	 31  	 J Ramsay Jr   	7.25	 D Settle
1436	67	1	4	 Metro Man             	    	   4 	 6/7Q  	 8@/4H 	 6@/4Q 	 5/5Q  	 4/7T   	4	 2:02.3 	 31.1	 P Langille    	7.35	 K Gillis
1437	67	1	1	 Prime Time Cowboy     	    	   1 	 4/3   	 5/2T  	 5/4Q  	 4/5   	 5/8    	5	 2:02.3 	 31.1	 D Romo        	1.15	 K Harper
1438	67	1	2	 J Gs Waylon           	    	   2 	 5/5   	 7/4   	 7/5T  	 6/7Q  	 6/11T  	6	 2:03.2 	 31.3	 D Spence      	13.70	 T Maclean
1439	67	1	6	 Secret Fantasy        	    	   6 	 1/1Q  	 1/Q   	 2/1H  	 7/8Q  	 7/22Q  	7	 2:05.2 	 34.3	 R Ellis       	8.45	 R Chase
1440	67	1	5	 Milliondollarkevin    	    	   5 	 3@/1T 	 2@/Q  	 8/13T 	 8/18Q 	 8/30Q  	8	 2:07   	 33.3	 Ma Campbell   	3.70	 S Dixon
1441	67	2	3	 Colin N Down          	    	   3 	 2@/NS 	 1/2Q  	 1/1H  	 1/1H  	 1/2Q   	1	 2:00   	 29.2	 G Barrieau    	0.40	 S Mason
1442	67	2	4	 J J Antonio           	    	   4 	 1/NS  	 2/2Q  	 2/1H  	 2/1H  	 2/2Q   	2	 2:00.2 	 29.3	 T Trites      	3.25	 E Watts
1443	67	2	5	 Ashes To Ashes        	    	   5 	 5/7Q  	 5/6H  	 4/3T  	 4/3Q  	 3/2Q   	3	 2:00.2 	 29  	 J Hughes      	0.65	 B Mckenna
1444	67	2	1	 Cowboys Dont Cry      	    	   1 	 3/1Q  	 3/3T  	 3/2H  	 3/2H  	 4/3T   	4	 2:00.4 	 29.4	 Ma Campbell   	4.05	 K Maclean
1445	67	2	2	 Private Paradise      	    	   2 	 4/5Q  	 4@/4  	 5/8Q  	 5/10Q 	 5/21Q  	5	 2:04.1 	 32  	 R Ellis       	8.60	 W Mackinnon
1446	67	3	5	 Ic A Free Spirit      	    	   5 	 1/2   	 1/1   	 1/2H  	 1/2   	 1/NK   	1	 2:00.4 	 29.4	 E Laffin      	1.05	 E Laffin
1447	67	3	4	 J J Cassius           	    	   4 	 2@/2  	 3/2   	 2/2H  	 2/2   	 2/NK   	2	 2:00.4 	 29.2	 D Romo        	5.90	 J Belliveau
1448	67	3	1	 Last Laugh            	    	   1 	 5/10H 	 5/7   	 5/7T  	 5/9   	 3/12   	3	 2:03.1 	 30.3	 A Camilli     	3.35	 A Camilli
1449	67	3	2	 P H Bossman           	    	   2 	 3/3   	 4/4H  	 4/4H  	 4/5T  	 4/13   	4	 2:03.2 	 31.3	 T Trites      	5.20	 Dr T Shive
1450	67	3	3	 Brookdale Jim         	    	   3 	 6/13  	 6/11Q 	 6/12T 	 6/16  	 5/22   	5	 2:05.1 	 31.3	 B Mccallum    	10.65	 B Mccallum
1451	67	3	6	 Windemeredancenart    	    	   6 	 4/5H  	 2@/1  	 3@X/3H	 3/5   	 6/43   	6	 2:09.2 	 37.4	 Ma Campbell   	2.70	 E Watts
1452	67	4	4	 N S Acadian           	    	   4 	 1/2H  	 1/1Q  	 1/3T  	 1/3T  	 1/6H   	1	 1:57.4 	 29.3	 Ma Campbell   	1.30	 H Smallwood
1453	67	4	3	 Brookdale Buster      	    	   3 	 2/2H  	 2/1Q  	 2/3T  	 2/3T  	 2/6H   	2	 1:59   	 30  	 B Mccallum    	1.60	 B Mccallum
1454	67	4	2	 Pictonians Derbie     	    	   2 	 4/9Q  	 4/6Q  	 4/6T  	 4/5H  	 3/7H   	3	 1:59.1 	 29.3	 A Campbell    	10.75	 B Mccallum
1455	67	4	1	 A Regal Beauty        	    	   1 	 3/7H  	 3/4   	 3@/4Q 	 3/4Q  	 4/7T   	4	 1:59.2 	 30.2	 D Spence      	3.50	 J Burton
1456	67	4	7	 P H Powerful          	    	   6 	 6/13T 	 6/9T  	 6@/9H 	 6/9Q  	 5/12Q  	5	 2:00.1 	 30.1	 T Trites      	11.50	 H Mac Kay
1457	67	4	5	 Ilava                 	    	   5 	 5/12Q 	 5/8Q  	 5@/8  	 5/6T  	 6/13H  	6	 2:00.2 	 30.3	 D Romo        	8.80	 J Janega
1458	67	4	8	 Maiden Heaven         	    	   7 	 7/15Q 	 7/11T 	 7/11H 	 7/11H 	 7/14Q  	7	 2:00.3 	 30.1	 P Langille    	14.60	 P Langille
1459	67	4	6	 Bad Break             	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1460	67	5	4	 Matts Tuition         	    	   4 	 7/7Q  	 6@/6  	 5@@/2Q	 4/1H  	 1/H    	1	 2:04.1 	 31.4	 D Crowe       	1.45	 D Crowe
1461	67	5	2	 Dixie Flyer           	    	   2 	 2/1Q  	 3/2Q  	 2@/H  	 1/1   	 2/H    	2	 2:04.1 	 32.1	 G Barrieau    	1.60	 G Barrieau
1462	67	5	5	 Dividend Day          	    	   5 	 5/4Q  	 5@/4T 	 6@/3H 	 6/2T  	 3/1T   	3	 2:04.3 	 32  	 S Mason       	10.05	 S Mason
1463	67	5	1	 Rj Gigolo             	    	   1 	 4/2T  	 4/3H  	 4@/2Q 	 3/1H  	 4/2    	4	 2:04.3 	 32.1	 D Carey       	9.15	 J Green
1464	67	5	7	 Big Joe Doby          	    	   7 	 3@/1T 	 2@/1  	 1/H   	 2/1   	 5/4Q   	5	 2:05   	 33  	 D Romo        	6.75	 G Mc Callum
1465	67	5	3	 Howmacs Dragonator    	    	   3 	 6/5H  	 7/6Q  	 7/3H  	 7/4Q  	 6/5    	6	 2:05.1 	 32.3	 B Mccallum    	8.00	 B Mccallum
1466	67	5	6	 Slide Guitar          	    	   6 	 1/1Q  	 1/1   	 3/2   	 5/2H  	 7/5Q   	7	 2:05.1 	 32.4	 P Langille    	5.65	 P Pinkney
1467	67	6	3	 Mighty Cowboy         	    	   3 	 1/1H  	 1/1T  	 1/T   	 1/1Q  	 1/1    	1	 2:00.1 	 29  	 D Crowe       	0.55	 D Crowe
1468	67	6	4	 Complete Player       	    	   4 	 2/1H  	 2/1T  	 3/1T  	 3/1H  	 2/1    	2	 2:00.2 	 28.4	 M Bradley     	2.50	 T Weatherbi
1469	67	6	6	 Libertys Choice       	    	   5 	 5/5H  	 4@/5  	 2@/T  	 2/1Q  	 3/2    	3	 2:00.3 	 29.1	 J Hughes      	7.55	 J Hughes
1470	67	6	1	 The Hawk              	    	   1 	 3/3H  	 3/4   	 4/3T  	 4/3   	 4/4Q   	4	 2:01   	 29  	 D Romo        	3.75	 D Romo
1471	67	6	2	 Windemerenightlife    	    	   2 	 4/4Q  	 5/6   	 5@/4T 	 5/5H  	 5/9Q   	5	 2:02   	 29.4	 Ma Campbell   	7.15	 E Watts
1472	67	6	5	 Casstielle            	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1473	68	1	7	 Our Star              	    	   7 	 7/8H  	 7@/8  	 2@/1Q 	 1/1   	 1/4    	1	 1:58   	 29.3	 R Ellis       	1.85	 G Rennison
1474	68	1	1	 Pride Of Paradise     	    	   1 	 3/2H  	 1/3H  	 1/1Q  	 2/1   	 2/4    	2	 1:58.4 	 30.3	 Ma Campbell   	7.90	 H Smallwood
1475	68	1	8	 Sharon The Moment     	    	   8 	 8/10  	 8/9Q  	 4@/3T 	 3/2Q  	 3/4H   	3	 1:58.4 	 29.4	 D Carey       	11.25	 D Carey
1476	68	1	4	 Lil Orphan Cam        	    	   4 	 6@/6T 	 5@/6Q 	 6@/4T 	 4/4Q  	 4/5Q   	4	 1:59   	 29.4	 P Langille    	3.25	 J Ellis
1477	68	1	6	 Arizona Bucks         	    	   6 	 4/4   	 4@/5  	 3/3T  	 5/4T  	 5/8T   	5	 1:59.4 	 30.4	 G Barrieau    	4.40	 D Pinkney
1478	68	1	2	 Eye Forty Seven       	    	   2 	 2/T   	 3/4T  	 8/6H  	 7/7Q  	 6/9    	6	 1:59.4 	 30.2	 T Trites      	6.10	 J Burton
1479	68	1	3	 Go With It            	    	   3 	 5/5H  	 6/7   	 7@/6Q 	 6/7   	 7/9Q   	7	 1:59.4 	 30.2	 B Mccallum    	8.30	 G Mccabe
1480	68	1	5	 I C Anastro           	    	   5 	 1@/T  	 IP2/3H	 5/4T  	 8/9H  	 8/17   	8	 2:01.2 	 32.1	 D Spence      	5.40	 N White
1481	68	2	6	 Jigtime Jones         	    	   6 	 4/7T  	 4/4T  	 4@/2T 	 1/Q   	 1/1    	1	 2:00   	 29.2	 R Macdonald   	4.30	 M Macdonald
1482	68	2	4	 Nameisonthehalter     	    	   4 	 3/5T  	 3@/3  	 2@/1  	 2/Q   	 2/1    	2	 2:00.1 	 30  	 G Barrieau    	0.70	 L Snow
1483	68	2	5	 Lucbobski             	    	   5 	 6/12T 	 6/8   	 6/6H  	 6/4   	 3/2    	3	 2:00.2 	 29.1	 D Romo        	4.90	 D Romo
1484	68	2	2	 Pownal Bay Saul       	    	   2 	 2/2Q  	 2/1T  	 3/1H  	 4/2Q  	 4/2H   	4	 2:00.2 	 30.1	 M Bradley     	34.30	 T Weatherbi
1485	68	2	3	 Ryans Allstar         	    	   3 	 5/10H 	 5/6Q  	 5@/5Q 	 5/3T  	 5/7T   	5	 2:01.3 	 30.3	 Ma Campbell   	3.65	 Ma Campbell
1486	68	2	1	 Windemerefallnforu    	    	   1 	 1/2Q  	 1/1T  	 1/1   	 3/1Q  	 6/13Q  	6	 2:02.3 	 32.3	 T Trites      	4.30	 E Watts
1487	68	3	2	 Distinctiv Rusty      	    	   2 	 1/2   	 1/2T  	 1/1H  	 1/1H  	 1/2    	1	 1:56.1 	 28.4	 R Ellis       	0.45	 G Rennison
1488	68	3	4	 Gerries Beach         	    	   4 	 2/2   	 2/2T  	 2/1H  	 2/1H  	 2/2    	2	 1:56.3 	 29  	 D Romo        	4.45	 K Harper
1489	68	3	1	 Mortal Combat         	    	   X1	 4/5Q  	 4/5Q  	 3/3   	 3/3H  	 3/3T   	3	 1:57   	 29  	 D Spence      	3.05	 A Maclean
1490	68	3	6	 J Rs Hurricane        	    	   6 	 6@/8  	 6/10  	 6@/6  	 6/8   	 4/9Q   	4	 1:58   	 29.2	 G Barrieau    	4.80	 J Belliveau
1491	68	3	3	 Dontstandinmyway      	    	   3 	 5/7   	 5/8   	 5/5   	 4/6T  	 5/9H   	5	 1:58   	 29.3	 P Rogerson    	54.55	 P Rogerson
1492	68	3	5	 Threes A Crowd        	    	   5 	 3/3H  	 3@/3Q 	 4@/4  	 5/6T  	 6/12Q  	6	 1:58.3 	 30.2	 T Trites      	12.05	 Dr T Shive
1493	68	4	6	 Tobinator             	    	   6 	 1/2T  	 1/2H  	 1/2   	 1/2Q  	 1/T    	1	 1:58   	 28.2	 R Ellis       	1.25	 T Hicken
1494	68	4	1	 Carters Caper         	    	   1 	 2/2T  	 2/2H  	 2/2   	 2/2Q  	 2/T    	2	 1:58.1 	 28.1	 M Macdonald   	1.15	 M Macdonald
1495	68	4	2	 Southsidelightning    	    	   2 	 3/4   	 4/4Q  	 4/3T  	 4/4   	 3/8    	3	 1:59.3 	 29.1	 M Bradley     	7.25	 T Weatherbi
1496	68	4	4	 Island Energetic      	    	   4 	 5/9T  	 5@/4T 	 5@@/3T	 3/3T  	 4/8Q   	4	 1:59.3 	 29.1	 D Romo        	4.95	 D Romo
1497	68	4	3	 Woodmere Soul         	    	   3 	 4/6H  	 3@/3Q 	 3@/3  	 5/4H  	 5/11H  	5	 2:00.1 	 30  	 G Barrieau    	5.40	 E Watts
1498	68	4	5	 Jdcyril               	    	   5 	 6/11Q 	 6@/6Q 	 6/5   	 6/6H  	 6/13T  	6	 2:00.4 	 30.1	 Ma Campbell   	48.65	 K Maclean
1499	68	5	1	 Oppies Artist         	    	   1 	 1/2Q  	 1/1T  	 1/1T  	 1/1Q  	 1/1T   	1	 1:57.1 	 30.3	 A Campbell    	2.85	 A Campbell
1500	68	5	7	 Four Starz Hold Em    	    	   7 	 2/2Q  	 2/1T  	 2/1T  	 2/1Q  	 2/1T   	2	 1:57.3 	 30.3	 D Spence      	3.10	 N White
1501	68	5	3	 Putnams Force+        	    	   3 	 I4/8H 	 3@/5T 	 4/3T  	 4/3   	 3/2T   	3	 1:57.4 	 30.2	 T Trites      	4.25	 J Green
1502	68	5	4	 Djs Kocakolacowboy    	    	   4 	 5/11Q 	 5@/7  	 3@/2T 	 3/2Q  	 4/7T   	4	 1:58.4 	 31.3	 Ma Campbell   	2.80	 H Smallwood
1503	68	5	6	 Brookdale Liz         	    	   6 	 7/14T 	 6@/12 	 6/6T  	 5/5Q  	 5/9T   	5	 1:59.1 	 31.1	 B Mccallum    	4.45	 B Mccallum
1504	68	5	2	 Eyebebuckntuff        	    	   2 	 X3/7Q 	 4/6T  	 5@/5T 	 6/6T  	 6/10H  	6	 1:59.1 	 31.2	 J Ramsay Jr   	4.30	 D Oconnor
1505	68	5	5	 Dashwood Darling      	    	   5 	 6/13Q 	 7/12Q 	 7@/8  	 7/8   	 7/17Q  	7	 2:00.3 	 32.2	 P Langille    	20.90	 T Ellis
1506	68	5	9	 Bizzy Izzy            	    	   8 	 8/16H 	 8/14T 	 8@/12 	 8/11T 	 8/17Q  	8	 2:00.3 	 31.3	 D Carey       	\N	 N White
1507	68	5	8	 Electric Syl          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	122	1	2	 Great Luck            	    	   2 	 2/2H  	 2/2T  	 2/2H  	 2/1   	 1/Q    	1	 2:06.1 	 30.3	 R Gillis      	\N	 J Murphy
\N	122	1	1	 P H Showboat          	    	   1 	 1/2H  	 1/2T  	 1/2H  	 1/1   	 2/Q    	2	 2:06.1 	 31  	 A Macdonell   	\N	 A Macdonell
\N	126	1	2	 Macnamarra            	    	   2 	 1/18  	 1/27  	 1/35  	 1/35  	 1/38   	1	 1:58   	 31.1	 J Mac Dougall 	\N	 R Smith
\N	126	1	1	 Gigolos Boozer        	    	   1 	 2/18  	 2/27  	 2/35  	 2/35  	 2/38   	2	 2:05.3 	 31.4	 R Gillis      	\N	 S Harper Jr
\N	136	1	4	 Lil Richie            	    	   4 	 1/1T  	 1/3H  	 1/2H  	 1/3   	 1/7H   	1	 1:56   	 30  	 B Mcclure     	\N	 D Nixon
\N	136	1	6	 Badlyinclined         	    	   6 	 2/1T  	 2/3H  	 2/2H  	 2/3   	 2/7H   	2	 1:57.2 	 31  	 M Saftic      	\N	 Alan D Fair
\N	136	1	1	 Norcross Blue Chip    	    	   1 	 4/5Q  	 5/11T 	 6/17  	 6/14H 	 3/14T  	3	 1:59   	 29.3	 D Megens      	\N	 D Megens
\N	136	1	7	 Pylater               	    	   7 	 7/10T 	 6@/13Q	 4@/15H	 3/10H 	 4/15   	4	 1:59   	 30  	 Ph Hudon      	\N	 K Mcmaster
\N	136	1	3	 Big Dylan             	    	   3 	 6@/8Q 	 3@/7T 	 3/14H 	 5/13H 	 5/16   	5	 1:59.1 	 30.2	 S Young       	\N	 M Brealey
\N	136	1	8	 Acefortyfouramanda    	    	   8 	 8/12T 	 8/16  	 8/18Q 	 7/17  	 6/16   	6	 1:59.1 	 29.3	 W Henry       	\N	 L Bako
\N	136	1	9	 Birdie                	    	   9 	 3/3T  	 4/11H 	 5@@/15	 4/12  	 7/17   	7	 1:59.2 	 30.1	 S Filion      	\N	 D Daigneaul
\N	136	1	2	 Fade Away             	    	   2 	 5/8   	 7/15T 	 7@/17H	 8/25  	 8/28   	8	 2:01.3 	 32.1	 Ja Macdonald  	\N	 R Muir
\N	136	1	5	 Brightside Gretel     	    	   5X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 J Jamieson    	\N	 W Reda
\N	136	2	5	 Noblecrest            	    	   3 	 2/2H  	 1/2H  	 1/2H  	 1/4   	 1/4Q   	1	 2:03   	 30.2	 J Jamieson    	\N	 V Hayter
\N	136	2	3	 Crazy Girl=           	    	   2 	 1/2H  	 2/2H  	 2/2H  	 2/4   	 2/4Q   	2	 2:03.4 	 30.4	 S Condren     	\N	 C Mitchell
\N	136	2	2	 Try To Resist         	    	   1 	 3/8   	 3/15  	 3/25  	 3/35  	 3/46   	3	 2:12.1 	 34.3	 M Saftic      	\N	 G Sloan
\N	136	3	2	 Real Lucky Day        	    	   2 	 2/4   	 2/1T  	 2/2H  	 2/2H  	 1/HD   	1	 1:59.3 	 30.2	 S Filion      	\N	 S Larocque
\N	136	3	1	 Magic Night           	    	   1 	 1/4   	 1/1T  	 1/2H  	 1/2H  	 2/HD   	2	 1:59.3 	 30.4	 W Henry       	\N	 W Henry
\N	136	3	4	 Victors Magic=        	    	   X4	 4/30  	 4/25  	 3/25  	 3/22  	 3/22   	3	 2:04   	 30.1	 J Jamieson    	\N	 J Darling
\N	136	3	3	 Jayport Sport=        	    	   X3	 3/25  	 3/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 M Saftic      	\N	 D Obrian
\N	136	4	2	 Gateway To Victory    	    	   2X	 5/7H  	 1@/1Q 	 1/2   	 1/3   	 1/H    	1	 1:56   	 29.1	 J Jamieson    	\N	 T Alagna
\N	136	4	6	 Rodeo Sports          	    	   6 	 2@/1Q 	 2/1Q  	 2/2   	 2/3   	 2/H    	2	 1:56   	 28.4	 J Drury       	\N	 C Coleman
\N	136	4	3	 Fade                  	    	   3 	 3/2T  	 4/5T  	 4/9   	 4/6T  	 3/2T   	3	 1:56.3 	 28  	 S Condren     	\N	 C Coleman
\N	136	4	1	 Pretty Angel Eyes     	    	   1 	 1/1Q  	 3/4   	 3/5H  	 3/5T  	 4/5Q   	4	 1:57   	 29.1	 R Mayotte     	\N	 R Mayotte
\N	136	4	5	 Treasure Mach         	    	   5 	 4/5H  	 5/8   	 5/10H 	 5/9   	 5/8H   	5	 1:57.3 	 28.4	 S Filion      	\N	 T Osullivan
\N	136	4	4	 Daenerys Hanover      	    	   4 	 6/11  	 6/11H 	 6/13T 	 6/11T 	 6/10Q  	6	 1:58   	 28.2	 P Macdonell   	\N	 S Mehlenbac
\N	136	5	3	 Anutherdynamic        	    	   3 	 1/3H  	 1/4   	 1/Q   	 1/3   	 1/4H   	1	 2:00.2 	 30  	 P Macdonell   	\N	 W Walters
\N	136	5	4	 Windshield=           	    	   4 	 3/5T  	 3/7Q  	 3/3T  	 3/5T  	 2/4H   	2	 2:01.1 	 30  	 Ja Macdonald  	\N	 G Graham
\N	136	5	2	 Thee Desperado=       	    	   2 	 2/3H  	 2/4   	 2@/Q  	 2/3   	 3/4H   	3	 2:01.1 	 30.4	 S Condren     	\N	 T Mckibbin
\N	136	5	1	 Results May Vary=     	    	   1 	 4/8   	 4/10T 	 4/6T  	 4/9T  	 4/12Q  	4	 2:02.4 	 31  	 M Saftic      	\N	 K Bodz
\N	137	1	1	 Goodmorning Ky        	    	   1 	 2/Q   	 1@/T  	 1@/1  	 1/2   	 1/2    	1	 2:05   	 31.1	 N Rogers      	\N	 N Rogers
\N	137	1	3	 Southfield Speedy     	    	   3 	 3/3   	 3/3H  	 3@/2Q 	 3/3   	 2/2    	2	 2:05.2 	 31.1	 T Gallant     	\N	 T Gallant
\N	137	1	2	 Myambrose             	    	   2 	 1@/Q  	 2/T   	 2/1   	 2/2   	 3/4Q   	3	 2:05.4 	 31.4	 G Chappell    	\N	 C Macdougal
\N	137	2	3	 R Es Nancy+           	    	   3 	 1/7H  	 1/14  	 1/23  	 1/25  	 1/29   	1	 1:59   	 29.2	 M Pezzarello  	\N	 D Sweet
\N	137	2	1	 Southfield Spirit     	    	   1 	 2/7H  	 2/14  	 2/23  	 2/25  	 2/29   	2	 2:04.4 	 30.3	 N Rogers      	\N	 T Mann
\N	137	2	2	 Elm Grove Kaptain     	    	   X2	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 J Hughes      	\N	 B Mckenna
\N	137	3	2	 Shouldabeenaclown     	    	   2 	 1/1T  	 2/1Q  	 2/2Q  	 2/1T  	 1/NK   	1	 2:11.1 	 31.4	 E Stewart     	\N	 E Stewart
\N	137	3	1	 Winny                 	    	   1 	 2/1T  	 1@/1Q 	 1/2Q  	 1/1T  	 2/NK   	2	 2:11.1 	 32.1	 N Rogers      	\N	 N Rogers
\N	137	3	3	 Ladies Gone Wild(T)   	    	   X3	 3BE/3T	 3/2T  	 3/4T  	 3/4T  	 3/5Q   	3	 2:12.1 	 32.1	 G Cole        	\N	 G Cole
\N	138	1	2	 Ladies Gone Wild      	    	   2 	 1/5Q  	 1/6   	 1/2T  	 1/2   	 1/1    	1	 2:09.1 	 32.2	 G Cole        	\N	 G Cole
\N	138	1	1	 Here Comes Joe        	    	   1 	 2/5Q  	 2/6   	 2/2T  	 2/2   	 2/1    	2	 2:09.2 	 32  	 K Murphy      	\N	 C Smith
\N	138	2	3	 Elm Grove Kaptain     	    	   3 	 3/5T  	 2@/1  	 1/7Q  	 1/15  	 1/24   	1	 2:01.1 	 30  	 K Murphy      	\N	 B Mckenna
\N	138	2	2	 Shouldabeenaclown     	    	   2 	 2/3Q  	 3/1T  	 3/9   	 3/16  	 2/24   	2	 2:06   	 33  	 E Stewart     	\N	 E Stewart
\N	138	2	1	 Winny                 	    	   1 	 1/3Q  	 1/1   	 2/7Q  	 2/15  	 3/27   	3	 2:06.3 	 34  	 N Rogers      	\N	 N Rogers
\N	141	1	2	 Rj Gigolo             	    	   2 	 1/2Q  	 1/3   	 1/2   	 1/1   	 1/2Q   	1	 2:05.1 	 30.3	 D Carey       	\N	 J Green
\N	141	1	3	 Howmacs Dragonator    	    	   3 	 3/4H  	 3/5H  	 3@/3  	 2/1   	 2/2Q   	2	 2:05.3 	 30.2	 B Mccallum    	\N	 B Mccallum
\N	141	1	1	 Bourbonstreet Lady+   	    	   1 	 2/2Q  	 2/3   	 2/2   	 3/2T  	 3/4Q   	3	 2:06   	 31  	 D Romo        	\N	 D Romo
\N	141	2	2	 Lucbobski             	    	   2 	 2@/2  	 1/4H  	 1/6   	 1/8H  	 1/19H  	1	 2:00.4 	 29.1	 D Romo        	\N	 D Romo
\N	141	2	4	 Secret Fantasy        	    	   4 	 1/2   	 2/4H  	 2/6   	 2/8H  	 2/19H  	2	 2:04.3 	 31.4	 R Ellis       	\N	 R Chase
\N	141	2	3	 Southwind Oasis       	    	   3 	 3/2Q  	 3/7T  	 3/13  	 3/13H 	 3/21   	3	 2:05   	 30.4	 C Isenor      	\N	 W Mcneil
\N	141	2	1	 Big Joe Doby          	    	   1 	 4/4   	 4/10H 	 4/15  	 4/15  	 4/23   	4	 2:05.2 	 30.4	 B Mccallum    	\N	 J Janega
\N	144	1	3	 Video Storage         	    	   3 	 1/5   	 1/9   	 1/7   	 1/5   	 1/3    	1	 2:02   	 29.4	 D Crowe       	\N	 L Johnson
\N	144	1	2	 Maudail Mac           	    	   2 	 2/5   	 2/9   	 2/7   	 2/5   	 2/3    	2	 2:02.3 	 29  	 M Macdonald   	\N	 M Macdonald
\N	144	1	1	 Heads Up Hanover      	    	   1 	 3/6H  	 3/10T 	 3/9   	 3/6H  	 3/3H   	3	 2:02.3 	 28.3	 C Isenor      	\N	 W Mcneil
\N	132	1	8	 Traceur Hanover       	    	   8 	 1/1T  	 2/1T  	 2/1T  	 3/2Q  	 1/NS   	1	 1:55.2 	 27.2	 S Filion      	\N	 R Moreau
\N	132	1	4	 Beast Mode            	    	   4 	 2/1T  	 1/1T  	 1/1T  	 1/1   	 2/NS   	2	 1:55.2 	 27.4	 Trev Henry    	\N	 C Nicol
\N	132	1	7	 Ideal Jet             	    	   7 	 3/4   	 3/3H  	 3/3H  	 2/1   	 3/H    	3	 1:55.2 	 27.1	 J Jamieson    	\N	 C Barss
\N	132	1	5	 Bringhome Theblue     	    	   5 	 4/6T  	 4/5H  	 4@/5Q 	 4/6T  	 4/6Q   	4	 1:56.3 	 28  	 C Auciello    	\N	 C Auciello
\N	132	1	2	 Homer Run             	    	   2 	 6/13H 	 6/12H 	 6@/11 	 6/13T 	 5/17   	5	 1:58.4 	 29  	 Dr J Flanigan 	\N	 Dr J Flanig
\N	132	1	1	 Passion Quizrace      	    	   1 	 5/10  	 5/8   	 5/9H  	 5/12H 	 6/19   	6	 1:59.1 	 29.4	 Ph Hudon      	\N	 K Gangell
\N	132	1	3	 Real Buzz             	    	   3 	 7/18  	 7/15H 	 7/12Q 	 7/16T 	 7/22   	7	 1:59.4 	 29.4	 Do Brown      	\N	 L Blais
\N	132	1	6	 Nicholas Ryan         	    	   6 	 8/21H 	 8/17  	 8/14H 	 8/20H 	 8/28   	8	 2:01   	 30.3	 J Drury       	\N	 C Auciello
\N	132	2	8	 Mister Herbie         	    	   8 	 2/1H  	 1/3   	 1/8H  	 1/8T  	 1/4Q   	1	 1:56.1 	 29.1	 J Jamieson    	\N	 J Gillis
\N	132	2	2	 Marquis Volo=         	    	   2 	 5/9H  	 5/11T 	 4@/11H	 2/8T  	 2/4Q   	2	 1:57   	 27.4	 P Henriksen   	\N	 P Henriksen
\N	132	2	3	 Way Outta Here=       	    	   3 	 6/11T 	 6/14T 	 5@/13Q	 4/12H 	 3/9Q   	3	 1:58   	 28.2	 M Vanderkemp  	\N	 M Vanderkem
\N	132	2	6	 Moonbeam Hall         	    	   6 	 4/7   	 4/9H  	 6/13H 	 6/15H 	 4/12   	4	 1:58.3 	 29  	 M Baillargeon 	\N	 B Baillarge
\N	132	2	7	 Little Stuie          	    	   7 	 1/1H  	 2/3   	 2/8H  	 3/11H 	 5/14Q  	5	 1:59   	 30.2	 Ph Hudon      	\N	 W Dunn
\N	132	2	1	 Joyous Hall           	    	   1 	 3/3T  	 3/5T  	 3/10Q 	 5/14  	 6/19   	6	 2:00   	 31  	 M Saftic      	\N	 B Bahr
\N	132	2	5	 Danielle Hall         	    	   5X	 X8/DIS	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 C Jamieson    	\N	 C Jamieson
\N	132	2	4	 April Breeze On By=   	    	   4X	 X7/DIS	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 J Renaud      	\N	 J Walker
\N	132	3	4	 Happy Hannah          	    	   4 	 2/H   	 1/4   	 1/3H  	 1/3H  	 1/8T   	1	 1:56.2 	 28.3	 Ra Waples     	\N	 M Steacy
\N	132	3	6	 Manhattan Play        	    	   6 	 8/13H 	 8/19  	 7/14T 	 7/12  	 2/8T   	2	 1:58.1 	 27.2	 M Saftic      	\N	 N Comegna
\N	132	3	5	 Dance Craze           	    	   5 	 5@/6H 	 5/10T 	 5/10  	 5/10Q 	 3/9T   	3	 1:58.2 	 28.3	 S Filion      	\N	 T Osullivan
\N	132	3	2	 Wicked Hill           	    	   2 	 3/2H  	 3/6T  	 3/5T  	 3/4T  	 4/10   	4	 1:58.2 	 29.2	 J Jamieson    	\N	 D Menary
\N	132	3	8	 B Fifteen             	    	   8 	 4@/4  	 4/8T  	 4/8Q  	 4/7H  	 5/10T  	5	 1:58.3 	 29.1	 C Christoforou	\N	 C Christofo
\N	132	3	7	 Little Hanover        	    	   7 	 1@/H  	 2/4   	 2/3H  	 2/3H  	 6/11   	6	 1:58.3 	 30.1	 Do Brown      	\N	 L Blais
\N	132	3	1	 Just Too Spoiled      	    	   1 	 6/7T  	 6/13H 	 6/13H 	 6/11T 	 7/11T  	7	 1:58.4 	 28.2	 D Mcnair      	\N	 P Reid
\N	132	3	3	 Two Hearted           	    	   3 	 7/10H 	 7/16  	 8@/15H	 8/17T 	 8/26   	8	 2:01.3 	 30.4	 Trev Henry    	\N	 P Hunt
\N	132	4	7	 Dunbar Hall=          	    	   7 	 2/2H  	 1/2H  	 1/3H  	 1/5H  	 1/8H   	1	 2:01   	 28.3	 J Jamieson    	\N	 C Jamieson
\N	132	4	4	 Kameran Hanover       	    	   4 	 3/7H  	 3/7T  	 3/5T  	 2/5H  	 2/8H   	2	 2:02.3 	 29  	 C Christoforou	\N	 C Christofo
\N	132	4	3	 Quadrangle            	    	   3 	 7/19Q 	 7/19H 	 6@/13H	 5/12H 	 3/12T  	3	 2:03.3 	 28.3	 J Moiseyev    	\N	 C Christofo
\N	132	4	8	 Upvote Hanover=       	    	   8 	 1/2H  	 2/2H  	 2/3H  	 3/6T  	 4/13H  	4	 2:03.3 	 30.3	 P Henriksen   	\N	 P Henriksen
\N	132	4	1	 Regal Hill            	    	   1 	 4/13  	 4/13H 	 4/7T  	 4/10T 	 5/14H  	5	 2:03.4 	 29.4	 G Peck        	\N	 G Peck
\N	132	4	5	 Whirlaway Hanover     	    	   5 	 6/16T 	 6/17  	 7/13T 	 6/13  	 6/15   	6	 2:04   	 28.4	 Ri Zeron      	\N	 N Bardier J
\N	132	4	6	 Persuaded=            	    	   6 	 5@/15T	 5@/15Q	 5/12  	 7/16T 	 7/18   	7	 2:04.3 	 29.4	 S Mahar       	\N	 S Mahar
\N	132	4	2	 Jd Luther             	    	   2X	 X8/28 	 8/27  	 8/22  	 8/31  	 8/39   	8	 2:08.4 	 32  	 Tra Henry     	\N	 Dr J Chandl
\N	132	5	3	 Ready Any Time=       	    	   3 	 3/5Q  	 3/4H  	 1@/1Q 	 1/3T  	 1/7T   	1	 1:57.1 	 28.4	 P Henriksen   	\N	 P Henriksen
\N	132	5	5	 Magic Missions=       	    	   5 	 2/2H  	 2/2   	 3/2T  	 2/3T  	 2/7T   	2	 1:58.4 	 29.4	 Ph Hudon      	\N	 W Budd
\N	132	5	8	 Sos Harddrive=        	    	   8 	 4/10T 	 4/7   	 4/8T  	 3/11H 	 3/16   	3	 2:00.2 	 30.1	 J Maguire     	\N	 J Maguire
\N	132	5	1	 Sass That Mass=       	    	   1 	 6/20  	 5@/14T	 5/12H 	 4/14H 	 4/18   	4	 2:00.4 	 30  	 J Renaud      	\N	 J Walker
\N	132	5	4	 Weve Had Enough       	    	   4X	 X7/25H	 7/20H 	 7/19T 	 6/18H 	 5/21   	5	 2:01.2 	 29  	 R Mayotte     	\N	 R Mayotte
\N	132	5	6	 Warrawee Rob          	    	   6 	 5/17T 	 6/15  	 6/16T 	 7/19  	 6/25   	6	 2:02.1 	 30.2	 M Baillargeon 	\N	 B Baillarge
\N	132	5	7	 Derivative=           	    	   7 	 1/2H  	 1/2   	 2/1Q  	 X5X/17	 7/DIS  	7	        	     	 T Burgess     	\N	 B Burgess
\N	132	5	2	 Work That Magic       	    	   X2	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 C Christoforou	\N	 S Charlton
\N	132	6	5	 Hurricane Beach       	    	   4 	 3/4   	 3/3T  	 3@/3  	 1/H   	 1/1T   	1	 1:57.4 	 28.3	 S Filion      	\N	 L Blais
\N	132	6	2	 Forrest Porsche       	    	   2 	 1/1T  	 1/1H  	 1/2H  	 2/H   	 2/1T   	2	 1:58.1 	 29.3	 D Graham      	\N	 D Graham
\N	132	6	6	 Beach Volley Ball     	    	   5 	 5/10H 	 5/8   	 5/8H  	 4/6   	 3/3    	3	 1:58.2 	 28.1	 Do Brown      	\N	 L Blais
\N	132	6	1	 Major Master Piece    	    	   1 	 2/1T  	 2/1H  	 2/2H  	 3/3H  	 4/4Q   	4	 1:58.3 	 29.3	 J Jamieson    	\N	 D Menary
\N	132	6	3	 East Bound Eddie      	    	   3 	 4/5T  	 4/5H  	 4/6H  	 5/10H 	 5/17   	5	 2:01.1 	 31.2	 A Macdonald   	\N	 A Macdonald
\N	133	1	1	 Timepiece=            	    	   1 	 5/16T 	 2@/1T 	 1/3H  	 1/3H  	 1/2Q   	1	 2:03.4 	 30.4	 A Macdonald   	\N	 A Macdonald
\N	133	1	6	 Irenes Love=          	    	   5 	 3/9   	 4/5Q  	 3/4T  	 2/3H  	 2/2Q   	2	 2:04.1 	 30.1	 M Saftic      	\N	 M Dowling
\N	133	1	8	 Stritch=              	    	   7 	 4/12T 	 5/9H  	 4/7H  	 4/6T  	 3/4    	3	 2:04.3 	 30.1	 C Steacy      	\N	 M Steacy
\N	133	1	2	 For A Reason          	    	   2 	 1/3H  	 1/1T  	 2/3H  	 3/6   	 4/9    	4	 2:05.3 	 32  	 J Jamieson    	\N	 V Cochrane
\N	133	1	7	 Kuil Deva=            	    	   6 	 2/3H  	 3/2H  	 X5/17H	 5/23  	 5/16   	5	 2:07   	 30.3	 J Whelan      	\N	 J Whelan
\N	133	1	5	 Sweet Kimmy=          	    	   4X	 7/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 Ra Waples     	\N	 B Maxwell
\N	133	1	4	 Da Miracle            	    	   X3	 6/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 Trev Henry    	\N	 P Hunt
\N	145	1	7	 Gigs And Reels        	    	   7 	 7/8T  	 4@/1Q 	 1@/1H 	 1/1H  	 1/3H   	1	 2:01   	 30.2	 D Crowe       	3.65	 D Crowe
\N	145	1	8	 Putnams Legacy+       	    	   8 	 8/10  	 6@/3  	 4@@/2T	 3/2H  	 2/3H   	2	 2:01.3 	 30.2	 B Mccallum    	13.70	 B Mccallum
\N	145	1	3	 Flag Of Honor         	    	   3 	 2/1Q  	 3/1Q  	 3@/1T 	 2/1H  	 3/4T   	3	 2:02   	 31  	 J Ramsay Jr   	7.25	 D Settle
\N	145	1	4	 Metro Man             	    	   4 	 6/7Q  	 8@/4H 	 6@/4Q 	 5/5Q  	 4/7T   	4	 2:02.3 	 31.1	 P Langille    	7.35	 K Gillis
\N	145	1	1	 Prime Time Cowboy     	    	   1 	 4/3   	 5/2T  	 5/4Q  	 4/5   	 5/8    	5	 2:02.3 	 31.1	 D Romo        	1.15	 K Harper
\N	145	1	2	 J Gs Waylon           	    	   2 	 5/5   	 7/4   	 7/5T  	 6/7Q  	 6/11T  	6	 2:03.2 	 31.3	 D Spence      	13.70	 T Maclean
\N	145	1	6	 Secret Fantasy        	    	   6 	 1/1Q  	 1/Q   	 2/1H  	 7/8Q  	 7/22Q  	7	 2:05.2 	 34.3	 R Ellis       	8.45	 R Chase
\N	145	1	5	 Milliondollarkevin    	    	   5 	 3@/1T 	 2@/Q  	 8/13T 	 8/18Q 	 8/30Q  	8	 2:07   	 33.3	 Ma Campbell   	3.70	 S Dixon
\N	145	2	3	 Colin N Down          	    	   3 	 2@/NS 	 1/2Q  	 1/1H  	 1/1H  	 1/2Q   	1	 2:00   	 29.2	 G Barrieau    	0.40	 S Mason
\N	145	2	4	 J J Antonio           	    	   4 	 1/NS  	 2/2Q  	 2/1H  	 2/1H  	 2/2Q   	2	 2:00.2 	 29.3	 T Trites      	3.25	 E Watts
\N	145	2	5	 Ashes To Ashes        	    	   5 	 5/7Q  	 5/6H  	 4/3T  	 4/3Q  	 3/2Q   	3	 2:00.2 	 29  	 J Hughes      	0.65	 B Mckenna
\N	145	2	1	 Cowboys Dont Cry      	    	   1 	 3/1Q  	 3/3T  	 3/2H  	 3/2H  	 4/3T   	4	 2:00.4 	 29.4	 Ma Campbell   	4.05	 K Maclean
\N	145	2	2	 Private Paradise      	    	   2 	 4/5Q  	 4@/4  	 5/8Q  	 5/10Q 	 5/21Q  	5	 2:04.1 	 32  	 R Ellis       	8.60	 W Mackinnon
\N	145	3	5	 Ic A Free Spirit      	    	   5 	 1/2   	 1/1   	 1/2H  	 1/2   	 1/NK   	1	 2:00.4 	 29.4	 E Laffin      	1.05	 E Laffin
\N	145	3	4	 J J Cassius           	    	   4 	 2@/2  	 3/2   	 2/2H  	 2/2   	 2/NK   	2	 2:00.4 	 29.2	 D Romo        	5.90	 J Belliveau
\N	145	3	1	 Last Laugh            	    	   1 	 5/10H 	 5/7   	 5/7T  	 5/9   	 3/12   	3	 2:03.1 	 30.3	 A Camilli     	3.35	 A Camilli
\N	145	3	2	 P H Bossman           	    	   2 	 3/3   	 4/4H  	 4/4H  	 4/5T  	 4/13   	4	 2:03.2 	 31.3	 T Trites      	5.20	 Dr T Shive
\N	145	3	3	 Brookdale Jim         	    	   3 	 6/13  	 6/11Q 	 6/12T 	 6/16  	 5/22   	5	 2:05.1 	 31.3	 B Mccallum    	10.65	 B Mccallum
\N	145	3	6	 Windemeredancenart    	    	   6 	 4/5H  	 2@/1  	 3@X/3H	 3/5   	 6/43   	6	 2:09.2 	 37.4	 Ma Campbell   	2.70	 E Watts
\N	145	4	4	 N S Acadian           	    	   4 	 1/2H  	 1/1Q  	 1/3T  	 1/3T  	 1/6H   	1	 1:57.4 	 29.3	 Ma Campbell   	1.30	 H Smallwood
\N	145	4	3	 Brookdale Buster      	    	   3 	 2/2H  	 2/1Q  	 2/3T  	 2/3T  	 2/6H   	2	 1:59   	 30  	 B Mccallum    	1.60	 B Mccallum
\N	145	4	2	 Pictonians Derbie     	    	   2 	 4/9Q  	 4/6Q  	 4/6T  	 4/5H  	 3/7H   	3	 1:59.1 	 29.3	 A Campbell    	10.75	 B Mccallum
\N	145	4	1	 A Regal Beauty        	    	   1 	 3/7H  	 3/4   	 3@/4Q 	 3/4Q  	 4/7T   	4	 1:59.2 	 30.2	 D Spence      	3.50	 J Burton
\N	145	4	7	 P H Powerful          	    	   6 	 6/13T 	 6/9T  	 6@/9H 	 6/9Q  	 5/12Q  	5	 2:00.1 	 30.1	 T Trites      	11.50	 H Mac Kay
\N	145	4	5	 Ilava                 	    	   5 	 5/12Q 	 5/8Q  	 5@/8  	 5/6T  	 6/13H  	6	 2:00.2 	 30.3	 D Romo        	8.80	 J Janega
\N	145	4	8	 Maiden Heaven         	    	   7 	 7/15Q 	 7/11T 	 7/11H 	 7/11H 	 7/14Q  	7	 2:00.3 	 30.1	 P Langille    	14.60	 P Langille
\N	145	4	6	 Bad Break             	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
\N	145	5	4	 Matts Tuition         	    	   4 	 7/7Q  	 6@/6  	 5@@/2Q	 4/1H  	 1/H    	1	 2:04.1 	 31.4	 D Crowe       	1.45	 D Crowe
\N	145	5	2	 Dixie Flyer           	    	   2 	 2/1Q  	 3/2Q  	 2@/H  	 1/1   	 2/H    	2	 2:04.1 	 32.1	 G Barrieau    	1.60	 G Barrieau
\N	145	5	5	 Dividend Day          	    	   5 	 5/4Q  	 5@/4T 	 6@/3H 	 6/2T  	 3/1T   	3	 2:04.3 	 32  	 S Mason       	10.05	 S Mason
\N	145	5	1	 Rj Gigolo             	    	   1 	 4/2T  	 4/3H  	 4@/2Q 	 3/1H  	 4/2    	4	 2:04.3 	 32.1	 D Carey       	9.15	 J Green
\N	145	5	7	 Big Joe Doby          	    	   7 	 3@/1T 	 2@/1  	 1/H   	 2/1   	 5/4Q   	5	 2:05   	 33  	 D Romo        	6.75	 G Mc Callum
\N	145	5	3	 Howmacs Dragonator    	    	   3 	 6/5H  	 7/6Q  	 7/3H  	 7/4Q  	 6/5    	6	 2:05.1 	 32.3	 B Mccallum    	8.00	 B Mccallum
\N	145	5	6	 Slide Guitar          	    	   6 	 1/1Q  	 1/1   	 3/2   	 5/2H  	 7/5Q   	7	 2:05.1 	 32.4	 P Langille    	5.65	 P Pinkney
\N	145	6	3	 Mighty Cowboy         	    	   3 	 1/1H  	 1/1T  	 1/T   	 1/1Q  	 1/1    	1	 2:00.1 	 29  	 D Crowe       	0.55	 D Crowe
\N	145	6	4	 Complete Player       	    	   4 	 2/1H  	 2/1T  	 3/1T  	 3/1H  	 2/1    	2	 2:00.2 	 28.4	 M Bradley     	2.50	 T Weatherbi
\N	145	6	6	 Libertys Choice       	    	   5 	 5/5H  	 4@/5  	 2@/T  	 2/1Q  	 3/2    	3	 2:00.3 	 29.1	 J Hughes      	7.55	 J Hughes
\N	145	6	1	 The Hawk              	    	   1 	 3/3H  	 3/4   	 4/3T  	 4/3   	 4/4Q   	4	 2:01   	 29  	 D Romo        	3.75	 D Romo
\N	145	6	2	 Windemerenightlife    	    	   2 	 4/4Q  	 5/6   	 5@/4T 	 5/5H  	 5/9Q   	5	 2:02   	 29.4	 Ma Campbell   	7.15	 E Watts
\N	145	6	5	 Casstielle            	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
\N	146	1	7	 Our Star              	    	   7 	 7/8H  	 7@/8  	 2@/1Q 	 1/1   	 1/4    	1	 1:58   	 29.3	 R Ellis       	1.85	 G Rennison
\N	146	1	1	 Pride Of Paradise     	    	   1 	 3/2H  	 1/3H  	 1/1Q  	 2/1   	 2/4    	2	 1:58.4 	 30.3	 Ma Campbell   	7.90	 H Smallwood
\N	146	1	8	 Sharon The Moment     	    	   8 	 8/10  	 8/9Q  	 4@/3T 	 3/2Q  	 3/4H   	3	 1:58.4 	 29.4	 D Carey       	11.25	 D Carey
\N	146	1	4	 Lil Orphan Cam        	    	   4 	 6@/6T 	 5@/6Q 	 6@/4T 	 4/4Q  	 4/5Q   	4	 1:59   	 29.4	 P Langille    	3.25	 J Ellis
\N	146	1	6	 Arizona Bucks         	    	   6 	 4/4   	 4@/5  	 3/3T  	 5/4T  	 5/8T   	5	 1:59.4 	 30.4	 G Barrieau    	4.40	 D Pinkney
\N	146	1	2	 Eye Forty Seven       	    	   2 	 2/T   	 3/4T  	 8/6H  	 7/7Q  	 6/9    	6	 1:59.4 	 30.2	 T Trites      	6.10	 J Burton
\N	146	1	3	 Go With It            	    	   3 	 5/5H  	 6/7   	 7@/6Q 	 6/7   	 7/9Q   	7	 1:59.4 	 30.2	 B Mccallum    	8.30	 G Mccabe
\N	146	1	5	 I C Anastro           	    	   5 	 1@/T  	 IP2/3H	 5/4T  	 8/9H  	 8/17   	8	 2:01.2 	 32.1	 D Spence      	5.40	 N White
\N	146	2	6	 Jigtime Jones         	    	   6 	 4/7T  	 4/4T  	 4@/2T 	 1/Q   	 1/1    	1	 2:00   	 29.2	 R Macdonald   	4.30	 M Macdonald
\N	146	2	4	 Nameisonthehalter     	    	   4 	 3/5T  	 3@/3  	 2@/1  	 2/Q   	 2/1    	2	 2:00.1 	 30  	 G Barrieau    	0.70	 L Snow
\N	146	2	5	 Lucbobski             	    	   5 	 6/12T 	 6/8   	 6/6H  	 6/4   	 3/2    	3	 2:00.2 	 29.1	 D Romo        	4.90	 D Romo
\N	146	2	2	 Pownal Bay Saul       	    	   2 	 2/2Q  	 2/1T  	 3/1H  	 4/2Q  	 4/2H   	4	 2:00.2 	 30.1	 M Bradley     	34.30	 T Weatherbi
\N	146	2	3	 Ryans Allstar         	    	   3 	 5/10H 	 5/6Q  	 5@/5Q 	 5/3T  	 5/7T   	5	 2:01.3 	 30.3	 Ma Campbell   	3.65	 Ma Campbell
\N	146	2	1	 Windemerefallnforu    	    	   1 	 1/2Q  	 1/1T  	 1/1   	 3/1Q  	 6/13Q  	6	 2:02.3 	 32.3	 T Trites      	4.30	 E Watts
\N	146	3	2	 Distinctiv Rusty      	    	   2 	 1/2   	 1/2T  	 1/1H  	 1/1H  	 1/2    	1	 1:56.1 	 28.4	 R Ellis       	0.45	 G Rennison
\N	146	3	4	 Gerries Beach         	    	   4 	 2/2   	 2/2T  	 2/1H  	 2/1H  	 2/2    	2	 1:56.3 	 29  	 D Romo        	4.45	 K Harper
\N	146	3	1	 Mortal Combat         	    	   X1	 4/5Q  	 4/5Q  	 3/3   	 3/3H  	 3/3T   	3	 1:57   	 29  	 D Spence      	3.05	 A Maclean
\N	146	3	6	 J Rs Hurricane        	    	   6 	 6@/8  	 6/10  	 6@/6  	 6/8   	 4/9Q   	4	 1:58   	 29.2	 G Barrieau    	4.80	 J Belliveau
\N	146	3	3	 Dontstandinmyway      	    	   3 	 5/7   	 5/8   	 5/5   	 4/6T  	 5/9H   	5	 1:58   	 29.3	 P Rogerson    	54.55	 P Rogerson
\N	146	3	5	 Threes A Crowd        	    	   5 	 3/3H  	 3@/3Q 	 4@/4  	 5/6T  	 6/12Q  	6	 1:58.3 	 30.2	 T Trites      	12.05	 Dr T Shive
\N	146	4	6	 Tobinator             	    	   6 	 1/2T  	 1/2H  	 1/2   	 1/2Q  	 1/T    	1	 1:58   	 28.2	 R Ellis       	1.25	 T Hicken
\N	146	4	1	 Carters Caper         	    	   1 	 2/2T  	 2/2H  	 2/2   	 2/2Q  	 2/T    	2	 1:58.1 	 28.1	 M Macdonald   	1.15	 M Macdonald
\N	146	4	2	 Southsidelightning    	    	   2 	 3/4   	 4/4Q  	 4/3T  	 4/4   	 3/8    	3	 1:59.3 	 29.1	 M Bradley     	7.25	 T Weatherbi
\N	146	4	4	 Island Energetic      	    	   4 	 5/9T  	 5@/4T 	 5@@/3T	 3/3T  	 4/8Q   	4	 1:59.3 	 29.1	 D Romo        	4.95	 D Romo
\N	146	4	3	 Woodmere Soul         	    	   3 	 4/6H  	 3@/3Q 	 3@/3  	 5/4H  	 5/11H  	5	 2:00.1 	 30  	 G Barrieau    	5.40	 E Watts
\N	146	4	5	 Jdcyril               	    	   5 	 6/11Q 	 6@/6Q 	 6/5   	 6/6H  	 6/13T  	6	 2:00.4 	 30.1	 Ma Campbell   	48.65	 K Maclean
\N	146	5	1	 Oppies Artist         	    	   1 	 1/2Q  	 1/1T  	 1/1T  	 1/1Q  	 1/1T   	1	 1:57.1 	 30.3	 A Campbell    	2.85	 A Campbell
\N	146	5	7	 Four Starz Hold Em    	    	   7 	 2/2Q  	 2/1T  	 2/1T  	 2/1Q  	 2/1T   	2	 1:57.3 	 30.3	 D Spence      	3.10	 N White
\N	146	5	3	 Putnams Force+        	    	   3 	 I4/8H 	 3@/5T 	 4/3T  	 4/3   	 3/2T   	3	 1:57.4 	 30.2	 T Trites      	4.25	 J Green
\N	146	5	4	 Djs Kocakolacowboy    	    	   4 	 5/11Q 	 5@/7  	 3@/2T 	 3/2Q  	 4/7T   	4	 1:58.4 	 31.3	 Ma Campbell   	2.80	 H Smallwood
\N	146	5	6	 Brookdale Liz         	    	   6 	 7/14T 	 6@/12 	 6/6T  	 5/5Q  	 5/9T   	5	 1:59.1 	 31.1	 B Mccallum    	4.45	 B Mccallum
\N	146	5	2	 Eyebebuckntuff        	    	   2 	 X3/7Q 	 4/6T  	 5@/5T 	 6/6T  	 6/10H  	6	 1:59.1 	 31.2	 J Ramsay Jr   	4.30	 D Oconnor
\N	146	5	5	 Dashwood Darling      	    	   5 	 6/13Q 	 7/12Q 	 7@/8  	 7/8   	 7/17Q  	7	 2:00.3 	 32.2	 P Langille    	20.90	 T Ellis
\N	146	5	9	 Bizzy Izzy            	    	   8 	 8/16H 	 8/14T 	 8@/12 	 8/11T 	 8/17Q  	8	 2:00.3 	 31.3	 D Carey       	\N	 N White
\N	146	5	8	 Electric Syl          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	118	1	5	 Last Lecture          	    	   4 	 1/1H  	 1/1T  	 1/1T  	 1/2   	 1/HD   	1	 1:59.4 	 29.2	 J Mayhew      	\N	 J Mayhew
\N	118	1	6	 Goldies Bad Girl      	    	   5 	 2/1H  	 2/1T  	 2/1T  	 2/2   	 2/HD   	2	 1:59.4 	 29  	 A Moore       	\N	 G Price
\N	118	1	1	 Homey Joe             	    	   1 	 5/6   	 5@/6  	 3@/2T 	 3/2   	 3/1Q   	3	 2:00   	 29  	 M Macquarrie  	\N	 M Macquarri
\N	118	1	3	 Apocolyps Seelster    	    	   2 	 3/3H  	 3/3T  	 4/3T  	 4/4   	 4/4Q   	4	 2:00.3 	 29.2	 G Rooney      	\N	 F Maguire
\N	118	1	4	 Astreos Squirt        	    	   3 	 4@/4  	 4/5H  	 5/5T  	 5/6   	 5/5T   	5	 2:01   	 29.2	 A Hamlin      	\N	 S Zubaty
\N	118	2	3	 Magical Pockets       	    	   2 	 1/2   	 1/2   	 1/2   	 1/3   	 1/5T   	1	 2:01   	 29.3	 D Rankin Jr   	\N	 R Fulmer
\N	118	2	5	 Justice Delight=      	    	   4 	 2/2   	 2/2   	 2/2   	 2/3   	 2/5T   	2	 2:02.1 	 30.2	 M Hamlin      	\N	 M Hamlin
\N	118	2	4	 Jimori Shimmer=       	    	   3 	 3/3T  	 3/3T  	 3/4   	 3/4   	 3/11   	3	 2:03.1 	 31  	 G Rooney      	\N	 J Ellis
\N	118	2	1	 Striking Nikee        	    	   1 	 4/5T  	 4/6T  	 4/9   	 4/10  	 4/15H  	4	 2:04   	 30.4	 J Obrien      	\N	 J Obrien
\N	72	1	5	 Appellate             	    	   5 	 6/13  	 6/15H 	 3/7H  	 3/3Q  	 1/H    	1	 1:58.4 	 28.4	 K Clark       	\N	 K Clark
\N	72	1	3	 Whisper Well          	    	   3 	 2/4   	 2/1H  	 1/1H  	 1/3   	 2/H    	2	 1:58.4 	 30.1	 B Watt        	\N	 B Watt
\N	72	1	6	 Hollywood Redneck     	    	   6 	 1/4   	 1/1H  	 2/1H  	 2/3   	 3/4Q   	3	 1:59.3 	 30.4	 G Hudon       	\N	 G Hudon
\N	72	1	4	 A Wish For Wings      	    	   4 	 5/11  	 5/11H 	 5/15H 	 5/15T 	 4/16Q  	4	 2:02   	 30.2	 J Gray        	\N	 S Crump
\N	72	1	1	 Speed Shift           	    	   1 	 3/6   	 3/6H  	 4/14H 	 4/15Q 	 5/20   	5	 2:02.4 	 31.2	 M Hennessy    	\N	 K Read
\N	72	1	2	 Fast Lane Denali      	    	   2 	 4/8   	 4/9H  	 6/16H 	 6/19T 	 6/25T  	6	 2:04   	 32.1	 N Sobey       	\N	 T Tracey
\N	72	2	4	 Lil Bit O Jingle      	    	   4 	 2@/HD 	 1/1H  	 1/1H  	 1/2   	 1/6    	1	 2:02.1 	 29.4	 T Cullen      	\N	 T Cullen
\N	72	2	6	 Latestngreatest       	    	   6 	 1/HD  	 2/1H  	 2/1H  	 2/2   	 2/6    	2	 2:03.2 	 30.4	 K Clark       	\N	 K Clark
\N	72	2	3	 Blue Star Cascade     	    	   3 	 5/6Q  	 5/12H 	 5/10H 	 3/8   	 3/8H   	3	 2:03.4 	 29.2	 G Hudon       	\N	 G Hudon
\N	72	2	8	 Heated Exchange       	    	   8 	 7/11Q 	 7/17H 	 6@/12H	 5/10  	 4/9T   	4	 2:04.1 	 29.2	 R Cullen      	\N	 T Cullen
\N	72	2	1	 Cenalta Cougar        	    	   1 	 3/2Q  	 3/7H  	 3/7H  	 4/9   	 5/11Q  	5	 2:04.2 	 30.3	 T Redwood     	\N	 D Stout
\N	72	2	2	 Make Some Smiles      	    	   2 	 4/4Q  	 4/10H 	 4/9H  	 6/10H 	 6/11T  	6	 2:04.3 	 30.2	 K Hoerdt      	\N	 K Hoerdt
\N	72	2	5	 Starry Eyes           	    	   5 	 6/8T  	 6/15H 	 7/14  	 7/16H 	 7/20T  	7	 2:06.2 	 31.1	 D Sifert      	\N	 D Sifert
\N	72	2	7	 Orangevale Gazette    	    	   X7	 8/15Q 	 8/22H 	 8/24  	 8/29  	 8/36H  	8	 2:09.2 	 32.1	 M Bourgeois   	\N	 M Bourgeois
\N	72	3	5	 Capitol Hill          	    	   5 	 4/4H  	 4/7   	 3@/2Q 	 2/HD  	 1/2    	1	 2:03.2 	 30  	 G Clark       	\N	 S Crump
\N	72	3	4	 Formula D M           	    	   4 	 1/1H  	 1/2   	 1/2   	 1/HD  	 2/2    	2	 2:03.4 	 30.4	 G Hudon       	\N	 K Read
\N	72	3	6	 Lilmessinaround       	    	   6 	 5/6   	 5/10  	 5@/5T 	 4/5T  	 3/4H   	3	 2:04.1 	 30  	 R Schneider   	\N	 R Schneider
\N	72	3	2	 The Insinerator       	    	   2 	 2/1H  	 2/2   	 2/2   	 3/5Q  	 4/12   	4	 2:05.4 	 32.2	 D Hudon       	\N	 G Abbott
\N	72	3	1	 Ganymeda Gold         	    	   1 	 3/3   	 3/5H  	 4/5Q  	 5/9T  	 5/18Q  	5	 2:07   	 33  	 N Sobey       	\N	 N Sobey
\N	72	3	3	 El Capone             	    	   3X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 T Tracey      	\N	 T Tracey
\N	73	1	5	 Cowboys Dirtyboots    	    	   5 	 4/5   	 4/5   	 4/4H  	 5/5H  	 1/H    	1	 1:57.4 	 29.1	 R Grundy      	7.60	 D Crick
\N	73	1	2	 Hollywood Redneck     	    	   2 	 2/1H  	 2/1H  	 2/1H  	 2/2   	 2/H    	2	 1:57.4 	 29.4	 G Hudon       	9.75	 G Hudon
\N	73	1	4	 Vow To Win            	    	   4 	 3/3H  	 3/3H  	 3/3   	 3/3   	 3/1    	3	 1:58   	 29.3	 D Hudon       	8.15	 Q Schneider
\N	73	1	1	 Rock Shooter          	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 4/1Q   	4	 1:58   	 30.1	 T Cullen      	0.30	 T Cullen
\N	73	1	6	 Rare Breed            	    	   6 	 5/6H  	 5/6H  	 5/6   	 4/5   	 5/4    	5	 1:58.3 	 29.3	 M Hennessy    	15.65	 D Sifert
\N	73	1	3	 Swing N Ace           	    	   X3	 6/DIS 	 6/35  	 6/35  	 6/30  	 6/27H  	6	 2:03.1 	 28.2	 E Hensley     	9.15	 A Hensley
\N	73	2	6	 Cenalta Jade          	    	   6 	 5@/3T 	 4@/2Q 	 2@/HD 	 2/2   	 1/NK   	1	 2:02   	 32.3	 Jb Campbell   	2.05	 M Roy
\N	73	2	1	 Awhimaway             	    	   1 	 1/1H  	 1/HD  	 1/HD  	 1/2   	 2/NK   	2	 2:02   	 32.3	 K Clark       	4.95	 K Clark
\N	73	2	4	 Minettas Highball     	    	   4 	 6/4T  	 6/5Q  	 5/5   	 4/6H  	 3/1H   	3	 2:02.1 	 31.4	 K Ducharme    	4.95	 L Ducharme
\N	73	2	3	 Barbarela Rose        	    	   3 	 4/3Q  	 5@/4Q 	 6@@/5H	 I5/8  	 5P4/3T 	5	 2:02.4 	 32.2	 T Redwood     	3.45	 A Arsenault
\N	73	2	7	 Nevada                	    	   7 	 8/7T  	 8/7T  	 7@@/7 	 IX6/9H	 6P5/4Q 	6	 2:02.4 	 32  	 N Sobey       	24.35	 K Clark
\N	73	2	5	 Showmesomeemotion     	    	   5 	 7/6Q  	 7@/6Q 	 4@/3H 	 3/4H  	 4P6/2  	4	 2:02.2 	 32.2	 G Hudon       	4.35	 P Giesbrech
\N	73	2	2	 Forever Feisty        	    	   2 	 2/1H  	 3/1Q  	 3/3Q  	 7/10H 	 7/11T  	7	 2:04.2 	 34.2	 P Shaw        	42.50	 D Shaw
\N	73	2	8	 Exclusive             	    	   8 	 3@/1T 	 2@/HD 	 8/8   	 8/23  	 8/35H  	8	 2:09   	 38  	 D Hudon       	10.30	 S Arsenault
\N	73	3	2	 Mystery Mania         	    	   2 	 3/3H  	 3/3   	 1@/1  	 1/4   	 1/2T   	1	 2:00.1 	 31.1	 K Clark       	2.00	 K Clark
\N	73	3	5	 Whysantanna           	    	   5 	 7/10H 	 7/9   	 6/4H  	 8/8T  	 2/2T   	2	 2:00.4 	 31  	 M Hennessy    	3.80	 R Hennessy
\N	73	3	6	 Mystery Affair        	    	   6 	 8/12  	 8/10H 	 8@@/5H	 7/8Q  	 3/4H   	3	 2:01   	 31  	 G Hudon       	5.30	 P Giesbrech
\N	73	3	1	 Formula D M           	    	   1 	 4/5   	 4/4H  	 4@/2T 	 3/4Q  	 4/4T   	4	 2:01.1 	 31.3	 D Hudon       	19.20	 K Read
\N	73	3	4	 Brendons Eileen       	    	   4 	 6/9   	 6/7H  	 7@/5  	 6/7T  	 5/6Q   	5	 2:01.2 	 31.2	 P Shaw        	6.45	 D Sifert
\N	73	3	7	 Moon Struct           	    	   7 	 2/1H  	 2/1H  	 3/2H  	 5/6T  	 6/7    	6	 2:01.3 	 32.1	 N Sobey       	12.65	 G Lutz
\N	73	3	3	 Emmas Big Girl        	    	   3 	 5/7   	 5/6   	 5@@/4Q	 4/5T  	 7/7    	7	 2:01.3 	 31.4	 Jb Campbell   	3.35	 D Shaw
\N	73	3	8	 My Glorifly           	    	   8 	 1/1H  	 1/1H  	 2/1   	 2/4   	 8/8T   	8	 2:02   	 32.4	 R Grundy      	23.60	 D Crick
\N	73	4	3	 Mystic Messenger      	    	   3 	 1/4   	 1/1H  	 1/1H  	 1/2   	 1/2    	1	 1:57.4 	 29.1	 T Bowman      	4.30	 V Sifert
\N	73	4	1	 Heart N Hustle        	    	   1 	 2/4   	 2/1H  	 2/1H  	 2/2   	 2/2    	2	 1:58.1 	 29.2	 Jb Campbell   	4.25	 M Roy
\N	73	4	8	 Caliscape             	    	   8 	 5/8H  	 5@/5  	 5@@/3H	 6/7H  	 3/8    	3	 1:59.2 	 30.1	 T Cullen      	3.10	 T Cullen
\N	73	4	6	 Avonlee Knight        	    	   6 	 4/7   	 4@/3H 	 4@/3Q 	 5/7   	 4/9    	4	 1:59.3 	 30.2	 N Sobey       	6.05	 G Lutz
\N	73	4	4	 Coliseum Hanover      	    	   4 	 6/10  	 6/5H  	 6/4H  	 4I/6  	 6P5/9T 	6	 1:59.4 	 30.2	 R Cullen      	7.40	 T Cullen
\N	73	4	2	 Mister Meister        	    	   2 	 3/5H  	 3/3   	 3/3   	 3/4   	 5P6/9Q 	5	 1:59.3 	 30.2	 R Grundy      	8.90	 R Grundy
\N	73	4	5	 Promise We Can        	    	   5 	 7/11H 	 7@/6H 	 7@/5  	 7/8H  	 7/10T  	7	 2:00   	 30.2	 K Clark       	9.10	 G Lutz
\N	73	4	7	 Thisboycanfinish      	    	   7 	 8/13  	 8/7H  	 8@/6H 	 8/10  	 8/11H  	8	 2:00   	 30.1	 G Clark       	6.15	 S Crump
\N	73	5	8	 Mods Mystery          	    	   8 	 4/4H  	 4/4H  	 3@/1Q 	 1/Q   	 1/5Q   	1	 2:01.2 	 32  	 A Arsenault   	22.80	 A Arsenault
\N	73	5	3	 Crash My Party        	    	   3 	 1/1H  	 1/1H  	 2/1   	 4/2   	 2/5Q   	2	 2:02.2 	 33  	 G Hudon       	1.15	 G Hudon
\N	73	5	5	 Lissie Borden         	    	   5 	 2@/1H 	 2/1H  	 1@/1  	 2/Q   	 3/6H   	3	 2:02.3 	 33.2	 T Cullen      	2.25	 D Lamont
\N	73	5	4	 Hf Princess Peach     	    	   4 	 6/9   	 7/8   	 6@/5Q 	 3/1T  	 4/6H   	4	 2:02.3 	 32.2	 M Hennessy    	17.30	 H Haining
\N	73	5	1	 Starry Eyes           	    	   1 	 5/7H  	 5/6H  	 7/7Q  	 7/6H  	 5/7H   	5	 2:02.4 	 32.1	 D Sifert      	11.95	 D Sifert
\N	73	5	6	 Is Santa Real         	    	   X6	 8/12H 	 6@/7H 	 4@/4Q 	 5/4   	 6/8Q   	6	 2:03   	 33  	 N Sobey       	6.25	 N Sobey
\N	73	5	7	 Fast Lane Denali      	    	   7 	 7/11  	 8/9H  	 8/9Q  	 8/8   	 7/8H   	7	 2:03   	 32  	 T Tracey      	23.20	 T Tracey
\N	73	5	2	 Miss Bojangles        	    	   2 	 3/3   	 3/3   	 5/4T  	 6/6   	 8/10Q  	8	 2:03.2 	 33.1	 K Clark       	8.40	 J Ratchford
\N	73	6	1	 Dickies Motel         	    	   1 	 2/1H  	 3/1H  	 3@/2  	 3/1T  	 1/1H   	1	 1:58.1 	 31.1	 Jb Campbell   	6.70	 R Schneider
\N	73	6	3	 Viola                 	    	   3 	 3/3   	 2@/H  	 1/1H  	 1/1H  	 2/1H   	2	 1:58.2 	 31.4	 J Hudon       	5.15	 J Hudon
\N	73	6	9	 P L Impressive        	    	   9 	 4/4H  	 5@/4  	 4/7   	 4/3T  	 3/2Q   	3	 1:58.3 	 30.3	 E Hensley     	4.80	 A Hensley
\N	73	6	5	 Happy Promise         	    	   5 	 1/1H  	 1/H   	 2/1H  	 2/1H  	 4/3Q   	4	 1:58.4 	 32  	 G Clark       	8.15	 G Clark
\N	73	6	7	 Royal Classic         	    	   7 	 8/13  	 8/8T  	 5/9   	 5/5T  	 5/4T   	5	 1:59.1 	 30.4	 D Hudon       	18.55	 Q Schneider
\N	73	6	6	 Wigesjet              	    	   6 	 7/11  	 7@/8H 	 6/10H 	 6/9T  	 6/10   	6	 2:00.1 	 31.3	 T Cullen      	4.55	 J Marchment
\N	73	6	8	 Hoofenanny            	    	   8 	 9/14H 	 9/10Q 	 7/13H 	 7/12T 	 7/11Q  	7	 2:00.2 	 31.1	 M Hennessy    	16.35	 D Cutting
\N	73	6	2	 Club Dreams           	    	   2 	 6/9   	 4/3H  	 X8/23H	 8/17T 	 8DQ/14T	8	 2:01.1 	 30  	 D A Kelly     	7.80	 R Parish
\N	73	6	4	 Terra True            	    	   4 	 5/7H  	 6@/5H 	 IX9/DI	 FELL  	 DNF    	\N	        	     	 G Hudon       	3.05	 G Hudon
\N	74	1	5	 Sudden Storm          	    	   5 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/T    	1	 1:58.2 	 29.3	 T Bowman      	4.40	 D Sifert
\N	74	1	6	 Outlaw This Is It     	    	   6 	 6@/8  	 5@/3H 	 2@/H  	 2/1H  	 2/T    	2	 1:58.3 	 29.4	 T Redwood     	6.15	 D Stout
\N	74	1	7	 Canelo                	    	   7 	 2/1H  	 3/1T  	 3/2   	 3/3H  	 3/3H   	3	 1:59   	 29.4	 T Cullen      	2.70	 T Cullen
\N	74	1	9	 Scrappy Fella         	    	   9 	 8/10H 	 7@/5H 	 4@/4  	 4/6H  	 4/4H   	4	 1:59.1 	 29.3	 M Hennessy    	4.45	 R Hennessy
\N	74	1	4	 Cenalta Eclipse       	    	   4 	 7/9   	 8/7   	 6/5H  	 5/8H  	 5/4T   	5	 1:59.2 	 29.3	 R Goulet      	2.95	 G Empey
\N	74	1	1	 Shyloh Sage           	    	   1 	 3/3   	 4/3Q  	 5/5   	 6/9H  	 6/8T   	6	 2:00.1 	 30.2	 A Arsenault   	10.55	 A Arsenault
\N	74	1	3	 Thisboyisonfire       	    	   3 	 5/7H  	 6/5   	 7/7   	 7/13H 	 7/18   	7	 2:02   	 31.4	 Jb Campbell   	22.55	 Jb Campbell
\N	74	1	2	 Speed Shift           	    	   2 	 4/4H  	 2@/1H 	 8@/7H 	 8/17H 	 8/21T  	8	 2:02.4 	 32.3	 G Hudon       	15.20	 K Read
\N	74	1	8	 Sayitlikeyoumeanit    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	74	2	6	 Kim Chee              	    	   6 	 4/4H  	 4@/3T 	 3@/2H 	 2/2   	 1/NK   	1	 1:58.2 	 30  	 N Sobey       	3.00	 G Lutz
\N	74	2	4	 Shes A Ladro          	    	   4 	 1/1H  	 1/2   	 1/2   	 1/2   	 2/NK   	2	 1:58.2 	 30.2	 B Gray        	13.10	 B Gray
\N	74	2	9	 Yanotherhos           	    	   9 	 5/6   	 5@/5Q 	 5@/3T 	 4/4H  	 3/1    	3	 1:58.3 	 29.4	 T Bowman      	2.70	 J Waltenbur
\N	74	2	1	 Fast Lane Ferrari     	    	   1 	 2/1H  	 2/2   	 2/2   	 3/3H  	 4/3T   	4	 1:59.1 	 30.4	 D Hudon       	6.20	 D Hudon
\N	74	2	8	 Triple Action         	    	   8 	 9/12  	 9/9H  	 7@@/6H	 5/9H  	 5/8T   	5	 2:00.1 	 31  	 G Hudon       	17.60	 J Ratchford
\N	74	2	3	 Run And Tell          	    	   3 	 7/9   	 7/7T  	 9@@/8T	 9/11  	 6/9H   	6	 2:00.1 	 30.2	 T Tracey      	5.55	 T Tracey
\N	74	2	5	 Three Wishes          	    	   5 	 8/10H 	 8@/8  	 6@/6Q 	 8/10H 	 7/10T  	7	 2:00.3 	 31.2	 T Cullen      	4.25	 K Howard
\N	74	2	7	 Little Sister         	    	   7 	 3/3   	 3@/2Q 	 4/3H  	 6/9T  	 8/14   	8	 2:01.1 	 32.3	 T Redwood     	13.70	 A Macleod
\N	74	2	2	 Market For Romance    	    	   2 	 6/7H  	 6/5T  	 8/6T  	 7/10Q 	 9/16T  	9	 2:01.4 	 32.2	 K Ducharme    	31.20	 K Ducharme
\N	77	1	3	 Bees Burner           	    	   3 	 3/3   	 3/3   	 2/1H  	 2/2   	 1/H    	1	 2:04   	 31  	 J Gagne       	\N	 M Dumont
\N	77	1	5	 Smokin Barrels        	    	   5 	 1/1H  	 2/1H  	 1/1H  	 1/2   	 2/H    	2	 2:04   	 31.1	 N Sobey       	\N	 J Waltenbur
\N	77	1	4	 Rollin In Paris       	    	   4 	 4/5   	 4/4H  	 3/2   	 3/4   	 3/2    	3	 2:04.2 	 31.1	 T Bowman      	\N	 R Lancaster
\N	77	1	2	 Coz And Effect        	    	   2X	 5/7   	 5/6   	 4/6   	 4/5H  	 4/4    	4	 2:04.4 	 30.4	 T Redwood     	\N	 D Stout
\N	77	1	1	 Fescue                	    	   1 	 2/1H  	 1/1H  	 X5/8  	 5/15H 	 5/15Q  	5	 2:07   	 32.3	 R Hennessy    	\N	 S Johnson
\N	80	1	2	 Mateo                 	    	   2 	 2/2   	 2@/Q  	 1/3   	 1/4   	 1/6    	1	 2:02   	 29  	 E Hensley     	\N	 D Cutting
\N	80	1	4	 Stylomilohos          	    	   4 	 4/7   	 4/4Q  	 3@/5  	 2/4   	 2/6    	2	 2:03.1 	 29.1	 T Bowman      	\N	 R Lancaster
\N	80	1	1	 Outlawintriguedbyu    	    	   1 	 3/5   	 3@/2T 	 2X/3  	 3/12  	 3/14H  	3	 2:04.4 	 31.1	 C Kolthammer  	\N	 C Kolthamme
\N	80	1	3	 Brain Teaser          	    	   3 	 5/9   	 5/9Q  	 5/12  	 5/21  	 4/22H  	4	 2:06.2 	 31  	 R Grundy      	\N	 R Grundy
\N	80	1	5	 Hf Flying Glory       	    	   5 	 1/2   	 1/Q   	 4/7   	 4/19  	 5/25H  	5	 2:07   	 32.3	 H Haining     	\N	 H Haining
\N	80	1	6	 Orangevale Gazette    	    	   X6	 6/21  	 6/20  	 6/32  	 6/DIS 	 6/DIS  	6	        	     	 D Hudon       	\N	 M Bourgeois
\N	80	2	3	 Fire Of The Dragon    	    	   3 	 3/3   	 4/4H  	 3/3H  	 2/Q   	 1/T    	1	 2:02.2 	 29.4	 T Bowman      	\N	 R Lancaster
\N	80	2	5	 Bettah                	    	   5 	 2/1H  	 3/3   	 2/2   	 3/2Q  	 2/T    	2	 2:02.3 	 30.1	 Jb Campbell   	\N	 S Crump
\N	80	2	4	 Makin My Move         	    	   4 	 1/1H  	 2/1H  	 1/2   	 1/Q   	 3/1H   	3	 2:02.3 	 30.3	 T Cullen      	\N	 T Cullen
\N	80	2	2	 Chief Saratoga        	    	   2 	 5/7   	 5/6   	 4/5   	 4/4Q  	 4/1T   	4	 2:02.4 	 29.4	 R Schneider   	\N	 R Schneider
\N	80	2	1	 West Town Lady        	    	   1 	 4/5   	 1/1H  	 5/5H  	 5/13  	 5/22Q  	5	 2:06.4 	 33.4	 N Sobey       	\N	 N Sobey
\N	80	3	4	 Skade                 	    	   4 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 1/3T   	1	 1:58.2 	 28.2	 Jb Campbell   	\N	 S Campbell
\N	80	3	2	 Nevermissabeat        	    	   2 	 3/3   	 3/3   	 3/3   	 3/4   	 2/3T   	2	 1:59.1 	 28.3	 R Goulet      	\N	 R Goulet
\N	80	3	1	 Final Say             	    	   1 	 2/1H  	 2/1H  	 2/1H  	 2/2   	 3/3T   	3	 1:59.1 	 29  	 T Bowman      	\N	 T Bowman
\N	80	3	3	 Little Bit Faster     	    	   3 	 4/4H  	 4/4H  	 4/4H  	 4/6   	 4/5H   	4	 1:59.2 	 28.3	 H Haining     	\N	 H Haining
\N	80	3	5	 Metajka Road          	    	   5 	 5/6   	 5/6   	 5/8H  	 5/8H  	 5/8T   	5	 2:00.1 	 28.3	 J Gagne       	\N	 M Dumont
\N	83	1	2	 Rewind Again          	    	   2 	 3/5H  	 3/4   	 1/8   	 1/11  	 1/14   	1	 2:02   	 30  	 K Murphy      	\N	 C Murphy
\N	83	1	3	 Ic Brandonscowgirl    	    	   3 	 4/9   	 4/10  	 3@/11 	 3/12  	 2/14   	2	 2:04.4 	 30.3	 A Merner      	\N	 A Merner
\N	83	1	4	 Gypsy Queen           	    	   4 	 1/3H  	 1/2   	 2/8   	 2/11  	 3/18H  	3	 2:05.3 	 32  	 N Myers       	\N	 M Macdonald
\N	83	1	1	 Monastery             	    	   1 	 2/3H  	 2/2   	 4/14  	 4/DIS 	 4/DIS  	4	        	     	 K Arsenault   	\N	 K Arsenault
\N	83	2	4	 Oceanview Pancho=     	    	   4 	 2/2H  	 2/2   	 2/2H  	 2/2H  	 1/H    	1	 2:06.4 	 30.3	 P Larrabee    	\N	 P Larrabee
\N	83	2	3	 B J Classic=          	    	   3 	 1/2H  	 1/2   	 1/2H  	 1/2H  	 2/H    	2	 2:06.4 	 31  	 Bri Macphee   	\N	 B Honkoop
\N	83	2	5	 Glencove Carter=      	    	   5 	 X3X/9 	 5/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 H Shepherd    	\N	 C Bagnall
\N	83	2	1	 Sanctified=           	    	   X1	 5/DIS 	 4/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 B Andrew      	\N	 B White
\N	83	2	2	 Glencove Zsa Zsa      	    	   2X	 4/DIS 	 3/DIS 	 5X/DIS	 X5/DIS	 5/DIS  	5	        	     	 K Arsenault   	\N	 C Bagnall
\N	83	3	3	 Mick Dundee           	    	   3 	 1/2   	 1/1T  	 1/2   	 1/H   	 1/T    	1	 2:01.4 	 29.1	 D Mac Neill   	\N	 D Mac Neill
\N	83	3	1	 Ascaryone Hanover     	    	   1 	 2/2   	 2/1T  	 2/2   	 2/H   	 2/T    	2	 2:02   	 29  	 K Murphy      	\N	 C Murphy
\N	83	3	2	 Jamiesmilingcowboy    	    	   2 	 3/4   	 3/3H  	 3/3H  	 X3/8  	 3/21   	3	 2:06   	 32.4	 K Arsenault   	\N	 K Arsenault
\N	83	4	1	 Sanchez Blue Chip     	    	   1 	 3/11  	 3/4Q  	 2@/1H 	 2/1H  	 1/1H   	1	 2:02   	 29.4	 V Poulton     	\N	 D Clow
\N	83	4	4	 Zanzibar+             	    	   4 	 1/8   	 1/2H  	 1/1H  	 1/1H  	 2/1H   	2	 2:02.1 	 30.1	 P Morrison    	\N	 P Morrison
\N	83	4	3	 Umiztagoodthing+      	    	   3 	 2/8   	 2/2H  	 3/2T  	 3/2T  	 3/2    	3	 2:02.2 	 29.4	 T Walsh       	\N	 T Walsh
\N	83	4	2	 Prynne Hanover+       	    	   2 	 4/13H 	 4/6   	 4@/3H 	 4/4H  	 X4/7H  	4	 2:03.2 	 30.4	 A Campbell    	\N	 R Squires
\N	86	1	4	 Frill Seeker=         	    	   3 	 1/30  	 1/33  	 1/37  	 1/38  	 1/39H  	1	 2:01   	 30.3	 G Hennessey   	\N	 K Arsenault
\N	86	1	1	 Sanctified=           	    	   1 	 2/30  	 2/33  	 2/37  	 2/38  	 2/39H  	2	 2:08.4 	 31  	 B Andrew      	\N	 B White
\N	86	1	2	 Glencove Carter=      	    	   X2	 3/DIS 	 PULLED	UP     	       	 DNF    	\N	        	     	 H Shepherd    	\N	 C Bagnall
\N	86	2	1	 Lorne Valley Lucy     	    	   1 	 1/3Q  	 1/2Q  	 1/2   	 1/1T  	 1/1    	1	 2:05   	 30.2	 G Chappell    	\N	 G Chappell
\N	86	2	2	 Kashkantbymeluv       	    	   2 	 2/3Q  	 2/2Q  	 2/2   	 2/1T  	 2/1    	2	 2:05.1 	 30.1	 D Mac Neill   	\N	 R Gass
\N	86	2	3	 Woodmere Intrepid     	    	   3 	 3/5H  	 3/4   	 3@/2Q 	 3/2H  	 3/4H   	3	 2:05.4 	 30.4	 Ma Campbell   	\N	 Ma Campbell
\N	86	3	2	 J J Dazzler           	    	   2 	 1/2   	 1/1H  	 1/1T  	 1/2Q  	 1/2    	1	 2:02.3 	 31.1	 M Mcguigan    	\N	 K Wilkie
\N	86	3	1	 Ourgirlellie          	    	   1 	 2/2   	 2/1H  	 2/1T  	 2/2Q  	 2/2    	2	 2:03   	 31.1	 P Lanigan     	\N	 P Lanigan
\N	119	1	6	 What A Promise        	    	   6 	 2/2   	 I1/3H 	 1/13  	 1/3   	 2P1/1H 	2	 2:14.2 	 35.3	 R Remillard   	4.45	 B Mcnaughto
\N	119	1	5	 Heartland Spark       	    	   5 	 5@/11 	 I4/5  	 3/13Q 	 3/12  	 3P2/18H	3	 2:17.4 	 36.2	 M Fillion     	0.95	 M Fillion
\N	119	1	4	 Trishas Fancy         	    	   4 	 3/6   	 IX6/15	 5/20  	 4/19  	 4P3/24 	4	 2:19   	 36.1	 K Rogers      	4.45	 K Rogers
\N	119	1	2	 Margies Candy         	    	   2 	 4/10  	 I3/3T 	 4/18  	 5/DIS 	 5P4/DIS	5	        	     	 R Rey         	\N	 R Rey
\N	119	1	7	 Dont Chud Me          	    	   7 	 6/12  	 IX5/8H	 6/25  	 6/DIS 	 6P5/DIS	6	        	     	 C Manning     	9.95	 C Manning
\N	119	1	3	 Luvn The Life         	    	   3 	 1/2   	 X2@/3H	 2@/13 	 2/3   	 1P6/1H 	1	 2:14.1 	 32.4	 D Rey         	0.95	 D Rey
\N	119	1	1	 Cordees Whitesocks    	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
\N	119	2	3	 Gold Star Sonata      	    	   3 	 1/1H  	 1/Q   	 2/H   	 2/2   	 1/NS   	1	 2:04.1 	 32  	 D Howlett     	3.45	 T Williams
\N	119	2	4	 Wild Chic             	    	   4 	 2/1H  	 2@/Q  	 1@/H  	 1/2   	 2/NS   	2	 2:04.1 	 32  	 R Remillard   	1.20	 R Remillard
\N	119	2	2	 Smoky Moon            	    	   2 	 4/5   	 3@/4H 	 3/6   	 3/13  	 3/13   	3	 2:06.4 	 33.2	 M Fillion     	1.40	 K Hildebran
\N	119	2	5	 Gottaluckydeal+       	    	   5 	 X6/14 	 6/9H  	 6@/11 	 4/18  	 4/21   	4	 2:08.2 	 34  	 C Manning     	\N	 C Manning
\N	119	2	1	 Come On Kathryn       	    	   1 	 3/3   	 4/4T  	 4/7H  	 5/19  	 5/25   	5	 2:09.1 	 35.3	 T Grundy      	5.65	 C Manning
\N	119	2	6	 Freedom Forever       	    	   6 	 5/7   	 5/7   	 5/10  	 6/37  	 6/39   	6	 2:12   	 37.4	 M Rey         	3.45	 M Rey Clark
\N	119	3	1	 Good Chemistry        	    	   1 	 2/1H  	 2/2H  	 2/2   	 3/1H  	 1/1    	1	 2:09.2 	 32  	 D Howlett     	2.50	 T Williams
\N	119	3	4	 Diggin A Trench       	    	   4 	 3/3   	 3/4H  	 3@/3  	 1/H   	 2/1    	2	 2:09.3 	 32  	 M Rey         	3.10	 R Rey
\N	119	3	5	 Home Matters          	    	   5 	 1/1H  	 1/2H  	 1/2   	 2/H   	 3/3    	3	 2:10   	 33  	 D Rey         	3.10	 R Rey
\N	119	3	3	 Redonkulous           	    	   3 	 4/4H  	 4/6H  	 4/5   	 4/11  	 4/12   	4	 2:11.4 	 33.4	 R Rey         	0.45	 R Rey
\N	119	3	2	 Mixed Blessings+      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
\N	123	1	1	 Bay Win               	    	   1 	 1/NR  	 1/NR  	 1/NR  	 1/NR  	 1/NR   	1	 2:07.3 	 31.1	 R Gillis      	\N	 D Beaton
\N	89	1	4	 Catch A Lucky Star    	    	   4 	 3/3T  	 3/3H  	 3/3H  	 3/2T  	 1/HD   	1	 2:00.3 	 29.2	 C Steacy      	\N	 J Watt
\N	89	1	3	 Rocket Art            	    	   3 	 1/2   	 1/1T  	 1/1T  	 1/1Q  	 2/HD   	2	 2:00.3 	 30  	 G Rooney      	\N	 D Meekison 
\N	89	1	2	 Watt A Funny Face     	    	   2 	 2/2   	 2/1T  	 2/1T  	 2/1Q  	 3/1    	3	 2:00.4 	 29.4	 C German      	\N	 J Watt
\N	89	1	1	 Shanghai Noodle       	    	   1 	 4/5T  	 4/5Q  	 4/5Q  	 4/4T  	 4/6    	4	 2:01.4 	 30.1	 G Mcclure     	\N	 G Mcclure
\N	90	1	8	 Daniellas Shadow      	    	   8 	 5/6   	 1@/H  	 1/2   	 1/2H  	 1/2Q   	1	 1:58.2 	 29.3	 J Harris      	29.35	 J Watt
\N	90	1	4	 Honi Maker            	    	   4 	 7/9Q  	 6@/4Q 	 4@@/3H	 2/2H  	 2/2Q   	2	 1:58.4 	 29.2	 L House       	7.70	 W Walker
\N	90	1	2	 Rocket Art            	    	   2 	 2/1H  	 3/2   	 5/4   	 4/8   	 3/9H   	3	 2:00.1 	 30.3	 R Holliday    	16.00	 D Meekison 
\N	90	1	1	 Shes All Good         	    	   1 	 1/1H  	 2/H   	 2/2   	 3/6H  	 4/9T   	4	 2:00.2 	 31.1	 N Steward     	0.60	 P Shepherd
\N	90	1	7	 Ivegotmyeyeonu        	    	   7 	 3/3   	 5/4Q  	 7/6   	 6/10H 	 5/10   	5	 2:00.2 	 30.2	 C Steacy      	16.65	 R Steward
\N	90	1	6	 Life On The Links     	    	   6 	 8/10T 	 8/7H  	 8/7H  	 7/12  	 6/10Q  	6	 2:00.2 	 30.1	 G Rooney      	11.25	 E Lock
\N	90	1	3	 Zinfandart            	    	   3 	 4/4H  	 7/6   	 6@/5  	 5/9   	 7/10T  	7	 2:00.3 	 30.4	 D Mcclure     	11.15	 G Mcclure
\N	90	1	5	 Whosurbeast           	    	   5 	 6/7H  	 4@/2H 	 3@/3  	 8/13Q 	 8/22H  	8	 2:02.4 	 33.2	 A Macdonald   	2.60	 J Darling
\N	90	2	6	 Little Quick          	    	   4 	 5/8   	 5@/4H 	 3@@/1H	 2/1Q  	 1/1H   	1	 1:58.1 	 28.4	 J Harris      	2.30	 J Watt
\N	90	2	7	 Kennairnlaughaloud    	    	   5 	 2/1H  	 2@/1  	 2@/H  	 3/1T  	 2/1H   	2	 1:58.2 	 29.1	 J Ryan        	1.20	 J Riehl
\N	90	2	2	 Its Machademic        	    	   1 	 3/4   	 3/2T  	 4/2H  	 4/4Q  	 3/2    	3	 1:58.3 	 29  	 L House       	3.20	 C Schneider
\N	90	2	5	 Cantcountmeout        	    	   3 	 1/1H  	 1/1   	 1/H   	 1/1Q  	 4/3H   	4	 1:58.4 	 29.3	 A Macdonald   	3.90	 A Macdonald
\N	90	2	4	 Distinctiv Cam        	    	   2 	 4/6H  	 4/4H  	 5/8H  	 5/12Q 	 5/12   	5	 2:00.3 	 29.4	 G Rooney      	6.85	 K Macnaught
\N	90	2	3	 Acton O So Royal      	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	90	2	1	 Hog Aufray            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	90	3	4	 Onatopp=              	    	   4 	 4/4H  	 2@/T  	 1@/1T 	 1/3H  	 1/1Q   	1	 2:03.4 	 30.2	 A Macdonald   	2.10	 A Macdonald
\N	90	3	6	 Burning Memories      	    	   6 	 5/6   	 4@/2T 	 2@/1T 	 3/3T  	 2/1Q   	2	 2:04   	 30.1	 L House       	2.70	 R Bryce
\N	90	3	1	 Highfield             	    	   1 	 3/3   	 5/4   	 4@/3T 	 4/5Q  	 3/1H   	3	 2:04   	 29.4	 Do Brown      	4.10	 P Forgie
\N	90	3	3	 Attitude To Burn=     	    	   3 	 2/1H  	 3/2Q  	 3/2Q  	 2/3H  	 4/2H   	4	 2:04.1 	 30.2	 R Holliday    	3.80	 K Haskell
\N	90	3	5	 Ink Master=           	    	   5 	 1/1H  	 1/T   	 X5/5  	 5/17  	 5/20   	5	 2:07.4 	 33.2	 N Steward     	3.30	 L Bako
\N	90	3	2	 For A Reason          	    	   2X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6BE/DIS	6	        	     	 H Lewis       	9.90	 V Cochrane
\N	90	4	1	 Win One Soon          	    	   1 	 1/1H  	 1/1   	 1/1H  	 1/1   	 1/1    	1	 1:56.3 	 28.4	 R Holliday    	2.15	 K Fritsch
\N	90	4	8	 Stoney Durkin         	    	   8 	 2/1H  	 3/2   	 3/1H  	 3/2   	 2/1    	2	 1:56.4 	 28.4	 N Steward     	3.70	 L Fitzsimmo
\N	90	4	3	 Camythical            	    	   3 	 6/11Q 	 4@/3Q 	 4/3   	 4/3H  	 3/3    	3	 1:57.1 	 28.4	 D Megens      	7.25	 D Megens
\N	90	4	2	 Derby Dylan           	    	   2 	 5/8T  	 2@/1  	 2@/1H 	 2/1   	 4/3Q   	4	 1:57.1 	 29.1	 L House       	5.15	 C Schneider
\N	90	4	7	 Colorado Buck         	    	   7 	 4/4Q  	 7/5T  	 8@/6Q 	 6/5   	 5/6Q   	5	 1:57.4 	 28.4	 A Macdonald   	9.45	 D Schweitze
\N	90	4	4	 Twilite Zone          	    	   4 	 7/13T 	 6@/4T 	 5@/4  	 5/3H  	 6/6Q   	6	 1:57.4 	 29.1	 Kn Oliver     	3.65	 Kn Oliver
\N	90	4	6	 Bugger Max            	    	   6 	 8/15T 	 8@/6T 	 7@@/6 	 8/7Q  	 7/10H  	7	 1:58.3 	 29.3	 J Harris      	8.95	 D Beatson
\N	90	4	5	 Rock N Roll Legacy    	    	   5 	 3@/3  	 5/3T  	 6/5   	 7/6   	 8/14   	8	 1:59.2 	 30.3	 G Rooney      	3.85	 R Marriage
\N	90	5	2	 Country Baran         	    	   2 	 2/2   	 2/1H  	 3@/2  	 2/1   	 1/T    	1	 1:59.3 	 28.4	 N Steward     	3.00	 L Fitzsimmo
\N	90	5	7	 Sws Caviar            	    	   7 	 5/9T  	 4@/5Q 	 1@/1  	 1/1   	 2/T    	2	 1:59.4 	 29.2	 R Holliday    	0.80	 J Kerr
\N	90	5	6	 Bradys Play           	    	   6 	 1/2   	 1/1H  	 2/1   	 3/3   	 3/4    	3	 2:00.2 	 29.4	 G Rooney      	4.10	 C Blake
\N	90	5	4	 Larjon Laney          	    	   4 	 3/6   	 3/3H  	 4/4   	 4/6   	 4/8Q   	4	 2:01.1 	 30  	 A Macdonald   	17.70	 L Lane
\N	90	5	1	 Vinmara               	    	   1 	 4/8   	 5/6Q  	 5@/5H 	 5/7Q  	 5/9T   	5	 2:01.3 	 30.1	 L House       	8.95	 A Shelton
\N	90	5	3	 Ponders Xample        	    	   3 	 6/11T 	 6/18Q 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 J Harris      	10.55	 F Maguire
\N	90	5	5	 Shanghai Noodle(vl)   	    	   5 	 7/13Q 	 X7X/28	 PULLED	UP     	 DNF    	\N	        	     	 D Mcclure     	9.90	 G Mcclure
\N	90	5	8	 Tailored Service      	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	90	6	1	 Grits N Gravy         	    	   1 	 1/2   	 1/1H  	 1/1   	 1/1   	 1/NK   	1	 1:59.2 	 29.1	 G Rooney      	1.80	 W Hamm
\N	90	6	8	 Flames Cammi Boy      	    	   8 	 2/2   	 2/1H  	 3/2   	 3/2   	 2/NK   	2	 1:59.2 	 28.4	 T Smith       	8.05	 J Walker
\N	90	6	2	 Jackstan              	    	   2 	 3/4   	 3@/2H 	 2@/1  	 2/1   	 3/2T   	3	 2:00   	 29.3	 R Holliday    	1.20	 F Maguire
\N	90	6	5	 Regal Roxy            	    	   4 	 6/9   	 5/5H  	 5/4   	 5/4   	 4/3Q   	4	 2:00   	 29  	 A Macdonald   	9.80	 T Gilkinson
\N	90	6	7	 Blue Chip Sunshine    	    	   6 	 4/5H  	 4@/4  	 4@/3  	 4/3   	 5/3H   	5	 2:00   	 29.1	 Kn Oliver     	7.50	 Kn Oliver
\N	90	6	6	 Stonebridge Scout     	    	   5 	 7/11  	 7/7Q  	 7/6H  	 7/6   	 6/4H   	6	 2:00.1 	 28.4	 L House       	11.75	 A Hardy
\N	90	6	3	 Only The Lonely       	    	   3 	 5/7Q  	 6@/5H 	 6@/5  	 6/5   	 7/6    	7	 2:00.3 	 29.2	 N Steward     	8.05	 P Shepherd
\N	90	6	4	 St Lads Flirt         	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
\N	91	1	2	 Dali On Up            	    	   2 	 5/6H  	 8/7   	 6@@/6Q	 2/1H  	 1/H    	1	 1:59.4 	 29  	 R Holliday    	5.05	 L Fitzsimmo
\N	91	1	6	 Wildcat Art           	    	   6 	 7/9H  	 5@/3Q 	 3@/3H 	 3/1H  	 2/H    	2	 1:59.4 	 29.3	 A Macdonald   	1.40	 T Gilkinson
\N	91	1	1	 Jazzmo                	    	   1 	 1/1T  	 1/1H  	 1/1T  	 1/1H  	 3/2T   	3	 2:00.2 	 30.4	 L House       	6.00	 F Schaeffer
\N	91	1	5	 Red Leaf Morgan       	    	   5 	 6/8   	 2@/1H 	 2@/1T 	 4/1H  	 4/5Q   	4	 2:00.4 	 30.4	 J Harris      	2.55	 J Watt
\N	91	1	8	 Passionate Pete       	    	   8 	 3/3Q  	 4/3   	 5@/5T 	 5/2   	 5/6Q   	5	 2:01   	 30.1	 J Ryan        	7.25	 D Dowling
\N	91	1	7	 Slots Of Fun          	    	   7 	 4/4T  	 6/4H  	 7/7Q  	 6/4H  	 6/6Q   	6	 2:01   	 30  	 G Rooney      	14.45	 R Carroll
\N	91	1	4	 Julio Lauxmont        	    	   4 	 2/1T  	 3/1H  	 4/4T  	 7/6Q  	 7/12H  	7	 2:02.1 	 31.3	 N Steward     	8.35	 L Bako
\N	91	1	3	 Riverwalk             	    	   3 	 8/11Q 	 7@/5H 	 8EX/10	 PU BE 	 DNF    	\N	        	     	 C Steacy      	31.55	 G Jacklin
\N	91	2	3	 Jeannes Faith         	    	   3 	 1/1H  	 1/1   	 1/1   	 1/1   	 1/2    	1	 2:00.4 	 30  	 N Steward     	1.45	 D Schweitze
\N	91	2	2	 Modern Man            	    	   2 	 3/3   	 2@/1  	 2@/1  	 2/1   	 2/2    	2	 2:01.1 	 30.1	 C Brown       	4.00	 C Brown
\N	91	2	4	 Larjon Emma           	    	   4 	 2/1H  	 3/2   	 3/2   	 3/2   	 3/2Q   	3	 2:01.1 	 30  	 A Macdonald   	7.70	 L Lane
\N	91	2	1	 Joeys Kidd            	    	   1 	 6/8Q  	 6@/5  	 4@/3Q 	 4/3   	 4/6    	4	 2:02   	 30.3	 H Lewis       	2.45	 V Cochrane
\N	91	2	7	 Albergetty            	    	   7 	 8/11H 	 7/6   	 8/6T  	 8/7H  	 5/7    	5	 2:02.1 	 30  	 C Steacy      	15.35	 D Walters
\N	91	2	5	 Jiffyson              	    	   5 	 7/9T  	 8@/7  	 7@@/5T	 6/6   	 6/8H   	6	 2:02.2 	 30.2	 G Rooney      	8.45	 P Bissett
\N	91	2	6	 Bachata Hanover       	    	   6 	 4/5   	 5/4   	 5/4Q  	 5/5   	 7/10T  	7	 2:03   	 31.2	 Kn Oliver     	9.20	 Kn Oliver
\N	91	2	8	 Born With Class       	    	   8 	 5/6H  	 4@/3  	 6@/5Q 	 7/7   	 8/10T  	8	 2:03   	 31.1	 L House       	3.90	 P Brickman
\N	91	3	7	 Charmbo Curiosity     	    	   6 	 5/6   	 5/5H  	 4@@/3T	 2/2H  	 1/NS   	1	 1:58.2 	 28.1	 A Macdonald   	5.10	 P Bissett
\N	91	3	6	 Buttons               	    	   5 	 1/1H  	 1/1   	 1/1T  	 1/2H  	 2/NS   	2	 1:58.2 	 29  	 N Steward     	1.25	 B Belore
\N	91	3	3	 Play Like A Pro       	    	   3 	 6/7H  	 6@/5T 	 6/5T  	 5/6H  	 3/5T   	3	 1:59.3 	 29  	 J Ryan        	5.30	 D Dowling
\N	91	3	8	 Zetlan Rocket         	    	   8 	 4/4H  	 4@/3T 	 3@@@/2	 3/5   	 4/9    	4	 2:00.1 	 30.1	 T Smith       	11.10	 J Walker
\N	91	3	2	 Poplar Duke           	    	   2 	 3/3   	 2@/1  	 2@/1T 	 4/6   	 5/9T   	5	 2:00.2 	 30.3	 G Rooney      	3.50	 V Vanstone
\N	91	3	1	 Unwavering            	    	   1 	 2/1H  	 3/2T  	 5/4   	 6/8   	 6/14T  	6	 2:01.2 	 31.1	 R Holliday    	20.85	 M Taylor
\N	91	3	4	 Payback               	    	   4X	 7/25H 	 7/19T 	 7/18T 	 7/23  	 7/28H  	7	 2:04   	 30.4	 Da Wall       	3.80	 De Wall
\N	91	3	5	 Kerrfect Fella        	    	   SC	TCHED -	JUDGES(	NELIGIB	E)     	        	\N	        	     	               	\N	 
\N	91	4	3	 Lexis D J             	    	   3 	 1/NS  	 1/1   	 1/1H  	 1/2   	 1/2    	1	 1:59.2 	 30  	 B Arsenault   	3.10	 S Arsenault
\N	91	4	1	 Kennel Buddy=         	    	   1 	 3/1T  	 3/2   	 2/1H  	 2/2   	 2/2    	2	 1:59.4 	 30.1	 J Ryan        	3.40	 D Dowling
\N	91	4	5	 Meadowview Cliffy     	    	   5 	 7/7H  	 6@/5  	 5@/3Q 	 4/4H  	 3/2H   	3	 1:59.4 	 29.4	 Do Brown      	4.00	 P Forgie
\N	91	4	7	 Spartan Victory       	    	   7 	 4@/2T 	 4@/3  	 3@/1H 	 3/3H  	 4/4T   	4	 2:00.2 	 30.4	 R Holliday    	5.00	 K Di Cenzo
\N	91	4	4	 Boots N Hearts        	    	   4 	 5/3T  	 5/4   	 4/3Q  	 5/5T  	 5/8H   	5	 2:01   	 31  	 Da Wall       	8.70	 De Wall
\N	91	4	2	 Massive Muscles       	    	   2 	 6/5T  	 7/6   	 6/5   	 6/7Q  	 6/8H   	6	 2:01   	 30.3	 J Renaud      	3.55	 P Walker
\N	91	4	6	 Lets Leavem           	    	   6 	 2@/NS 	 2@/1  	 7@/6T 	 7/11T 	 7/15H  	7	 2:02.2 	 31.3	 N Steward     	4.50	 W Robinson
\N	91	4	8	 Tortola Sunrise=      	    	   8X	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 A Macdonald   	3.80	 A Macdonald
\N	94	1	3	 Make Some Memories    	    	   3 	 3/10  	 3/7   	 3/1T  	 1/HD  	 1/2T   	1	 2:03   	 29.3	 A Hamlin      	\N	 T Myers
\N	94	1	2	 Beer And A Haircut    	    	   2 	 1/8   	 1/5   	 2/NS  	 2/HD  	 2/2T   	2	 2:03.3 	 30.3	 B Forward     	\N	 S Roberts
\N	94	1	5	 Dear Wee Mel          	    	   5 	 4/12  	 2/5   	 1@/NS 	 3/5   	 3/10H  	3	 2:05   	 32  	 M Williams    	\N	 L Mansfield
\N	94	1	4	 Twelve Apaches        	    	   4 	 5/14  	 4/13  	 4/7T  	 4/11  	 4/34   	4	 2:09.4 	 35.1	 A Lilley      	\N	 A Lilley
\N	94	1	1	 Hall Oak              	    	   1 	 2EX/8 	 PULLED	UP     	       	 DNF    	\N	        	     	 A Moore       	\N	 W Durbridge
\N	94	2	5	 Stock Losses          	    	   3 	 2/2H  	 2/1T  	 1@/1  	 1/5   	 1/7H   	1	 2:02.1 	 29.1	 A Hamlin      	\N	 
\N	94	2	3	 Acefortyfouramanda    	    	   X2	 3/4Q  	 3/3H  	 3/3   	 2/5   	 2/7H   	2	 2:03.3 	 30  	 A Lilley      	\N	 L Bako
\N	94	2	1	 Foreigner             	    	   1 	 1/2H  	 1/1T  	 2/1   	 3/6   	 3/16   	3	 2:05.2 	 32.1	 B Forward     	\N	 D Dowling
\N	97	1	4	 Just Like Buttah      	    	   4 	 3/3T  	 2@/1Q 	 1/8   	 1/12  	 1/18   	1	 2:02.3 	 29.4	 C Johnston    	\N	 D Good
\N	97	1	2	 Hall Oak              	    	   2 	 1/1T  	 1/1Q  	 2/8   	 2/12  	 2/18   	2	 2:06.1 	 31.4	 J Coke        	\N	 W Durbridge
\N	97	1	3	 Ehmacharena           	    	   3 	 4/5T  	 4/14Q 	 4/17T 	 4/21  	 3/22H  	3	 2:07   	 30.3	 B Forward     	\N	 M Rogers
\N	97	1	5	 Donato B Winnin=(T)   	    	   5 	 2/1T  	 3/4Q  	 3/16  	 3/20  	 4/24Q  	4	 2:07.2 	 31.2	 D Duford      	\N	 A Duford
\N	97	1	1	 Duet Seelster=(T)     	    	   1 	 5X/DIS	 PULLED	UP     	       	 DNF    	\N	        	     	 R Maclean     	\N	 R Maclean
\N	98	1	5	 Take Off Eh           	    	   5 	 3/3   	 3/3   	 4/2T  	 3@/3  	 1/T    	1	 2:06.2 	 29.4	 C Miles       	7.60	 C Miles
\N	98	1	4	 Sassyandiknowit       	    	   4 	 1/1H  	 1/1H  	 1/1H  	 1/1H  	 2/T    	2	 2:06.3 	 30.3	 T Trites      	0.20	 W Mahar
\N	98	1	3	 Windemere Jimmy       	    	   3 	 2/1H  	 2/1H  	 2/1H  	 2/1H  	 3/2Q   	3	 2:06.4 	 30.3	 S Trites      	3.30	 S Watts
\N	98	1	1	 Cocagne Countess      	    	   1 	 4/4H  	 4/4H  	 5@/4Q 	 5/5   	 4/3Q   	4	 2:07   	 30.1	 G Gallant     	3.70	 G Gallant
\N	98	1	2	 Little Carny          	    	   2 	 5/6   	 5/6   	 3@/2H 	 4@/4H 	 5/11H  	5	 2:08.3 	 32.1	 M Haig        	24.90	 D Foley
\N	98	2	3	 Hyperion Blue Chip    	    	   3 	 1@/1  	 1/1H  	 1/1H  	 1/2   	 1/3    	1	 2:02.1 	 30  	 Dr M Downey   	0.55	 Dr M Downey
\N	98	2	1	 Choco Du Ruisseau     	    	   1 	 2/1   	 2/1H  	 3/1T  	 3/2Q  	 3P2/8  	3	 2:03.4 	 31.1	 T Trites      	2.50	 C Miles
\N	98	2	2	 Cruise Level          	    	   2 	 3/5H  	 5/4   	 5/3Q  	 5/4   	 4P3/8Q 	4	 2:03.4 	 31  	 C Decourcey   	30.50	 C Decourcey
\N	98	2	5	 Windemere Nick        	    	   5 	 5/8H  	 4@I/3T	 4@/2  	 4@/3T 	 5P4/9T 	5	 2:04.1 	 31.3	 S Trites      	5.30	 S Watts
\N	98	2	4	 Northern Smoke Out    	    	   4 	 4/7   	 3@X/2 	 2@/1H 	 2@/2  	 2P5/3  	2	 2:02.4 	 30.2	 S Hubbard     	2.15	 S Wright
\N	98	3	3	 Upstairswithron       	    	   3 	 2/1H  	 2/1H  	 2@/1H 	 1@/Q  	 1/T    	1	 2:03.4 	 30.1	 S Hubbard     	8.95	 R Macneil
\N	98	3	6	 Yankee Dancer         	    	   6 	 1/1H  	 1/1H  	 1/1H  	 2/Q   	 2/T    	2	 2:04   	 30.3	 M Haig        	3.40	 B Goodwin
\N	98	3	1	 Milliondollarjewel    	    	   1 	 4/4H  	 5@/3  	 3@@/3 	 3/1T  	 3/1T   	3	 2:04.1 	 30.1	 T Trites      	0.55	 C Decourcey
\N	98	3	5	 Victory George        	    	   5 	 5@/5  	 3@/1T 	 4@/3Q 	 4/2   	 4/3    	4	 2:04.2 	 30.2	 J Lewis       	4.70	 J Lewis
\N	98	3	4	 Da Vinci Art          	    	   4 	 6/6H  	 6/4T  	 6/5T  	 5/7   	 5/11   	5	 2:06   	 31.2	 S Trites      	3.40	 R Dickinson
\N	98	3	2	 Shipps Xcalibur       	    	   2 	 3/3   	 4/2T  	 5/5Q  	 6/7Q  	 6/15Q  	6	 2:06.4 	 32.2	 W Watts       	12.30	 D Foley
\N	98	4	1	 Skippy                	    	   NO	ONTEST 	       	       	       	 DNF    	\N	        	     	 L Armstrong   	\N	 H Defazio
\N	98	4	4	 Ideal Ticket          	    	   NO	ONTEST 	       	       	       	 DNF    	\N	        	     	 S Trites      	\N	 R Dickinson
\N	98	4	2	 Allstar Seelster      	    	   NO	ONTEST 	       	       	       	 DNF    	\N	        	     	 E Harvey      	\N	 E Harvey
\N	98	4	5	 Stare Down            	    	   NO	ONTEST 	       	       	       	 DNF    	\N	        	     	 Dr M Downey   	\N	 E Stevenson
\N	98	4	3	 Haunto                	    	   NO	ONTEST 	       	       	       	 DNF    	\N	        	     	 M Haig        	\N	 G White
\N	98	5	2	 Grimsby               	    	   1 	 3/2Q  	 3/1Q  	 3/1Q  	 2/1   	 1/1T   	1	 2:03.3 	 32.4	 W Hubbard     	2.15	 W Hubbard
\N	98	5	3	 Meter Leader          	    	   2 	 4/4T  	 4/3   	 4/2T  	 4/2   	 2/1T   	2	 2:04   	 32.4	 A Bustard     	3.20	 P Sowers
\N	98	5	4	 Goldin Opportunity    	    	   3 	 2/H   	 1/Q   	 1/T   	 1/1   	 3/2Q   	3	 2:04   	 33.2	 P Reid        	2.40	 P Reid
\N	98	5	5	 Cecils Express        	    	   4 	 1@/H  	 2@/Q  	 2@/T  	 3@/1  	 4/2H   	4	 2:04   	 33.1	 T Trites      	0.70	 R Phillips
\N	98	5	1	 Simon Said            	    	   SC	TCHED--	UDGES  	       	       	        	\N	        	     	               	\N	 
\N	98	6	5	 Fall Bliss            	    	   4 	 4/4H  	 4@/3Q 	 3@/1Q 	 1@/T  	 1/1Q   	1	 1:59   	 29  	 Dr M Downey   	0.65	 Dr M Downey
\N	98	6	4	 City Of The Year      	    	   3 	 3/3   	 1@/1  	 1@/1  	 2/T   	 2/1Q   	2	 1:59.1 	 29.2	 M Downey      	1.40	 M Downey
\N	98	6	2	 Magical Alex          	    	   1 	 1/1H  	 2/1   	 2/1   	 3/2Q  	 3/6    	3	 2:00.1 	 30.1	 T Trites      	10.20	 R Macneil
\N	98	6	3	 Coral Snake           	    	   2 	 2/1H  	 3/2H  	 4/2T  	 4/4   	 4/8    	4	 2:00.3 	 30.1	 L Armstrong   	2.05	 R Armstrong
\N	98	6	1	 Momara                	    	   SC	TCHED-J	DGES   	       	       	        	\N	        	     	               	\N	 
\N	99	1	2	 R Es Miss Eliza       	    	   2 	 1/5   	 1/5   	 1/10  	 1/12  	 1/15   	1	 2:09.4 	 32.4	 S Trites      	\N	 C Miles
\N	99	1	3	 The Pita              	    	   3 	 2/5   	 2/5   	 2/10  	 2/12  	 2/15   	2	 2:12.4 	 33.4	 C Miles       	\N	 C Miles
\N	99	1	1	 Elm Grove Lynarush+   	    	   X1	 X3/DIS	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 G Wright      	\N	 G Wright
\N	99	2	2	 Windsong Leo          	    	   2 	 1/3H  	 1/12  	 1/15  	 1/18  	 1/26   	1	 1:59   	 28.3	 S Trites      	\N	 P Jones
\N	99	2	1	 Choco Du Ruisseau     	    	   1 	 2/3H  	 2/12  	 2/15  	 2/18  	 2/26   	2	 2:04.1 	 30.4	 T Trites      	\N	 T Dunphy
\N	100	1	5	 Mach Messier          	    	   5 	 4/6H  	 3@/1H 	 2@/2  	 2/1H  	 1/1T   	1	 1:55   	 28.3	 J Ryan        	1.85	 M Bishop
\N	100	1	3	 My Old Master         	    	   3 	 3/3H  	 1@/HD 	 1/2   	 1/1H  	 2/1T   	2	 1:55.2 	 29.2	 B Davis Jr    	1.20	 B Macintosh
\N	100	1	6	 Toy Cop               	    	   6 	 5/8H  	 5@/3H 	 4@/4  	 3/2H  	 3/3T   	3	 1:55.4 	 29  	 A Carroll     	3.25	 K Bodz
\N	100	1	1	 Santanna Sam          	    	   1 	 2/1H  	 4/2   	 5/5H  	 4/12  	 4/15Q  	4	 1:58   	 31  	 P Mackenzie   	8.95	 R Jarvis
\N	100	1	7	 Oforpetesake          	    	   7 	 6/10  	 6/4H  	 7/7   	 6/14  	 5/15Q  	5	 1:58   	 30.3	 R Doyle       	27.90	 J Hastie
\N	100	1	4	 Big Dylan             	    	   4 	 7/11H 	 7/6   	 6@X/6 	 7/15H 	 6/15T  	6	 1:58.1 	 31  	 S Young       	17.95	 M Brealey
\N	100	1	2	 Well Played Out       	    	   2 	 1/1H  	 2/HD  	 3/3H  	 5/12H 	 7/26   	7	 2:00.1 	 33.3	 T Moore       	8.05	 J Copley
\N	100	2	1	 Thrift Shop           	    	   1 	 3/3H  	 3/3H  	 2@/1H 	 1/HD  	 1/1T   	1	 1:56.3 	 30  	 S Byron       	1.70	 J Holding
\N	100	2	5	 Buttercup Baby        	    	   4 	 1/1H  	 1/1H  	 1/1H  	 2/HD  	 2/1T   	2	 1:57   	 30.3	 J Ryan        	6.55	 K Reibeling
\N	100	2	3	 Justabitevil+         	    	   2 	 2/1H  	 2/1H  	 3/2H  	 3/2H  	 3/3H   	3	 1:57.1 	 30.2	 A Byron       	11.30	 T Knight
\N	100	2	6	 Come On Eileen        	    	   5 	 4/5   	 4/5   	 4/4H  	 4/5Q  	 4/9T   	4	 1:58.3 	 31.2	 P Mackenzie   	3.20	 M Brethour
\N	100	2	4	 Orch Vicky            	    	   3 	 X5/6H 	 5/11H 	 5/17  	 5/21H 	 5/20Q  	5	 2:00.3 	 30.4	 S Young       	0.90	 G Remmen
\N	100	2	2	 Notebookandtablet     	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
\N	100	3	1	 Missus Big            	    	   1 	 1/1H  	 1/1H  	 1/1Q  	 1/1T  	 1/3Q   	1	 1:57.1 	 28.1	 B Mcclure     	1.40	 D Tyrrell
\N	100	3	2	 Miss Print            	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1T  	 2/3Q   	2	 1:57.4 	 28.3	 N Steward     	1.30	 A Mccabe
\N	100	3	3	 Classic Comedy        	    	   3 	 3/3   	 3/3   	 2@/1Q 	 3/3H  	 3/4T   	3	 1:58.1 	 29  	 Tra Henry     	9.70	 C Auciello
\N	100	3	4	 Casimir Pardon Me     	    	   4 	 4/4H  	 4/4H  	 4/4H  	 4/5   	 4/5T   	4	 1:58.2 	 28.3	 S Byron       	4.85	 K Reibeling
\N	100	3	6	 Badlands Delight      	    	   5 	 5/6   	 5/6   	 5/6H  	 5/6Q  	 5/6    	5	 1:58.2 	 28.1	 A Carroll     	3.45	 D Lehan
\N	100	3	5	 Total Knockout(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	100	4	4	 Im A Gift             	    	   4 	 3/3   	 4@/3H 	 2@/1H 	 2/Q   	 1/H    	1	 1:53.3 	 28.3	 D Dupont      	1.05	 M Dupont
\N	100	4	5	 Skyway Boomer         	    	   5 	 4/4H  	 5@/4H 	 4@/3H 	 3/2Q  	 2/H    	2	 1:53.3 	 28.1	 T Moore       	2.95	 J Copley
\N	100	4	3	 Lively Freddie        	    	   3 	 6/7H  	 7@/6H 	 6@/5H 	 5/4H  	 3/2    	3	 1:54   	 28.1	 B Mcclure     	2.35	 D Nixon
\N	100	4	1	 Surf Report           	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/Q   	 4/3H   	4	 1:54.1 	 29.2	 A Carroll     	9.15	 M Etsell
\N	100	4	6	 Stature Seelster(L)   	    	   6 	 7/9   	 6/5   	 7/6   	 6/5   	 5/4T   	5	 1:54.3 	 28.3	 P Mackenzie   	32.85	 M Isabel
\N	100	4	7	 Sporty Mercedes       	    	   7 	 5/6   	 3/3   	 5/4   	 7/6Q  	 6/7T   	6	 1:55.1 	 29.3	 B Davis Jr    	25.20	 B Macintosh
\N	100	4	2	 Singhampton Kenny     	    	   2 	 2/1H  	 2/1H  	 3/3   	 4/3   	 7/12   	7	 1:56   	 30.3	 Tra Henry     	6.35	 L Fuller
\N	100	5	1	 Mckinney              	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1   	 1/1Q   	1	 1:52.1 	 28.3	 B Mcclure     	1.30	 Corey Johns
\N	100	5	2	 American Rock         	    	   2 	 2/1H  	 3/2Q  	 3/2Q  	 3/2H  	 2/1Q   	2	 1:52.2 	 28.2	 A Carroll     	1.80	 R Moreau
\N	100	5	6	 Lets Wait And See     	    	   6 	 6/7H  	 2@/1H 	 2@/1  	 2/1   	 3/1T   	3	 1:52.3 	 28.4	 N Steward     	17.50	 S Friend
\N	100	5	4	 Thorn In Your Side(L) 	    	   4 	 3/3   	 4/3H  	 5/4   	 4/4   	 4/2Q   	4	 1:52.3 	 28.1	 Tra Henry     	3.55	 C Auciello
\N	100	5	3	 Buddha Blue Chip      	    	   3 	 4/4H  	 7/6   	 7/6   	 5/4H  	 5/2T   	5	 1:52.4 	 28  	 P Mackenzie   	5.65	 J Dupont
\N	100	5	7	 Sports Lightning      	    	   7 	 7/9   	 5@/4  	 4@/3H 	 6/6   	 6/5T   	6	 1:53.2 	 29.1	 S Young       	25.90	 M Brealey
\N	100	5	5	 Haydens Little Man(L) 	    	   5 	 5/6   	 6@/5H 	 6@/5H 	 7/7H  	 7/7    	7	 1:53.3 	 29  	 J Ryan        	11.40	 J Ryan
\N	100	6	5	 St Lads Lotto(L)      	    	   5 	 1/1H  	 1/1H  	 1/1H  	 1/4   	 1/2Q   	1	 1:52.4 	 29.2	 J Ryan        	0.75	 J Ryan
\N	100	6	7	 Arrived Late(L)       	    	   7 	 7/9   	 7/9   	 7@/5T 	 6/6Q  	 2/2Q   	2	 1:53.1 	 28.3	 B Mcclure     	12.05	 C Gilmour
\N	100	6	4	 A Marcou Story        	    	   4 	 5/6   	 5/6   	 5@/4H 	 4/5   	 3/2H   	3	 1:53.1 	 29  	 R Jones       	3.20	 R Jones
\N	100	6	3	 Crafty Master         	    	   3 	 4/4H  	 4/4H  	 3@/2Q 	 3/4H  	 4/7H   	4	 1:54.1 	 30.2	 A Carroll     	4.45	 V Puddy
\N	100	6	1	 Mac Raider            	    	   1 	 2/1H  	 2/1H  	 2/1H  	 2/4   	 5/8Q   	5	 1:54.2 	 30.4	 B Davis Jr    	9.70	 L Fuller
\N	100	6	6	 Corsica Hall(L)       	    	   6 	 3/3   	 3/3   	 4/3Q  	 5/5H  	 6/8Q   	6	 1:54.2 	 30.2	 Tra Henry     	11.20	 C Auciello
\N	100	6	2	 My Friend Diaz        	    	   2 	 6/7H  	 6/7H  	 6/5   	 7X/6T 	 X7/12H 	7	 1:55.1 	 30.4	 S Byron       	9.00	 D Lever
\N	101	1	6	 Lisvinnie(L)          	    	   6 	 9/13Q 	 7@/9H 	 5@@/4H	 4/2H  	 1/1H   	1	 1:53.2 	 28.3	 D St Pierre   	2.20	 Corey Johns
\N	101	1	5	 Sword Ofthe Spirit    	    	   5 	 1/3   	 1/2H  	 1/Q   	 1/1Q  	 2/1H   	2	 1:53.3 	 29.3	 R Jones       	10.30	 R Jones
\N	101	1	2	 Mach On The Beach     	    	   2 	 2/3   	 2/2H  	 3/1H  	 3/2   	 3/1T   	3	 1:53.4 	 29.3	 S Byron       	6.60	 D Fontaine
\N	101	1	3	 Smack Talk            	    	   3 	 7/10H 	 8/11  	 7@@/5H	 6/4H  	 4/1T   	4	 1:53.4 	 28.4	 B Mcclure     	4.70	 J Williamso
\N	101	1	4	 Chosen Hombre         	    	   4 	 6/9   	 6/8   	 8/7   	 8/7Q  	 5/5    	5	 1:54.2 	 29  	 P Mackenzie   	19.05	 M Brethour
\N	101	1	8	 Soaking Up The Sun    	    	   8 	 3/4H  	 3/4   	 2@/Q  	 2/1Q  	 6/5T   	6	 1:54.3 	 30.3	 Tra Henry     	11.90	 R Moreau
\N	101	1	9	 Calgary Seelster(L)   	    	   9 	 5/7H  	 5/7H  	 6@/5  	 5/4   	 7/6T   	7	 1:54.4 	 29.4	 N Steward     	2.15	 A Mccabe
\N	101	1	1	 Canadian Edition(L)   	    	   1 	 4/6   	 4/6   	 4/4   	 7/6   	 8/6T   	8	 1:54.4 	 30  	 A Carroll     	6.85	 V Puddy
\N	101	1	7	 One Warrawee          	    	   7 	 8/12  	 9/12H 	 9/8Q  	 9/8T  	 9/12T  	9	 1:56   	 30.2	 A Byron       	17.30	 E Galinski
\N	101	2	1	 The Illuminator       	    	   1 	 1/1H  	 2/1H  	 2/1H  	 2/T   	 1/T    	1	 1:54   	 28.3	 B Mcclure     	2.75	 Ri Zeron
\N	101	2	5	 Terror Hall           	    	   5 	 5/8   	 5/10H 	 5@/5  	 4/4H  	 2/T    	2	 1:54.1 	 28  	 A Carroll     	3.10	 R Moreau
\N	101	2	2	 Spirit Shadow         	    	   2 	 2/1H  	 1/1H  	 1/1H  	 1/T   	 3/2T   	3	 1:54.3 	 29.2	 P Mackenzie   	0.45	 J Dupont
\N	101	2	4	 Lissilas              	    	   4 	 4/6H  	 4/7H  	 4@/3H 	 3/4   	 4/3T   	4	 1:54.4 	 29  	 D St Pierre   	71.00	 Colin Johns
\N	101	2	9	 Cool Jack             	    	   8 	 8/12H 	 8/15  	 8/8H  	 5/6   	 5/5    	5	 1:55   	 28.1	 N Steward     	36.75	 J Copley
\N	101	2	6	 Winning Drive         	    	   6 	 6/9H  	 6/12  	 6@/5H 	 6/6H  	 6/7T   	6	 1:55.3 	 29.2	 T Moore       	29.50	 R Howie
\N	101	2	3	 Whiskey Wisdom        	    	   3 	 3/3H  	 3/4H  	 3/3   	 7/7   	 7/8H   	7	 1:55.3 	 29.4	 T Smith       	33.40	 J Walker
\N	101	2	8	 Master Smile          	    	   7 	 7/11  	 7/13H 	 7/7   	 8/8H  	 8/14Q  	8	 1:56.4 	 30.1	 B Davis Jr    	29.15	 J Mcginnis
\N	101	2	7	 Barefoot Bluejeans    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	101	3	2	 Kona(L)               	    	   2 	 4/4H  	 5/4Q  	 4@/1H 	 3/1H  	 1/1Q   	1	 2:00   	 31.2	 D St Pierre   	1.90	 Colin Johns
\N	101	3	1	 Deck The Halls        	    	   1 	 2/1H  	 3/1H  	 3/1H  	 4/1T  	 2/1Q   	2	 2:00.1 	 31.3	 N Steward     	4.60	 P Belanger 
\N	101	3	4	 L H Fillybuster       	    	   4 	 1/1H  	 1/1   	 1/NK  	 2/HD  	 3/3H   	3	 2:00.3 	 32.1	 A Carroll     	1.20	 W Budd
\N	101	3	5	 Ken U Sing=(L)        	    	   5 	 5/6   	 2@/1  	 2@/NK 	 1/HD  	 4/5Q   	4	 2:01   	 32.3	 D Bowins      	2.55	 D Bowins
\N	101	3	3	 Protege Seelster(L)   	    	   3 	 3/3   	 4/3   	 5/8H  	 5/11H 	 5/23T  	5	 2:04.4 	 34.4	 B Davis Jr    	12.90	 P Shepherd
\N	101	4	5	 Twomacsonemach(L)     	    	   4 	 4/5H  	 4@/3H 	 2@/1  	 2/1   	 1/HD   	1	 1:55.2 	 27.2	 A Carroll     	3.90	 V Puddy
\N	101	4	3	 P L Jackson           	    	   2 	 1/1H  	 1/1H  	 1/1   	 1/1   	 2/HD   	2	 1:55.2 	 27.3	 B Mcclure     	0.35	 R Mcmillan
\N	101	4	4	 Day Trade Hanover     	    	   3 	 2/1H  	 2/1H  	 3/1H  	 3/2H  	 3/2Q   	3	 1:55.4 	 27.4	 R Jones       	3.60	 R Jones
\N	101	4	9	 Relish                	    	   7 	 7/10  	 7@/7Q 	 6@I/5 	 5/7   	 4/9H   	4	 1:57.1 	 28.2	 P Mackenzie   	31.40	 R Mackenzie
\N	101	4	8	 Sippen Whisky         	    	   6 	 6/8H  	 5@/5H 	 4@I/3Q	 4/6H  	 5/11H  	5	 1:57.3 	 29.1	 Tra Henry     	10.55	 C Fuller
\N	101	4	7	 Wawanosh Wave         	    	   5 	 5/7   	 6/6   	 7I/5T 	 6/9H  	 6/14H  	6	 1:58.1 	 29.1	 T Smith       	64.00	 J Walker
\N	101	4	1	 Lil Richie            	    	   1 	 3/3   	 3/3   	 5X/3H 	 7/16  	 7/DIS  	7	        	     	 A Byron       	17.80	 D Nixon
\N	101	4	2	 Only Half Bad         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	101	4	6	 Six Flags             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	1	6	 Heza Workof Art       	    	   5 	 5/5H  	 4@/3  	 2@/1  	 1/NS  	 1/NS   	1	 1:54.2 	 29.1	 B Mcclure     	0.85	 J Watt
\N	102	1	7	 Wine Shark            	    	   6 	 1/1   	 1/1   	 1/1   	 2/NS  	 2/NS   	2	 1:54.2 	 29.2	 J Ryan        	2.40	 J Ryan
\N	102	1	2	 Arnold Dick           	    	   2 	 4/4   	 5/3H  	 5/7H  	 3/10  	 3/12   	3	 1:56.4 	 30.2	 P Mackenzie   	6.30	 P Mackenzie
\N	102	1	3	 Highpoint Chip        	    	   3 	 6/7   	 6/5   	 6@/8H 	 5/12  	 4/17H  	4	 1:57.4 	 31.1	 L House       	41.40	 P Roberts
\N	102	1	1	 Roan Bruiser(L)       	    	   1 	 3/2H  	 2@/1  	 4@/7  	 7/14  	 5/17T  	5	 1:58   	 31.3	 Tra Henry     	6.40	 S Halkes
\N	102	1	8	 Amillionbucks         	    	   7 	 7/8H  	 7/6H  	 7/9Q  	 6/12H 	 6/18T  	6	 1:58.1 	 31.2	 S Byron       	24.05	 G Cicero
\N	102	1	5	 Windsun Cheyenne(L)   	    	   4 	 2/1   	 3/1H  	 3/6H  	 4/11H 	 7/22H  	7	 1:58.4 	 32.3	 N Steward     	5.15	 D Tackoor
\N	102	1	4	 Jimmy Be Good         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	1	9	 Hot Rock Star         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	2	1	 Classic Bolt          	    	   1 	 2/1H  	 2/1H  	 2/3H  	 2/3   	 2P1/2  	2	 1:57   	 28.4	 J Ryan        	2.60	 C Gilmour
\N	102	2	6	 Silversmith           	    	   6 	 1/1H  	 1/1H  	 1/3H  	 1/3   	 3P2/2T 	3	 1:57.1 	 29.3	 P Mackenzie   	1.25	 A Macdonald
\N	102	2	3	 Screenwriter          	    	   3 	 4/4H  	 3@/2  	 3@/4  	 3/3T  	 4P3/6Q 	4	 1:57.4 	 29.2	 B Mcclure     	10.80	 C Fuller
\N	102	2	4	 Machcellerator        	    	   4 	 5/6   	 5/5   	 6I/7H 	 6/8   	 5P4/9Q 	5	 1:58.2 	 29.2	 S Young       	11.70	 T Stein
\N	102	2	2	 Tea With Ms Mcgill    	    	   2 	 3/3   	 4/3H  	 4X/5H 	 4/5   	 1P5/2  	1	 TDIS   	     	 A Macdonald   	1.75	 A Macdonald
\N	102	2	7	 Home James            	    	   7 	 7/9   	 6@/5H 	 5@/7  	 5/7H  	 6/9H   	6	 1:58.2 	 29.2	 Tra Henry     	15.05	 Tra Henry
\N	102	2	5	 Hazamenaz             	    	   5 	 6/7H  	 7/7   	 7@/8  	 7/12  	 7/22   	7	 2:01   	 31.4	 R Holliday    	36.10	 C Fuller
\N	102	3	5	 Go Get Bruce          	    	   5 	 6/6Q  	 4@/5T 	 3@/3  	 3/2Q  	 1/2    	1	 1:58.4 	 30  	 B Forward     	1.65	 S Charlton
\N	102	3	2	 Rainbow View          	    	   2 	 2/H   	 1@/H  	 1/1Q  	 1/1   	 2/2    	2	 1:59.1 	 31  	 A Haughan     	5.20	 M Crone
\N	102	3	4	 Tyrone Zoey           	    	   4 	 5/4T  	 2@/H  	 2@/1Q 	 2/1   	 3/5Q   	3	 1:59.4 	 31.2	 B Mcclure     	1.50	 J Watt
\N	102	3	3	 Burst Hanover         	    	   3 	 4/3Q  	 6/7H  	 5@/8Q 	 5/8H  	 4/9T   	4	 2:00.4 	 31  	 L House       	7.40	 P Roberts
\N	102	3	1	 Murs Son=             	    	   1 	 3/1T  	 5/6T  	 6/8T  	 6/9   	 5/10   	5	 2:00.4 	 30.4	 A Carroll     	9.50	 C Carss
\N	102	3	6	 Fashion Star=(L)      	    	   6 	 1@/H  	 3/4H  	 4/6Q  	 4/6H  	 6/10H  	6	 2:00.4 	 31.2	 A Macdonald   	3.70	 A Macdonald
\N	102	4	2	 Scotty Mach N         	    	   2 	 2/1   	 1/1H  	 1/1H  	 1/1   	 1/H    	1	 1:55.2 	 29.2	 P Mackenzie   	5.05	 G Way
\N	102	4	4	 Shootin To Kill       	    	   4 	 3/2H  	 3@/2  	 2@/1H 	 2/1   	 2/H    	2	 1:55.2 	 29.1	 B Mcclure     	0.95	 J Copley
\N	102	4	6	 Attaboyaaron          	    	   6 	 4/4   	 5@/4  	 4@/3H 	 3/1H  	 3/H    	3	 1:55.2 	 28.4	 N Steward     	9.50	 J Watt
\N	102	4	1	 Acefortyfourtalon     	    	   1 	 5/5H  	 4/3H  	 5/4   	 4/2H  	 4/1H   	4	 1:55.3 	 28.4	 J Ryan        	3.10	 G Durbano
\N	102	4	9	 Jolted                	    	   8 	 8/10  	 8/7H  	 8/7H  	 7/5H  	 5/1T   	5	 1:55.4 	 28.2	 Tra Henry     	10.20	 I Darveau
\N	102	4	8	 Twang Twang           	    	   7 	 7/8H  	 7@/6  	 7@/6  	 8/6H  	 6/2Q   	6	 1:55.4 	 28.3	 K Sheppard    	17.35	 K Sheppard
\N	102	4	3	 Beach Boy             	    	   3 	 6/7   	 6/5H  	 6/5H  	 6/4   	 7/5H   	7	 1:56.2 	 29.2	 R Holliday    	7.45	 S Pryjma
\N	102	4	5	 Vijayscam             	    	   5 	 1/1   	 2/1H  	 3/2   	 5/3Q  	 8/6H   	8	 1:56.3 	 30.1	 A Macdonald   	15.40	 D Graham
\N	102	4	7	 Regally Magnified     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	5	1	 Billiondolarsecret    	    	   1 	 2/1H  	 2/1H  	 3/2   	 2/1H  	 1/NS   	1	 1:57.2 	 28.3	 Tra Henry     	18.85	 S Doyle
\N	102	5	2	 Bettor Feather        	    	   2 	 1/1H  	 1/1H  	 1/1H  	 1/1H  	 2/NS   	2	 1:57.2 	 29  	 A Carroll     	0.60	 R Moreau
\N	102	5	8	 Braonach              	    	   6 	 6/9   	 6/7H  	 5@/5Q 	 3/4   	 3/3Q   	3	 1:58   	 28.3	 A Macdonald   	3.95	 A Macdonald
\N	102	5	7	 Skittle Hanover       	    	   5 	 5/7H  	 5/6   	 6/6   	 6/7H  	 4/4T   	4	 1:58.2 	 28.4	 A Haughan     	35.55	 J Williamso
\N	102	5	3	 A Royal Hanover       	    	   3 	 3/3   	 3/3   	 4/3H  	 5/6   	 5/8T   	5	 1:59.1 	 30.1	 B Davis Jr    	50.70	 B Macintosh
\N	102	5	9	 The Camel Express     	    	   7 	 7/10H 	 7/9   	 7/10  	 7/11H 	 6/10H  	6	 1:59.2 	 29  	 R Holliday    	5.95	 L Joyce
\N	102	5	5	 Big Chute             	    	   4 	 4/4H  	 4/4H  	 2@/1H 	 4/4H  	 7/12H  	7	 1:59.4 	 31.1	 P Mackenzie   	2.60	 M Brethour
\N	102	5	4	 Crazy Alice           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	5	6	 Im Stunning           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	102	6	4	 Severus Hanover=      	    	   4 	 2/1H  	 3/3   	 2@/1H 	 2/Q   	 1/1T   	1	 1:56.4 	 29.3	 B Mcclure     	10.60	 D Frey
\N	102	6	3	 Covert Operative=(L)  	    	   3 	 3/3   	 1/1H  	 1/1H  	 1/Q   	 2DH/1T 	2	 1:57.1 	 30.1	 N Steward     	0.95	 P Henriksen
\N	102	6	6	 Utopia=               	    	   6 	 6/8   	 6/7H  	 4@/3  	 4/2   	 2DH/1T 	2	 1:57.1 	 29.3	 J Ryan        	6.10	 J Ryan
\N	102	6	5	 Chuckalo Caden        	    	   5 	 1/1H  	 2/1H  	 3/1H  	 3/1H  	 4/2T   	4	 1:57.2 	 30.1	 S Young       	10.90	 C Thompson
\N	102	6	2	 Tortola Sunrise=      	    	   2 	 5/6H  	 5/6   	 7/5H  	 7/5   	 5/3H   	5	 1:57.2 	 29.2	 A Macdonald   	1.55	 A Macdonald
\N	102	6	1	 Class Me Nice=(L)     	    	   1 	 4/4H  	 4/4H  	 5/3H  	 5/3H  	 6/3H   	6	 1:57.2 	 29.4	 R Holliday    	15.10	 B Weinholdt
\N	102	6	7	 Amoureuse Hanover     	    	   7 	 7/9H  	 7/9   	 6@/5  	 6/4   	 7/5    	7	 1:57.4 	 29.4	 A Carroll     	15.50	 B Peterson
\N	102	6	8	 Early Hit             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	103	1	9	 Dixie Lullaby         	    	   9 	 9/12  	 9@/11 	 8@/6H 	 5/4Q  	 1/1    	1	 1:55.1 	 29  	 B Forward     	6.75	 R Fellows
\N	103	1	5	 Rockin Sockem         	    	   5 	 2/1H  	 2/1H  	 2/1H  	 2/1   	 2/1    	2	 1:55.2 	 30.1	 P Mackenzie   	13.95	 T Stokes
\N	103	1	4	 Deucette              	    	   4 	 6/7H  	 6@/6H 	 6@/5  	 3/2   	 3/1T   	3	 1:55.3 	 29.3	 B Mcclure     	1.20	 T Jacobson
\N	103	1	2	 Jens Credit           	    	   2 	 4/4H  	 4@/4H 	 4@/3  	 4/2H  	 4/3    	4	 1:55.4 	 30.1	 A Carroll     	4.85	 V Puddy
\N	103	1	8	 P L Jasmine           	    	   8 	 1/1H  	 1/1H  	 1/1H  	 1/1   	 5/4    	5	 1:56   	 31  	 R Holliday    	11.90	 R Mcmillan
\N	103	1	6	 Radar Trap            	    	   6 	 7/9   	 7/8H  	 7/5H  	 8/7H  	 6/4H   	6	 1:56   	 30  	 J Ryan        	29.25	 C Barss
\N	103	1	3	 Casimir Overthetop    	    	   3 	 5/6   	 5/5   	 5/3H  	 6/4H  	 7/4T   	7	 1:56.1 	 30.3	 G Large       	12.20	 G Large
\N	103	1	7	 Ima Holy Terror       	    	   7 	 8/10H 	 8/9   	 9/14  	 9/12  	 8/12T  	8	 1:57.4 	 30  	 C Steacy      	46.35	 R Hughes
\N	103	1	1	 Imacutiepatootie      	    	   1 	 3/3   	 3/3   	 3@/2H 	 7/6   	 9/13   	9	 1:57.4 	 32.2	 M Whelan      	2.25	 A Colville
\N	103	2	7	 Lady Crazy            	    	   7 	 2@/1  	 2@/HD 	 2@/H  	 2/HD  	 1/1    	1	 1:56.1 	 30.1	 Tra Henry     	4.50	 C Bradshaw
\N	103	2	5	 Jiminey Three         	    	   5 	 1/1   	 1/HD  	 1/H   	 1/HD  	 2/1    	2	 1:56.2 	 30.2	 A Carroll     	2.40	 R Moreau
\N	103	2	2	 Bad At Redhot         	    	   2 	 5/4H  	 5@/5H 	 4@/2  	 4/2   	 3/1Q   	3	 1:56.2 	 30  	 R Holliday    	4.45	 W Dunn
\N	103	2	4	 Frankies First Luv    	    	   4 	 6/6   	 6/6   	 5@@/3H	 3/1H  	 4DH/1H 	4	 1:56.2 	 29.4	 B Mcclure     	5.45	 J Marsden
\N	103	2	8	 Northern Prima        	    	   8 	 8/9   	 8/8H  	 8/6   	 7/5H  	 4DH/1H 	4	 1:56.2 	 29.1	 P Mackenzie   	14.15	 M Brethour
\N	103	2	3	 Flower Bomb           	    	   3 	 4/3   	 4/4   	 6/4   	 8/6H  	 6/2H   	6	 1:56.3 	 29.4	 B Forward     	2.70	 B Macintosh
\N	103	2	6	 Warrawee Rocket       	    	   6 	 7/7H  	 7/7   	 7@/4H 	 6/4   	 7/2T   	7	 1:56.4 	 30  	 B Davis Jr    	9.95	 T Stein
\N	103	2	1	 Inexplicable Ruby     	    	   1 	 3/1H  	 3/3H  	 3/1H  	 5/3H  	 8/4    	8	 1:57   	 30.4	 N Steward     	9.70	 J Copley
\N	103	3	1	 Par Intended          	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1H  	 1/H    	1	 1:56   	 28.4	 A Carroll     	3.00	 V Puddy
\N	103	3	2	 Markathy              	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1H  	 2/H    	2	 1:56   	 28.3	 N Steward     	6.00	 P Belanger 
\N	103	3	3	 E L Spartacus         	    	   3 	 3/3   	 4/3H  	 5/3H  	 4/3   	 3/1H   	3	 1:56.1 	 28.2	 B Mcclure     	7.40	 J Watt
\N	103	3	4	 Panedictine(L)        	    	   4 	 4/4H  	 3@/2  	 2@/1  	 3/1H  	 4/2Q   	4	 1:56.2 	 29  	 B Davis Jr    	6.80	 T Stein
\N	103	3	6	 Cruizin K C           	    	   6 	 6/7H  	 6@/5H 	 6@/4H 	 7/7   	 5/5Q   	5	 1:57   	 29  	 P Mackenzie   	1.45	 P Coleman
\N	103	3	5	 Connery Blue Chip     	    	   5 	 5/6   	 5@/4  	 4@/3  	 5/4H  	 6/7Q   	6	 1:57.2 	 29.3	 C Steacy      	12.55	 P Shepherd
\N	103	3	7	 Amble Over Hanover(L) 	    	   7 	 7/9   	 7@/6H 	 7@@/5 	 6/6   	 7/7T   	7	 1:57.3 	 29.2	 Tra Henry     	5.25	 L Fuller
\N	103	3	8	 Gunpowder             	    	   8 	 8/10H 	 8/7H  	 8/6Q  	 8/8H  	 8/7T   	8	 1:57.3 	 29.1	 B Forward     	17.95	 M Rain
\N	103	4	1	 Platoon Seelster      	    	   1 	 3/3   	 1/1H  	 1/1   	 1/1H  	 1/1    	1	 1:56.2 	 28.4	 R Holliday    	0.90	 D Holliday
\N	103	4	7	 Big Rich=(L)          	    	   7 	 1/1H  	 2/1H  	 3/1H  	 3/2   	 2/1    	2	 1:56.3 	 28.4	 B Davis Jr    	5.55	 R Moreau
\N	103	4	9	 Delcrest Massy=(L)    	    	   9 	 5/6   	 5/4   	 4@/3  	 2/1H  	 3/1H   	3	 1:56.3 	 28.2	 A Carroll     	29.35	 V Puddy
\N	103	4	8	 In Secret=(L)         	    	   8 	 9/12  	 9/10  	 9/7Q  	 7/6   	 4/1H   	4	 1:56.3 	 27.3	 B Mcclure     	11.20	 P Henriksen
\N	103	4	3	 Doubledown Gass       	    	   3 	 2/1H  	 3/3   	 5/3H  	 5/4   	 5/1T   	5	 1:56.4 	 28.3	 R Gassien     	4.40	 R Gassien
\N	103	4	4	 Call Me Richard       	    	   4 	 7/9   	 6/5H  	 6@/4H 	 6/5H  	 6/3    	6	 1:57   	 28.3	 P Mackenzie   	4.65	 C Bradshaw
\N	103	4	2	 Domedomedome(L)       	    	   2 	 6/7H  	 7/7   	 7/6   	 9/7H  	 7/3T   	7	 1:57.1 	 28.2	 Jo Kovacs     	14.05	 J Moiseyev
\N	103	4	5	 R Choochoo Charlie=(L)	)   	   5 	 8/10H 	 8@/8H 	 8@/6H 	 8/7   	 8/6H   	8	 1:57.3 	 28.4	 Tra Henry     	15.20	 C Auciello
\N	103	4	6	 Warrawee Proton       	    	   6 	 4/4H  	 4/3H  	 2@/1  	 4X/3T 	 9/22   	9	 2:00.4 	 33  	 B Forward     	17.90	 T Langille
\N	106	1	4	 Ulysses Bi            	    	   3 	 1/6Q  	 1/6H  	 1/15  	 1/31  	 1/37   	1	 1:59.3 	 31.2	 S Byron       	\N	 G Lance
\N	106	1	1	 Crystal Gumdrop=      	   -	1  1I	 3/38  	 3/38  	 3/36  	 3/31  	 2/37   	2	 2:07   	 31.3	 B Mcclure     	\N	 J Gillis
\N	106	1	5	 Media Eclipse         	    	   4 	 2/6Q  	 2/6H  	 2/15  	 2/31  	 3/DIS  	3	        	     	 R Ertel       	\N	 R Ertel
\N	106	1	2	 Austin Hall           	    	   2X	 4/DIS 	 4/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 K Jones       	\N	 K Jones
\N	106	2	5	 Certain Smiley        	    	   4 	 1/2   	 1/2   	 1/1H  	 1/1T  	 1/HD   	1	 2:00.1 	 30.2	 B Mcclure     	\N	 J Stewart
\N	106	2	1	 Machet Time           	    	   1 	 2/2   	 2/2   	 2/1H  	 2/1T  	 2/HD   	2	 2:00.1 	 30.1	 A Byron       	\N	 D Matson
\N	106	2	2	 Jibb                  	    	   2 	 3/3T  	 3/8H  	 4/9T  	 3/14  	 3/19T  	3	 2:04.1 	 32.2	 L Larochelle  	\N	 L Larochell
\N	106	2	4	 Acefortyfourashley    	    	   3 	 4/5Q  	 4@/8H 	 3@/9T 	 4/14T 	 4/25Q  	4	 2:05.1 	 33.2	 T Jacobson    	\N	 G Durbano
\N	106	3	1	 Warrawee Quince=      	    	   1 	 4/5   	 3/5T  	 3/5   	 2/2H  	 1/2    	1	 2:02.2 	 31  	 S Byron       	\N	 C Fuller
\N	106	3	5	 High Society=         	    	   5 	 2@/H  	 1/3H  	 1/3H  	 1/2H  	 2/2    	2	 2:02.4 	 32.2	 R Hughes      	\N	 R Hughes
\N	106	3	3	 E L Ima Diesel        	    	   3 	 1/H   	 2/3H  	 2/3H  	 3/3   	 3/4H   	3	 2:03.1 	 32.1	 P Rouleau     	\N	 A Hickey
\N	106	3	4	 Zorgwijk Parkhill     	    	   4X	 3/3H  	 5/21  	 5/24  	 5/26  	 4/30   	4	 2:08.2 	 33.1	 A Byron       	\N	 R Dincognit
\N	106	3	2	 Poppis Boys           	    	   2X	 5/7Q  	 4/10  	 X4/19 	 4/23  	 5/32   	5	 2:08.4 	 34.3	 R Ertel       	\N	 R Ertel
\N	107	1	1	 Big Yellow(L)         	    	   1 	 2/2   	 2/5   	 1/1   	 1/2   	 1/1H   	1	 1:55.2 	 30.1	 S Young       	2.90	 B Wallace
\N	107	1	2	 Upgrade Valley        	    	   2 	 4/4   	 4@/8  	 2/1   	 2/2   	 2/1H   	2	 1:55.3 	 30.1	 P Mackenzie   	5.55	 P Smith
\N	107	1	5	 Emperor               	    	   5 	 8/12  	 7/12  	 4@/5  	 3/6   	 3/5H   	3	 1:56.2 	 30.1	 A Carroll     	1.70	 R Mcintosh
\N	107	1	8	 The Avenger           	    	   8 	 3@/3  	 3/7   	 3/4   	 4/8   	 4/10   	4	 1:57.2 	 31.2	 B Davis Jr    	36.55	 W Robinson
\N	107	1	6	 Stonebridge Marvel    	    	   6 	 9/14  	 8/14  	 7/8   	 6/11  	 5/12T  	5	 1:58   	 31.1	 N Steward     	16.80	 J Belliveau
\N	107	1	9	 Zetlan Rocket         	    	   9 	 5/6   	 5/9H  	 5/6   	 5/10  	 6/16H  	6	 1:58.3 	 32.1	 T Smith       	86.05	 J Walker
\N	107	1	3	 Wild Chance           	    	   3 	 6/8   	 6@/10 	 8/10  	 7/15  	 7/21   	7	 1:59.3 	 32.2	 B Mcclure     	4.65	 W Whebby
\N	107	1	7	 Derby Dale            	    	   7 	 1/2   	 1/5   	 6/7   	 8/17  	 8/30   	8	 2:01.2 	 34.4	 B Forward     	7.40	 V Puddy
\N	107	1	4	 Rockstar Drums        	    	   4 	 7X/10 	 9/17  	 9/18  	 9/25  	 9/34   	9	 2:02.1 	 33.2	 L Ouellette   	24.35	 J Morrison
\N	107	2	1	 Trishas Wish          	    	   1 	 2/2   	 2/1   	 3/2   	 3/1   	 1/H    	1	 1:58.4 	 30.3	 R Battin      	9.50	 R Battin
\N	107	2	5	 Ginger                	    	   5 	 1/2   	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:58.4 	 31  	 B Forward     	7.45	 L Johnson
\N	107	2	3	 Blazinhart Hanover    	    	   3 	 6/10  	 6/6H  	 6/5   	 5/2H  	 3/2    	3	 1:59.1 	 30.2	 T Moore       	24.05	 J Wright
\N	107	2	2	 Lady Santana          	    	   2 	 5/7   	 5@/3H 	 4@/2H 	 4/1H  	 4/2Q   	4	 1:59.1 	 31  	 B Davis Jr    	2.70	 J Pereira
\N	107	2	4	 Mach Of The Town      	    	   4 	 3/4   	 4/3   	 5@/3H 	 6/3   	 5/4Q   	5	 1:59.3 	 31.1	 N Steward     	1.60	 G Robinson
\N	107	2	8	 Shanghai Nights       	    	   8 	 9/16  	 9/11  	 8/6H  	 7/3H  	 6/5T   	6	 2:00   	 31  	 P Mackenzie   	12.15	 L Mansfield
\N	107	2	9	 Hussys Sport          	    	   9 	 4/5H  	 3@/1H 	 2@/H  	 2/H   	 7/6Q   	7	 2:00   	 32.1	 L House       	9.90	 S Mcniven
\N	107	2	7	 On The Rise           	    	   7 	 8/14  	 8@/9  	 9/7H  	 9/5H  	 8/7T   	8	 2:00.2 	 31.1	 R Holliday    	76.15	 W Durbridge
\N	107	2	6	 Jinglewriter(L)       	    	   6 	 7/12  	 7@/7  	 7@/5H 	 8/4H  	 9/12   	9	 2:01.1 	 32.2	 A Carroll     	7.35	 B Treen
\N	107	3	5	 Unce Hanover          	    	   4 	 4/4H  	 3@/2  	 2@/1  	 2/1   	 1/NS   	1	 2:02.1 	 30  	 A Carroll     	2.95	 C Coleman
\N	107	3	4	 Hands Up For Luck     	    	   3 	 2/1   	 1/1   	 1/1   	 1/1   	 2/NS   	2	 2:02.1 	 30.1	 B Davis Jr    	0.65	 A Macdonald
\N	107	3	3	 Cam Engine            	    	   2 	 6/7H  	 5@/4  	 3@@/2 	 3/1H  	 3/1    	3	 2:02.2 	 30  	 P Mackenzie   	15.70	 M Rivest
\N	107	3	7	 Chalky                	    	   6 	 1/1   	 2/1   	 4/3H  	 4/2H  	 4/1Q   	4	 2:02.2 	 29.4	 Mi Horner     	12.05	 Ma Horner
\N	107	3	8	 Flying Solo           	    	   7 	 7/9   	 7@/6  	 5@/4H 	 6/4H  	 5/3T   	5	 2:03   	 30.1	 Tra Henry     	22.10	 V Cochrane
\N	107	3	9	 All Access            	    	   9 	 5/6   	 6/5   	 7@/6H 	 7/5H  	 6/4T   	6	 2:03.1 	 30  	 N Boyd        	22.90	 J Dean
\N	107	3	1	 Best Of Luck Bilbo    	    	   1 	 3/3   	 4/3   	 6/5H  	 5/4   	 7/5    	7	 2:03.1 	 30.1	 S Hudon       	22.00	 K Gangell
\N	107	3	6	 Little Johnny         	    	   5 	 8/10  	 8/7H  	 8/8H  	 8/8H  	 8/7H   	8	 2:03.3 	 30  	 B Forward     	9.15	 N Liadis
\N	107	3	2	 About A Boy           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	107	4	1	 Gia Diamond(L)        	    	   1 	 1/1H  	 1/1   	 1/1H  	 1/3   	 1/7T   	1	 1:57.1 	 29  	 J Ryan        	3.20	 J Ryan
\N	107	4	6	 Squeeze This          	    	   6 	 5/5   	 6@/5  	 5@@/4 	 4/4H  	 2/7T   	2	 1:58.4 	 29.4	 Tra Henry     	0.85	 D Lindsey
\N	107	4	9	 Shes Dignified        	    	   9 	 2/1H  	 2/1   	 2/1H  	 2/3   	 3/8    	3	 1:58.4 	 30.2	 P Mackenzie   	22.55	 S Gillard
\N	107	4	3	 All The Ladies        	    	   3 	 4/4   	 5@/3H 	 3@@/2H	 3/3H  	 4/9H   	4	 1:59   	 30.2	 A Haughan     	38.00	 M Crone
\N	107	4	2	 Sportsonthebeach      	    	   2 	 3/3   	 3@/2  	 6@/5  	 6/7   	 5/11H  	5	 1:59.2 	 30.1	 A Carroll     	10.00	 G Mcdonnell
\N	107	4	4	 Casimir Lucky Lady    	    	   4 	 6/6   	 4/3   	 4/3H  	 5/6H  	 6/15H  	6	 2:00.1 	 31.2	 B Mcclure     	17.70	 B Kempton
\N	107	4	7	 Blushing Promise      	    	   7 	 8/9H  	 8/8H  	 8/6H  	 8/9   	 7/15T  	7	 2:00.2 	 31  	 C Brown       	40.25	 G Laurignan
\N	107	4	8	 Mach Shark            	    	   8 	 9/11  	 9/11  	 9/7H  	 9/10H 	 8/16   	8	 2:00.2 	 30.4	 G Rooney      	41.55	 V Mcmurren
\N	107	4	5	 Mighty Mouse          	    	   5 	 7/8   	 7@/7  	 7@@/5H	 7/7H  	 9/16H  	9	 2:00.2 	 31.1	 N Steward     	4.50	 J Watt
\N	107	5	9	 Littlebitaswagger     	    	   9 	 4/3   	 4/3   	 6/4   	 4/2H  	 1/H    	1	 1:56.3 	 29  	 Tra Henry     	24.60	 J Harris
\N	107	5	2	 Blue Zombie           	    	   2 	 1/1H  	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:56.3 	 29.4	 A Carroll     	1.10	 C Coleman
\N	107	5	3	 Adore Him             	    	   3 	 5/4H  	 5@/3H 	 2@@/H 	 2/H   	 3/H    	3	 1:56.3 	 29.4	 N Steward     	1.85	 C Blake
\N	107	5	1	 Deseronto(L)          	    	   1 	 2/1H  	 2/1   	 3/2   	 3/1H  	 4/1T   	4	 1:57   	 29.4	 R Holliday    	9.65	 D Lindsey
\N	107	5	4	 Another Great Pick    	    	   4 	 6/6H  	 6/5   	 8/6   	 5/4   	 5/3    	5	 1:57.1 	 29.1	 R Battin      	18.85	 R Battin
\N	107	5	5	 Art Again             	    	   5 	 3@/2  	 3@/1H 	 4@/2H 	 6/4H  	 6/6    	6	 1:57.4 	 30.3	 B Mcclure     	6.15	 G Mcdonnell
\N	107	5	7	 Distinctiv Sean       	    	   7 	 8/9   	 9/7H  	 9/8   	 7/6   	 7/6H   	7	 1:57.4 	 29.2	 G Rooney      	62.60	 V Mcmurren
\N	107	5	8	 Harbourlite Jerry     	    	   8 	 9/10H 	 8@/6H 	 7@/5  	 8/6H  	 8/8    	8	 1:58.1 	 30.2	 B Forward     	189.35	 J Rankin
\N	107	5	6	 Mr Irresistible       	    	   6 	 7/7H  	 7@/5H 	 5@/3H 	 9/7   	 9/10H  	9	 1:58.3 	 31.1	 P Mackenzie   	24.00	 M Etsell
\N	107	6	2	 Youths Awesome(L)     	    	   2 	 4/4   	 5/4   	 5@/3H 	 5/3   	 1/NS   	1	 1:57.1 	 30  	 R Battin      	15.40	 R Battin
\N	107	6	6	 Here Comes William    	    	   6 	 6@/5H 	 4@/2H 	 4@/2H 	 3/1H  	 2/NS   	2	 1:57.1 	 30.1	 D Dupont      	0.75	 M Dupont
\N	107	6	9	 Goldstar Badlands     	    	   9 	 3/2   	 2@/H  	 2@/H  	 1/1   	 3/1Q   	3	 1:57.2 	 30.4	 G Rooney      	9.70	 H Toll
\N	107	6	3	 Evasive Card Shark    	    	   3 	 2/1   	 3/2   	 3/2   	 4/2   	 4/1Q   	4	 1:57.2 	 30.2	 D St Pierre   	9.55	 T Staley
\N	107	6	7	 Monster In Law        	    	   7 	 9/9H  	 9/8   	 7/5H  	 6/4H  	 5/1H   	5	 1:57.2 	 29.4	 N Steward     	47.40	 D Beatson
\N	107	6	1	 Intrigued Intended    	    	   1 	 1/1   	 1/H   	 1/H   	 2/1   	 6/3T   	6	 1:58   	 31.2	 R Holliday    	13.55	 G Weatherbe
\N	107	6	5	 Grits N Gravy         	    	   5 	 7/7   	 7@/6H 	 8@/6  	 7/5   	 7/3T   	7	 1:58   	 30.1	 B Mcclure     	8.80	 W Hamm
\N	107	6	8	 Big Moment            	    	   8 	 8@/7H 	 8/7   	 9/8   	 8/6   	 8/4    	8	 1:58   	 29.4	 A Carroll     	13.85	 R Mcintosh
\N	107	6	4	 Relleno Hanover(L)    	    	   4 	 5/5   	 6@/4H 	 6@/4H 	 9/7   	 9/4H   	9	 1:58   	 30.3	 B Forward     	6.50	 G Mcdonnell
\N	108	1	1	 Dreydl Hanover        	    	   1 	 1/H   	 1/1H  	 1/1H  	 1/4   	 1/4H   	1	 1:57.1 	 30.2	 A Haughan     	1.10	 G Remmen
\N	108	1	9	 Bugger Max            	    	   9 	 3/2   	 3@/2  	 2@/1H 	 2/4   	 2/4H   	2	 1:58   	 31  	 N Steward     	4.30	 D Beatson
\N	108	1	6	 St Lads Zeke          	    	   6 	 9/10  	 9/13  	 7@/5H 	 7/7   	 3/5    	3	 1:58.1 	 30.2	 S Young       	13.85	 G Wain
\N	108	1	3	 Kendal Fresco         	    	   3 	 2@/H  	 2/1H  	 4/3   	 3/4H  	 4/5Q   	4	 1:58.1 	 30.4	 L House       	11.40	 S Mcniven
\N	108	1	4	 Hussys Blu Boy        	    	   4 	 6/6   	 6@/5H 	 5@/3H 	 5/5H  	 5/6    	5	 1:58.2 	 31  	 B Mcclure     	3.00	 S Mcniven
\N	108	1	5	 Boysgotfever          	    	   5 	 7/7   	 7@/7  	 8/6H  	 6/6H  	 6/6Q   	6	 1:58.2 	 30.2	 T Moore       	20.50	 M Macri
\N	108	1	2	 The Kop               	    	   2 	 5/4H  	 5/5   	 6@/4H 	 8/7H  	 7/10T  	7	 1:59.2 	 31.4	 R Holliday    	20.55	 F Maguire
\N	108	1	7	 Terra Cotta Lad       	    	   7 	 4@/3  	 4@/3  	 3@@/2 	 4/5   	 8/13T  	8	 2:00   	 32.4	 B Forward     	26.25	 G Mcdonnell
\N	108	1	8	 Machme To The Moon    	    	   8 	 8/8H  	 8/12  	 9/10  	 9/12  	 9/17T  	9	 2:00.4 	 32  	 A Carroll     	42.50	 W Robinson
\N	108	2	9	 Spartan Victory       	    	   9 	 5/4   	 3@/1H 	 3@/1H 	 2/NS  	 1/1Q   	1	 2:00.3 	 28.3	 R Holliday    	2.10	 K Di Cenzo
\N	108	2	7	 Thundering Ovation    	    	   7 	 1@/1  	 1/1   	 1/1   	 1/NS  	 2/1Q   	2	 2:00.4 	 29  	 P Mackenzie   	1.50	 G Sloan
\N	108	2	4	 Sonny With Achance    	    	   4 	 3/2   	 4/2H  	 4/3   	 4/4   	 3/5H   	3	 2:01.3 	 29.1	 J Obrien      	38.05	 J Obrien
\N	108	2	2	 Stolen Goods          	    	   2 	 2/1   	 2/1   	 2/1   	 3/2H  	 4/5H   	4	 2:01.3 	 29.3	 B Forward     	13.35	 J Rankin
\N	108	2	5	 Flexie                	    	   5 	 4@/3  	 6/4H  	 7/5H  	 6/5H  	 5/6Q   	5	 2:01.4 	 29  	 Tra Henry     	26.35	 M Giles
\N	108	2	6	 Lexus Rocky           	    	   6 	 7/6   	 7@/5H 	 6@/4H 	 7/6H  	 6/7Q   	6	 2:02   	 29.2	 A Carroll     	5.15	 D Sinclair
\N	108	2	3	 Majestic Mystic=      	    	   3 	 6/5   	 5@/3H 	 5@/3H 	 5/4H  	 7/8T   	7	 2:02.2 	 30  	 G Ketros      	38.25	 G Ketros
\N	108	2	8	 Bambino Hall(L)       	    	   8 	 8/8   	 8/6H  	 8@/6H 	 8/7H  	 8/10   	8	 2:02.3 	 29.3	 J Ryan        	5.00	 J Ryan
\N	108	2	1	 Piscean(L)            	    	   X1	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 B Mcclure     	\N	 C Beelby
\N	108	3	6	 Argyle Alberwhosur    	    	   6 	 6/7   	 2@/1  	 2@/H  	 1/3   	 1/7    	1	 1:59   	 30.2	 B Forward     	5.00	 J Pedden
\N	108	3	3	 Gossip Model          	    	   3 	 3/3   	 4@/3  	 5@/3H 	 3/3H  	 2/7    	2	 2:00.2 	 31.1	 Tra Henry     	0.90	 K Di Cenzo
\N	108	3	2	 Noodles               	    	   2 	 1/1H  	 1/1   	 1/H   	 2/3   	 3/8H   	3	 2:00.3 	 32  	 N Steward     	4.75	 R Mitchell
\N	108	3	4	 Flysantanna           	    	   4 	 2/1H  	 3/2   	 3/2   	 4/4   	 4/9H   	4	 2:00.4 	 31.4	 P Mackenzie   	5.65	 Alan W Fair
\N	108	3	1	 Maritime Girl         	    	   1 	 4/4H  	 5/4   	 4/3   	 5/4H  	 5/10   	5	 2:01   	 31.4	 S Young       	15.85	 J Wright
\N	108	3	7	 Impatient Lady        	    	   7 	 7/8   	 6@/5  	 6@/5  	 7/6   	 6/10T  	6	 2:01.1 	 31.3	 T Moore       	25.00	 R Duld
\N	108	3	5	 Acefourtyfouramber    	    	   5 	 5/6   	 7/6H  	 8/6H  	 8/7   	 7/10T  	7	 2:01.1 	 31.2	 J Ryan        	38.45	 S Peacock
\N	108	3	8	 Sportsillustrator     	    	   8 	 8/9   	 8@/7  	 7@@/5H	 6/5H  	 8/11H  	8	 2:01.1 	 31.3	 B Mcclure     	13.65	 R Mcneill
\N	108	4	1	 B Fast Eddie          	    	   1 	 1/1   	 1/1   	 1/H   	 1/1H  	 1/2Q   	1	 1:57.1 	 29  	 B Mcclure     	1.75	 B Baillarge
\N	108	4	5	 The Big Beast         	    	   5 	 3/2   	 3/2   	 3/2   	 2/1H  	 2/2Q   	2	 1:57.3 	 29  	 L Ouellette   	5.65	 M Ouimet
\N	108	4	4	 Preppy Art            	    	   4 	 6/5   	 6/4H  	 6/4H  	 4/3H  	 3/3Q   	3	 1:57.4 	 28.4	 T Fritz       	31.25	 T Fritz
\N	108	4	2	 Sutton Seelster       	    	   2 	 2/1   	 2/1   	 2@/H  	 3/2   	 4/3H   	4	 1:57.4 	 29.3	 T Moore       	1.50	 Dr I Moore
\N	108	4	3	 Mister Big Top        	    	   3 	 5/4   	 5@/3H 	 5@@/4 	 5/4   	 5/5H   	5	 1:58.1 	 29.1	 Tra Henry     	44.90	 J Byron
\N	108	4	7	 Shaker                	    	   7 	 7/6   	 7/5H  	 7/6   	 6/6   	 6/5T   	6	 1:58.2 	 29  	 B Forward     	33.30	 P Shakes
\N	108	4	6	 Rough Trade           	    	   6 	 8/7H  	 9/7H  	 9/8H  	 7/8   	 7/7T   	7	 1:58.4 	 29  	 P Mackenzie   	14.10	 F Hincks
\N	108	4	8	 Cams Lucky Sam(L)     	    	   8 	 9/9   	 8@/6  	 8@/6H 	 8/10  	 8/9    	8	 1:59   	 29.3	 J Ryan        	13.15	 N Gallucci
\N	108	4	9	 Invinceable B         	    	   9 	 4/3   	 4@/2H 	 4@/3H 	 9/12  	 9/20   	9	 2:01.1 	 32.2	 G Rooney      	11.65	 K Campbell
\N	109	1	1	 Rosberg               	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1   	 1/T    	1	 2:01.3 	 29.4	 J Moiseyev    	0.60	 J Walker
\N	109	1	4	 Zorgwijk Rocket=      	    	   4 	 2/1H  	 2/1   	 2/1   	 2/1   	 2/T    	2	 2:01.4 	 29.4	 J Hudon Jr    	3.30	 J Hudon Jr
\N	109	1	6	 Mr Marshmellow=       	    	   6 	 3/3   	 3/2H  	 3/2   	 3/2   	 3/3H   	3	 2:02.1 	 30  	 O Gois        	5.50	 O Gois
\N	109	1	7	 Many A Man            	    	   7 	 6/9   	 6@/7  	 5/5   	 5/4   	 4/5    	4	 2:02.3 	 29.4	 A Carroll     	40.60	 R Mcintosh
\N	109	1	2	 Yo Yo Mass=           	    	   2 	 5/7H  	 5@/5H 	 4/3H  	 4/3   	 5/6    	5	 2:02.4 	 30.2	 B Mcclure     	6.85	 K Reibeling
\N	109	1	3	 Stonebridge Brass     	    	   3 	 4/6   	 4/5   	 6/10  	 6/16  	 6/27   	6	 2:07   	 33.1	 S Byron       	63.65	 J Bax
\N	109	1	5	 Adventure Ahead=      	    	   5 	 X7X/24	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 A Macdonald   	24.55	 A Macdonald
\N	109	2	4	 Kitarro               	    	   4 	 3/3   	 3/2   	 3@/1  	 3/1H  	 1/8H   	1	 2:03.2 	 30.1	 P Mackenzie   	4.60	 K Reibeling
\N	109	2	3	 Northern Dazzle       	    	   3 	 1/H   	 2/1   	 4/4   	 4/7   	 2/8H   	2	 2:05   	 31.1	 D Mcnair      	19.30	 R Mcnair
\N	109	2	2	 Critical Mass=        	    	   2 	 2@/H  	 1/1   	 1/H   	 1I/H  	 3/11T  	3	 2:05.4 	 32.4	 B Mcclure     	0.55	 D Menary
\N	109	2	5	 My Big Kadillac       	    	   5 	 4/5   	 4/3   	 2@/H  	 2IX/H 	 4/12H  	4	 2:05.4 	 32.4	 A Carroll     	2.90	 R Mcintosh
\N	109	2	1	 Laminin               	    	   1X	 5/12  	 5/13  	 5X/14 	 5X/19 	 5/22   	5	 2:07.4 	 32  	 C Jamieson    	11.40	 C Jamieson
\N	109	2	6	 Bourne=               	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	109	2	7	 More Than Majestic=   	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	109	3	1	 Clear Idea            	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:59.2 	 29.2	 B Davis Jr    	1.90	 B Macintosh
\N	109	3	4	 Cousin Mary           	    	   4 	 4/5   	 4@/3  	 3@@/1H	 2/1   	 2/H    	2	 1:59.2 	 29.1	 R Holliday    	1.40	 J Kerr
\N	109	3	3	 Michelles Hattrick    	    	   3 	 3/3   	 2@/1  	 2@/1  	 3/1H  	 3/2    	3	 1:59.4 	 29.3	 Trev Henry    	2.85	 J Pereira
\N	109	3	2	 Dirt On My Skirt      	    	   2 	 2/1   	 3/2   	 4/2   	 4/2   	 4/2H   	4	 1:59.4 	 29.2	 S Young       	15.25	 C Flanigan
\N	109	3	6	 Fading Shadow         	    	   6 	 6/8   	 6@/5  	 5@/3H 	 5/3   	 5/3Q   	5	 2:00   	 29.2	 D Mcnair      	11.85	 J Darling
\N	109	3	5	 Lyons Moonlight       	    	   5 	 5/6H  	 5/4H  	 6/4H  	 6/5   	 6/4    	6	 2:00.1 	 29.2	 A Haughan     	68.10	 B Goit
\N	109	3	7	 Dancing Shadows K     	    	   7 	 8/10H 	 7@/6H 	 7@/5  	 7/6   	 7/7H   	7	 2:00.4 	 29.4	 Ja Macdonald  	47.65	 P Reid
\N	109	3	9	 Uncool                	    	   9 	 7/9H  	 8/9H  	 8/11  	 8/14  	 8/23   	8	 2:04   	 31.4	 N Steward     	80.65	 Alan W Fair
\N	109	3	8	 Lady Oxford           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	109	4	2	 Prettyndangerous      	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:55.2 	 30  	 J Ryan        	2.30	 B Curran
\N	109	4	3	 Moon Lake(L)          	    	   2 	 2/1   	 2/1   	 2/1   	 2/1   	 2/H    	2	 1:55.2 	 29.4	 B Forward     	9.50	 D Lehan
\N	109	4	7	 Romance In Camelot(L) 	    	   6 	 6/7   	 5/4H  	 3/2H  	 3/2   	 3/3Q   	3	 1:56   	 30.1	 R Holliday    	35.35	 M Rivest
\N	109	4	8	 St Lads Pixie         	    	   7 	 7/9   	 7/6H  	 5/4H  	 4/3H  	 4/4T   	4	 1:56.2 	 30.1	 B Mcclure     	20.95	 J Watt
\N	109	4	4	 Cyndalianne Duc       	    	   3 	 4/4   	 4@/3  	 6@/5  	 6/4H  	 5/5Q   	5	 1:56.2 	 30  	 N Steward     	4.55	 G Robinson
\N	109	4	6	 Good Luck Kathy       	    	   5 	 5/5   	 6@/5H 	 7/6   	 7/6H  	 6/5H   	6	 1:56.2 	 29.4	 A Carroll     	9.40	 S Rose
\N	109	4	5	 Little Anna Mae(L)    	    	   4 	 3/2   	 3@/2  	 4@/3  	 5/4   	 7/5T   	7	 1:56.3 	 30.3	 Trev Henry    	1.15	 L Lalonde J
\N	109	4	1	 Twilight Katie        	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
\N	109	5	4	 Themanofmydreams      	    	   3 	 2/1   	 1/1H  	 1/1H  	 1/1H  	 1/2T   	1	 2:03.3 	 30  	 D St Pierre   	0.45	 T Staley
\N	109	5	5	 Little Lion Man       	    	   4 	 1/1   	 2/1H  	 2/1H  	 2/1H  	 2/2T   	2	 2:04.1 	 30.2	 Trev Henry    	6.85	 R Moreau
\N	109	5	2	 Lexus Gilmore=        	    	   1 	 3/2   	 3/2H  	 4/3   	 3/3   	 3/6    	3	 2:04.4 	 30.3	 L House       	28.35	 N Dunstan
\N	109	5	8	 Smoking Mass          	    	   7 	 6/7H  	 6/6H  	 6/5   	 5/4H  	 4/7T   	4	 2:05.1 	 30.3	 D Dupont      	35.90	 M Dupont
\N	109	5	7	 A J Ricochet          	    	   6 	 5/6   	 5/5H  	 5@/4  	 6/5   	 5/8Q   	5	 2:05.1 	 30.4	 A Carroll     	31.25	 A Dimmers
\N	109	5	3	 Motown Jackpot        	    	   2 	 4/4H  	 4/4   	 3@/2  	 4/3H  	 6/9    	6	 2:05.2 	 31.2	 M Baillargeon 	3.25	 B Baillarge
\N	109	5	6	 Lmc Mass Gem          	    	   5X	 7/10  	 X7/7  	 7/25  	 7/30  	 7/42   	7	 2:12   	 33.2	 P Mackenzie   	11.35	 K Reibeling
\N	109	5	1	 Majestic Streak       	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	109	6	5	 Coherent=             	    	   5 	 6@/4H 	 3@/2  	 2@/H  	 2/H   	 1/NK   	1	 2:02.4 	 30.3	 R Jenkins Jr  	10.80	 F Marion
\N	109	6	4	 Tinas War             	    	   4 	 3/2   	 4/3   	 4/3H  	 4/2H  	 2/NK   	2	 2:02.4 	 30  	 G Mcknight    	8.45	 G Mcknight
\N	109	6	3	 Shes All Muscle       	    	   3 	 1/1   	 1/1   	 1/H   	 1/H   	 3/1    	3	 2:03   	 30.4	 J Ryan        	2.40	 J Wilson
\N	109	6	9	 Angel Assault=        	    	   9 	 5/4   	 8/7   	 7/6   	 5/3H  	 4/2Q   	4	 2:03.1 	 29.4	 M Whelan      	6.45	 W Whelan
\N	109	6	2	 Tymal Bolt            	    	   2 	 2/1   	 2/1   	 3/2   	 3/2   	 5/3Q   	5	 2:03.2 	 30.4	 T Borth       	7.80	 F Baker Jr
\N	109	6	6	 Its Easy To Dance     	    	   6 	 7/6   	 5@/4  	 5@/4  	 7/6   	 6/11H  	6	 2:05   	 32  	 R Shepherd    	2.85	 P Shepherd
\N	109	6	8	 Zorgwijk Priority=    	    	   7 	 8/7H  	 7@/6  	 6@/5  	 EX6/4H	 7BE/26 	7	 2:08   	 34.4	 P Mackenzie   	32.15	 T Mckibbin
\N	109	6	1	 Scorr Again           	    	   1 	 4/3   	 6/5H  	 X8/16 	 8/26  	 8/DIS  	8	        	     	 Do Brown      	4.30	 Do Brown
\N	109	6	7	 Whatdreamsrmadeof     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	110	1	1	 Tauriel               	    	   1 	 1/1   	 1/1   	 1/1   	 1/1H  	 1/1    	1	 1:57.1 	 28.3	 B Forward     	3.65	 J Barton
\N	110	1	3	 Greystone Ladyluck    	    	   3X	 2/1   	 2/1   	 3/2   	 2/1H  	 2/1    	2	 1:57.2 	 28.2	 B Davis Jr    	1.30	 B Belore
\N	110	1	9	 Life Groove           	    	   9 	 5/5H  	 3@/2  	 2/1   	 3/2   	 3/2H   	3	 1:57.3 	 28.4	 P Mackenzie   	6.25	 R Laarman
\N	110	1	2	 Alliwannadoisplay     	    	   2 	 4/4H  	 5/4H  	 5/4   	 4/4H  	 4/6T   	4	 1:58.3 	 29.1	 R Shepherd    	25.45	 G Adair
\N	110	1	5	 On A Cloud            	    	   5 	 6/7   	 6/6   	 7/6   	 6/6H  	 5/7Q   	5	 1:58.3 	 28.4	 Ja Macdonald  	4.60	 T Bain
\N	110	1	6	 Boyur Attractive      	    	   6 	 7/8   	 7@/6H 	 6@/4H 	 7/7H  	 6/9T   	6	 1:59.1 	 29.4	 Trev Henry    	14.80	 R Steward
\N	110	1	7	 Tz Tizzy              	    	   7 	 8/9   	 8/7H  	 8@/6H 	 8/8   	 7/10   	7	 1:59.1 	 29.2	 L House       	28.00	 S Mcniven
\N	110	1	4	 Evas Best Girl        	    	   4 	 3/2H  	 4@/3  	 4@/3  	 5/5   	 8/12   	8	 1:59.3 	 30.2	 N Steward     	8.45	 P Core
\N	110	1	8	 Lady London           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	110	2	2	 St Lads Moonwalk      	    	   2 	 4@/3  	 1/1H  	 1/1H  	 1/1H  	 1/2H   	1	 1:53.4 	 28.1	 D Mcnair      	0.75	 J Darling
\N	110	2	3	 Newbie                	    	   3 	 1@/1  	 2/1H  	 2/1H  	 2/1H  	 2/2H   	2	 1:54.1 	 28.2	 B Davis Jr    	2.05	 I Hyatt
\N	110	2	6	 Rockabella            	    	   5 	 6/9   	 6/7H  	 6/5   	 4/4   	 3/8    	3	 1:55.2 	 28.4	 Trev Henry    	8.45	 T Stein
\N	110	2	8	 Raylan Givens(L)      	    	   7 	 2/1   	 3/3   	 4/3H  	 3/3   	 4/8T   	4	 1:55.3 	 29.2	 C Steacy      	89.55	 J Morrison
\N	110	2	7	 Rock N Roll Legacy(L) 	    	   6 	 8/11  	 8/9H  	 8/7   	 7/6H  	 5/9Q   	5	 1:55.3 	 28.3	 G Rooney      	29.15	 R Marriage
\N	110	2	1	 Ciona Bromach(L)      	    	   1 	 5/6   	 5/6   	 5@/4  	 5/4H  	 6/9Q   	6	 1:55.3 	 29.1	 A Haughan     	25.60	 D Obrienmor
\N	110	2	4	 Two Of Clubs          	    	   4 	 3/2H  	 4/4   	 3@/2  	 6/5   	 7/17   	7	 1:57.1 	 31.1	 S Young       	13.00	 G Rivest
\N	110	2	9	 Kid Galahad N         	    	   9 	 7/10  	 7@/8  	 7@/6  	 8/7   	 8/17   	8	 1:57.1 	 30.2	 L House       	15.15	 S Taylor
\N	110	2	5	 Mister X              	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	110	3	1	 Tougher Than Ever=    	    	   1 	 3/2H  	 3/3   	 2@/H  	 2/H   	 1/2Q   	1	 2:02.2 	 30.3	 Ja Macdonald  	2.75	 R Norman
\N	110	3	5	 Warrawee Shipshape=   	    	   5 	 2/1   	 2/1H  	 3/2   	 3/2   	 2/2Q   	2	 2:02.4 	 30.3	 A Green       	2.00	 A Green
\N	110	3	7	 Dontcrampmystyle=     	    	   7 	 1@/1  	 1/1H  	 1/H   	 1/H   	 3/3Q   	3	 2:03   	 31.1	 Trev Henry    	2.15	 A Mccabe
\N	110	3	4	 Jack In My Coke=      	    	   4 	 6/12  	 5@/6H 	 4/3H  	 4/3   	 4/6H   	4	 2:03.3 	 31.1	 J Maguire     	7.00	 J Maguire
\N	110	3	3	 Charmbo Chrome        	    	   3 	 5/11  	 6/8   	 5/6H  	 5/6   	 5/7T   	5	 2:04   	 31  	 A Hamilton    	38.05	 J Rier
\N	110	3	6	 Piston Popper         	    	   6 	 7/15  	 7/12  	 6/9   	 6/11  	 6/16   	6	 2:05.3 	 32  	 G Rivest      	47.70	 G Rivest
\N	110	3	2	 Airborne Seelster     	    	   2 	 4/8   	 4/5H  	 X7/18 	 7/18  	 7/24   	7	 2:07.1 	 31.4	 D Mcnair      	7.15	 R Mcnair
\N	110	4	2	 Top Of The Morning(L) 	    	   2 	 3/2   	 3@/1H 	 2@/H  	 2/H   	 1/NK   	1	 1:58.1 	 30.4	 T Moore       	2.85	 T Moore
\N	110	4	7	 Nor Star Renegade     	    	   7 	 2@/1  	 1/1   	 1/H   	 1/H   	 2/NK   	2	 1:58.1 	 30.4	 D Mcnair      	6.80	 R Lindenfie
\N	110	4	9	 Kablooie(L)           	    	   9 	 6/7H  	 6@/5  	 5@/3H 	 5/3   	 3/2Q   	3	 1:58.3 	 30.3	 B Mcclure     	3.65	 D Lagace
\N	110	4	3	 Star Struck Luck      	    	   3 	 7/8H  	 7@/6H 	 6@/5  	 7/4H  	 4/3Q   	4	 1:58.4 	 30.2	 Br Richardson 	9.55	 E Laybourne
\N	110	4	5	 Joeys Kidd            	    	   5 	 8/10  	 9@/8H 	 7@/6  	 6/3H  	 5/3H   	5	 1:58.4 	 30.1	 P Mackenzie   	64.20	 V Cochrane
\N	110	4	1	 Bandicoot             	    	   1 	 4/4H  	 4@/3H 	 4/3   	 3/2   	 6/5    	6	 1:59.1 	 31.1	 Trev Henry    	2.50	 M Stoikopou
\N	110	4	4	 Rocknroll Band        	    	   4 	 5/6   	 5/4H  	 8/7   	 8/6H  	 7/6    	7	 1:59.2 	 30.3	 N Steward     	7.15	 P Belanger 
\N	110	4	6	 Jackson Killean(L)    	    	   6 	 1/1   	 2/1   	 3/2   	 4/2H  	 8/7    	8	 1:59.3 	 31.4	 B Forward     	14.85	 L Privett
\N	110	4	8	 Two Face(L)           	    	   8 	 9/11H 	 8/8   	 9@/8  	 9/7   	 9/7H   	9	 1:59.3 	 30.3	 M Whelan      	39.85	 F Soyka
\N	111	1	4	 Ms Medusa=            	    	   4 	 2/1   	 2/1H  	 3/2   	 3/1H  	 1/H    	1	 2:01.1 	 29.4	 P Henriksen   	6.65	 P Henriksen
\N	111	1	2	 Willie Wonka=         	    	   2 	 3/6   	 3/4   	 2@/1  	 2/1   	 2/H    	2	 2:01.1 	 30  	 A Carroll     	8.70	 R Mcintosh
\N	111	1	1	 Hilarious Hero=       	    	   1 	 1/1   	 1/1H  	 1/1   	 1/1   	 3/1Q   	3	 2:01.2 	 30.2	 B Mcclure     	2.25	 T Macdonnel
\N	111	1	6	 Moon Dance            	    	   6 	 5/9   	 5/8   	 4@/3  	 4/3   	 4/2H   	4	 2:01.3 	 30  	 T Durand      	2.25	 T Durand
\N	111	1	3	 Prince Of Minto       	    	   3 	 4/8   	 4/7   	 5/4   	 5/6   	 5/5H   	5	 2:02.1 	 30.2	 M Baillargeon 	3.35	 B Baillarge
\N	111	1	9	 Whos Cheatin Who=     	    	   9 	 6/10H 	 6/11  	 6/5   	 X6/8  	 X6/18H 	6	 2:04.4 	 32.4	 R Shepherd    	18.55	 D Sinclair
\N	111	1	7	 Style Spotlight       	    	   7 	 7/12H 	 7/16  	 7/17  	 7/20  	 7/31   	7	 2:07.2 	 33  	 P Walker      	69.55	 P Walker
\N	111	1	5	 South Win Bax         	    	   5 	 9/16  	 9/23  	 8@/18 	 8/21  	 8/32   	8	 2:07.3 	 33  	 J Bax         	18.70	 J Bax
\N	111	1	8	 Jungle Gem            	    	   8 	 8/14  	 8/19  	 9/20  	 9/24  	 9/37   	9	 2:08.3 	 33.3	 D Fritz       	33.35	 D Fritz
\N	111	2	1	 J J Mystic Storm      	    	   1 	 1/1H  	 1/1   	 1/1   	 1/2   	 1/2T   	1	 1:57.2 	 29  	 P Mackenzie   	1.80	 S Charlton
\N	111	2	5	 Southwind Jagger      	    	   5 	 2/1H  	 2/1   	 2/1   	 2/2   	 2/2T   	2	 1:58   	 29.2	 T Moore       	6.60	 R Ellis
\N	111	2	4	 Catch Twenty Two      	    	   4 	 5/5H  	 3@/1H 	 3@/1H 	 3/3   	 3/7H   	3	 1:58.4 	 30.1	 B Mcclure     	8.40	 S Friend
\N	111	2	6	 Hes Got Style         	    	   6 	 6/6H  	 5@/3  	 4@/3  	 4/4   	 4/7H   	4	 1:58.4 	 29.4	 L House       	11.55	 S Mcniven
\N	111	2	2	 Jansen Hanover        	    	   2 	 3/3   	 4/2H  	 5/4   	 5/5H  	 5/7T   	5	 1:59   	 29.4	 Br Richardson 	1.35	 E Laybourne
\N	111	2	7	 Moot Court            	    	   7 	 7/7H  	 7/5   	 6/5   	 6/7   	 6/16   	6	 2:00.3 	 31.1	 R Holliday    	16.75	 R Mcnair
\N	111	2	3	 Spaniard              	    	   3 	 4@/4H 	 6/4H  	 7/12  	 7/19  	 7/31   	7	 2:03.3 	 32.4	 A Carroll     	17.65	 M Etsell
\N	111	3	1	 Life Strikes          	    	   1 	 1/3   	 1/1H  	 1/1H  	 1/1H  	 1/T    	1	 2:00.4 	 31.4	 M Baillargeon 	1.25	 M Robitaill
\N	111	3	7	 Summajestic           	    	   5 	 4/6   	 4/4H  	 3@/2  	 3/2   	 2/T    	2	 2:01   	 31.3	 S Byron       	5.95	 D Byron
\N	111	3	5	 P L Jade=             	    	   3 	 2/3   	 2/1H  	 2/1H  	 2/1H  	 3/1H   	3	 2:01   	 31.4	 M Dupuis      	1.75	 M Dupuis
\N	111	3	9	 Shes All Magic        	    	   9 	 3/4   	 3/3   	 4/3H  	 4/3H  	 4/3    	4	 2:01.2 	 31.4	 P Henriksen   	7.45	 P Henriksen
\N	111	3	4	 Relevant=             	    	   2 	 5/8   	 5/6   	 5/9H  	 5/9H  	 5/14T  	5	 2:03.4 	 33  	 G Macdonald   	23.75	 L Privett
\N	111	3	8	 Tala Seelster         	    	   6 	 X6/12 	 6/12  	 6/11  	 6/11  	 6/15   	6	 2:03.4 	 32.3	 B Mcclure     	20.05	 W Budd
\N	111	3	6	 Moxie Begonia         	    	   4X	 7/24  	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Harris      	18.50	 G Oliver
\N	111	3	2	 Shezastrikin Loral    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	111	3	3	 Daytrooper            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	111	4	1	 Marina Desbi          	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/2    	1	 1:57.3 	 29.3	 L House       	1.55	 M Paulic
\N	111	4	2	 Lucky                 	    	   2 	 3/2H  	 3@/1H 	 2@/1  	 2/1   	 2/2    	2	 1:58   	 29.4	 Tra Henry     	5.80	 M Fitzgeral
\N	111	4	3	 Twin B Amour          	    	   3 	 2/1   	 2/1   	 3/2   	 3/2   	 3/5    	3	 1:58.3 	 30.1	 J Harris      	3.05	 J Harris
\N	111	4	4	 The Prophet Mary(L)   	    	   4 	 4/4   	 4/3   	 4/3H  	 4/3   	 4/5T   	4	 1:58.4 	 30.1	 N Steward     	4.35	 J Watt
\N	111	4	8	 Im A Debutant+(L)     	    	   8 	 7@/7  	 7@/5H 	 7@/6  	 7/5H  	 5/6Q   	5	 1:58.4 	 29.3	 T Moore       	14.35	 L Privett
\N	111	4	6	 Lotteria              	    	   6 	 8/8   	 8/6H  	 8@/7  	 8/6   	 6/8    	6	 1:59.1 	 29.4	 B Mcclure     	14.30	 G Laurignan
\N	111	4	9	 Alibi Terror          	    	   9 	 5/5   	 5@/3H 	 5@/4  	 5/3H  	 7/8    	7	 1:59.1 	 30.2	 R Holliday    	26.40	 T Schlatman
\N	111	4	5	 Mach Denali           	    	   5 	 6/6   	 6/5   	 6/5H  	 6/5   	 8/8Q   	8	 1:59.1 	 30.1	 A Carroll     	20.60	 M Etsell
\N	111	4	7	 Oh Chute              	    	   7 	 9/9   	 9/7   	 9@/8  	 9/9   	 9/16   	9	 2:00.4 	 31.1	 P Mackenzie   	38.50	 Alan W Fair
\N	111	5	2	 Wilma C               	    	   2 	 3/6   	 2/1   	 2@/H  	 2/H   	 1/1    	1	 2:01.3 	 31.1	 K Sheppard    	0.95	 K Sheppard
\N	111	5	9	 T C Sno Massive=      	    	   9 	 4/7   	 4@/3  	 3@/1H 	 3/1   	 2/1    	2	 2:01.4 	 31.1	 B Mcclure     	9.75	 Ri Zeron
\N	111	5	5	 Clone The Tone        	    	   5 	 2/1   	 3/2   	 4/2H  	 4/2H  	 3/1T   	3	 2:02   	 31.1	 R Shepherd    	44.75	 S Weber
\N	111	5	6	 Zorgwijk Queen        	    	   6 	 1/1   	 1/1   	 1/H   	 1/H   	 4/2    	4	 2:02   	 31.3	 T Borth       	17.40	 R Wade
\N	111	5	10	 Vimy Ridge Vesta      	    	   1 	 X6/11 	 6/6   	 6/7   	 5/5H  	 5/10   	5	 2:03.3 	 31.4	 L House       	9.20	 S Loughran
\N	111	5	7	 Stonebridge Peace     	    	   X7	 7/19  	 7/13  	 7/13  	 7/11  	 6/14H  	6	 2:04.2 	 31.2	 T Moore       	7.80	 J Copley
\N	111	5	4	 Beer Before Noon=     	    	   4X	 X8/24 	 8/19  	 8/14  	 8/13  	 7/16H  	7	 2:04.4 	 31.3	 A Carroll     	6.10	 P Lawrence
\N	111	5	8	 Don Jarvis            	    	   8 	 5/9   	 5/4H  	 5/5H  	 6/7H  	 8/16T  	8	 2:05   	 33.3	 R Holliday    	47.95	 M Giles
\N	111	5	3	 Lovin Karma           	    	   X3	 X9/DIS	 X9/DIS	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 P Mackenzie   	5.40	 C Yates
\N	111	5	1	 Citizen Hall          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	111	6	2	 Let Em Bounce         	    	   2 	 2/1   	 1/1   	 1/1   	 1/1   	 1/T    	1	 1:57.3 	 29.4	 B Mcclure     	1.90	 W Budd
\N	111	6	7	 Heza Workof Art       	    	   7 	 1@/1  	 2/1   	 2/1   	 2/1   	 2/T    	2	 1:57.4 	 29.4	 J Harris      	20.00	 J Watt
\N	111	6	5	 Whim Roader           	    	   5 	 7/7   	 5/11  	 3@/4  	 3/2   	 3/3    	3	 1:58.1 	 29.3	 B Forward     	37.20	 L Privett
\N	111	6	9	 Sports Vision         	    	   9 	 6/5H  	 4/10  	 4/5   	 4/4   	 4/8T   	4	 1:59.2 	 30.3	 A Carroll     	7.60	 S Friend
\N	111	6	8	 Casimir Obama         	    	   8 	 9/10  	 7/13  	 5/6H  	 5/5   	 5/10H  	5	 1:59.3 	 30.3	 L House       	68.30	 R Deacon
\N	111	6	6	 Gotameeting           	    	   6 	 8/8H  	 6/12  	 6/8   	 6/7   	 6/12   	6	 2:00   	 30.3	 P Mackenzie   	39.35	 J Loosemore
\N	111	6	4	 Sharks Play           	    	   4 	 5/4   	 8/23  	 7/12  	 7/13  	 7/30   	7	 2:03.3 	 33.2	 N Steward     	15.90	 P Shepherd
\N	111	6	3	 Jet Er Done(L)        	    	   3 	 3/2   	 3/7   	 8/17  	 8/25  	 8CH/DIS	8	        	     	 T Moore       	35.90	 T Moore
\N	111	6	1	 Master Smile          	    	   1 	 4/3   	 9/DIS 	 PULLED	UP     	 DNF    	\N	        	     	 Tra Henry     	2.85	 J Mcginnis
\N	112	1	1	 Whosgoingtocatchus    	    	   1 	 1/1   	 1/H   	 1/1   	 1/1   	 1/1Q   	1	 1:59.1 	 30.1	 A Carroll     	1.00	 J Pond
\N	112	1	2	 Tymal Wizard=         	    	   2 	 2/1   	 3/1H  	 3/1H  	 2/1   	 2/1Q   	2	 1:59.2 	 30.1	 P Mackenzie   	4.55	 Alan W Fair
\N	112	1	6	 Howie=                	    	   6 	 3@/1H 	 2@/H  	 2@/1  	 3/1H  	 3/3H   	3	 1:59.4 	 30.3	 R Shepherd    	5.45	 C Yates
\N	112	1	4	 Irish Thunder         	    	   4 	 4/3   	 4/2H  	 4/2H  	 4/2H  	 4/4    	4	 2:00   	 30.3	 L House       	14.00	 P Brickman
\N	112	1	5	 Windsun Hugo          	    	   5 	 6/6   	 6@/5  	 5@/3  	 5/3   	 5/4Q   	5	 2:00   	 30.2	 R Holliday    	14.25	 K Di Cenzo
\N	112	1	9	 William Star          	    	   9 	 5/5   	 5/4   	 6@/4  	 6/3H  	 6/4Q   	6	 2:00   	 30.1	 J Maguire     	16.20	 J Maguire
\N	112	1	7	 Allies Gift           	    	   7 	 8/8   	 8@X/8 	 7@@/4H	 7/4   	 7/4H   	7	 2:00   	 30.1	 B Mcclure     	7.85	 L Ouellette
\N	112	1	3	 Hot Stikynsweet       	    	   3 	 7/7   	 7/7H  	 8/6   	 8/5   	 8/5H   	8	 2:00.1 	 30  	 S Young       	36.25	 G Carachi
\N	112	1	8	 All Out Henry         	    	   8 	 9/9   	 9/9   	 9@/6H 	 9/6   	 9/5T   	9	 2:00.2 	 30.1	 Do Brown      	20.60	 P Forgie
\N	112	2	1	 Rain Cloud Hanover    	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1H  	 1/T    	1	 1:55.1 	 28.3	 P Mackenzie   	3.05	 C Nicol
\N	112	2	2	 Tilikum               	    	   2 	 2/1H  	 2/1   	 3/1H  	 2/1H  	 2/T    	2	 1:55.2 	 28.3	 D St Pierre   	1.85	 T Staley
\N	112	2	6	 Doo Wee Rusty(L)      	    	   6 	 7/8   	 3@/1H 	 2@/1  	 3/2   	 3/5Q   	3	 1:56.1 	 29.2	 J Harris      	4.15	 J Harris
\N	112	2	3	 Miss Brandi K         	    	   3 	 3/3   	 4/3   	 5/3H  	 4/3   	 4/6Q   	4	 1:56.2 	 29.1	 R Shepherd    	8.40	 D Obrien
\N	112	2	4	 Fast Flyin Mach       	    	   4 	 4/4H  	 6/5   	 6@/4H 	 6/4H  	 5/8    	5	 1:56.4 	 29.2	 D Fritz       	27.45	 D Fritz
\N	112	2	7	 Island Blue           	    	   7 	 8/9H  	 5@/3H 	 4@/2  	 5/3H  	 6/8T   	6	 1:57   	 30  	 L House       	58.95	 S Mcniven
\N	112	2	9	 Cards That Count      	    	   9 	 6/7   	 8@/6H 	 8@/7  	 8/8   	 7/14   	7	 1:58   	 30  	 R Holliday    	16.80	 P Core
\N	112	2	5	 Emerald Rihanna       	    	   5 	 5/6   	 7/6   	 7/6H  	 7/7   	 8/16   	8	 1:58.2 	 30.3	 N Steward     	3.95	 C Schneider
\N	112	2	8	 Winning Matrimony     	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
\N	112	3	3	 Spy Flex=             	    	   3 	 1/1   	 1/1   	 1/H   	 1/1   	 1/NK   	1	 2:01.1 	 30.3	 G Rooney      	4.15	 F Drouillar
\N	112	3	4	 Don Luigi             	    	   4 	 2/1   	 2/1   	 3/1H  	 2/1   	 2/NK   	2	 2:01.1 	 30.2	 J Harris      	6.70	 R Griffiths
\N	112	3	1	 Toss It Back          	    	   1 	 4/4H  	 4/2H  	 4/3   	 4/3   	 3/1    	3	 2:01.2 	 30.1	 P Mackenzie   	4.65	 P Hunt
\N	112	3	7	 Talbotcreek Suzie=    	    	   7 	 3/2   	 3@/1H 	 2@/H  	 3/1H  	 4/5    	4	 2:02.1 	 31.3	 G Mcknight    	5.85	 G Mcknight
\N	112	3	6	 Nashville             	    	   6 	 5/6H  	 5@/3  	 5@/3H 	 5/3H  	 5/7Q   	5	 2:02.3 	 31.2	 R Holliday    	3.60	 N Elliott
\N	112	3	8	 Dead Red Hitter=      	    	   8 	 7/9H  	 7/6   	 7/5H  	 6/5   	 6/7T   	6	 2:02.4 	 31.1	 A Carroll     	71.55	 M Giles
\N	112	3	9	 Tiz                   	    	   9 	 6/8   	 6@/5  	 6@/4H 	 7/5H  	 7/8    	7	 2:02.4 	 31.2	 B Forward     	18.25	 J Pedden
\N	112	3	5	 Holiday Bro           	    	   5I	 8/10H 	 8/8   	 8/6H  	 8/7   	 8/10T  	8	 2:03.2 	 31.3	 T Moore       	5.60	 I Gallant
\N	112	3	10	 Leroys Dream=         	    	   2X	 9/12  	 9/9   	 9/8H  	 9/11  	 9/20   	9	 2:05.1 	 33  	 A Macdonald   	6.95	 A Macdonald
\N	112	3	2	 La Bella Rosa         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	112	4	4	 Lady Caterina=        	    	   4 	 2/1   	 2/1H  	 2/1   	 3/1H  	 1/NS   	1	 2:00.1 	 31  	 N Steward     	6.45	 Alan D Fair
\N	112	4	1	 Chewey=               	    	   1 	 1@/1  	 1/1H  	 1/1   	 1/H   	 2/NS   	2	 2:00.1 	 31.1	 B Mcclure     	1.30	 E Galinski
\N	112	4	9	 Noble Power           	    	   9 	 3/2   	 3@/2  	 3@/1H 	 2/H   	 3/1    	3	 2:00.2 	 31.1	 P Mackenzie   	10.10	 S Kerwood
\N	112	4	6	 Excellence            	    	   6 	 4/3   	 5/4   	 4/2   	 4/3   	 4/1T   	4	 2:00.3 	 31.1	 J Harris      	8.00	 I Downey
\N	112	4	2	 Increditable(L)       	    	   2 	 5/4   	 4@/3  	 5@/3  	 5/3H  	 5/2T   	5	 2:00.4 	 31.1	 R Shepherd    	3.85	 J Dupont
\N	112	4	7	 Incredable Frank(L)   	    	   7 	 8/7H  	 8/7H  	 8/7   	 7/6   	 6/3H   	6	 2:00.4 	 30.2	 A Carroll     	7.35	 R Moreau
\N	112	4	10	 Mr Putter             	    	   5 	 7/6   	 7/6H  	 6/5   	 6/4H  	 7/4H   	7	 2:01   	 31  	 R Holliday    	18.85	 T Genoe
\N	112	4	3	 Lima Playtime         	    	   3 	 6/5   	 6@/5  	 7/6   	 8/8   	 8/6T   	8	 2:01.3 	 31.2	 S Barrington  	24.40	 Ri Zeron
\N	112	4	8	 Nomad=(L)             	    	   8 	 9/9   	 9@/8  	 9/8H  	 9/9   	 9/9    	9	 2:02   	 31.2	 Do Brown      	34.10	 L Jonasson
\N	112	4	5	 Lady Dynamite=(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	115	1	2	 A Crafty Lady         	    	   2 	 3/4   	 3@/2H 	 1/2   	 1/3   	 1/4T   	1	 1:59.3 	 29.3	 R Shepherd    	\N	 A Hohner
\N	115	1	8	 Rods Famous Ribs      	    	   6 	 4/5T  	 4@/4  	 3@/2H 	 2/3   	 2/4T   	2	 2:00.3 	 30.1	 N Day         	\N	 R Moore
\N	115	1	3	 Thor Seelster(T)      	    	   3 	 5/7Q  	 5/5   	 5@/4  	 4/5   	 3/14Q  	3	 2:02.2 	 31.3	 R Holliday    	\N	 N Elliott
\N	115	1	1	 Twin B Serenity       	    	   1 	 2/1H  	 2/1H  	 4/3   	 5/5H  	 4/18Q  	4	 2:03.1 	 32.3	 R Gebhardt    	\N	 R Gebhardt
\N	115	1	5	 Jettin To Vegas       	    	   5 	 1/1H  	 1/1H  	 2/2   	 3/4   	 5/19T  	5	 2:03.3 	 33.1	 W Tymcio      	\N	 W Tymcio
\N	115	1	4	 First N Third         	    	   X4	 6/27Q 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 J Lee         	\N	 J Lee
\N	129	1	2	 Nothing But Bad       	    	   2 	 1/1H  	 2/2Q  	 1/5H  	 1/10  	 1/10H  	1	 2:00.4 	 30.2	 J Gillespie   	\N	 T Gillespie
\N	129	1	4	 Featured Illusion(T)  	    	   4 	 3/7   	 3/8H  	 3/9   	 2/10  	 2/10H  	2	 2:02.4 	 30.3	 M Johnson     	\N	 M Johnson
\N	129	1	5	 Top Dollar(T)         	    	   5 	 4/8H  	 4/10H 	 4/11  	 4/12H 	 3/12   	3	 2:03.1 	 30.3	 A Larsen      	\N	 A Larsen
\N	129	1	1	 Casimir Q Motion      	    	   1 	 5/11  	 5/13  	 5/13H 	 5/14  	 4/14T  	4	 2:03.4 	 30.4	 G Brown       	\N	 D Mccaw
\N	129	1	3	 Oaklea Victor(T)      	    	   3 	 2/1H  	 1/2Q  	 2/5H  	 3/10H 	 5/19   	5	 2:04.3 	 33.1	 J Bailey      	\N	 G Hart
\N	129	1	6	 Melanie C=(T)         	    	   6 	 6/13H 	 6/16H 	 6/17  	 6/19  	 6/21H  	6	 2:05   	 31.1	 B Collins     	\N	 B Collins
\N	134	1	5	 Janettes Image        	    	   5 	 4/5T  	 4/5T  	 3@/2H 	 2/NK  	 1/H    	1	 1:54.3 	 27.3	 Ja Macdonald  	1.00	 D Nixon
\N	134	1	6	 Diamond Tested        	    	   6 	 6/10H 	 6/10H 	 5@/4H 	 3/2   	 2/H    	2	 1:54.3 	 27.1	 D Mcnair      	25.90	 M Brethour
\N	134	1	3	 Misty De Vie          	    	   3 	 5/8H  	 5/8Q  	 6/6   	 6/6H  	 3BE/2H 	3	 1:55   	 27.1	 C Christoforou	15.50	 G Hunt
\N	134	1	1	 Place To Rocknroll    	    	   1 	 1/1T  	 1/2Q  	 1/2Q  	 1/NK  	 4/2H   	4	 1:55   	 28.2	 S Filion      	0.85	 T Alagna
\N	134	1	2	 Nic Nac Patty Mach    	    	   2 	 3/3H  	 3/3H  	 4/3T  	 5/4T  	 5/3    	5	 1:55.1 	 27.4	 Ra Waples     	20.40	 C Mitchell
\N	134	1	4	 Electric Ponder       	    	   4 	 2/1T  	 2/2Q  	 2/2Q  	 4/3H  	 6/5H   	6	 1:55.3 	 28.3	 M Saftic      	44.80	 D Brewer
\N	134	1	7	 City Charm            	    	   7 	 7/12H 	 7/12H 	 7@/6H 	 7/7Q  	 7/12H  	7	 1:57   	 29.1	 J Drury       	67.00	 B Macintosh
\N	134	2	6	 Candlelight Dinner    	    	   5 	 3@/2  	 1/2   	 2@/H  	 1/2   	 1/6    	1	 1:54.2 	 27.2	 J Drury       	0.10	 C Coleman
\N	134	2	5	 Black Jack Pat        	    	   4 	 1/2   	 2/2   	 3/2H  	 3/3T  	 2/6    	2	 1:55.3 	 28.1	 J Jamieson    	12.25	 D Menary
\N	134	2	2	 Moment To Ponder      	    	   2 	 4/4   	 4/5T  	 6@/6  	 6/8Q  	 3/7Q   	3	 1:55.4 	 27.3	 Ra Waples     	16.85	 R Mcintosh
\N	134	2	7	 Touching Thought      	    	   6 	 6/7H  	 6@/8Q 	 1/H   	 2/2   	 4/7T   	4	 1:56   	 29  	 Trev Henry    	9.30	 R Mcintosh
\N	134	2	1	 Braida Hanover        	    	   1 	 2/2   	 3/4   	 5/4H  	 4/6H  	 5/7T   	5	 1:56   	 28.1	 Ph Hudon      	39.95	 Colin Johns
\N	134	2	3	 Ohello Blue Chip(L)   	    	   3 	 5/5T  	 5/8   	 4@/4Q 	 5/7H  	 6/12   	6	 1:56.4 	 29  	 A Macdonald   	41.35	 A Macdonald
\N	134	2	8	 Takeyourbreathaway    	    	   7 	 7/10  	 7@/11 	 7/8T  	 7/11H 	 7/13H  	7	 1:57   	 28.1	 C Christoforou	46.75	 B Macintosh
\N	134	2	4	 Somemoneysomewhere    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	134	3	2	 Inner Drive           	    	   2 	 2/1T  	 2/T   	 2/1T  	 2/1H  	 1/NK   	1	 1:59.4 	 30.1	 P Macdonell   	0.75	 R Mcintosh
\N	134	3	6	 Hab Faith=            	    	   5 	 4/6Q  	 1@/T  	 1/1T  	 1/1H  	 2/NK   	2	 1:59.4 	 30.3	 D Mcnair      	1.90	 R Mcnair
\N	134	3	5	 Parkhill Nocredit     	    	   4 	 1/1T  	 3/3   	 3/4   	 3/4   	 3/2Q   	3	 2:00.1 	 30.1	 S Byron       	9.30	 J Bax
\N	134	3	1	 Sunnyday Kash         	    	   1 	 3/4Q  	 4/5T  	 4/10T 	 4/14H 	 4/19   	4	 2:03.3 	 32.1	 Da Wall       	86.05	 L Gibbons
\N	134	3	8	 Oh Miss Sophie        	    	   7 	 6/10T 	 X6X/10	 6/29  	 6/30  	 5/23H  	5	 2:04.2 	 29.2	 Ra Waples     	5.50	 Ro Waples J
\N	134	3	7	 Ticket To Seattle     	    	   6 	 5/8H  	 5/7T  	 X5X/16	 5/28  	 6/23H  	6	 2:04.2 	 32  	 Ja Macdonald  	36.15	 M Steacy
\N	134	3	3	 Duet Seelster=        	    	   3 	 X7/19H	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 R Holliday    	74.70	 R Maclean
\N	134	3	4	 Blink Shes Gone=      	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
\N	134	4	9	 Three Rivers Dell(L)  	    	   9 	 1/NK  	 2/1H  	 3/2   	 2/Q   	 1/1    	1	 1:53.3 	 28.2	 S Filion      	8.25	 R Fellows
\N	134	4	6	 Mayfield Duke         	    	   6 	 4/3H  	 4/5H  	 7/5T  	 6/3   	 2/1    	2	 1:53.4 	 27.4	 M Saftic      	14.05	 J Green
\N	134	4	5	 Jack Rackham          	    	   5 	 8/11T 	 8@/10 	 6@/4H 	 4/1H  	 3/2    	3	 1:54   	 28.2	 Trev Henry    	1.30	 A Montini
\N	134	4	4	 Archangel Three       	    	   4 	 7/10  	 6@/8Q 	 4@/2T 	 1/Q   	 4/2Q   	4	 1:54   	 28.3	 Ri Zeron      	3.85	 K Benn
\N	134	4	2	 To His Credit         	    	   2 	 5/6   	 5@/6H 	 2@/1  	 5/2   	 5/7    	5	 1:55   	 30  	 J Jamieson    	2.50	 C Jamieson
\N	134	4	1	 Corsica Hall(L)       	    	   1 	 3/1T  	 3/3Q  	 5/3T  	 7/3H  	 6/9H   	6	 1:55.2 	 29.4	 J Drury       	27.35	 C Auciello
\N	134	4	7	 Rose Run Ranger       	    	   7 	 9/13T 	 9/12H 	 8@/8Q 	 8/7T  	 7/12H  	7	 1:56   	 29.3	 R Holliday    	89.60	 J Pentland
\N	134	4	10	 Chalk Player          	    	   10	 2@/NK 	 1/1H  	 1/1   	 3X/H  	 8/12T  	8	 1:56.1 	 31.2	 D Mcnair      	19.80	 J Ritchie
\N	134	4	8	 Einhorn(L)            	    	   8 	 10/16Q	 10/17 	 10/14H	 10/13 	 9/14T  	9	 1:56.3 	 29  	 Ja Macdonald  	106.65	 M Rogers
\N	134	4	3	 Jet Black Cadillac    	    	   3 	 6/8Q  	 7/8T  	 9/8T  	 9/11H 	 10/23H 	10	 1:58.1 	 31.3	 S Condren     	110.60	 Alan W Fair
\N	134	5	6	 Monopoly              	    	   6 	 2/1H  	 2/1H  	 2/1H  	 1/T   	 1/4    	1	 1:56.2 	 29.3	 Trev Henry    	10.85	 G Cicero
\N	134	5	2	 Agent Dinozzo=        	    	   2 	 6/13T 	 6@/10T	 6@@/7 	 4/4H  	 2/4    	2	 1:57.1 	 29.1	 S Young       	1.10	 V Hayter
\N	134	5	7	 Silky Flashy Nfast    	    	   7 	 3/3H  	 3/3T  	 3/3Q  	 3/2Q  	 3/5Q   	3	 1:57.2 	 30.1	 M Baillargeon 	2.65	 B Baillarge
\N	134	5	9	 Rose Run Rudi         	    	   9 	 1@/1H 	 1/1H  	 1/1H  	 2/T   	 4/7Q   	4	 1:57.4 	 31.1	 S Byron       	7.35	 D Byron
\N	134	5	1	 Uf Musclemass Star    	    	   1 	 4/6Q  	 4/5T  	 4/5Q  	 5/6   	 5/11Q  	5	 1:58.3 	 31  	 S Filion      	9.45	 R Moreau
\N	134	5	10	 Archery=              	    	   10	 8/19Q 	 7@/13H	 7/7Q  	 6/7   	 6/11T  	6	 1:58.4 	 30.4	 D Mcnair      	57.30	 R Mcnair
\N	134	5	8	 Scotties Spirit=      	    	   8 	 5/10T 	 5/8Q  	 5@/6T 	 7/7T  	 7/16Q  	7	 1:59.3 	 31.3	 C Christoforou	18.85	 M Brethour
\N	134	5	3	 Copper Blues=         	    	   3 	 7/17H 	 8/18  	 8/16T 	 8/18H 	 8/26H  	8	 2:01.3 	 31.3	 C Steacy      	70.15	 M Steacy
\N	134	5	4	 Deuce Deuce Deuce     	    	   4X	 9/26  	 9/35  	 9/33T 	 9/33  	 9/35   	9	 2:03.2 	 30  	 J Moiseyev    	13.35	 J Moiseyev
\N	134	5	5	 Stormont Viceroy=     	    	   X5	 10/DIS	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 Ja Macdonald  	91.95	 N Jones
\N	134	6	5	 Powerful Mission      	    	   4 	 3/5Q  	 3/4   	 2@/1  	 1/Q   	 1/3    	1	 1:59.2 	 28.4	 Ph Hudon      	2.30	 K St Charle
\N	134	6	8	 Man Shes Hot          	    	   7 	 4/7   	 4/6   	 4@/2T 	 3/2Q  	 2/3    	2	 2:00   	 29  	 C Christoforou	1.85	 D Fontaine
\N	134	6	2	 Whole Lot Of Sugar    	    	   1 	 1/2T  	 1/2   	 1/1   	 2/Q   	 3/3    	3	 2:00   	 29.3	 J Jamieson    	3.30	 G Demers
\N	134	6	4	 You Cant Afford Me    	    	   3 	 6/10H 	 6/10T 	 6/7T  	 6/6T  	 4/5Q   	4	 2:00.2 	 28.2	 R Mayotte     	6.75	 S Mceneny
\N	134	6	3	 Warrawee Storm        	    	   2 	 5/8H  	 5/8Q  	 5/5H  	 5/6T  	 5/9H   	5	 2:01.1 	 29.4	 W Henry       	40.15	 W Henry
\N	134	6	6	 Hopeswishesndreams    	    	   5 	 2/2T  	 2/2   	 3/2Q  	 4/3H  	 6/12T  	6	 2:02   	 31.1	 D Mcnair      	6.90	 R Mcnair
\N	134	6	7	 Majestic Wanda        	    	   6 	 X7@/18	 7/25  	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 P Macdonell   	21.10	 J Bax
\N	134	6	1	 Rare Ruby             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	135	1	1	 Give Em Heck(L)       	    	   1 	 1/1T  	 1/1H  	 1/1T  	 1/1H  	 1/1H   	1	 1:54   	 29  	 Trev Henry    	0.80	 M Weller
\N	135	1	2	 P L Dangerous         	    	   2 	 5/8Q  	 5@/6H 	 4@@/3 	 2/1H  	 2/1H   	2	 1:54.1 	 28.3	 Ja Macdonald  	10.35	 B Gibson
\N	135	1	8	 Maracasso(L)          	    	   8 	 2/1T  	 2/1H  	 2/1T  	 3/2H  	 3/3H   	3	 1:54.3 	 29.1	 Ra Waples     	3.45	 N Gallucci
\N	135	1	5	 Rolandale Buster      	    	   5 	 3/4   	 3@/3Q 	 3@/1T 	 4/3Q  	 4/5Q   	4	 1:55   	 29.3	 G Ketros      	33.20	 G Ketros
\N	135	1	6	 Evening Job(L)        	    	   6 	 4/6   	 4/4T  	 5/3Q  	 5/4T  	 5/5T   	5	 1:55.1 	 29.3	 Ph Hudon      	21.50	 T Riley
\N	135	1	7	 Big Harold(L)         	    	   7 	 8/17Q 	 7@/9H 	 7@@/5Q	 6/4T  	 6/8Q   	6	 1:55.3 	 29.3	 S Filion      	9.95	 J Libby
\N	135	1	4	 Highland Boreas       	    	   4 	 6/11Q 	 6/8H  	 6/5   	 7/5H  	 7/19   	7	 1:57.4 	 31.4	 J Jamieson    	15.40	 M Fine
\N	135	1	3	 Twin B Sportsman      	    	   3 	 7/15  	 8@/11H	 8@/8  	 8/10Q 	 8/19   	8	 1:57.4 	 31.1	 S Byron       	69.30	 C Campbell
\N	135	1	9	 Hp Black Shadow(L)    	    	   9X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 D Mcnair      	8.35	 V Puddy
\N	135	2	2	 Golden Son            	    	   2 	 1/1T  	 1/1T  	 1/1H  	 1/2H  	 1/4    	1	 1:55.2 	 28.3	 S Filion      	0.45	 R Moreau
\N	135	2	5	 Mostinterestingman=   	    	   5 	 4/5H  	 4/5H  	 3@/4H 	 2/2H  	 2/4    	2	 1:56.1 	 28.3	 S Condren     	10.35	 M Dupuis
\N	135	2	6	 French Bastille=      	    	   6 	 6/10H 	 6/9   	 6@/7H 	 4/5T  	 3/4    	3	 1:56.1 	 28  	 Ja Macdonald  	24.85	 M Steacy
\N	135	2	9	 I Want Kandy(L)       	    	   9 	 2/1T  	 2/1T  	 2/1H  	 3/2H  	 4/7H   	4	 1:56.4 	 29.4	 Ph Hudon      	57.20	 A Montini
\N	135	2	3	 Dewtiful Lass=        	    	   3 	 5/8Q  	 5/7Q  	 5/6T  	 6/7Q  	 5/10Q  	5	 1:57.2 	 29.1	 Ra Waples     	118.15	 B Macdonald
\N	135	2	1	 Stormont Esquire=(L)  	    	   1 	 3/3T  	 3/3H  	 4/4T  	 5/7Q  	 6/13H  	6	 1:58   	 30.1	 J Jamieson    	46.45	 K Benn
\N	135	2	10	 Moonlight Cocktail    	    	   10	 8/15T 	 8/14H 	 8@/14T	 7/14  	 7/13T  	7	 1:58.1 	 28.2	 P Macdonell   	23.35	 J Bax
\N	135	2	7	 Dewy Dont Cheat       	    	   7 	 7/14Q 	 7/12H 	 7/13Q 	 8/16  	 8/17H  	8	 1:58.4 	 29.2	 Ri Zeron      	2.45	 Ri Zeron
\N	135	2	8	 Dynamic Edge          	    	   X8	 10/37T	 9/24H 	 9/22H 	 9/27T 	 9/32   	9	 2:01.4 	 30.3	 D Mcnair      	52.05	 R Mcnair
\N	135	2	4	 Classical Son=        	    	   4X	 X9X/17	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 M Baillargeon 	143.40	 S Larocque
\N	135	3	6	 Ideal Wheel           	    	   5 	 3/3H  	 3/3   	 2@/H  	 1/1T  	 1/2H   	1	 1:54   	 28  	 J Drury       	0.35	 C Coleman
\N	135	3	9	 Darlings Dragon       	    	   8 	 1/2   	 2/1H  	 3/2Q  	 3/2   	 2/2H   	2	 1:54.2 	 28  	 D Dupont      	4.30	 M Dupont
\N	135	3	3	 Woodacudashuda        	    	   2 	 5/6T  	 5/6T  	 4/4Q  	 5/6   	 3/7Q   	3	 1:55.2 	 28.3	 D Mcnair      	21.70	 J Morrison
\N	135	3	7	 One Source            	    	   6 	 4/5Q  	 4/4T  	 5@/4T 	 4/5Q  	 4/7T   	4	 1:55.3 	 28.3	 S Filion      	9.00	 R Moreau
\N	135	3	5	 Rock This Way         	    	   4 	 2/2   	 1/1H  	 1/H   	 2/1T  	 5/8T   	5	 1:55.4 	 29.4	 M Baillargeon 	8.90	 B Baillarge
\N	135	3	8	 Heza Big Dealer       	    	   7 	 8/11T 	 7/13T 	 7@/11Q	 6/12T 	 6/9H   	6	 1:55.4 	 27.3	 Ph Hudon      	30.40	 M Brethour
\N	135	3	1	 Word Game             	    	   1 	 6/8   	 6/9   	 6/9T  	 7/17T 	 7/29   	7	 1:59.4 	 31.4	 M Saftic      	101.65	 R Mcnair
\N	135	3	4	 Mavericks A Terror    	    	   3 	 7/10Q 	 X8/18T	 8/22H 	 8/30T 	 8/35   	8	 2:01   	 30.3	 Ja Macdonald  	81.90	 S Mceneny
\N	135	3	2	 Southwind General     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\N	135	4	7	 Anikadabra            	    	   7 	 1/3Q  	 1/1T  	 1/2   	 1/1T  	 1/3    	1	 1:59.3 	 29.4	 Ri Zeron      	10.35	 R Fellows
\N	135	4	5	 P C Pipe Dream        	    	   5 	 6/12T 	 5@/9  	 3@/3T 	 3/2H  	 2/3    	2	 2:00.1 	 29.3	 C Clements    	1.40	 P Clements
\N	135	4	3	 Late Shift=           	    	   3 	 2/3Q  	 2/1T  	 2/2   	 2/1T  	 3/4H   	3	 2:00.2 	 30.1	 Ja Macdonald  	7.75	 M Steacy
\N	135	4	2	 Tymal Declan          	    	   2 	 3/6Q  	 3/4H  	 4/4Q  	 4/5T  	 4/5T   	4	 2:00.4 	 30.1	 S Byron       	6.00	 J Bax
\N	135	4	6	 Kendras Coco          	    	   X6	 7/17Q 	 7@/10T	 6/9Q  	 5X/8H 	 X5/10Q 	5	 2:01.3 	 30  	 D Boughton    	1.75	 J Drennan
\N	135	4	4	 Judy Judy Judy=       	    	   4 	 5/10H 	 4/8   	 5/6H  	 6/9T  	 6/19Q  	6	 2:03.2 	 32.2	 S Filion      	20.60	 K Jones
\N	135	4	1	 Ionia=                	    	   1 	 4/8   	 X6X/10	 7/24  	 7/28H 	 7/DIS  	7	        	     	 Ra Waples     	21.20	 Colin Johns
\N	135	5	7	 Mystic Deuce(L)       	    	   7 	 5/11  	 5/10H 	 6/7H  	 5/4Q  	 1/NK   	1	 1:52.4 	 28.4	 C Christoforou	1.55	 N Gallucci
\N	135	5	5	 Hemingway(L)          	    	   5 	 6/13H 	 7/12H 	 7@/8T 	 4/3T  	 2/NK   	2	 1:52.4 	 28.2	 Trev Henry    	9.65	 R Moffatt
\N	135	5	10	 Highland Tartan       	    	   10	 1@/1T 	 1/1T  	 1/3H  	 1/1H  	 3/T    	3	 1:53   	 30.2	 J Drury       	8.55	 M Fine
\N	135	5	6	 Better Art(L)         	    	   6 	 7/15H 	 6@/12H	 5@/6H 	 3/2H  	 4/1    	4	 1:53   	 29.1	 S Filion      	4.75	 E Laybourne
\N	135	5	8	 Velocity Headlight(L) 	    	   8 	 4/8T  	 4/8H  	 3@/4H 	 2/1H  	 5/3Q   	5	 1:53.2 	 30  	 D Mcnair      	5.20	 L Bako
\N	135	5	4	 Stimulus Spending     	    	   4 	 10/21H	 10/20T	 10@/14	 9/9   	 6/6T   	6	 1:54.1 	 28.4	 Ja Macdonald  	33.75	 K Di Cenzo
\N	135	5	3	 Highland Bogart       	    	   3 	 3/6Q  	 3/5   	 4/5H  	 7/6H  	 7/12Q  	7	 1:55.1 	 31.3	 M Saftic      	43.70	 S Friend
\N	135	5	1	 Never Been Told       	    	   1 	 2/1T  	 2/1T  	 2/3H  	 6/5T  	 8/12Q  	8	 1:55.1 	 32  	 Ph Hudon      	4.35	 A Montini
\N	135	5	2	 P L Inferno           	    	   2 	 9/19Q 	 9@/17H	 8@@/10	 8/7T  	 9/19Q  	9	 1:56.3 	 32  	 S Young       	32.85	 J Libby
\N	135	5	9	 Sky Guy               	    	   9 	 8@/17H	 8/15H 	 9/13H 	 10/16H	 10/24H 	10	 1:57.3 	 32.2	 A Macdonald   	49.15	 A Macdonald
\N	147	1	2	 Cam Crazy             	    	   2 	 3/2   	 2/1H  	 2/1H  	 2/1Q  	 1/H    	1	 1:59.4 	 30.4	 M Bradley     	3.60	 M Bradley
\N	147	1	1	 Windemere Johny       	    	   1 	 1/1   	 1/1H  	 1/1H  	 1/1Q  	 2/H    	2	 1:59.4 	 31  	 D Romo        	3.95	 E Watts
\N	147	1	5	 Woodmere Terror       	    	   5 	 4/4   	 4/3H  	 4/2H  	 3/2H  	 3/1T   	3	 2:00.1 	 31  	 G Barrieau    	4.45	 A Maclean
\N	147	1	4	 Mystic Cruiser        	    	   4 	 2@/1  	 3@/2H 	 3@/2H 	 4/4   	 4/8    	4	 2:01.2 	 32.1	 E Laffin      	0.30	 F Saunders
\N	147	1	3	 Deacon Brodie         	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
\N	147	2	1	 A Bs Future           	    	   1X	 2/1H  	 3/2   	 3/2   	 3/1T  	 1/NK   	1	 2:00   	 29.3	 M Macdonald   	9.20	 B Macdonald
\N	147	2	5	 Coasttocoastshark     	    	   5 	 3/2T  	 5/4   	 5/3Q  	 5/3   	 2/NK   	2	 2:00   	 29.2	 C Macpherson  	1.25	 J Wallace
\N	147	2	4	 J Gs Willie           	    	   4 	 1/1H  	 1/1   	 1/1   	 1/1H  	 3/1    	3	 2:00.1 	 30.1	 D Spence      	6.25	 A Maclean
\N	147	2	3	 J K Cowboy            	    	   3 	 5@/5  	 2@/1  	 2@/1  	 2/1H  	 4/7T   	4	 2:01.3 	 31.2	 R Perrot      	1.35	 R Perrot
\N	147	2	2	 Sugar Crisp+          	    	   2 	 X4/4  	 4@/3  	 4/2Q  	 4/3   	 5/10T  	5	 2:02.1 	 31.4	 K Arsenault   	2.70	 M Mcguigan
\N	147	3	3	 Sauble Liz            	    	   3 	 1/1Q  	 1/1   	 2/Q   	 2/1Q  	 1/1    	1	 2:01.3 	 31.4	 K Parris      	8.85	 C Covin
\N	147	3	8	 Mach Vegas            	    	   8 	 2/1Q  	 3/2Q  	 3/1T  	 3/2H  	 2/1    	2	 2:01.4 	 31.3	 R Ellis       	4.25	 R Chase
\N	147	3	4	 Djs Kocakolacowboy    	    	   4 	 3@/1T 	 2@/1  	 1@/Q  	 1/1Q  	 3/2T   	3	 2:02.1 	 32.2	 H Smallwood   	2.05	 H Smallwood
\N	147	3	5	 Pick N Scoop          	    	   5 	 7/6   	 7/8H  	 6@/4T 	 4/3H  	 4/3    	4	 2:02.1 	 31.2	 C Macdonald   	6.05	 C Macdonald
\N	147	3	2	 Metro Man             	    	   2 	 4/3   	 5/4T  	 5/3T  	 5/4Q  	 5/3H   	5	 2:02.1 	 31.3	 D Crowe       	8.55	 K Gillis
\N	147	3	6	 Bizzy Izzy            	    	   6 	 8/7H  	 8@/9H 	 8/6T  	 7/5T  	 6/6Q   	6	 2:02.4 	 31.3	 E Laffin      	14.55	 N White
\N	147	3	1	 Glenview Natalie      	    	   1 	 5@/3H 	 4@/3Q 	 4@/2T 	 6/4Q  	 7/8Q   	7	 2:03.1 	 32.4	 D Spence      	4.90	 A Johnson
\N	147	3	7	 Rosa Santanna         	    	   7 	 6@/5T 	 6@/7H 	 7@/6H 	 8/5T  	 8/11   	8	 2:03.4 	 32.4	 G Barrieau    	2.65	 D Ellis
\N	147	4	1	 Magical Cowboy        	    	   1 	 2/1Q  	 2/1Q  	 2/1Q  	 2/1Q  	 1/H    	1	 1:58.1 	 29  	 C Macpherson  	1.30	 R Gass
\N	147	4	5	 Howmacsblackjack      	    	   5 	 1/1Q  	 1/1Q  	 1/1Q  	 1/1Q  	 2/H    	2	 1:58.1 	 29.1	 A Smith       	2.70	 A Smith
\N	147	4	6	 Silverhill Storm      	    	   6 	 5/6H  	 5/8T  	 4@/2T 	 3/1Q  	 3/2    	3	 1:58.3 	 29  	 J Hughes      	14.15	 J Hughes
\N	147	4	3	 Abner The Great       	    	   3 	 3/3H  	 3/4Q  	 3/2T  	 4/2H  	 4/3H   	4	 1:58.4 	 29.1	 G Barrieau    	2.15	 E Watts
\N	147	4	2	 Keen Edge             	    	   2 	 4/5   	 4/7H  	 5/4   	 5/3T  	 5/7    	5	 1:59.3 	 29.4	 D Romo        	9.60	 D Romo
\N	147	4	4	 Ic A Life Force       	    	   X4	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 K Arsenault   	4.15	 J Smith
\N	147	5	2	 Burkes Bandit         	    	   2 	 5@/9H 	 4@/4T 	 2@/1Q 	 2/NS  	 1/H    	1	 1:57.1 	 30  	 C Macpherson  	0.85	 T Hicken
\N	147	5	3	 Oppies Artist         	    	   3 	 1/2   	 1/2   	 1/1Q  	 1/NS  	 2/H    	2	 1:57.1 	 30.1	 A Campbell    	8.75	 A Campbell
\N	147	5	6	 Four Starz Hold Em    	    	   6 	 2/2   	 2/2   	 3/2Q  	 3/3Q  	 3/7T   	3	 1:58.4 	 31.2	 D Spence      	18.15	 N White
\N	147	5	8	 Djnorthernstar        	    	   8 	 8@/12T	 7@/10 	 6@@/4T	 5/4H  	 4/9H   	4	 1:59   	 31  	 R Ellis       	3.10	 D Jackson
\N	147	5	5	 Pride Of Paradise     	    	   5 	 6/10T 	 5@/8Q 	 5@/4Q 	 6/5   	 5/10T  	5	 1:59.2 	 31.3	 H Smallwood   	10.40	 H Smallwood
\N	147	5	4	 Neigh Monster         	    	   4 	 3/3Q  	 3/3T  	 4/4Q  	 4/4H  	 6/12H  	6	 1:59.3 	 31.4	 R Laffin      	3.45	 D Gillis
\N	147	5	7	 Pi Hanover            	    	   7 	 7@/11Q	 8/11  	 8@/10T	 8/15H 	 7/20T  	7	 2:01.2 	 32.1	 R Perrot      	13.65	 R Perrot
\N	147	5	1	 Go With It            	    	   1 	 4/8Q  	 6/8T  	 7/9T  	 7/15  	 8/21T  	8	 2:01.3 	 32.3	 B Mccallum    	15.35	 G Mccabe
\N	147	6	2	 Dusty Lane Arby       	    	   2 	 5/5H  	 5@/4T 	 4@/2Q 	 4/3   	 1/1H   	1	 1:57.1 	 29  	 C Macpherson  	3.05	 R Gass
\N	147	6	4	 Jackson K Down        	    	   4 	 1/1Q  	 1/1T  	 1/1   	 1/1Q  	 2/1H   	2	 1:57.2 	 29.3	 G Barrieau    	0.60	 S Mason
\N	147	6	6	 Lukes Cowboy          	    	   6 	 2/1Q  	 2/1T  	 3/1Q  	 2/1Q  	 3/1H   	3	 1:57.2 	 29.2	 K Arsenault   	3.70	 K Arsenault
\N	147	6	3	 J J Jodster           	    	   3 	 3/2H  	 3/3   	 5/2T  	 5/3   	 4/3Q   	4	 1:57.4 	 29.2	 D Romo        	23.15	 E Watts
\N	147	6	1	 Elm Grove Kaboom+     	    	   1 	 4/4Q  	 4@/3Q 	 2@/1  	 3/2   	 5/3T   	5	 1:58   	 30  	 A Smith       	9.20	 A Smith
\N	147	6	5	 Pictonian Power       	    	   5 	 6/6T  	 6/8T  	 6@/4Q 	 6/4H  	 6/4Q   	6	 1:58   	 29.2	 M Macdonald   	5.60	 M Macdonald
\N	148	1	4	 Icandothat            	    	   4 	 1/1H  	 1/2H  	 1/1H  	 1/1   	 1/H    	1	 2:00.3 	 30.4	 R Ellis       	1.25	 R Ellis
\N	148	1	1	 Lifeinthecountry      	    	   1 	 2/1H  	 3/2H  	 3/1T  	 3/2   	 2/H    	2	 2:00.3 	 30.2	 G Barrieau    	2.70	 J Ramsay Jr
\N	148	1	3	 Modern Best           	    	   3 	 4/4Q  	 4@/3H 	 4@/2T 	 4/2   	 3/H    	3	 2:00.3 	 30.1	 K Parris      	3.55	 C Covin
\N	148	1	2	 C L La Rousse         	    	   2 	 3/3   	 2@/2H 	 2@/1H 	 2/1   	 4/T    	4	 2:00.4 	 30.4	 M Macdonald   	2.80	 L Parker
\N	148	1	7	 Kendal Courageous     	    	   7 	 6/6T  	 5/4H  	 5/3Q  	 5/3   	 5/1H   	5	 2:00.4 	 30.2	 C Stevens     	37.40	 C Stevens
\N	148	1	5	 Just Lovey            	    	   5 	 5/5H  	 6@/5Q 	 6@/4Q 	 6/3Q  	 6/3T   	6	 2:01.2 	 30.4	 D Spence      	16.45	 N White
\N	148	1	6	 Mattadors Rose        	    	   6 	 8@/8H 	 8@/7Q 	 8/6H  	 8/5T  	 7/6T   	7	 2:02   	 31  	 J Lilley      	31.00	 J Lilley
\N	148	1	8	 Charlottes Style      	    	   8 	 7/8   	 7/6Q  	 7/5   	 7/4H  	 8/10T  	8	 2:02.4 	 32  	 D Carey       	15.10	 D Oconnor
\N	148	2	4	 Offshore Cowboy       	    	   4 	 3/2H  	 2@/H  	 1@/H  	 1/H   	 1/H    	1	 1:57.1 	 28.1	 J Hughes      	3.05	 D Milligan
\N	148	2	2	 Heart And Soul        	    	   2 	 1/1Q  	 1/H   	 2/H   	 2/H   	 2/H    	2	 1:57.1 	 28.1	 M Macdonald   	0.55	 M Macdonald
\N	148	2	1	 Wishiwasagigolo       	    	   1 	 2/1Q  	 3/1H  	 3/1T  	 3/1T  	 3/2    	3	 1:57.3 	 28.1	 M Bradley     	12.80	 A Smith
\N	148	2	3	 Mister Pibb           	    	   3 	 4/4   	 5/4   	 6/4Q  	 6/4Q  	 4/6Q   	4	 1:58.2 	 28.3	 D Romo        	8.55	 D Romo
\N	148	2	6	 K D Overdrive         	    	   6 	 6/6H  	 6@/4Q 	 5@/4  	 5/4   	 5/7    	5	 1:58.3 	 28.4	 G Barrieau    	6.55	 S Mason
\N	148	2	5	 Beaus Cowboy          	    	   5 	 5/5Q  	 4@/2H 	 4@/2  	 4/2T  	 6/8H   	6	 1:58.4 	 29.2	 C Cheverie    	4.50	 R Gass
\N	148	3	5	 Ramblinglily          	    	   5 	 2/1H  	 3/1T  	 2/1Q  	 2/1Q  	 1/HD   	1	 1:55.1 	 28.3	 C Cheverie    	1.75	 A Jones
\N	148	3	4	 Best Risque           	    	   4 	 1/1H  	 1/1Q  	 1/1Q  	 1/1Q  	 2/HD   	2	 1:55.1 	 28.4	 J Hughes      	8.60	 B Ladner
\N	148	3	1	 Shadows Mystery       	    	   1 	 3/3H  	 5/3   	 3/4   	 3/2T  	 3/4    	3	 1:56   	 28.4	 G Barrieau    	1.35	 J Matheson
\N	148	3	3	 Grins Little Flirt    	    	   3 	 7/10Q 	 7@/7Q 	 5/5H  	 4/4H  	 4/6    	4	 1:56.2 	 29  	 R Doucet      	10.65	 R Mac Leod
\N	148	3	6	 Miss Oromocto         	    	   6 	 8/11H 	 8@/9Q 	 7@/6T 	 5/6   	 5/8T   	5	 1:57   	 29.1	 M Haig        	11.90	 M Land
\N	148	3	8	 All Chocolate         	    	   8 	 4@/4H 	 2@/1Q 	 4@/5  	 6/6H  	 6/13H  	6	 1:57.4 	 30.2	 C Macpherson  	8.55	 T Hicken
\N	148	3	7	 Barona Lilac          	    	   7 	 5/5H  	 4@/2T 	 6@@/5T	 7/7H  	 7/20Q  	7	 1:59.1 	 31.3	 D Crowe       	5.15	 D Crowe
\N	148	3	2	 Sendmeasign           	    	   2 	 6/9   	 6/7   	 8/10T 	 8/11H 	 8/22   	8	 1:59.3 	 31  	 K Arsenault   	18.00	 M Sobey
\N	148	4	5	 D Gs Camme            	    	   5 	 1/1Q  	 1/1   	 1/1H  	 1/1T  	 1/3    	1	 1:53.2 	 28.2	 G Barrieau    	0.85	 J Matheson
\N	148	4	1	 Big Surf              	    	   1 	 2/1Q  	 3/2Q  	 2/1H  	 2/1T  	 2/3    	2	 1:54   	 28.4	 C Macpherson  	3.45	 T Hicken
\N	148	4	3	 Midnight Play         	    	   3 	 4/4   	 4/5T  	 4/3   	 3/3T  	 3/6    	3	 1:54.3 	 29  	 M Macdonald   	4.00	 T Hicken
\N	148	4	6	 Jeb                   	    	   6 	 6/6H  	 6/8H  	 6@@/4H	 6/5   	 4/9    	4	 1:55.1 	 29.2	 K Arsenault   	8.40	 J Hughes
\N	148	4	4	 His Boy Elroy         	    	   4 	 5/4Q  	 5/7   	 5@/4  	 5/5   	 5/9Q   	5	 1:55.1 	 29.2	 B Mccallum    	5.10	 B Mccallum
\N	148	4	2	 Ok Galahad            	    	   2 	 3/2H  	 2@/1  	 3@/2  	 4/4   	 6/10Q  	6	 1:55.2 	 30  	 J Hughes      	5.75	 J Hughes
\N	151	1	3	 Aaronel               	    	   2 	 1/2T  	 1/4H  	 1/6   	 1/5   	 1/4H   	1	 2:03.4 	 30.3	 E Laffin      	\N	 P Langille
\N	151	1	2	 Southwind Oasis       	    	   1 	 2/2T  	 2/4H  	 2/6   	 2/5   	 2/4H   	2	 2:04.3 	 30.1	 C Isenor      	\N	 W Mcneil
\N	151	1	4	 Meetmeatthebeach      	    	   3 	 3/6Q  	 3/8Q  	 3/9   	 3/10  	 3/13Q  	3	 2:06.2 	 31.2	 M Macdonald   	\N	 T Hardy
\.


--
-- Data for Name: race_details_20160724; Type: TABLE DATA; Schema: public; Owner: colin
--

COPY race_details_20160724 (id, race_id, race_number, horse_number, horse, hv, pp, quarter, half, thirdq, stretch, finish, finish_parsed, "time", lastq, driver, odds, trainer) FROM stdin;
1	7	1	5	 Audreys Dream         	    	   5 	 1/1   	 2/1H  	 1/2   	 1/8   	 1/9    	1	 1:53.3 	 28.1	 E Hensley     	0.35	 A Hensley
2	7	1	4	 Get Thereovernight    	    	   4 	 5/4Q  	 5/6   	 4/4H  	 3/9H  	 2/9    	2	 1:55.2 	 29.1	 K Hoerdt      	13.00	 K Hoerdt
3	7	1	3	 Son Of Anarchy        	    	   3 	 4/2T  	 4/4H  	 5@/4T 	 4/11  	 3/9T   	3	 1:55.3 	 29.1	 D A Kelly     	15.00	 G Manning
4	7	1	2	 Spinfiniti            	    	   2 	 2@/1  	 1/1H  	 3/2H  	 2/8   	 4/11   	4	 1:55.4 	 30  	 T Bowman      	20.05	 A Hensley
5	7	1	1	 Nobettorplacetobe     	    	   1 	 3/1Q  	 3/3   	 2@/2  	 5/14  	 5/23T  	5	 1:58.2 	 32.3	 T Cullen      	2.25	 T Cullen
6	7	2	2	 Smoke Eater           	    	   2 	 3/3H  	 3/4   	 3/2   	 3/1H  	 1/2H   	1	 1:57.2 	 28.4	 D Hudon       	4.05	 Q Schneider
7	7	2	3	 Da Magician           	    	   3 	 1/1H  	 1/1   	 1/1   	 1/HD  	 2/2H   	2	 1:57.4 	 29.3	 S Masse       	3.75	 S Masse
8	7	2	4	 Secrets Mystery       	    	   4 	 4/5H  	 4/5H  	 2@/1  	 2/HD  	 3/2T   	3	 1:58   	 29.3	 E Hensley     	3.75	 A Goertzen
9	7	2	7	 Outlaw Kismet         	    	   7 	 5/7   	 5/7   	 4/3H  	 4/3H  	 4/5Q   	4	 1:58.2 	 29.3	 J Gray        	2.75	 J Ratchford
10	7	2	5	 Pocket Novel          	    	   5X	 6/13  	 6/9   	 6/6   	 5/8H  	 5/14   	5	 2:00.1 	 30.4	 G Hudon       	22.00	 P Giesbrech
11	7	2	1	 Courageous C          	    	   X1	 7/16  	 7/12  	 7/8H  	 6/10H 	 6/15Q  	6	 2:00.2 	 30.3	 T Redwood     	2.75	 T Redwood
12	7	2	6	 Trustee               	    	   6 	 2/1H  	 2@/1  	 5/5H  	 7/14  	 7/21   	7	 2:01.3 	 32.2	 R Starkewski  	13.25	 R Starkewsk
13	7	3	3	 Retros Mystery        	    	   3 	 1@/1  	 1/1   	 1/1H  	 1/2   	 1/T    	1	 2:00.4 	 30.2	 R Starkewski  	2.50	 R Starkewsk
14	7	3	8	 Murder Mystery        	    	   8 	 2/1   	 3/1H  	 4/2T  	 2/2   	 2/T    	2	 2:01   	 30  	 R Hennessy    	22.35	 R Hennessy
15	7	3	6	 Charge And Go         	    	   6 	 4/7   	 6/5   	 5@@/3Q	 4/7   	 3/2Q   	3	 2:01.1 	 30.1	 K Clark       	1.95	 K Clark
16	7	3	2	 Tap Man               	    	   2 	 6/11H 	 2@/1  	 2/1H  	 3/4   	 4/3    	4	 2:01.2 	 30.4	 M Hennessy    	4.50	 R Hennessy
17	7	3	4	 Fanchastic            	    	   4 	 7X/13 	 8/12  	 7@/6Q 	 7/10  	 5/6T   	5	 2:02.1 	 30.3	 J Gray        	5.60	 A Arsenault
18	7	3	1	 Burntisland Billy     	    	   1 	 5/10  	 5@/3H 	 3@/2H 	 6/9   	 6/10T  	6	 2:03   	 32.1	 B Watt        	9.45	 P Giesbrech
19	7	3	5	 Fescue                	    	   5 	 3/3   	 4/3   	 6/5Q  	 5X/8  	 7/11H  	7	 2:03   	 31.3	 Jb Campbell   	11.50	 S Johnson
20	7	3	7	 Bring It In           	    	   7 	 8/16  	 7/8   	 8/12Q 	 8/17  	 8/23   	8	 2:05.2 	 32.3	 G Hudon       	19.75	 G Hudon
21	7	4	4	 Lifeimittatesart      	    	   4 	 4/5   	 3@/1T 	 2@/HD 	 1/HD  	 1/NS   	1	 1:55.4 	 28.3	 E Hensley     	0.95	 A Hensley
22	7	4	3	 Who Doesnt            	    	   3 	 1/2   	 1/1H  	 1/HD  	 2/HD  	 2/NS   	2	 1:55.4 	 28.3	 T Cullen      	1.60	 T Cullen
23	7	4	7	 Sterling Cooper       	    	   7 	 7/9H  	 7/6Q  	 3@@/H 	 3/NK  	 3/NK   	3	 1:55.4 	 28.3	 Jb Campbell   	20.80	 Jb Campbell
24	7	4	5	 Blue Eyed Cowboy      	    	   5 	 5/6H  	 5@/3Q 	 5@/1Q 	 5/4Q  	 4/1H   	4	 1:56   	 28.3	 T Bowman      	8.15	 R Starkewsk
25	7	4	1	 Cool Cowboy           	    	   1 	 2/2   	 2/1H  	 4/1   	 4/2Q  	 5/2T   	5	 1:56.2 	 29  	 K Hoerdt      	25.10	 K Hoerdt
26	7	4	2	 Premium Attaction     	    	   2 	 3/3H  	 4/2T  	 6/2Q  	 6/5T  	 6/3    	6	 1:56.2 	 28.4	 G Hudon       	10.60	 G Hudon
27	7	4	6	 Johnny Gun            	    	   6 	 6/8   	 6@/4T 	 7@/2T 	 7/7T  	 7/6T   	7	 1:57.1 	 29.2	 K Clark       	18.95	 H Haining
28	7	5	5	 Counter Strike        	    	   5 	 5/5   	 4@/2Q 	 2@@/1 	 1/3   	 1/3Q   	1	 1:54   	 28  	 T Cullen      	0.85	 T Cullen
29	7	5	7	 Drake                 	    	   7 	 7/8   	 6@/4T 	 4@/2  	 2/3   	 2/3Q   	2	 1:54.3 	 28.2	 E Hensley     	19.50	 A Hensley
30	7	5	1	 Big Time Sunrise      	    	   1 	 X1@/H 	 1/HD  	 3/1H  	 4/7   	 3/8    	3	 1:55.3 	 29.3	 K Clark       	3.35	 A Arsenault
31	7	5	2	 Rain Gauge            	    	   2 	 3/2   	 2@/HD 	 1@/1  	 3/5   	 4/8    	4	 1:55.3 	 29.4	 R Cullen      	4.85	 T Cullen
32	7	5	4	 Silent Rescue         	    	   4 	 4/3H  	 5/3T  	 6/4H  	 6/9   	 5/9H   	5	 1:55.4 	 29.1	 G Clark       	15.70	 G Clark
33	7	5	3	 Royal Renegade        	    	   3 	 2/H   	 3/1T  	 5@/3  	 5/8   	 6/9T   	6	 1:56   	 29.3	 R Hennessy    	14.55	 R Hennessy
34	7	5	6	 Mister Hat            	    	   6 	 6/6H  	 7/6Q  	 8/7   	 7/10  	 7/11Q  	7	 1:56.1 	 29  	 J Gagne       	26.80	 M Dumont
35	7	5	8	 Outlaw Deacon Jim     	    	   8 	 8/9H  	 8@/6T 	 7@/5  	 8/10H 	 8/12   	8	 1:56.2 	 29.3	 M Hennessy    	12.70	 R Hennessy
36	7	6	1	 Raging Fingers        	    	   1 	 1@/H  	 1/1H  	 1/H   	 1/H   	 1/NK   	1	 1:55.4 	 30.2	 T Cullen      	0.55	 T Cullen
37	7	6	4	 Captain Hazardous     	    	   4 	 5/5   	 3@/3  	 2@/H  	 2/H   	 2/NK   	2	 1:55.4 	 30.2	 D Hudon       	4.10	 D Hudon
38	7	6	3	 Lizard King           	    	   3 	 2/H   	 2/1H  	 3@/2  	 3/3H  	 3/1T   	3	 1:56.1 	 30.2	 T Redwood     	5.15	 T Redwood
39	7	6	2	 Somewhereinmexico     	    	   2 	 4/3H  	 5/4T  	 5/7H  	 4/6H  	 4/2Q   	4	 1:56.1 	 29.2	 D A Kelly     	19.70	 D A Kelly
40	7	6	6	 Cowboys Dirtyboots    	    	   5 	 6/6H  	 7/6T  	 6@@/7T	 6/10  	 5/7H   	5	 1:57.1 	 30.1	 R Grundy      	13.25	 D Crick
41	7	6	8	 Medicine Hat          	    	   7 	 3/2   	 4/3Q  	 4/6   	 5/9H  	 6/9H   	6	 1:57.3 	 31  	 K Hoerdt      	22.55	 K Hoerdt
42	7	6	7	 Karate King+          	    	   6 	 7/8   	 6@/5Q 	 7/8   	 7/14  	 7/21   	7	 2:00   	 33  	 K Clark       	15.10	 D Stout
43	7	6	5	 Full Moon Dodger      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
44	8	1	1	 Watch My Luck         	    	   1 	 4/6   	 4@/3H 	 2@/HD 	 2/HD  	 1/T    	1	 1:56.1 	 29.1	 J Gagne       	4.00	 M Dumont
45	8	1	5	 Jet Hot Stuff         	    	   5 	 6/9H  	 6@/5Q 	 4@/2H 	 3/1T  	 2/T    	2	 1:56.2 	 29  	 E Hensley     	1.60	 A Hensley
46	8	1	8	 Remember Terror       	    	   8 	 7/11  	 7/6T  	 6@/4Q 	 4/4T  	 3/4T   	3	 1:57.1 	 29.2	 S Masse       	19.20	 S Masse
47	8	1	3	 Phoenician Gal        	    	   3 	 1/1H  	 1/1H  	 1/HD  	 1/HD  	 4/5Q   	4	 1:57.1 	 30.1	 T Cullen      	1.65	 T Cullen
48	8	1	2	 Blue Star Texas       	    	   2 	 3/4H  	 3/3   	 5/4   	 5/6T  	 5/5H   	5	 1:57.1 	 29.2	 Jb Campbell   	11.05	 Jb Campbell
49	8	1	4	 Scarlet V             	    	   4 	 5/8   	 5/5   	 7/5T  	 7/9T  	 6/11H  	6	 1:58.2 	 30.1	 D Hudon       	21.10	 Q Schneider
50	8	1	7	 Mozelle Hanover       	    	   7 	 2/1H  	 2/1H  	 3/2Q  	 6/8T  	 7/21   	7	 2:00.2 	 33  	 J Gray        	30.55	 G Lutz
51	8	1	6	 Miss Hoozzitz         	    	   6X	 X8/25 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 T Bowman      	17.20	 D Lamont
52	8	2	4	 Ninetymile Hanover    	    	   4 	 6/9Q  	 6/8   	 6/3H  	 3/2Q  	 1/1    	1	 1:58.1 	 30.3	 D Hudon       	14.30	 D Hudon
53	8	2	3	 Make It So            	    	   3 	 5/5Q  	 5/3   	 4@@/2 	 1/2   	 2/1    	2	 1:58.2 	 31  	 T Cullen      	3.50	 T Cullen
54	8	2	7	 Acesndeuces           	    	   7 	 8/13T 	 7@/11 	 5@/3  	 4/2T  	 3/3Q   	3	 1:58.4 	 31.1	 N Sobey       	6.25	 S Johnson
55	8	2	2	 Hale Street           	    	   2 	 2@/Q  	 2@/H  	 2@/HD 	 2/2   	 4/6T   	4	 1:59.3 	 32.3	 T Bowman      	6.55	 D Cutting
56	8	2	8	 Upfront Cosmo         	    	   X8	 9/15T 	 9/15  	 8/7   	 7/6Q  	 5/7Q   	5	 1:59.3 	 31.1	 T Redwood     	33.70	 T Redwood
57	8	2	1	 Western Fortune       	    	   1 	 3/1T  	 3/1H  	 3/1H  	 6/5Q  	 6/8    	6	 1:59.4 	 32.3	 D A Kelly     	3.25	 C Reid
58	8	2	6	 Regina Beach          	    	   6 	 7/12Q 	 8/12  	 7/6H  	 8/6T  	 7/10Q  	7	 2:00.1 	 32  	 Jb Campbell   	5.70	 Jb Campbell
59	8	2	5	 Lone Rider            	    	   5 	 1/Q   	 1/H   	 1/HD  	 5/4T  	 8BE/12T	8	 2:00.4 	 33.4	 S Masse       	7.70	 S Arsenault
60	8	2	9	 Little Bit Faster     	    	   9 	 4/3Q  	 4@/2  	 X9@@/7	 9/DIS 	 9/DIS  	9	        	     	 M Hennessy    	6.15	 H Haining
61	8	3	3	 Vow To Win            	    	   3 	 6/6H  	 7@/8T 	 7@@/8H	 5/3   	 1/H    	1	 1:59   	 31.4	 J Gagne       	20.10	 Q Schneider
62	8	3	4	 Classy Artist         	    	   4 	 7/8   	 8@/10Q	 8@@/10	 2/2   	 2/H    	2	 1:59   	 31.2	 R Starkewski  	12.75	 R Starkewsk
63	8	3	6	 Ptsmagicmark          	    	   6 	 2@/1  	 3/5   	 3/4H  	 4/2H  	 3/2    	3	 1:59.2 	 33  	 K Ducharme    	15.55	 L Ducharme
64	8	3	2	 Red Tornado           	    	   2 	 4/3H  	 4/7   	 4/6H  	 3/2Q  	 4/2H   	4	 1:59.2 	 32.3	 M Hennessy    	4.30	 R Hennessy
65	8	3	1	 Man Of Many Arts      	    	   1 	 1/1   	 2/1   	 1/H   	 1/2   	 5/3H   	5	 1:59.3 	 34  	 T Bowman      	3.25	 D Lamont
66	8	3	5	 Iwontdothatagain      	    	   5 	 8/9H  	 6/8H  	 6/8Q  	 8/6H  	 6/3H   	6	 1:59.3 	 32.2	 J Gray        	15.15	 J Ratchford
67	8	3	7	 Broadview Bridge      	    	   7 	 5/5   	 5@/7H 	 5@/8  	 6/5   	 7/4H   	7	 1:59.4 	 32.3	 T Cullen      	1.75	 T Cullen
68	8	3	9	 Its Eds Idea          	    	   9 	 3/2   	 1@/1  	 2@/H  	 7/5H  	 8/5    	8	 2:00   	 34.2	 S Masse       	4.50	 S Masse
69	8	3	8	 Rare Breed            	    	   8 	 9/11  	 9/11T 	 9/15  	 9/11H 	 9/16   	9	 2:02.1 	 33.3	 G Hudon       	71.20	 D Sifert
70	8	4	3	 Greek Ruler           	    	   3 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/NR   	1	 1:57.4 	 30.1	 M Hennessy    	1.10	 C Lancaster
71	8	4	7	 Sonic Spark           	    	   7 	 7/9   	 5@/3H 	 4@/2  	 4/2Q  	 2/NR   	2	 NR     	     	 T Bowman      	29.60	 H Haining
72	8	4	9	 Rock Shooter          	    	   9 	 3/3   	 4/3   	 5/3   	 5/3T  	 3/NR   	3	 NR     	     	 T Cullen      	4.00	 T Cullen
73	8	4	2	 Lightning Legs        	    	   2 	 2/1H  	 2/1H  	 3/1H  	 3/1T  	 4/NR   	4	 NR     	     	 E Hensley     	5.30	 A Hensley
74	8	4	6	 Steal The Diamonds    	    	   6 	 6/7H  	 3@/2  	 2@/H  	 2/1H  	 5/NR   	5	 NR     	     	 D A Kelly     	14.55	 G Manning
75	8	4	4	 B R Money Matters     	    	   4 	 4/4H  	 6/5   	 6/6   	 6/5T  	 6/NR   	6	 NR     	     	 J Gray        	8.65	 A Jensen
76	8	4	5	 Cowboy Mathis         	    	   5 	 5/6   	 8/6T  	 8/9   	 7/9T  	 7/NR   	7	 NR     	     	 K Clark       	16.50	 K Clark
77	8	4	8	 Promise To Lynette    	    	   8 	 8/10H 	 7@/5Q 	 7@/7  	 8/12T 	 8/NR   	8	 NR     	     	 G Hudon       	10.05	 G Hudon
78	8	4	1	 You And Tequila       	    	   1X	 FELL  	       	       	       	 DNF    	\N	        	     	 T Redwood     	24.65	 T Redwood
79	9	1	5	 Appellate             	    	   5 	 6/13  	 6/15H 	 3/7H  	 3/3Q  	 1/H    	1	 1:58.4 	 28.4	 K Clark       	\N	 K Clark
80	9	1	3	 Whisper Well          	    	   3 	 2/4   	 2/1H  	 1/1H  	 1/3   	 2/H    	2	 1:58.4 	 30.1	 B Watt        	\N	 B Watt
81	9	1	6	 Hollywood Redneck     	    	   6 	 1/4   	 1/1H  	 2/1H  	 2/3   	 3/4Q   	3	 1:59.3 	 30.4	 G Hudon       	\N	 G Hudon
82	9	1	4	 A Wish For Wings      	    	   4 	 5/11  	 5/11H 	 5/15H 	 5/15T 	 4/16Q  	4	 2:02   	 30.2	 J Gray        	\N	 S Crump
83	9	1	1	 Speed Shift           	    	   1 	 3/6   	 3/6H  	 4/14H 	 4/15Q 	 5/20   	5	 2:02.4 	 31.2	 M Hennessy    	\N	 K Read
84	9	1	2	 Fast Lane Denali      	    	   2 	 4/8   	 4/9H  	 6/16H 	 6/19T 	 6/25T  	6	 2:04   	 32.1	 N Sobey       	\N	 T Tracey
85	9	2	4	 Lil Bit O Jingle      	    	   4 	 2@/HD 	 1/1H  	 1/1H  	 1/2   	 1/6    	1	 2:02.1 	 29.4	 T Cullen      	\N	 T Cullen
86	9	2	6	 Latestngreatest       	    	   6 	 1/HD  	 2/1H  	 2/1H  	 2/2   	 2/6    	2	 2:03.2 	 30.4	 K Clark       	\N	 K Clark
87	9	2	3	 Blue Star Cascade     	    	   3 	 5/6Q  	 5/12H 	 5/10H 	 3/8   	 3/8H   	3	 2:03.4 	 29.2	 G Hudon       	\N	 G Hudon
88	9	2	8	 Heated Exchange       	    	   8 	 7/11Q 	 7/17H 	 6@/12H	 5/10  	 4/9T   	4	 2:04.1 	 29.2	 R Cullen      	\N	 T Cullen
89	9	2	1	 Cenalta Cougar        	    	   1 	 3/2Q  	 3/7H  	 3/7H  	 4/9   	 5/11Q  	5	 2:04.2 	 30.3	 T Redwood     	\N	 D Stout
90	9	2	2	 Make Some Smiles      	    	   2 	 4/4Q  	 4/10H 	 4/9H  	 6/10H 	 6/11T  	6	 2:04.3 	 30.2	 K Hoerdt      	\N	 K Hoerdt
91	9	2	5	 Starry Eyes           	    	   5 	 6/8T  	 6/15H 	 7/14  	 7/16H 	 7/20T  	7	 2:06.2 	 31.1	 D Sifert      	\N	 D Sifert
92	9	2	7	 Orangevale Gazette    	    	   X7	 8/15Q 	 8/22H 	 8/24  	 8/29  	 8/36H  	8	 2:09.2 	 32.1	 M Bourgeois   	\N	 M Bourgeois
93	9	3	5	 Capitol Hill          	    	   5 	 4/4H  	 4/7   	 3@/2Q 	 2/HD  	 1/2    	1	 2:03.2 	 30  	 G Clark       	\N	 S Crump
94	9	3	4	 Formula D M           	    	   4 	 1/1H  	 1/2   	 1/2   	 1/HD  	 2/2    	2	 2:03.4 	 30.4	 G Hudon       	\N	 K Read
95	9	3	6	 Lilmessinaround       	    	   6 	 5/6   	 5/10  	 5@/5T 	 4/5T  	 3/4H   	3	 2:04.1 	 30  	 R Schneider   	\N	 R Schneider
96	9	3	2	 The Insinerator       	    	   2 	 2/1H  	 2/2   	 2/2   	 3/5Q  	 4/12   	4	 2:05.4 	 32.2	 D Hudon       	\N	 G Abbott
97	9	3	1	 Ganymeda Gold         	    	   1 	 3/3   	 3/5H  	 4/5Q  	 5/9T  	 5/18Q  	5	 2:07   	 33  	 N Sobey       	\N	 N Sobey
98	9	3	3	 El Capone             	    	   3X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 T Tracey      	\N	 T Tracey
99	10	1	5	 Audreys Dream         	    	   5 	 1/1   	 2/1H  	 1/2   	 1/8   	 1/9    	1	 1:53.3 	 28.1	 E Hensley     	0.35	 A Hensley
100	10	1	4	 Get Thereovernight    	    	   4 	 5/4Q  	 5/6   	 4/4H  	 3/9H  	 2/9    	2	 1:55.2 	 29.1	 K Hoerdt      	13.00	 K Hoerdt
101	10	1	3	 Son Of Anarchy        	    	   3 	 4/2T  	 4/4H  	 5@/4T 	 4/11  	 3/9T   	3	 1:55.3 	 29.1	 D A Kelly     	15.00	 G Manning
102	10	1	2	 Spinfiniti            	    	   2 	 2@/1  	 1/1H  	 3/2H  	 2/8   	 4/11   	4	 1:55.4 	 30  	 T Bowman      	20.05	 A Hensley
103	10	1	1	 Nobettorplacetobe     	    	   1 	 3/1Q  	 3/3   	 2@/2  	 5/14  	 5/23T  	5	 1:58.2 	 32.3	 T Cullen      	2.25	 T Cullen
104	10	2	2	 Smoke Eater           	    	   2 	 3/3H  	 3/4   	 3/2   	 3/1H  	 1/2H   	1	 1:57.2 	 28.4	 D Hudon       	4.05	 Q Schneider
105	10	2	3	 Da Magician           	    	   3 	 1/1H  	 1/1   	 1/1   	 1/HD  	 2/2H   	2	 1:57.4 	 29.3	 S Masse       	3.75	 S Masse
106	10	2	4	 Secrets Mystery       	    	   4 	 4/5H  	 4/5H  	 2@/1  	 2/HD  	 3/2T   	3	 1:58   	 29.3	 E Hensley     	3.75	 A Goertzen
107	10	2	7	 Outlaw Kismet         	    	   7 	 5/7   	 5/7   	 4/3H  	 4/3H  	 4/5Q   	4	 1:58.2 	 29.3	 J Gray        	2.75	 J Ratchford
108	10	2	5	 Pocket Novel          	    	   5X	 6/13  	 6/9   	 6/6   	 5/8H  	 5/14   	5	 2:00.1 	 30.4	 G Hudon       	22.00	 P Giesbrech
109	10	2	1	 Courageous C          	    	   X1	 7/16  	 7/12  	 7/8H  	 6/10H 	 6/15Q  	6	 2:00.2 	 30.3	 T Redwood     	2.75	 T Redwood
110	10	2	6	 Trustee               	    	   6 	 2/1H  	 2@/1  	 5/5H  	 7/14  	 7/21   	7	 2:01.3 	 32.2	 R Starkewski  	13.25	 R Starkewsk
111	10	3	3	 Retros Mystery        	    	   3 	 1@/1  	 1/1   	 1/1H  	 1/2   	 1/T    	1	 2:00.4 	 30.2	 R Starkewski  	2.50	 R Starkewsk
112	10	3	8	 Murder Mystery        	    	   8 	 2/1   	 3/1H  	 4/2T  	 2/2   	 2/T    	2	 2:01   	 30  	 R Hennessy    	22.35	 R Hennessy
113	10	3	6	 Charge And Go         	    	   6 	 4/7   	 6/5   	 5@@/3Q	 4/7   	 3/2Q   	3	 2:01.1 	 30.1	 K Clark       	1.95	 K Clark
114	10	3	2	 Tap Man               	    	   2 	 6/11H 	 2@/1  	 2/1H  	 3/4   	 4/3    	4	 2:01.2 	 30.4	 M Hennessy    	4.50	 R Hennessy
115	10	3	4	 Fanchastic            	    	   4 	 7X/13 	 8/12  	 7@/6Q 	 7/10  	 5/6T   	5	 2:02.1 	 30.3	 J Gray        	5.60	 A Arsenault
116	10	3	1	 Burntisland Billy     	    	   1 	 5/10  	 5@/3H 	 3@/2H 	 6/9   	 6/10T  	6	 2:03   	 32.1	 B Watt        	9.45	 P Giesbrech
117	10	3	5	 Fescue                	    	   5 	 3/3   	 4/3   	 6/5Q  	 5X/8  	 7/11H  	7	 2:03   	 31.3	 Jb Campbell   	11.50	 S Johnson
118	10	3	7	 Bring It In           	    	   7 	 8/16  	 7/8   	 8/12Q 	 8/17  	 8/23   	8	 2:05.2 	 32.3	 G Hudon       	19.75	 G Hudon
119	10	4	4	 Lifeimittatesart      	    	   4 	 4/5   	 3@/1T 	 2@/HD 	 1/HD  	 1/NS   	1	 1:55.4 	 28.3	 E Hensley     	0.95	 A Hensley
120	10	4	3	 Who Doesnt            	    	   3 	 1/2   	 1/1H  	 1/HD  	 2/HD  	 2/NS   	2	 1:55.4 	 28.3	 T Cullen      	1.60	 T Cullen
121	10	4	7	 Sterling Cooper       	    	   7 	 7/9H  	 7/6Q  	 3@@/H 	 3/NK  	 3/NK   	3	 1:55.4 	 28.3	 Jb Campbell   	20.80	 Jb Campbell
122	10	4	5	 Blue Eyed Cowboy      	    	   5 	 5/6H  	 5@/3Q 	 5@/1Q 	 5/4Q  	 4/1H   	4	 1:56   	 28.3	 T Bowman      	8.15	 R Starkewsk
123	10	4	1	 Cool Cowboy           	    	   1 	 2/2   	 2/1H  	 4/1   	 4/2Q  	 5/2T   	5	 1:56.2 	 29  	 K Hoerdt      	25.10	 K Hoerdt
124	10	4	2	 Premium Attaction     	    	   2 	 3/3H  	 4/2T  	 6/2Q  	 6/5T  	 6/3    	6	 1:56.2 	 28.4	 G Hudon       	10.60	 G Hudon
125	10	4	6	 Johnny Gun            	    	   6 	 6/8   	 6@/4T 	 7@/2T 	 7/7T  	 7/6T   	7	 1:57.1 	 29.2	 K Clark       	18.95	 H Haining
126	10	5	5	 Counter Strike        	    	   5 	 5/5   	 4@/2Q 	 2@@/1 	 1/3   	 1/3Q   	1	 1:54   	 28  	 T Cullen      	0.85	 T Cullen
127	10	5	7	 Drake                 	    	   7 	 7/8   	 6@/4T 	 4@/2  	 2/3   	 2/3Q   	2	 1:54.3 	 28.2	 E Hensley     	19.50	 A Hensley
128	10	5	1	 Big Time Sunrise      	    	   1 	 X1@/H 	 1/HD  	 3/1H  	 4/7   	 3/8    	3	 1:55.3 	 29.3	 K Clark       	3.35	 A Arsenault
129	10	5	2	 Rain Gauge            	    	   2 	 3/2   	 2@/HD 	 1@/1  	 3/5   	 4/8    	4	 1:55.3 	 29.4	 R Cullen      	4.85	 T Cullen
130	10	5	4	 Silent Rescue         	    	   4 	 4/3H  	 5/3T  	 6/4H  	 6/9   	 5/9H   	5	 1:55.4 	 29.1	 G Clark       	15.70	 G Clark
131	10	5	3	 Royal Renegade        	    	   3 	 2/H   	 3/1T  	 5@/3  	 5/8   	 6/9T   	6	 1:56   	 29.3	 R Hennessy    	14.55	 R Hennessy
132	10	5	6	 Mister Hat            	    	   6 	 6/6H  	 7/6Q  	 8/7   	 7/10  	 7/11Q  	7	 1:56.1 	 29  	 J Gagne       	26.80	 M Dumont
133	10	5	8	 Outlaw Deacon Jim     	    	   8 	 8/9H  	 8@/6T 	 7@/5  	 8/10H 	 8/12   	8	 1:56.2 	 29.3	 M Hennessy    	12.70	 R Hennessy
134	10	6	1	 Raging Fingers        	    	   1 	 1@/H  	 1/1H  	 1/H   	 1/H   	 1/NK   	1	 1:55.4 	 30.2	 T Cullen      	0.55	 T Cullen
135	10	6	4	 Captain Hazardous     	    	   4 	 5/5   	 3@/3  	 2@/H  	 2/H   	 2/NK   	2	 1:55.4 	 30.2	 D Hudon       	4.10	 D Hudon
136	10	6	3	 Lizard King           	    	   3 	 2/H   	 2/1H  	 3@/2  	 3/3H  	 3/1T   	3	 1:56.1 	 30.2	 T Redwood     	5.15	 T Redwood
137	10	6	2	 Somewhereinmexico     	    	   2 	 4/3H  	 5/4T  	 5/7H  	 4/6H  	 4/2Q   	4	 1:56.1 	 29.2	 D A Kelly     	19.70	 D A Kelly
138	10	6	6	 Cowboys Dirtyboots    	    	   5 	 6/6H  	 7/6T  	 6@@/7T	 6/10  	 5/7H   	5	 1:57.1 	 30.1	 R Grundy      	13.25	 D Crick
139	10	6	8	 Medicine Hat          	    	   7 	 3/2   	 4/3Q  	 4/6   	 5/9H  	 6/9H   	6	 1:57.3 	 31  	 K Hoerdt      	22.55	 K Hoerdt
140	10	6	7	 Karate King+          	    	   6 	 7/8   	 6@/5Q 	 7/8   	 7/14  	 7/21   	7	 2:00   	 33  	 K Clark       	15.10	 D Stout
141	10	6	5	 Full Moon Dodger      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
142	11	1	1	 Watch My Luck         	    	   1 	 4/6   	 4@/3H 	 2@/HD 	 2/HD  	 1/T    	1	 1:56.1 	 29.1	 J Gagne       	4.00	 M Dumont
143	11	1	5	 Jet Hot Stuff         	    	   5 	 6/9H  	 6@/5Q 	 4@/2H 	 3/1T  	 2/T    	2	 1:56.2 	 29  	 E Hensley     	1.60	 A Hensley
144	11	1	8	 Remember Terror       	    	   8 	 7/11  	 7/6T  	 6@/4Q 	 4/4T  	 3/4T   	3	 1:57.1 	 29.2	 S Masse       	19.20	 S Masse
145	11	1	3	 Phoenician Gal        	    	   3 	 1/1H  	 1/1H  	 1/HD  	 1/HD  	 4/5Q   	4	 1:57.1 	 30.1	 T Cullen      	1.65	 T Cullen
146	11	1	2	 Blue Star Texas       	    	   2 	 3/4H  	 3/3   	 5/4   	 5/6T  	 5/5H   	5	 1:57.1 	 29.2	 Jb Campbell   	11.05	 Jb Campbell
147	11	1	4	 Scarlet V             	    	   4 	 5/8   	 5/5   	 7/5T  	 7/9T  	 6/11H  	6	 1:58.2 	 30.1	 D Hudon       	21.10	 Q Schneider
148	11	1	7	 Mozelle Hanover       	    	   7 	 2/1H  	 2/1H  	 3/2Q  	 6/8T  	 7/21   	7	 2:00.2 	 33  	 J Gray        	30.55	 G Lutz
149	11	1	6	 Miss Hoozzitz         	    	   6X	 X8/25 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 T Bowman      	17.20	 D Lamont
150	11	2	4	 Ninetymile Hanover    	    	   4 	 6/9Q  	 6/8   	 6/3H  	 3/2Q  	 1/1    	1	 1:58.1 	 30.3	 D Hudon       	14.30	 D Hudon
151	11	2	3	 Make It So            	    	   3 	 5/5Q  	 5/3   	 4@@/2 	 1/2   	 2/1    	2	 1:58.2 	 31  	 T Cullen      	3.50	 T Cullen
152	11	2	7	 Acesndeuces           	    	   7 	 8/13T 	 7@/11 	 5@/3  	 4/2T  	 3/3Q   	3	 1:58.4 	 31.1	 N Sobey       	6.25	 S Johnson
153	11	2	2	 Hale Street           	    	   2 	 2@/Q  	 2@/H  	 2@/HD 	 2/2   	 4/6T   	4	 1:59.3 	 32.3	 T Bowman      	6.55	 D Cutting
154	11	2	8	 Upfront Cosmo         	    	   X8	 9/15T 	 9/15  	 8/7   	 7/6Q  	 5/7Q   	5	 1:59.3 	 31.1	 T Redwood     	33.70	 T Redwood
155	11	2	1	 Western Fortune       	    	   1 	 3/1T  	 3/1H  	 3/1H  	 6/5Q  	 6/8    	6	 1:59.4 	 32.3	 D A Kelly     	3.25	 C Reid
156	11	2	6	 Regina Beach          	    	   6 	 7/12Q 	 8/12  	 7/6H  	 8/6T  	 7/10Q  	7	 2:00.1 	 32  	 Jb Campbell   	5.70	 Jb Campbell
157	11	2	5	 Lone Rider            	    	   5 	 1/Q   	 1/H   	 1/HD  	 5/4T  	 8BE/12T	8	 2:00.4 	 33.4	 S Masse       	7.70	 S Arsenault
158	11	2	9	 Little Bit Faster     	    	   9 	 4/3Q  	 4@/2  	 X9@@/7	 9/DIS 	 9/DIS  	9	        	     	 M Hennessy    	6.15	 H Haining
159	11	3	3	 Vow To Win            	    	   3 	 6/6H  	 7@/8T 	 7@@/8H	 5/3   	 1/H    	1	 1:59   	 31.4	 J Gagne       	20.10	 Q Schneider
160	11	3	4	 Classy Artist         	    	   4 	 7/8   	 8@/10Q	 8@@/10	 2/2   	 2/H    	2	 1:59   	 31.2	 R Starkewski  	12.75	 R Starkewsk
161	11	3	6	 Ptsmagicmark          	    	   6 	 2@/1  	 3/5   	 3/4H  	 4/2H  	 3/2    	3	 1:59.2 	 33  	 K Ducharme    	15.55	 L Ducharme
162	11	3	2	 Red Tornado           	    	   2 	 4/3H  	 4/7   	 4/6H  	 3/2Q  	 4/2H   	4	 1:59.2 	 32.3	 M Hennessy    	4.30	 R Hennessy
163	11	3	1	 Man Of Many Arts      	    	   1 	 1/1   	 2/1   	 1/H   	 1/2   	 5/3H   	5	 1:59.3 	 34  	 T Bowman      	3.25	 D Lamont
164	11	3	5	 Iwontdothatagain      	    	   5 	 8/9H  	 6/8H  	 6/8Q  	 8/6H  	 6/3H   	6	 1:59.3 	 32.2	 J Gray        	15.15	 J Ratchford
165	11	3	7	 Broadview Bridge      	    	   7 	 5/5   	 5@/7H 	 5@/8  	 6/5   	 7/4H   	7	 1:59.4 	 32.3	 T Cullen      	1.75	 T Cullen
166	11	3	9	 Its Eds Idea          	    	   9 	 3/2   	 1@/1  	 2@/H  	 7/5H  	 8/5    	8	 2:00   	 34.2	 S Masse       	4.50	 S Masse
167	11	3	8	 Rare Breed            	    	   8 	 9/11  	 9/11T 	 9/15  	 9/11H 	 9/16   	9	 2:02.1 	 33.3	 G Hudon       	71.20	 D Sifert
168	11	4	3	 Greek Ruler           	    	   3 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/NR   	1	 1:57.4 	 30.1	 M Hennessy    	1.10	 C Lancaster
169	11	4	7	 Sonic Spark           	    	   7 	 7/9   	 5@/3H 	 4@/2  	 4/2Q  	 2/NR   	2	 NR     	     	 T Bowman      	29.60	 H Haining
170	11	4	9	 Rock Shooter          	    	   9 	 3/3   	 4/3   	 5/3   	 5/3T  	 3/NR   	3	 NR     	     	 T Cullen      	4.00	 T Cullen
171	11	4	2	 Lightning Legs        	    	   2 	 2/1H  	 2/1H  	 3/1H  	 3/1T  	 4/NR   	4	 NR     	     	 E Hensley     	5.30	 A Hensley
172	11	4	6	 Steal The Diamonds    	    	   6 	 6/7H  	 3@/2  	 2@/H  	 2/1H  	 5/NR   	5	 NR     	     	 D A Kelly     	14.55	 G Manning
173	11	4	4	 B R Money Matters     	    	   4 	 4/4H  	 6/5   	 6/6   	 6/5T  	 6/NR   	6	 NR     	     	 J Gray        	8.65	 A Jensen
174	11	4	5	 Cowboy Mathis         	    	   5 	 5/6   	 8/6T  	 8/9   	 7/9T  	 7/NR   	7	 NR     	     	 K Clark       	16.50	 K Clark
175	11	4	8	 Promise To Lynette    	    	   8 	 8/10H 	 7@/5Q 	 7@/7  	 8/12T 	 8/NR   	8	 NR     	     	 G Hudon       	10.05	 G Hudon
176	11	4	1	 You And Tequila       	    	   1X	 FELL  	       	       	       	 DNF    	\N	        	     	 T Redwood     	24.65	 T Redwood
177	12	1	5	 Appellate             	    	   5 	 6/13  	 6/15H 	 3/7H  	 3/3Q  	 1/H    	1	 1:58.4 	 28.4	 K Clark       	\N	 K Clark
178	12	1	3	 Whisper Well          	    	   3 	 2/4   	 2/1H  	 1/1H  	 1/3   	 2/H    	2	 1:58.4 	 30.1	 B Watt        	\N	 B Watt
179	12	1	6	 Hollywood Redneck     	    	   6 	 1/4   	 1/1H  	 2/1H  	 2/3   	 3/4Q   	3	 1:59.3 	 30.4	 G Hudon       	\N	 G Hudon
180	12	1	4	 A Wish For Wings      	    	   4 	 5/11  	 5/11H 	 5/15H 	 5/15T 	 4/16Q  	4	 2:02   	 30.2	 J Gray        	\N	 S Crump
181	12	1	1	 Speed Shift           	    	   1 	 3/6   	 3/6H  	 4/14H 	 4/15Q 	 5/20   	5	 2:02.4 	 31.2	 M Hennessy    	\N	 K Read
182	12	1	2	 Fast Lane Denali      	    	   2 	 4/8   	 4/9H  	 6/16H 	 6/19T 	 6/25T  	6	 2:04   	 32.1	 N Sobey       	\N	 T Tracey
183	12	2	4	 Lil Bit O Jingle      	    	   4 	 2@/HD 	 1/1H  	 1/1H  	 1/2   	 1/6    	1	 2:02.1 	 29.4	 T Cullen      	\N	 T Cullen
184	12	2	6	 Latestngreatest       	    	   6 	 1/HD  	 2/1H  	 2/1H  	 2/2   	 2/6    	2	 2:03.2 	 30.4	 K Clark       	\N	 K Clark
185	12	2	3	 Blue Star Cascade     	    	   3 	 5/6Q  	 5/12H 	 5/10H 	 3/8   	 3/8H   	3	 2:03.4 	 29.2	 G Hudon       	\N	 G Hudon
186	12	2	8	 Heated Exchange       	    	   8 	 7/11Q 	 7/17H 	 6@/12H	 5/10  	 4/9T   	4	 2:04.1 	 29.2	 R Cullen      	\N	 T Cullen
187	12	2	1	 Cenalta Cougar        	    	   1 	 3/2Q  	 3/7H  	 3/7H  	 4/9   	 5/11Q  	5	 2:04.2 	 30.3	 T Redwood     	\N	 D Stout
188	12	2	2	 Make Some Smiles      	    	   2 	 4/4Q  	 4/10H 	 4/9H  	 6/10H 	 6/11T  	6	 2:04.3 	 30.2	 K Hoerdt      	\N	 K Hoerdt
189	12	2	5	 Starry Eyes           	    	   5 	 6/8T  	 6/15H 	 7/14  	 7/16H 	 7/20T  	7	 2:06.2 	 31.1	 D Sifert      	\N	 D Sifert
190	12	2	7	 Orangevale Gazette    	    	   X7	 8/15Q 	 8/22H 	 8/24  	 8/29  	 8/36H  	8	 2:09.2 	 32.1	 M Bourgeois   	\N	 M Bourgeois
191	12	3	5	 Capitol Hill          	    	   5 	 4/4H  	 4/7   	 3@/2Q 	 2/HD  	 1/2    	1	 2:03.2 	 30  	 G Clark       	\N	 S Crump
192	12	3	4	 Formula D M           	    	   4 	 1/1H  	 1/2   	 1/2   	 1/HD  	 2/2    	2	 2:03.4 	 30.4	 G Hudon       	\N	 K Read
193	12	3	6	 Lilmessinaround       	    	   6 	 5/6   	 5/10  	 5@/5T 	 4/5T  	 3/4H   	3	 2:04.1 	 30  	 R Schneider   	\N	 R Schneider
194	12	3	2	 The Insinerator       	    	   2 	 2/1H  	 2/2   	 2/2   	 3/5Q  	 4/12   	4	 2:05.4 	 32.2	 D Hudon       	\N	 G Abbott
195	12	3	1	 Ganymeda Gold         	    	   1 	 3/3   	 3/5H  	 4/5Q  	 5/9T  	 5/18Q  	5	 2:07   	 33  	 N Sobey       	\N	 N Sobey
196	12	3	3	 El Capone             	    	   3X	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 T Tracey      	\N	 T Tracey
197	13	1	5	 Cowboys Dirtyboots    	    	   5 	 4/5   	 4/5   	 4/4H  	 5/5H  	 1/H    	1	 1:57.4 	 29.1	 R Grundy      	7.60	 D Crick
198	13	1	2	 Hollywood Redneck     	    	   2 	 2/1H  	 2/1H  	 2/1H  	 2/2   	 2/H    	2	 1:57.4 	 29.4	 G Hudon       	9.75	 G Hudon
199	13	1	4	 Vow To Win            	    	   4 	 3/3H  	 3/3H  	 3/3   	 3/3   	 3/1    	3	 1:58   	 29.3	 D Hudon       	8.15	 Q Schneider
200	13	1	1	 Rock Shooter          	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 4/1Q   	4	 1:58   	 30.1	 T Cullen      	0.30	 T Cullen
201	13	1	6	 Rare Breed            	    	   6 	 5/6H  	 5/6H  	 5/6   	 4/5   	 5/4    	5	 1:58.3 	 29.3	 M Hennessy    	15.65	 D Sifert
202	13	1	3	 Swing N Ace           	    	   X3	 6/DIS 	 6/35  	 6/35  	 6/30  	 6/27H  	6	 2:03.1 	 28.2	 E Hensley     	9.15	 A Hensley
203	13	2	6	 Cenalta Jade          	    	   6 	 5@/3T 	 4@/2Q 	 2@/HD 	 2/2   	 1/NK   	1	 2:02   	 32.3	 Jb Campbell   	2.05	 M Roy
204	13	2	1	 Awhimaway             	    	   1 	 1/1H  	 1/HD  	 1/HD  	 1/2   	 2/NK   	2	 2:02   	 32.3	 K Clark       	4.95	 K Clark
205	13	2	4	 Minettas Highball     	    	   4 	 6/4T  	 6/5Q  	 5/5   	 4/6H  	 3/1H   	3	 2:02.1 	 31.4	 K Ducharme    	4.95	 L Ducharme
206	13	2	3	 Barbarela Rose        	    	   3 	 4/3Q  	 5@/4Q 	 6@@/5H	 I5/8  	 5P4/3T 	5	 2:02.4 	 32.2	 T Redwood     	3.45	 A Arsenault
207	13	2	7	 Nevada                	    	   7 	 8/7T  	 8/7T  	 7@@/7 	 IX6/9H	 6P5/4Q 	6	 2:02.4 	 32  	 N Sobey       	24.35	 K Clark
208	13	2	5	 Showmesomeemotion     	    	   5 	 7/6Q  	 7@/6Q 	 4@/3H 	 3/4H  	 4P6/2  	4	 2:02.2 	 32.2	 G Hudon       	4.35	 P Giesbrech
209	13	2	2	 Forever Feisty        	    	   2 	 2/1H  	 3/1Q  	 3/3Q  	 7/10H 	 7/11T  	7	 2:04.2 	 34.2	 P Shaw        	42.50	 D Shaw
210	13	2	8	 Exclusive             	    	   8 	 3@/1T 	 2@/HD 	 8/8   	 8/23  	 8/35H  	8	 2:09   	 38  	 D Hudon       	10.30	 S Arsenault
211	13	3	2	 Mystery Mania         	    	   2 	 3/3H  	 3/3   	 1@/1  	 1/4   	 1/2T   	1	 2:00.1 	 31.1	 K Clark       	2.00	 K Clark
212	13	3	5	 Whysantanna           	    	   5 	 7/10H 	 7/9   	 6/4H  	 8/8T  	 2/2T   	2	 2:00.4 	 31  	 M Hennessy    	3.80	 R Hennessy
213	13	3	6	 Mystery Affair        	    	   6 	 8/12  	 8/10H 	 8@@/5H	 7/8Q  	 3/4H   	3	 2:01   	 31  	 G Hudon       	5.30	 P Giesbrech
214	13	3	1	 Formula D M           	    	   1 	 4/5   	 4/4H  	 4@/2T 	 3/4Q  	 4/4T   	4	 2:01.1 	 31.3	 D Hudon       	19.20	 K Read
215	13	3	4	 Brendons Eileen       	    	   4 	 6/9   	 6/7H  	 7@/5  	 6/7T  	 5/6Q   	5	 2:01.2 	 31.2	 P Shaw        	6.45	 D Sifert
216	13	3	7	 Moon Struct           	    	   7 	 2/1H  	 2/1H  	 3/2H  	 5/6T  	 6/7    	6	 2:01.3 	 32.1	 N Sobey       	12.65	 G Lutz
217	13	3	3	 Emmas Big Girl        	    	   3 	 5/7   	 5/6   	 5@@/4Q	 4/5T  	 7/7    	7	 2:01.3 	 31.4	 Jb Campbell   	3.35	 D Shaw
218	13	3	8	 My Glorifly           	    	   8 	 1/1H  	 1/1H  	 2/1   	 2/4   	 8/8T   	8	 2:02   	 32.4	 R Grundy      	23.60	 D Crick
219	13	4	3	 Mystic Messenger      	    	   3 	 1/4   	 1/1H  	 1/1H  	 1/2   	 1/2    	1	 1:57.4 	 29.1	 T Bowman      	4.30	 V Sifert
220	13	4	1	 Heart N Hustle        	    	   1 	 2/4   	 2/1H  	 2/1H  	 2/2   	 2/2    	2	 1:58.1 	 29.2	 Jb Campbell   	4.25	 M Roy
221	13	4	8	 Caliscape             	    	   8 	 5/8H  	 5@/5  	 5@@/3H	 6/7H  	 3/8    	3	 1:59.2 	 30.1	 T Cullen      	3.10	 T Cullen
222	13	4	6	 Avonlee Knight        	    	   6 	 4/7   	 4@/3H 	 4@/3Q 	 5/7   	 4/9    	4	 1:59.3 	 30.2	 N Sobey       	6.05	 G Lutz
223	13	4	4	 Coliseum Hanover      	    	   4 	 6/10  	 6/5H  	 6/4H  	 4I/6  	 6P5/9T 	6	 1:59.4 	 30.2	 R Cullen      	7.40	 T Cullen
224	13	4	2	 Mister Meister        	    	   2 	 3/5H  	 3/3   	 3/3   	 3/4   	 5P6/9Q 	5	 1:59.3 	 30.2	 R Grundy      	8.90	 R Grundy
225	13	4	5	 Promise We Can        	    	   5 	 7/11H 	 7@/6H 	 7@/5  	 7/8H  	 7/10T  	7	 2:00   	 30.2	 K Clark       	9.10	 G Lutz
226	13	4	7	 Thisboycanfinish      	    	   7 	 8/13  	 8/7H  	 8@/6H 	 8/10  	 8/11H  	8	 2:00   	 30.1	 G Clark       	6.15	 S Crump
227	13	5	8	 Mods Mystery          	    	   8 	 4/4H  	 4/4H  	 3@/1Q 	 1/Q   	 1/5Q   	1	 2:01.2 	 32  	 A Arsenault   	22.80	 A Arsenault
228	13	5	3	 Crash My Party        	    	   3 	 1/1H  	 1/1H  	 2/1   	 4/2   	 2/5Q   	2	 2:02.2 	 33  	 G Hudon       	1.15	 G Hudon
229	13	5	5	 Lissie Borden         	    	   5 	 2@/1H 	 2/1H  	 1@/1  	 2/Q   	 3/6H   	3	 2:02.3 	 33.2	 T Cullen      	2.25	 D Lamont
230	13	5	4	 Hf Princess Peach     	    	   4 	 6/9   	 7/8   	 6@/5Q 	 3/1T  	 4/6H   	4	 2:02.3 	 32.2	 M Hennessy    	17.30	 H Haining
231	13	5	1	 Starry Eyes           	    	   1 	 5/7H  	 5/6H  	 7/7Q  	 7/6H  	 5/7H   	5	 2:02.4 	 32.1	 D Sifert      	11.95	 D Sifert
232	13	5	6	 Is Santa Real         	    	   X6	 8/12H 	 6@/7H 	 4@/4Q 	 5/4   	 6/8Q   	6	 2:03   	 33  	 N Sobey       	6.25	 N Sobey
233	13	5	7	 Fast Lane Denali      	    	   7 	 7/11  	 8/9H  	 8/9Q  	 8/8   	 7/8H   	7	 2:03   	 32  	 T Tracey      	23.20	 T Tracey
234	13	5	2	 Miss Bojangles        	    	   2 	 3/3   	 3/3   	 5/4T  	 6/6   	 8/10Q  	8	 2:03.2 	 33.1	 K Clark       	8.40	 J Ratchford
235	13	6	1	 Dickies Motel         	    	   1 	 2/1H  	 3/1H  	 3@/2  	 3/1T  	 1/1H   	1	 1:58.1 	 31.1	 Jb Campbell   	6.70	 R Schneider
236	13	6	3	 Viola                 	    	   3 	 3/3   	 2@/H  	 1/1H  	 1/1H  	 2/1H   	2	 1:58.2 	 31.4	 J Hudon       	5.15	 J Hudon
237	13	6	9	 P L Impressive        	    	   9 	 4/4H  	 5@/4  	 4/7   	 4/3T  	 3/2Q   	3	 1:58.3 	 30.3	 E Hensley     	4.80	 A Hensley
238	13	6	5	 Happy Promise         	    	   5 	 1/1H  	 1/H   	 2/1H  	 2/1H  	 4/3Q   	4	 1:58.4 	 32  	 G Clark       	8.15	 G Clark
239	13	6	7	 Royal Classic         	    	   7 	 8/13  	 8/8T  	 5/9   	 5/5T  	 5/4T   	5	 1:59.1 	 30.4	 D Hudon       	18.55	 Q Schneider
240	13	6	6	 Wigesjet              	    	   6 	 7/11  	 7@/8H 	 6/10H 	 6/9T  	 6/10   	6	 2:00.1 	 31.3	 T Cullen      	4.55	 J Marchment
241	13	6	8	 Hoofenanny            	    	   8 	 9/14H 	 9/10Q 	 7/13H 	 7/12T 	 7/11Q  	7	 2:00.2 	 31.1	 M Hennessy    	16.35	 D Cutting
242	13	6	2	 Club Dreams           	    	   2 	 6/9   	 4/3H  	 X8/23H	 8/17T 	 8DQ/14T	8	 2:01.1 	 30  	 D A Kelly     	7.80	 R Parish
243	13	6	4	 Terra True            	    	   4 	 5/7H  	 6@/5H 	 IX9/DI	 FELL  	 DNF    	\N	        	     	 G Hudon       	3.05	 G Hudon
244	14	1	5	 Sudden Storm          	    	   5 	 1/1H  	 1/1H  	 1/H   	 1/1H  	 1/T    	1	 1:58.2 	 29.3	 T Bowman      	4.40	 D Sifert
245	14	1	6	 Outlaw This Is It     	    	   6 	 6@/8  	 5@/3H 	 2@/H  	 2/1H  	 2/T    	2	 1:58.3 	 29.4	 T Redwood     	6.15	 D Stout
246	14	1	7	 Canelo                	    	   7 	 2/1H  	 3/1T  	 3/2   	 3/3H  	 3/3H   	3	 1:59   	 29.4	 T Cullen      	2.70	 T Cullen
247	14	1	9	 Scrappy Fella         	    	   9 	 8/10H 	 7@/5H 	 4@/4  	 4/6H  	 4/4H   	4	 1:59.1 	 29.3	 M Hennessy    	4.45	 R Hennessy
248	14	1	4	 Cenalta Eclipse       	    	   4 	 7/9   	 8/7   	 6/5H  	 5/8H  	 5/4T   	5	 1:59.2 	 29.3	 R Goulet      	2.95	 G Empey
249	14	1	1	 Shyloh Sage           	    	   1 	 3/3   	 4/3Q  	 5/5   	 6/9H  	 6/8T   	6	 2:00.1 	 30.2	 A Arsenault   	10.55	 A Arsenault
250	14	1	3	 Thisboyisonfire       	    	   3 	 5/7H  	 6/5   	 7/7   	 7/13H 	 7/18   	7	 2:02   	 31.4	 Jb Campbell   	22.55	 Jb Campbell
251	14	1	2	 Speed Shift           	    	   2 	 4/4H  	 2@/1H 	 8@/7H 	 8/17H 	 8/21T  	8	 2:02.4 	 32.3	 G Hudon       	15.20	 K Read
252	14	1	8	 Sayitlikeyoumeanit    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
253	14	2	6	 Kim Chee              	    	   6 	 4/4H  	 4@/3T 	 3@/2H 	 2/2   	 1/NK   	1	 1:58.2 	 30  	 N Sobey       	3.00	 G Lutz
254	14	2	4	 Shes A Ladro          	    	   4 	 1/1H  	 1/2   	 1/2   	 1/2   	 2/NK   	2	 1:58.2 	 30.2	 B Gray        	13.10	 B Gray
255	14	2	9	 Yanotherhos           	    	   9 	 5/6   	 5@/5Q 	 5@/3T 	 4/4H  	 3/1    	3	 1:58.3 	 29.4	 T Bowman      	2.70	 J Waltenbur
256	14	2	1	 Fast Lane Ferrari     	    	   1 	 2/1H  	 2/2   	 2/2   	 3/3H  	 4/3T   	4	 1:59.1 	 30.4	 D Hudon       	6.20	 D Hudon
257	14	2	8	 Triple Action         	    	   8 	 9/12  	 9/9H  	 7@@/6H	 5/9H  	 5/8T   	5	 2:00.1 	 31  	 G Hudon       	17.60	 J Ratchford
258	14	2	3	 Run And Tell          	    	   3 	 7/9   	 7/7T  	 9@@/8T	 9/11  	 6/9H   	6	 2:00.1 	 30.2	 T Tracey      	5.55	 T Tracey
259	14	2	5	 Three Wishes          	    	   5 	 8/10H 	 8@/8  	 6@/6Q 	 8/10H 	 7/10T  	7	 2:00.3 	 31.2	 T Cullen      	4.25	 K Howard
260	14	2	7	 Little Sister         	    	   7 	 3/3   	 3@/2Q 	 4/3H  	 6/9T  	 8/14   	8	 2:01.1 	 32.3	 T Redwood     	13.70	 A Macleod
261	14	2	2	 Market For Romance    	    	   2 	 6/7H  	 6/5T  	 8/6T  	 7/10Q 	 9/16T  	9	 2:01.4 	 32.2	 K Ducharme    	31.20	 K Ducharme
262	16	1	1	 All The Weapons       	    	   1 	 2/1H  	 2/1T  	 2/2   	 2/1Q  	 1/3    	1	 2:00   	 29.4	 Bri Macphee   	3.20	 A Mc Guigan
263	16	1	6	 Caughtfoolinaround    	    	   6 	 1/1H  	 1/1T  	 1/2   	 1/1Q  	 2/3    	2	 2:00.3 	 30.4	 K Murphy      	1.30	 R Reynolds
264	16	1	8	 Twin B Macho          	    	   7 	 4/4H  	 4@/3H 	 3/3T  	 3/2T  	 3/5T   	3	 2:01.1 	 30.3	 K Arsenault   	5.30	 P Morrison
265	16	1	4	 Bumpsandbruises       	    	   4 	 6/7T  	 7@/7  	 4@@/6 	 4/4H  	 4/6    	4	 2:01.1 	 30.1	 R Neill       	2.50	 L Neill
266	16	1	5	 Canadian Rocket       	    	   5 	 7/10  	 6/6H  	 7/8T  	 6/8H  	 5/9    	5	 2:01.4 	 30.1	 M Cullen      	7.45	 G Macdougal
267	16	1	2	 Hopedale Paris        	    	   2 	 5/6   	 5@/5Q 	 5@/7  	 5/6T  	 6/9T   	6	 2:02   	 30.4	 Jy Pineau     	13.20	 Jy Pineau
268	16	1	3	 St Lads Coach         	    	   3 	 3/2T  	 3/3Q  	 6/7H  	 7/10H 	 7/22   	7	 2:04.2 	 33.1	 K Wilkie      	25.30	 K Wilkie
269	16	1	7	 Sparky Bayama         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
270	16	2	5	 Neal                  	    	   4 	 1@/1Q 	 1/1H  	 1/1T  	 1/1T  	 1/3T   	1	 2:02.1 	 29.3	 B Andrew      	0.85	 B Andrew
271	16	2	4	 Howmacs Pride         	    	   3 	 2/1Q  	 2/1H  	 2/1T  	 2/1T  	 2/3T   	2	 2:03   	 30  	 K Arsenault   	1.75	 K Arsenault
272	16	2	1	 Dusty Lane Jacob      	    	   1 	 3/3   	 3/3   	 3/3H  	 3/3Q  	 3/8H   	3	 2:03.4 	 30.3	 W Murphy      	7.55	 C Mac Donal
273	16	2	3	 Tymal Tyme            	    	   X2	 X5/7  	 4@/4  	 5/11  	 5/14  	 5P4/27 	5	 2:07.3 	 32.4	 Bri Macphee   	7.55	 C Mac Donal
274	16	2	6	 High Flying=          	    	   5 	 4/5Q  	 5/4H  	 4@X/4H	 4/4H  	 4P5/19 	4	 2:06   	 32.3	 G Hennessey   	3.65	 G Hennessey
275	16	2	2	 Job Well Done         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
276	16	3	5	 Anianne Hanover       	    	   5 	 3@/2H 	 3@/1T 	 2@/1  	 2/H   	 1/NK   	1	 2:00.4 	 29.4	 T Walsh       	1.30	 T Walsh
277	16	3	4	 Smart N Articulate    	    	   4 	 1/1T  	 1/1H  	 1/1   	 1/H   	 2/NK   	2	 2:00.4 	 30  	 K Arsenault   	2.60	 J Smith
278	16	3	8	 Scoot Out Of Here     	    	   7 	 5/5T  	 5@/6Q 	 4/3Q  	 4/2T  	 3/2    	3	 2:01.1 	 29.4	 V Doyle       	3.40	 V Doyle
279	16	3	1	 Outrageous Belle      	    	   1 	 2/1T  	 2/1H  	 3/1H  	 3/1T  	 4/3    	4	 2:01.2 	 30.2	 R Matheson    	10.25	 J Matheson
280	16	3	6	 Silverhill Midnite    	    	   6 	 6/7H  	 6@/8  	 5/7H  	 5/8   	 5/14   	5	 2:03.3 	 31.2	 P Lanigan     	15.90	 W Lanigan
281	16	3	3	 New Boss In Town      	    	   3 	 7/9   	 7/12  	 6/13  	 6/14  	 6/21   	6	 2:05   	 31.3	 G Chappell    	4.70	 E Watts
282	16	3	2	 Popa Was A Gigolo     	    	   2 	 4/3T  	 4/5T  	 7/17  	 7/25  	 7/DIS  	7	        	     	 K Sorrie      	11.40	 J Clarey
283	16	3	7	 Baby Picka            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
284	16	4	5	 Caliban Hanover       	    	   5 	 5/5   	 6@/6Q 	 5@/2T 	 3/1Q  	 1/3    	1	 2:02.3 	 30.1	 A Merner      	3.45	 R Gass
285	16	4	4	 Parkhill Jugernaut=   	    	   4 	 3/2   	 3@/3  	 1@/Q  	 1/Q   	 2/3    	2	 2:03.1 	 31.2	 A Campbell    	6.05	 A Campbell
286	16	4	7	 Tyne Valley=          	    	   7 	 6/7Q  	 4@/4H 	 3@/1H 	 4/1H  	 3/4    	3	 2:03.2 	 31.2	 C Cheverie    	1.45	 W Roloson
287	16	4	3	 Hopedale Dora         	    	   3 	 1/T   	 2/1T  	 4/1T  	 5/1T  	 4/4T   	4	 2:03.3 	 31.2	 Jy Pineau     	5.95	 Jy Pineau
288	16	4	6	 Majian Dillon=        	    	   6 	 2@/T  	 1/1T  	 2/Q   	 2/Q   	 5/4T   	5	 2:03.3 	 31.4	 J Ripley      	12.95	 J Ripley
289	16	4	2	 Phantom Beau=         	    	   2 	 7/10H 	 7/9H  	 7/6Q  	 7/5H  	 6/5T   	6	 2:03.4 	 30.4	 K Arsenault   	2.55	 T Weatherbi
290	16	4	1	 Diamond Mine          	    	   1 	 4/3H  	 5/4T  	 6/3H  	 6/4   	 7/7Q   	7	 2:04   	 31.3	 W Murphy      	11.95	 C Mac Donal
291	16	5	5	 J J Dream Chasin      	    	   5 	 2/Q   	 1/1Q  	 1/1Q  	 1/1Q  	 1/1    	1	 2:01.2 	 30  	 G Chappell    	0.60	 G Chappell
292	16	5	6	 Dustlanemissmolly     	    	   6 	 1@/Q  	 2/1Q  	 3/1H  	 2/1Q  	 2/1    	2	 2:01.3 	 30  	 A Merner      	5.70	 R Gass
293	16	5	3	 Gangnam Style         	    	   3 	 3/3H  	 3/3   	 5/3   	 3/3Q  	 3/1Q   	3	 2:01.3 	 29.3	 G Hennessey   	8.00	 J Matheson
294	16	5	4	 Mileysgotthepower     	    	   4 	 6/8Q  	 6@/5H 	 4@/2T 	 5/5   	 4/6H   	4	 2:02.3 	 30.3	 R Neill       	4.90	 J Noye
295	16	5	2	 Victory Cry           	    	   2 	 5/6H  	 4@/3Q 	 2@/1Q 	 4/3H  	 5/9T   	5	 2:03.2 	 31.4	 K Arsenault   	4.35	 K Arsenault
296	16	5	1	 Camtizzy              	    	   1 	 4/5   	 5/4Q  	 6/5   	 6/8   	 6/18   	6	 2:05   	 32.3	 R Matheson    	8.90	 J Matheson
297	16	6	5	 Freddie=              	    	   5 	 5/8T  	 4@/3Q 	 1@/T  	 1/4   	 1/6T   	1	 1:59   	 28.4	 R Desroche    	0.60	 Ma Campbell
298	16	6	2	 Wedgewood=            	    	   2 	 3/3T  	 3/3   	 4@/2T 	 3/4Q  	 2/6T   	2	 2:00.2 	 29.3	 G Chappell    	5.65	 G Claybourn
299	16	6	6	 Majian Chester        	    	   6 	 4/6H  	 5/4H  	 5@/4T 	 5/6T  	 3/9    	3	 2:00.4 	 29.3	 J Ripley      	27.45	 J Ripley
300	16	6	4	 I Aint No Lady        	    	   4 	 1/1H  	 1/1H  	 2/T   	 2/4   	 4/9Q   	4	 2:00.4 	 30.2	 Bri Macphee   	13.75	 G Cole
301	16	6	1	 Holy Molie Maggie=    	    	   1 	 2/1H  	 2/1H  	 3/2H  	 4/5Q  	 5/10H  	5	 2:01   	 30.2	 Jy Pineau     	13.15	 J Holmes
302	16	6	3	 Frill Seeker=         	    	   X3	 6/10H 	 6/6   	 6/6   	 6/7H  	 6/12   	6	 2:01.2 	 30  	 K Arsenault   	1.45	 K Arsenault
303	17	1	1	 Pictonian Zena+       	    	   1 	 1/Q   	 1/1H  	 1/3H  	 1/4Q  	 1/5    	1	 1:59.3 	 30.3	 S Bernard     	1.00	 S Bernard
304	17	1	3	 South Cove Pearl      	    	   3 	 4/4T  	 4/5   	 4@/5  	 3/4H  	 2/5    	2	 2:00.3 	 30.3	 K Arsenault   	7.65	 J Arsenault
305	17	1	2	 Briannas Angel        	    	   2 	 3/3Q  	 3/3Q  	 2@/3H 	 2/4Q  	 3/5Q   	3	 2:00.3 	 31  	 C Cheverie    	1.40	 T Wilkie
306	17	1	4	 A Littlegirlsdream    	    	   4 	 5/6Q  	 5/6H  	 5@/6Q 	 4/6Q  	 4/6Q   	4	 2:00.4 	 30.3	 R Phillips    	6.80	 R Phillips
307	17	1	7	 M D Caseys Charm      	    	   7 	 2@/Q  	 2/1H  	 3/4T  	 5/7H  	 5/12   	5	 2:02   	 32  	 S Ford        	21.05	 S Ford
308	17	1	5	 R Es Kate             	    	   5 	 6/10  	 6/8H  	 6/8H  	 6/10  	 6/13H  	6	 2:02.1 	 31.3	 R Neill       	9.30	 L Neill
309	17	1	6	 G Js Winning Fool     	    	   6 	 7/12H 	 7/13  	 7/15  	 7/16  	 7/17   	7	 2:03   	 31  	 R Desroche    	22.85	 K Wilkie
310	17	2	2	 Female Finesse        	    	   2 	 2/1H  	 2/1T  	 2/1H  	 2/1Q  	 1/1H   	1	 1:58.4 	 29  	 G Chappell    	3.50	 W White
311	17	2	3	 Outrageous Spirit     	    	   3 	 1/1H  	 1/1T  	 1/1H  	 1/1Q  	 2/1H   	2	 1:59   	 29.2	 G Hennessey   	0.50	 K Peters
312	17	2	5	 Julep Hanover         	    	   5 	 4/5   	 4/4T  	 4@/3Q 	 4/2T  	 3/4H   	3	 1:59.3 	 29.2	 W Myers       	8.75	 W Myers
313	17	2	1	 Starlight Violet      	    	   1 	 5/7Q  	 5/6H  	 5/4T  	 6/4Q  	 4/5    	4	 1:59.4 	 29.1	 K Murphy      	12.70	 M Bradley
314	17	2	4	 Gramercy Hanover      	    	   4 	 3/3Q  	 3/3Q  	 3@/2  	 3/1T  	 5/5T   	5	 2:00   	 30  	 B Webster     	4.45	 B Macleod
315	17	2	6	 Bettim Jenny          	    	   6 	 6/9T  	 6/8T  	 6@/5T 	 5/3Q  	 6/6    	6	 2:00   	 29.1	 J Lilley      	20.35	 J Lilley
316	17	2	7	 Yankee No More        	    	   7 	 7/12  	 7/11H 	 7/7Q  	 7/6   	 7/9T   	7	 2:00.4 	 29.4	 D Mac Neill   	15.35	 D Smith
317	17	3	5	 Jetta Flys+           	    	   5 	 1/1T  	 1/1H  	 1/1Q  	 1/1Q  	 1/2H   	1	 1:59.4 	 28.3	 S Quinn       	5.25	 S Quinn
318	17	3	2	 Van Zant              	    	   2 	 2/1T  	 2/1H  	 3/1H  	 2/1Q  	 2/2H   	2	 2:00.1 	 28.4	 R Matheson    	0.80	 J Matheson
319	17	3	3	 Cloudy Bay            	    	   3 	 4/5   	 5/4Q  	 6/4Q  	 4/5   	 3/8H   	3	 2:01.2 	 29.2	 A Merner      	2.00	 A Merner
320	17	3	1	 Ok Gladiator          	    	   1 	 3/3Q  	 3/3   	 4/2T  	 3/3H  	 4/9T   	4	 2:01.4 	 30  	 V Doyle       	15.15	 V Doyle
321	17	3	6	 Incredible Mike       	    	   6 	 6/11  	 6@/5  	 5@/3  	 6/6Q  	 5/11H  	5	 2:02   	 30.1	 K Murphy      	12.00	 G Macdougal
322	17	3	4	 Textually Active      	    	   4 	 5/9   	 4@/3H 	 2@/1Q 	 5/5T  	 6/13   	6	 2:02.2 	 31  	 G Chappell    	10.70	 P Gregory
323	17	3	7	 P H Littlecam         	    	   7 	 7/13H 	 7/7   	 8/5T  	 7/7   	 7/14   	7	 2:02.3 	 30.1	 Bri Macphee   	27.00	 B Webster
324	17	3	8	 Avid Yankee           	    	   8 	 8/16  	 8/8Q  	 7@/4H 	 8/7H  	 8/15   	8	 2:02.4 	 30.4	 M Mcguigan    	27.20	 A Ramsay
325	17	4	6	 Windemere Stanley     	    	   5 	 4/3T  	 3@/3  	 2@/HD 	 2/Q   	 1/1H   	1	 1:58   	 30.4	 A Merner      	6.50	 K Gillis
326	17	4	8	 Every Day             	    	   7 	 2@/1  	 2/1T  	 3/2Q  	 3/2Q  	 2/1H   	2	 1:58.1 	 30.3	 B Andrew      	13.90	 B Andrew
327	17	4	2	 Astronomical Union    	    	   2 	 1/1   	 1/1T  	 1/HD  	 1/Q   	 3/1T   	3	 1:58.2 	 31.1	 M Mcguigan    	1.20	 J Matheson
328	17	4	1	 Jamantha              	    	   1 	 3/2Q  	 4/3H  	 4/4Q  	 4/4Q  	 4/4Q   	4	 1:58.4 	 30.4	 D Mac Neill   	3.45	 D Macneill
329	17	4	4	 C J Bluefin+          	    	   4 	 6/7T  	 6/6   	 6/6   	 6/5H  	 5/4T   	5	 1:59   	 30.3	 N Bambrick    	14.70	 N Bambrick
330	17	4	7	 Miramonttogo          	    	   6 	 7/9H  	 7@/6T 	 7@/6Q 	 5/5Q  	 6/7H   	6	 1:59.2 	 31  	 G Neill       	25.45	 G Neill
331	17	4	3	 Howmac Royale         	    	   3 	 5/6   	 5@/5Q 	 5@/5  	 7/5T  	 7/13H  	7	 2:00.3 	 32.2	 K Arsenault   	1.70	 B Mullen
332	17	4	5	 Million Teen          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
333	17	5	6	 Smiley Bayama         	    	   6 	 3/2T  	 2@/1Q 	 1@/Q  	 1/T   	 1/1H   	1	 1:56.1 	 29  	 A Merner      	2.35	 R Gass
334	17	5	3	 Bazillion             	    	   3 	 2/1H  	 3/1H  	 3/1T  	 3/1H  	 2/1H   	2	 1:56.2 	 28.4	 Bri Macphee   	0.45	 T Hicken
335	17	5	1	 My Lucky Killean      	    	   1 	 1/1H  	 1/1Q  	 2/Q   	 2/T   	 3/5T   	3	 1:57.2 	 30.1	 K Murphy      	11.25	 C Murphy
336	17	5	4	 Nogreatmischief       	    	   4 	 4/4Q  	 4@/3Q 	 X7@/9 	 7/8   	 4/7H   	4	 1:57.3 	 28.3	 C Cheverie    	7.05	 C Cheverie
337	17	5	7	 Perfect Escape+       	    	   7 	 7/9H  	 7/7   	 6/6T  	 6/7Q  	 5/8    	5	 1:57.4 	 29.1	 R Matheson    	23.85	 J Matheson
338	17	5	2	 Whosurwinner          	    	   2 	 5/6Q  	 5/4T  	 4/5Q  	 4/6   	 6/8Q   	6	 1:57.4 	 29.3	 M Mcguigan    	16.25	 D Clow
339	17	5	5	 Tempo Seelster        	    	   5 	 6/8   	 6@/5  	 5@/6H 	 5/6T  	 7/8T   	7	 1:58   	 29.3	 T Walsh       	15.45	 V Poulton
340	17	6	7	 Windsun Rebel         	    	   7 	 8/15  	 8/6T  	 7@/9Q 	 7/5H  	 1/NK   	1	 1:58.2 	 28.1	 V Doyle       	16.40	 V Doyle
341	17	6	4	 Idealic Life          	    	   4 	 6/9H  	 5@/4  	 5@/5T 	 5/4Q  	 2/NK   	2	 1:58.2 	 28.4	 K Sorrie      	2.20	 T Hicken
342	17	6	6	 I D K                 	    	   6 	 1/1H  	 1/1T  	 1/2T  	 1/2H  	 3/NK   	3	 1:58.2 	 30  	 A Merner      	3.90	 D Clow
343	17	6	3	 Jersey Joe            	    	   3 	 4/5H  	 3@/2H 	 3@/4Q 	 3/2T  	 4/T    	4	 1:58.3 	 29.2	 V Poulton     	1.65	 D Clow
344	17	6	2	 Artners In Crime      	    	   2 	 2/1H  	 2/1T  	 2/2T  	 2/2H  	 5/1Q   	5	 1:58.3 	 29.3	 R Matheson    	4.60	 J Matheson
345	17	6	1	 Someone Like You      	    	   1 	 3/3   	 4/3H  	 4/4H  	 4/4   	 6/1H   	6	 1:58.3 	 29.2	 M Mcguigan    	8.05	 R Ferguson
346	17	6	8	 Superbo Hanover       	    	   8 	 5/7Q  	 6/5Q  	 6/7Q  	 6/5Q  	 7/3Q   	7	 1:59   	 29.1	 G Hennessey   	24.70	 G Hennessey
347	17	6	5	 Daylyn Horizon        	    	   5 	 7@/13 	 7@/6Q 	 8@@/10	 8/11  	 8/13   	8	 2:01   	 30.3	 G Chappell    	13.50	 B Campbell
348	18	1	2	 Rewind Again          	    	   2 	 3/5H  	 3/4   	 1/8   	 1/11  	 1/14   	1	 2:02   	 30  	 K Murphy      	\N	 C Murphy
349	18	1	3	 Ic Brandonscowgirl    	    	   3 	 4/9   	 4/10  	 3@/11 	 3/12  	 2/14   	2	 2:04.4 	 30.3	 A Merner      	\N	 A Merner
350	18	1	4	 Gypsy Queen           	    	   4 	 1/3H  	 1/2   	 2/8   	 2/11  	 3/18H  	3	 2:05.3 	 32  	 N Myers       	\N	 M Macdonald
351	18	1	1	 Monastery             	    	   1 	 2/3H  	 2/2   	 4/14  	 4/DIS 	 4/DIS  	4	        	     	 K Arsenault   	\N	 K Arsenault
352	18	2	4	 Oceanview Pancho=     	    	   4 	 2/2H  	 2/2   	 2/2H  	 2/2H  	 1/H    	1	 2:06.4 	 30.3	 P Larrabee    	\N	 P Larrabee
353	18	2	3	 B J Classic=          	    	   3 	 1/2H  	 1/2   	 1/2H  	 1/2H  	 2/H    	2	 2:06.4 	 31  	 Bri Macphee   	\N	 B Honkoop
354	18	2	5	 Glencove Carter=      	    	   5 	 X3X/9 	 5/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 H Shepherd    	\N	 C Bagnall
355	18	2	1	 Sanctified=           	    	   X1	 5/DIS 	 4/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 B Andrew      	\N	 B White
356	18	2	2	 Glencove Zsa Zsa      	    	   2X	 4/DIS 	 3/DIS 	 5X/DIS	 X5/DIS	 5/DIS  	5	        	     	 K Arsenault   	\N	 C Bagnall
357	18	3	3	 Mick Dundee           	    	   3 	 1/2   	 1/1T  	 1/2   	 1/H   	 1/T    	1	 2:01.4 	 29.1	 D Mac Neill   	\N	 D Mac Neill
358	18	3	1	 Ascaryone Hanover     	    	   1 	 2/2   	 2/1T  	 2/2   	 2/H   	 2/T    	2	 2:02   	 29  	 K Murphy      	\N	 C Murphy
359	18	3	2	 Jamiesmilingcowboy    	    	   2 	 3/4   	 3/3H  	 3/3H  	 X3/8  	 3/21   	3	 2:06   	 32.4	 K Arsenault   	\N	 K Arsenault
360	18	4	1	 Sanchez Blue Chip     	    	   1 	 3/11  	 3/4Q  	 2@/1H 	 2/1H  	 1/1H   	1	 2:02   	 29.4	 V Poulton     	\N	 D Clow
361	18	4	4	 Zanzibar+             	    	   4 	 1/8   	 1/2H  	 1/1H  	 1/1H  	 2/1H   	2	 2:02.1 	 30.1	 P Morrison    	\N	 P Morrison
362	18	4	3	 Umiztagoodthing+      	    	   3 	 2/8   	 2/2H  	 3/2T  	 3/2T  	 3/2    	3	 2:02.2 	 29.4	 T Walsh       	\N	 T Walsh
363	18	4	2	 Prynne Hanover+       	    	   2 	 4/13H 	 4/6   	 4@/3H 	 4/4H  	 X4/7H  	4	 2:03.2 	 30.4	 A Campbell    	\N	 R Squires
364	21	1	5	 Retail                	    	   4 	 1/3H  	 1/6H  	 1/12  	 1/13H 	 1/12H  	1	 1:57.1 	 29.1	 D Mcnair      	1.45	 D Meekison 
365	21	1	1	 Jazzmo                	    	   1 	 2/3H  	 2/6H  	 2/12  	 2/13H 	 2/12H  	2	 1:59.3 	 29.1	 L House       	1.75	 F Schaeffer
366	21	1	6	 Slots Of Fun          	    	   5 	 5/8H  	 5/12H 	 5@/18 	 5/19Q 	 3/14T  	3	 2:00.1 	 28.3	 G Rooney      	3.40	 R Carroll
367	21	1	3	 Chevalier Semalu      	    	   3 	 4/6T  	 4/11  	 3@/16H	 3/16H 	 4/17Q  	4	 2:00.3 	 29.2	 B Mcclure     	16.20	 L Privett
368	21	1	2	 Lautner Seelster      	    	   2 	 3/5Q  	 3/9H  	 4/17  	 4/18Q 	 5/18H  	5	 2:00.4 	 29.2	 Ja Macdonald  	2.65	 F Maguire
369	21	1	4	 Goliath Reigns        	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
370	21	2	5	 Shanghai Sugar        	    	   5 	 4/5   	 2@/1H 	 1/2H  	 1/5   	 1/4H   	1	 2:00   	 29  	 Tra Henry     	5.80	 Tra Henry
371	21	2	4	 Odysseus              	    	   4 	 2/1T  	 3/1T  	 2@/2H 	 2/5   	 2/4H   	2	 2:00.4 	 29.2	 Ja Macdonald  	14.55	 T Macdonnel
372	21	2	1	 Lady Sherri           	    	   1 	 1/1T  	 1/1H  	 3/3H  	 3/9   	 3/7    	3	 2:01.2 	 29.4	 J Hudon Jr    	20.00	 J Hudon Jr
373	21	2	3	 Southern Heart        	    	   3 	 6/8H  	 5@/4H 	 5@/6T 	 4/10Q 	 4/9    	4	 2:01.4 	 29.2	 S Filion      	1.50	 Dr I Moore
374	21	2	6	 Loves Angel           	    	   6 	 5/6T  	 6/5T  	 6/6T  	 7/13T 	 5/9H   	5	 2:01.4 	 29.2	 D Mcnair      	3.60	 R Mcnair
375	21	2	2	 Miss Mary Luck        	    	   2 	 3/3H  	 4/3Q  	 4/5Q  	 5/11Q 	 6/12Q  	6	 2:02.2 	 30.2	 B Davis Jr    	9.15	 B Macintosh
376	21	2	7	 St Lads Glory Gal     	    	   7 	 7/10Q 	 7@/7  	 7@/8H 	 6/12T 	 7/12H  	7	 2:02.2 	 29.4	 B Mcclure     	29.20	 J Dupont
377	21	3	2	 Buttons               	    	   2 	 1/1H  	 1/1   	 1/2   	 1/3H  	 1/2    	1	 1:58.4 	 28.4	 N Steward     	0.90	 B Belore
378	21	3	7	 Charmbo Curiosity     	    	   7 	 4/5Q  	 4@/3H 	 4/4H  	 3/4Q  	 2/2    	2	 1:59.1 	 28.2	 Trev Henry    	7.20	 P Bissett
379	21	3	1	 No Atm Fee            	    	   1 	 2/1H  	 3/2   	 3/3   	 2/3H  	 3/2Q   	3	 1:59.1 	 28.3	 Br Richardson 	4.45	 R Elgie
380	21	3	3	 Poplar Duke           	    	   3 	 3/3H  	 2@/1  	 2@/2  	 4/6Q  	 4/7Q   	4	 2:00.1 	 29.4	 D Mcnair      	2.10	 V Vanstone
381	21	3	4	 Big Sport             	    	   4 	 5/7   	 5@/5H 	 5@/6  	 5/8   	 5/8H   	5	 2:00.2 	 29.1	 G Rooney      	10.50	 H Toll
382	21	3	6	 Band Of Luck          	    	   6 	 7/10T 	 6/6H  	 6/7   	 6/10H 	 6/10H  	6	 2:00.4 	 29.2	 L House       	19.50	 S Taylor
383	21	3	5	 Arts First Luck       	    	   5 	 6/8T  	 7@/7H 	 X7/DIS	 7/DIS 	 7/DIS  	7	        	     	 T Smith       	23.15	 J Walker
384	21	4	7	 Bradys Play           	    	   7 	 2/1H  	 2@/1  	 1/1T  	 1/1H  	 1/1H   	1	 2:01.2 	 30.3	 D Mcnair      	16.05	 C Blake
385	21	4	3	 Todays Sports         	    	   3 	 5/6H  	 5/4T  	 6@/5T 	 4/5   	 2/1H   	2	 2:01.3 	 29.3	 Trev Henry    	1.30	 R Mcintosh
386	21	4	5	 Acefourtyfourxman     	    	   5 	 4/5   	 4@/2T 	 2@/1T 	 2/1H  	 3/3    	3	 2:02   	 30.4	 N Steward     	4.35	 G Durbano
387	21	4	4	 Kingsley B            	    	   4 	 6/8H  	 6/6Q  	 8/7T  	 6/8T  	 4/5T   	4	 2:02.3 	 30.1	 Mi Horner     	22.95	 O Bock
388	21	4	8	 Our Real Lady         	    	   8 	 7/10Q 	 7@/7Q 	 4@/3T 	 3/4   	 5/6    	5	 2:02.3 	 31  	 L House       	9.40	 G Arnold
389	21	4	6	 Rumour Has It Eh      	    	   6 	 8/12T 	 8/9Q  	 7@@/6T	 5/6Q  	 6/6Q   	6	 2:02.3 	 30.2	 Ja Macdonald  	17.60	 T Macdonnel
390	21	4	2	 Vinmara               	    	   2 	 3/3Q  	 3/2T  	 5/4T  	 7/11Q 	 7/9H   	7	 2:03.1 	 31.2	 G Rooney      	5.10	 A Shelton
391	21	4	1	 Raiders Hall          	    	   1 	 1/1H  	 1/1   	 3/2T  	 8/12Q 	 8/28Q  	8	 2:07   	 35.3	 Br Richardson 	2.45	 S Bell
392	21	5	5	 Red Leaf Morgan       	    	   5 	 5/6T  	 2@/1H 	 1@/T  	 1/4H  	 1/5Q   	1	 2:01.1 	 29  	 D Mcnair      	2.30	 J Watt
393	21	5	1	 Riverwalk             	    	   1 	 4/5Q  	 6/4Q  	 4@@/3Q	 3/4H  	 2/5Q   	2	 2:02.1 	 29.2	 G Rooney      	8.70	 G Jacklin
394	21	5	3	 Albergetty            	    	   3 	 2/1T  	 3/1H  	 3/2Q  	 4/6   	 3/5H   	3	 2:02.1 	 29.3	 C Steacy      	8.70	 D Walters
395	21	5	4	 Jiffyson              	    	   4 	 3/3H  	 4/3   	 5@/4Q 	 5/7   	 4/6H   	4	 2:02.2 	 29.2	 Trev Henry    	5.35	 P Bissett
396	21	5	2	 Lucky Beach           	    	   2 	 1/1T  	 1/1H  	 2/T   	 2/4H  	 5/7    	5	 2:02.3 	 30.1	 L House       	1.55	 S Taylor
397	21	5	6	 Lmc Nukular Stryke    	    	   6 	 6/8H  	 5@/3  	 6/9T  	 6/17  	 6/28Q  	6	 2:06.4 	 32.3	 N Steward     	2.75	 G Durbano
398	21	6	5	 Treasures Pearl       	    	   4 	 2/1H  	 3/1H  	 3/1T  	 3/2Q  	 1/H    	1	 1:59.4 	 28.3	 S Filion      	0.85	 R Adams
399	21	6	1	 The Joy Luck Club     	    	   1 	 3/3   	 2@/NS 	 2@/1Q 	 2I/1Q 	 3P2/2T 	3	 2:00.2 	 29.2	 Mi Horner     	3.65	 Ma Horner
400	21	6	3	 Shewearsthepants      	    	   3 	 1/1H  	 1/NS  	 1/1Q  	 1/1Q  	 2P3/H  	2	 1:59.4 	 29  	 D Mcnair      	1.70	 R Mcnair
401	21	6	2	 Artistic Style        	    	   2 	 4/4T  	 4/3H  	 4@@/2Q	 4/4Q  	 4/6Q   	4	 2:01   	 29.4	 Trev Henry    	3.95	 R Mcintosh
402	21	6	4	 Mach On               	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
403	21	6	6	 Casimir Qt            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
404	22	1	1	 Jet Airliner          	    	   1 	 1/1T  	 1/1Q  	 1/HD  	 1/1   	 1/H    	1	 1:58.4 	 29  	 D Mcnair      	1.20	 J Watt
405	22	1	6	 Jackstan              	    	   6 	 2/1T  	 3/2Q  	 3/1H  	 3/2   	 2/H    	2	 1:58.4 	 28.4	 Ja Macdonald  	10.45	 F Maguire
406	22	1	2	 Kinmundys Stryker     	    	   2 	 3/3T  	 2@/1Q 	 2@/HD 	 2/1   	 3/1Q   	3	 1:59   	 29.1	 Br Richardson 	3.70	 C Schneider
407	22	1	3	 B N Bad               	    	   3 	 4/5H  	 4@/3H 	 4@/1H 	 4/3   	 4/1T   	4	 1:59.1 	 29.1	 Tra Henry     	4.25	 Tra Henry
408	22	1	7	 Stonebridge Scout     	    	   7 	 7/10  	 7/7T  	 7/4H  	 7/7   	 5/4T   	5	 1:59.4 	 29.1	 L House       	35.80	 A Hardy
409	22	1	5	 Haute Couture         	    	   5 	 6/8H  	 6@/6H 	 6@/3Q 	 6/5T  	 6/5T   	6	 2:00   	 29.3	 G Rooney      	22.40	 A Shelton
410	22	1	4	 Pacific Oak           	    	   4 	 5/7   	 5/5Q  	 5/3   	 5/4T  	 7/5T   	7	 2:00   	 29.3	 Kn Oliver     	19.45	 Kn Oliver
411	22	1	8	 Baddestnbestest       	    	   X8	 8/25  	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 B Mcclure     	2.85	 J Dupont
412	22	2	1	 Kennairnlaughaloud    	    	   1 	 2@/1Q 	 1/1H  	 1/1H  	 1/1H  	 1/2    	1	 1:58.2 	 29.1	 Ja Macdonald  	1.15	 J Riehl
413	22	2	2	 Regal Again           	    	   2 	 3/3   	 4/3Q  	 3@/2T 	 3/1H  	 2/2    	2	 1:58.4 	 29  	 B Mcclure     	8.65	 De Morrisse
414	22	2	5	 Acton O So Royal      	    	   5 	 1/1Q  	 2/1H  	 2/1H  	 2/1H  	 3/2H   	3	 1:58.4 	 29.2	 Trev Henry    	2.40	 D Beatson
415	22	2	8	 Cantcountmeout        	    	   8 	 5/6T  	 6/5   	 4/4Q  	 4/3H  	 4/4    	4	 1:59.1 	 29.1	 A Macdonald   	6.25	 A Macdonald
416	22	2	4	 Sure Please           	    	   4 	 7/10T 	 8/7   	 8/7Q  	 6/7H  	 5/10Q  	5	 2:00.2 	 29.4	 Br Richardson 	44.50	 R Campbell
417	22	2	6	 Twin B Shadow         	    	   6 	 4/5   	 3@/2T 	 5@/4H 	 5/6H  	 6/10H  	6	 2:00.2 	 30.2	 C Steacy      	24.25	 H Wilson
418	22	2	3	 Artistic Cruiser      	    	   3 	 6/8T  	 5@/4H 	 6@@/4T	 7/8   	 7/12Q  	7	 2:00.4 	 30.3	 N Steward     	3.75	 G Robinson
419	22	2	7	 Its Machademic        	    	   7 	 8/12H 	 7@/6H 	 7@@/6Q	 8/9H  	 8/13H  	8	 2:01   	 30.3	 L House       	17.95	 C Schneider
420	22	3	3	 Ok Jewel              	    	   3 	 4/7   	 4/5T  	 4@/3Q 	 3/2H  	 1/H    	1	 2:00.3 	 29.2	 B Mcclure     	7.50	 T Jacobson
421	22	3	1	 P L Kaleidoscope      	    	   1 	 2/1H  	 1/1H  	 1/1   	 1/1   	 2/H    	2	 2:00.3 	 30  	 Trev Henry    	1.35	 M Dupuis
422	22	3	2	 Menagerie             	    	   2 	 3/4H  	 3/4   	 2@/1  	 2/1   	 3/T    	3	 2:00.4 	 30  	 A Macdonald   	5.40	 A Macdonald
423	22	3	4	 Twin B Cheeks         	    	   4 	 1/1H  	 2/1H  	 3/2Q  	 4/2T  	 4/4H   	4	 2:01.2 	 30.2	 D Mcnair      	1.65	 R Adams
424	22	3	6	 P L Kahluaa           	    	   6 	 6/13  	 6/11  	 6/6T  	 5/7Q  	 5/8Q   	5	 2:02.1 	 30.1	 M Morel       	4.45	 P Richer
425	22	3	5	 Three Secrets         	    	   5 	 5/9H  	 5/7H  	 5@/5T 	 6/7H  	 6/12   	6	 2:03   	 31.1	 C Steacy      	13.40	 B Macdonald
426	22	4	3	 Zinfandart            	    	   3 	 1/1H  	 1/1Q  	 1/1   	 1/1   	 1/2    	1	 2:02   	 29.1	 Trev Henry    	1.35	 G Mcclure
427	22	4	2	 Life On The Links     	    	   2 	 2/1H  	 3/1T  	 4/2Q  	 3/2   	 2/2    	2	 2:02.2 	 29.1	 A Macdonald   	8.30	 E Lock
428	22	4	7	 Play Ground           	    	   7 	 6@/6  	 4@/3  	 2@@/1 	 2/1   	 3/3H   	3	 2:02.3 	 29.3	 D Mcnair      	4.20	 G Bishop
429	22	4	8	 Lady With A Weapon    	    	   I8	 7/7   	 8@/6T 	 7@@/5Q	 5/6   	 4/4Q   	4	 2:02.4 	 29  	 G Rooney      	\N	 D Vleeming
430	22	4	1	 Anamazingdream Esa    	    	   X1	 8@/8  	 6@/4H 	 5@@/4 	 4/5   	 5/5Q   	5	 2:03   	 29.2	 N Steward     	1.50	 G Robinson
431	22	4	4	 Ocean Of Motion       	    	   4 	 3/3   	 5/3H  	 6IX/4Q	 6/8H  	 6/20H  	6	 2:06   	 32.2	 N Mac Innis   	15.10	 N Mac Innis
432	22	4	6	 Zenobia Blue Chip     	    	   6 	 4@/4  	 2@/1Q 	 3@IX/1	 ACC   	 DNF    	\N	        	     	 Br Richardson 	9.05	 J Kerr
433	22	4	5	 Windsong Ivory        	    	   5 	 5/5   	 7/5H  	 8IX/6Q	 ACC   	 DNF    	\N	        	     	 L House       	25.75	 K Pollard
434	23	1	4	 Catch A Lucky Star    	    	   4 	 3/3T  	 3/3H  	 3/3H  	 3/2T  	 1/HD   	1	 2:00.3 	 29.2	 C Steacy      	\N	 J Watt
435	23	1	3	 Rocket Art            	    	   3 	 1/2   	 1/1T  	 1/1T  	 1/1Q  	 2/HD   	2	 2:00.3 	 30  	 G Rooney      	\N	 D Meekison 
436	23	1	2	 Watt A Funny Face     	    	   2 	 2/2   	 2/1T  	 2/1T  	 2/1Q  	 3/1    	3	 2:00.4 	 29.4	 C German      	\N	 J Watt
437	23	1	1	 Shanghai Noodle       	    	   1 	 4/5T  	 4/5Q  	 4/5Q  	 4/4T  	 4/6    	4	 2:01.4 	 30.1	 G Mcclure     	\N	 G Mcclure
438	24	1	2	 Sweet Caldonia        	    	   2 	 3/2Q  	 3@/2Q 	 1@/NS 	 1/H   	 1/1Q   	1	 2:00.4 	 31.1	 C Johnston    	2.25	 T Bain
439	24	1	5	 B R Lucky Lady        	    	   5 	 1@/H  	 1/1T  	 2/NS  	 3/1   	 2/1Q   	2	 2:01   	 31.2	 B Forward     	2.15	 R Myers
440	24	1	6	 Jazzie Crombie        	    	   6 	 6/7T  	 6@/7  	 5@@/3 	 2/H   	 3/1Q   	3	 2:01   	 30.4	 A Lilley      	4.65	 J Graham
441	24	1	4	 Birkdale              	    	   4 	 5/5T  	 5/6Q  	 6/5   	 5/4   	 4/4Q   	4	 2:01.3 	 31  	 D Rankin Jr   	16.05	 R Spitzig
442	24	1	1	 Acton Real Foolish    	    	   1 	 2/H   	 2/1T  	 4/2   	 4/3   	 5/4T   	5	 2:01.4 	 31.4	 J Coke        	7.50	 D Pearson
443	24	1	7	 Wallet Sniffer        	    	   7 	 7/9H  	 7/10  	 7/6T  	 7/11  	 6/11T  	6	 2:03.1 	 32.1	 T Borth       	9.00	 T Bain
444	24	1	8	 Larjon Emma           	    	   8 	 4/4   	 4@/4Q 	 3@/2  	 6/10  	 7/13   	7	 2:03.2 	 33.2	 M Williams    	4.65	 L Lane
445	24	1	3	 Hrrn                  	    	   X3	 8/24H 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 D Duford      	41.65	 S Roberts
446	24	2	2	 My Greek Princess     	    	   2 	 2/5   	 2/4   	 1@/HD 	 1/4   	 1/NK   	1	 2:02.4 	 30.4	 T Borth       	0.75	 C Gaudreau
447	24	2	5	 Jimini Top            	    	   5 	 3/6T  	 3/5T  	 3/1T  	 2/4   	 2/NK   	2	 2:02.4 	 30.2	 C Johnston    	4.15	 T Bain
448	24	2	1	 Larjon Laney          	    	   1 	 6/12T 	 6/11Q 	 4@@/3T	 4/6   	 3/3H   	3	 2:03.2 	 30.3	 B Forward     	6.45	 L Lane
449	24	2	6	 Incredible Dutches    	    	   6 	 1/5   	 1/4   	 2/HD  	 3/5   	 4/8T   	4	 2:04.3 	 32.3	 A Moore       	7.65	 D Kenney
450	24	2	4	 Onimpulse             	    	   4 	 4/8T  	 4/7T  	 5@/4Q 	 5/9   	 5/9T   	5	 2:04.4 	 32  	 M Williams    	7.35	 T Bain
451	24	2	3	 Shadow Way            	    	   3 	 5/10T 	 5/9H  	 6/4Q  	 6/10  	 6/13T  	6	 2:05.3 	 32.4	 J Coke        	5.75	 D Pearson
452	24	3	6	 P J Lucky Lass        	    	   5 	 7/13Q 	 7/9H  	 4@/4  	 2/1   	 1/H    	1	 2:01   	 29.1	 A Moore       	1.60	 R Griffiths
453	24	3	1	 News Stand            	    	   1 	 2/1   	 1/1T  	 1/1T  	 1/1   	 2/H    	2	 2:01   	 30  	 T Borth       	3.25	 M Carther
454	24	3	4	 Perfect Poser         	    	   4 	 6/8Q  	 6@/7H 	 5/5   	 4/3T  	 3/1T   	3	 2:01.2 	 29.2	 B Forward     	3.70	 M Rogers
455	24	3	7	 Four Decades          	    	   6 	 1@/1  	 2/1T  	 3/2   	 3/2   	 4/4    	4	 2:01.4 	 30.2	 A Lilley      	8.90	 R Maclean
456	24	3	8	 Justins Deere         	    	   8 	 3/2T  	 3/3T  	 6/6T  	 6/5   	 5/7    	5	 2:02.2 	 30  	 D Rankin Jr   	7.15	 I Hyatt
457	24	3	3	 Regal Beagle          	    	   3 	 5/6H  	 4@/4T 	 2@/1T 	 5/4Q  	 6/7T   	6	 2:02.3 	 31.1	 C Johnston    	9.70	 D Currie
458	24	3	2	 Mister Fantastic      	    	   2 	 4/4T  	 5/6H  	 7@/7T 	 7/7   	 7/13Q  	7	 2:03.3 	 31  	 M Williams    	6.70	 L Mansfield
459	24	3	5	 Lyons Jewels          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
460	24	4	1	 Casimir Preist        	    	   1 	 1/1T  	 1/1H  	 1/1   	 1/1   	 1/1    	1	 2:01.4 	 30.4	 D Rankin Jr   	2.60	 T Spitzig
461	24	4	3	 Stonebridge Sting     	    	   3 	 2/1T  	 2/1H  	 2@/1  	 2/1   	 2/1    	2	 2:02   	 30.4	 C Johnston    	3.85	 J Sims
462	24	4	2	 Our Whosur            	    	   2 	 3/3T  	 3/3H  	 3/3   	 3/2   	 3/1Q   	3	 2:02   	 30.2	 Da Wall       	7.70	 De Wall
463	24	4	7	 Next Of Cam           	    	   7 	 7/14Q 	 I7@/8Q	 5@/4T 	 5/4   	 4/2    	4	 2:02.1 	 30.1	 T Borth       	3.15	 D Belan
464	24	4	4	 Dreamfair Hughie      	    	   4 	 4/5T  	 4/5Q  	 6/5   	 4/4   	 5/3H   	5	 2:02.2 	 30.2	 A Lilley      	8.90	 L Mansfield
465	24	4	6	 Play Like A Pro       	    	   6 	 6/12H 	 X5@/6Q	 4@/3  	 6/5   	 6/3H   	6	 2:02.2 	 30.4	 D Dowling     	7.30	 D Dowling
466	24	4	5	 Sweet Queen Cole      	    	   5 	 5/10T 	 6/7Q  	 7/7   	 7/7   	 7/5H   	7	 2:02.4 	 30.2	 M Williams    	3.60	 M Williams
467	24	5	1	 Laugh Amile           	    	   1 	 3/2   	 3/3H  	 2@/H  	 2/1   	 1/H    	1	 2:04   	 31.1	 T Borth       	6.10	 D Mcfadden
468	24	5	3	 Outside Chance        	    	   3 	 1/1   	 2/1T  	 3/1H  	 3/2   	 2/H    	2	 2:04   	 31  	 A Moore       	1.40	 A Moore
469	24	5	4	 Total Rebellion       	    	   4 	 2@/1  	 1/1T  	 1/H   	 1/1   	 3/T    	3	 2:04.1 	 31.2	 D Rankin Jr   	6.50	 R Maclean
470	24	5	7	 Ncutsnbutsncocants    	    	   7 	 I6/15T	 7/16Q 	 6@@/12	 5/9   	 4/4Q   	4	 2:04.4 	 29.3	 D Duford      	7.50	 M Carther
471	24	5	5	 Master Emerson        	    	   5 	 I7/16T	 5@/14H	 5@/11Q	 6/10  	 5/7H   	5	 2:05.2 	 30.2	 J Hahn        	15.45	 M Lariviere
472	24	5	6	 Royal Exposure        	    	   6 	 I4/12 	 4/6H  	 4/3Q  	 4/8   	 6/8H   	6	 2:05.3 	 32.1	 B Forward     	2.50	 B Sinclair
473	24	5	2	 Better Be Said        	    	   2 	 I5/14 	 6/14H 	 7/12H 	 7/18  	 7/26T  	7	 2:09.2 	 34.1	 M Williams    	12.15	 L Mansfield
474	24	5	8	 Jacob Too Too         	    	   8 	 X8/22T	 8@/17Q	 8/14H 	 8/19  	 8/27   	8	 2:09.2 	 33.4	 J Coke        	20.95	 D Pearson
475	24	6	1	 Capitol Trip          	    	   1 	 2/1   	 3/2   	 4/2H  	 4/1   	 1/H    	1	 2:02   	 29.2	 D Spitzig     	2.05	 D Spitzig
476	24	6	3	 Howdy Partner         	    	   3 	 1/1   	 1/1   	 1/1   	 1/NS  	 2/H    	2	 2:02   	 29.4	 D Rankin Jr   	5.85	 M Rogers
477	24	6	5	 Passionate Pete       	    	   5 	 6/6H  	 6@/5T 	 3@@/2 	 3/H   	 3/1    	3	 2:02.1 	 29.3	 D Dowling     	16.75	 D Dowling
478	24	6	8	 Julio Lauxmont        	    	   8 	 5/4T  	 5/4   	 7/4H  	 6/5   	 4/1    	4	 2:02.1 	 29.1	 A Lilley      	6.70	 L Bako
479	24	6	2	 Plain Easy            	    	   2 	 4/3   	 4@/3  	 5@/3  	 5/2   	 5/1Q   	5	 2:02.1 	 29.2	 M Williams    	3.55	 D Mcfadden
480	24	6	4	 Unchained Desire      	    	   4 	 3@/2  	 2@/1  	 2@/1  	 2/NS  	 6/1T   	6	 2:02.2 	 30  	 B Forward     	3.50	 L Johnson
481	24	6	6	 Unique Shuffle        	    	   6 	 7/8Q  	 7/6T  	 8/6Q  	 7/6   	 7/5H   	7	 2:03   	 29.3	 T Borth       	12.10	 G Mcdonnell
482	24	6	7	 Big Is Better         	    	   7 	 8/10Q 	 8@/8  	 6@@/4 	 8/9   	 8/9Q   	8	 2:03.4 	 30.4	 A Moore       	9.05	 A Moore
483	25	1	4	 Fantastic Flirt       	    	   4 	 3/2T  	 2/1H  	 3/1T  	 2/1   	 1/4H   	1	 2:00.3 	 30.3	 B Forward     	3.00	 J Rankin
484	25	1	2	 El Diablo Rojo        	    	   2 	 4/8T  	 3@/2  	 1@/NS 	 1/1   	 2/4H   	2	 2:01.2 	 31.4	 D Duford      	1.60	 A Duford
485	25	1	1	 Riversathome          	    	   1 	 1/1T  	 1/1H  	 2/NS  	 3/1   	 3/6T   	3	 2:02   	 32.2	 J Hahn        	9.55	 M Lariviere
486	25	1	3	 Terrain Seelster      	    	   3 	 5/10H 	 5@/4H 	 4/3T  	 4/6   	 4/13   	4	 2:03.1 	 32.4	 D Rankin Jr   	2.80	 A Deleersny
487	25	1	5	 Schrodinger=          	    	   5 	 2@/1T 	 4/4   	 5/5H  	 5/10  	 5/19T  	5	 2:04.3 	 34  	 D Spitzig     	11.70	 D Spitzig
488	25	1	6	 Weskey                	    	   6 	 6/12H 	 6/7H  	 6/7H  	 6/14  	 6/24H  	6	 2:05.2 	 34.2	 T Borth       	3.85	 T Borth
489	25	2	1	 Dex The Land          	    	   1 	 1/H   	 1/8   	 1/3   	 1/2   	 1/1    	1	 2:00   	 32.1	 T Borth       	1.00	 C Gaudreau
490	25	2	3	 Dont Yank My Chain    	    	   3 	 3/4H  	 2/8   	 2/3   	 2/2   	 2/1    	2	 2:00.1 	 31.4	 A Lilley      	4.55	 A Lilley
491	25	2	5	 Charlie Hustle        	    	   4 	 4/6H  	 3/10  	 3/4T  	 3/3   	 3/2H   	3	 2:00.2 	 31.3	 C Johnston    	10.80	 I Hyatt
492	25	2	2	 Payback               	    	   2X	 5/31H 	 5/30  	 5/22T 	 5/23  	 4/22Q  	4	 2:04.2 	 32  	 Da Wall       	9.25	 De Wall
493	25	2	6	 Isitfridayyet         	    	   5 	 2@X/H 	 4/20  	 4/19T 	 4/23  	 5/24H  	5	 2:04.4 	 33  	 M Williams    	1.40	 L Mansfield
494	25	2	4	 Barbies Belle         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
495	25	3	2	 Ground Shaker         	    	   2 	 2/1H  	 3/3H  	 4@@/5H	 2/H   	 1/2T   	1	 2:00   	 29.1	 B Forward     	3.25	 L Johnson
496	25	3	4	 Gorgiouseverytyme     	    	   4 	 4/6   	 4@/4  	 2@/5  	 1/H   	 2/2T   	2	 2:00.3 	 29.4	 A Lilley      	4.65	 J Lester
497	25	3	7	 Blissfullannmarie     	    	   6 	 6/9H  	 6/9T  	 5/7H  	 5/6   	 3/7H   	3	 2:01.2 	 30.1	 T Borth       	1.75	 C Gaudreau
498	25	3	1	 St Lads Sundance      	    	   1 	 1/1H  	 2/1T  	 3/5   	 4/4Q  	 4/8Q   	4	 2:01.3 	 30.4	 A Moore       	1.65	 R Duford
499	25	3	6	 America Rocks         	    	   5 	 5/7T  	 5/8   	 6/9H  	 6/8   	 5/13H  	5	 2:02.3 	 31  	 C Johnston    	19.05	 G Mcdonnell
500	25	3	3	 Peekaboo Toni         	    	   3 	 3/3   	 1/1T  	 1/5   	 3/2H  	 6/14   	6	 2:02.4 	 33  	 D Dowling     	12.75	 D Dowling
501	25	3	5	 Southwind Illusion    	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
502	25	4	6	 Kelly Rae             	    	   6 	 3/3H  	 3@/2H 	 1/1   	 1/1   	 1/H    	1	 2:00.2 	 30.4	 T Borth       	1.60	 J Lester
503	25	4	5	 Big Diva              	    	   5 	 4/5Q  	 4@/4Q 	 2@/1  	 2/1   	 2/H    	2	 2:00.2 	 30.3	 B Forward     	2.35	 M Rogers
504	25	4	1	 Primary Pick          	    	   1 	 2/1H  	 2/1H  	 5@/3H 	 3/2   	 3/1T   	3	 2:00.4 	 30.3	 J Hahn        	12.30	 C Gaudreau
505	25	4	3	 Release The Magic+    	    	   3 	 6/8Q  	 5@/6  	 4@@/3 	 4/3   	 4/2T   	4	 2:01   	 30.4	 A Hamlin      	3.20	 T Myers
506	25	4	4	 Stellar Steel         	    	   4 	 5@/7Q 	 6/6H  	 6@@/4H	 5/5   	 5/7    	5	 2:01.4 	 31.2	 C Johnston    	3.35	 D Currie
507	25	4	2	 Richlyn Ombretta      	    	   2 	 1/1H  	 1/1H  	 3/2   	 6/5H  	 6/10T  	6	 2:02.3 	 32.3	 A Moore       	17.10	 R Griffiths
508	26	1	3	 Make Some Memories    	    	   3 	 3/10  	 3/7   	 3/1T  	 1/HD  	 1/2T   	1	 2:03   	 29.3	 A Hamlin      	\N	 T Myers
509	26	1	2	 Beer And A Haircut    	    	   2 	 1/8   	 1/5   	 2/NS  	 2/HD  	 2/2T   	2	 2:03.3 	 30.3	 B Forward     	\N	 S Roberts
510	26	1	5	 Dear Wee Mel          	    	   5 	 4/12  	 2/5   	 1@/NS 	 3/5   	 3/10H  	3	 2:05   	 32  	 M Williams    	\N	 L Mansfield
511	26	1	4	 Twelve Apaches        	    	   4 	 5/14  	 4/13  	 4/7T  	 4/11  	 4/34   	4	 2:09.4 	 35.1	 A Lilley      	\N	 A Lilley
512	26	1	1	 Hall Oak              	    	   1 	 2EX/8 	 PULLED	UP     	       	 DNF    	\N	        	     	 A Moore       	\N	 W Durbridge
513	26	2	5	 Stock Losses          	    	   3 	 2/2H  	 2/1T  	 1@/1  	 1/5   	 1/7H   	1	 2:02.1 	 29.1	 A Hamlin      	\N	 
514	26	2	3	 Acefortyfouramanda    	    	   X2	 3/4Q  	 3/3H  	 3/3   	 2/5   	 2/7H   	2	 2:03.3 	 30  	 A Lilley      	\N	 L Bako
515	26	2	1	 Foreigner             	    	   1 	 1/2H  	 1/1T  	 2/1   	 3/6   	 3/16   	3	 2:05.2 	 32.1	 B Forward     	\N	 D Dowling
516	28	1	2	 R Es Miss Eliza       	    	   2 	 1/5   	 1/5   	 1/10  	 1/12  	 1/15   	1	 2:09.4 	 32.4	 S Trites      	\N	 C Miles
517	28	1	3	 The Pita              	    	   3 	 2/5   	 2/5   	 2/10  	 2/12  	 2/15   	2	 2:12.4 	 33.4	 C Miles       	\N	 C Miles
518	28	1	1	 Elm Grove Lynarush+   	    	   X1	 X3/DIS	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 G Wright      	\N	 G Wright
519	28	2	2	 Windsong Leo          	    	   2 	 1/3H  	 1/12  	 1/15  	 1/18  	 1/26   	1	 1:59   	 28.3	 S Trites      	\N	 P Jones
520	28	2	1	 Choco Du Ruisseau     	    	   1 	 2/3H  	 2/12  	 2/15  	 2/18  	 2/26   	2	 2:04.1 	 30.4	 T Trites      	\N	 T Dunphy
521	29	1	5	 Mach Messier          	    	   5 	 4/6H  	 3@/1H 	 2@/2  	 2/1H  	 1/1T   	1	 1:55   	 28.3	 J Ryan        	1.85	 M Bishop
522	29	1	3	 My Old Master         	    	   3 	 3/3H  	 1@/HD 	 1/2   	 1/1H  	 2/1T   	2	 1:55.2 	 29.2	 B Davis Jr    	1.20	 B Macintosh
523	29	1	6	 Toy Cop               	    	   6 	 5/8H  	 5@/3H 	 4@/4  	 3/2H  	 3/3T   	3	 1:55.4 	 29  	 A Carroll     	3.25	 K Bodz
524	29	1	1	 Santanna Sam          	    	   1 	 2/1H  	 4/2   	 5/5H  	 4/12  	 4/15Q  	4	 1:58   	 31  	 P Mackenzie   	8.95	 R Jarvis
525	29	1	7	 Oforpetesake          	    	   7 	 6/10  	 6/4H  	 7/7   	 6/14  	 5/15Q  	5	 1:58   	 30.3	 R Doyle       	27.90	 J Hastie
526	29	1	4	 Big Dylan             	    	   4 	 7/11H 	 7/6   	 6@X/6 	 7/15H 	 6/15T  	6	 1:58.1 	 31  	 S Young       	17.95	 M Brealey
527	29	1	2	 Well Played Out       	    	   2 	 1/1H  	 2/HD  	 3/3H  	 5/12H 	 7/26   	7	 2:00.1 	 33.3	 T Moore       	8.05	 J Copley
528	29	2	1	 Thrift Shop           	    	   1 	 3/3H  	 3/3H  	 2@/1H 	 1/HD  	 1/1T   	1	 1:56.3 	 30  	 S Byron       	1.70	 J Holding
529	29	2	5	 Buttercup Baby        	    	   4 	 1/1H  	 1/1H  	 1/1H  	 2/HD  	 2/1T   	2	 1:57   	 30.3	 J Ryan        	6.55	 K Reibeling
530	29	2	3	 Justabitevil+         	    	   2 	 2/1H  	 2/1H  	 3/2H  	 3/2H  	 3/3H   	3	 1:57.1 	 30.2	 A Byron       	11.30	 T Knight
531	29	2	6	 Come On Eileen        	    	   5 	 4/5   	 4/5   	 4/4H  	 4/5Q  	 4/9T   	4	 1:58.3 	 31.2	 P Mackenzie   	3.20	 M Brethour
532	29	2	4	 Orch Vicky            	    	   3 	 X5/6H 	 5/11H 	 5/17  	 5/21H 	 5/20Q  	5	 2:00.3 	 30.4	 S Young       	0.90	 G Remmen
533	29	2	2	 Notebookandtablet     	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
534	29	3	1	 Missus Big            	    	   1 	 1/1H  	 1/1H  	 1/1Q  	 1/1T  	 1/3Q   	1	 1:57.1 	 28.1	 B Mcclure     	1.40	 D Tyrrell
535	29	3	2	 Miss Print            	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1T  	 2/3Q   	2	 1:57.4 	 28.3	 N Steward     	1.30	 A Mccabe
536	29	3	3	 Classic Comedy        	    	   3 	 3/3   	 3/3   	 2@/1Q 	 3/3H  	 3/4T   	3	 1:58.1 	 29  	 Tra Henry     	9.70	 C Auciello
537	29	3	4	 Casimir Pardon Me     	    	   4 	 4/4H  	 4/4H  	 4/4H  	 4/5   	 4/5T   	4	 1:58.2 	 28.3	 S Byron       	4.85	 K Reibeling
538	29	3	6	 Badlands Delight      	    	   5 	 5/6   	 5/6   	 5/6H  	 5/6Q  	 5/6    	5	 1:58.2 	 28.1	 A Carroll     	3.45	 D Lehan
539	29	3	5	 Total Knockout(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
540	29	4	4	 Im A Gift             	    	   4 	 3/3   	 4@/3H 	 2@/1H 	 2/Q   	 1/H    	1	 1:53.3 	 28.3	 D Dupont      	1.05	 M Dupont
541	29	4	5	 Skyway Boomer         	    	   5 	 4/4H  	 5@/4H 	 4@/3H 	 3/2Q  	 2/H    	2	 1:53.3 	 28.1	 T Moore       	2.95	 J Copley
542	29	4	3	 Lively Freddie        	    	   3 	 6/7H  	 7@/6H 	 6@/5H 	 5/4H  	 3/2    	3	 1:54   	 28.1	 B Mcclure     	2.35	 D Nixon
543	29	4	1	 Surf Report           	    	   1 	 1/1H  	 1/1H  	 1/1H  	 1/Q   	 4/3H   	4	 1:54.1 	 29.2	 A Carroll     	9.15	 M Etsell
544	29	4	6	 Stature Seelster(L)   	    	   6 	 7/9   	 6/5   	 7/6   	 6/5   	 5/4T   	5	 1:54.3 	 28.3	 P Mackenzie   	32.85	 M Isabel
545	29	4	7	 Sporty Mercedes       	    	   7 	 5/6   	 3/3   	 5/4   	 7/6Q  	 6/7T   	6	 1:55.1 	 29.3	 B Davis Jr    	25.20	 B Macintosh
546	29	4	2	 Singhampton Kenny     	    	   2 	 2/1H  	 2/1H  	 3/3   	 4/3   	 7/12   	7	 1:56   	 30.3	 Tra Henry     	6.35	 L Fuller
547	29	5	1	 Mckinney              	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1   	 1/1Q   	1	 1:52.1 	 28.3	 B Mcclure     	1.30	 Corey Johns
548	29	5	2	 American Rock         	    	   2 	 2/1H  	 3/2Q  	 3/2Q  	 3/2H  	 2/1Q   	2	 1:52.2 	 28.2	 A Carroll     	1.80	 R Moreau
549	29	5	6	 Lets Wait And See     	    	   6 	 6/7H  	 2@/1H 	 2@/1  	 2/1   	 3/1T   	3	 1:52.3 	 28.4	 N Steward     	17.50	 S Friend
550	29	5	4	 Thorn In Your Side(L) 	    	   4 	 3/3   	 4/3H  	 5/4   	 4/4   	 4/2Q   	4	 1:52.3 	 28.1	 Tra Henry     	3.55	 C Auciello
551	29	5	3	 Buddha Blue Chip      	    	   3 	 4/4H  	 7/6   	 7/6   	 5/4H  	 5/2T   	5	 1:52.4 	 28  	 P Mackenzie   	5.65	 J Dupont
552	29	5	7	 Sports Lightning      	    	   7 	 7/9   	 5@/4  	 4@/3H 	 6/6   	 6/5T   	6	 1:53.2 	 29.1	 S Young       	25.90	 M Brealey
553	29	5	5	 Haydens Little Man(L) 	    	   5 	 5/6   	 6@/5H 	 6@/5H 	 7/7H  	 7/7    	7	 1:53.3 	 29  	 J Ryan        	11.40	 J Ryan
554	29	6	5	 St Lads Lotto(L)      	    	   5 	 1/1H  	 1/1H  	 1/1H  	 1/4   	 1/2Q   	1	 1:52.4 	 29.2	 J Ryan        	0.75	 J Ryan
555	29	6	7	 Arrived Late(L)       	    	   7 	 7/9   	 7/9   	 7@/5T 	 6/6Q  	 2/2Q   	2	 1:53.1 	 28.3	 B Mcclure     	12.05	 C Gilmour
556	29	6	4	 A Marcou Story        	    	   4 	 5/6   	 5/6   	 5@/4H 	 4/5   	 3/2H   	3	 1:53.1 	 29  	 R Jones       	3.20	 R Jones
557	29	6	3	 Crafty Master         	    	   3 	 4/4H  	 4/4H  	 3@/2Q 	 3/4H  	 4/7H   	4	 1:54.1 	 30.2	 A Carroll     	4.45	 V Puddy
558	29	6	1	 Mac Raider            	    	   1 	 2/1H  	 2/1H  	 2/1H  	 2/4   	 5/8Q   	5	 1:54.2 	 30.4	 B Davis Jr    	9.70	 L Fuller
559	29	6	6	 Corsica Hall(L)       	    	   6 	 3/3   	 3/3   	 4/3Q  	 5/5H  	 6/8Q   	6	 1:54.2 	 30.2	 Tra Henry     	11.20	 C Auciello
560	29	6	2	 My Friend Diaz        	    	   2 	 6/7H  	 6/7H  	 6/5   	 7X/6T 	 X7/12H 	7	 1:55.1 	 30.4	 S Byron       	9.00	 D Lever
561	30	1	6	 Lisvinnie(L)          	    	   6 	 9/13Q 	 7@/9H 	 5@@/4H	 4/2H  	 1/1H   	1	 1:53.2 	 28.3	 D St Pierre   	2.20	 Corey Johns
562	30	1	5	 Sword Ofthe Spirit    	    	   5 	 1/3   	 1/2H  	 1/Q   	 1/1Q  	 2/1H   	2	 1:53.3 	 29.3	 R Jones       	10.30	 R Jones
563	30	1	2	 Mach On The Beach     	    	   2 	 2/3   	 2/2H  	 3/1H  	 3/2   	 3/1T   	3	 1:53.4 	 29.3	 S Byron       	6.60	 D Fontaine
564	30	1	3	 Smack Talk            	    	   3 	 7/10H 	 8/11  	 7@@/5H	 6/4H  	 4/1T   	4	 1:53.4 	 28.4	 B Mcclure     	4.70	 J Williamso
565	30	1	4	 Chosen Hombre         	    	   4 	 6/9   	 6/8   	 8/7   	 8/7Q  	 5/5    	5	 1:54.2 	 29  	 P Mackenzie   	19.05	 M Brethour
566	30	1	8	 Soaking Up The Sun    	    	   8 	 3/4H  	 3/4   	 2@/Q  	 2/1Q  	 6/5T   	6	 1:54.3 	 30.3	 Tra Henry     	11.90	 R Moreau
567	30	1	9	 Calgary Seelster(L)   	    	   9 	 5/7H  	 5/7H  	 6@/5  	 5/4   	 7/6T   	7	 1:54.4 	 29.4	 N Steward     	2.15	 A Mccabe
568	30	1	1	 Canadian Edition(L)   	    	   1 	 4/6   	 4/6   	 4/4   	 7/6   	 8/6T   	8	 1:54.4 	 30  	 A Carroll     	6.85	 V Puddy
569	30	1	7	 One Warrawee          	    	   7 	 8/12  	 9/12H 	 9/8Q  	 9/8T  	 9/12T  	9	 1:56   	 30.2	 A Byron       	17.30	 E Galinski
570	30	2	1	 The Illuminator       	    	   1 	 1/1H  	 2/1H  	 2/1H  	 2/T   	 1/T    	1	 1:54   	 28.3	 B Mcclure     	2.75	 Ri Zeron
571	30	2	5	 Terror Hall           	    	   5 	 5/8   	 5/10H 	 5@/5  	 4/4H  	 2/T    	2	 1:54.1 	 28  	 A Carroll     	3.10	 R Moreau
572	30	2	2	 Spirit Shadow         	    	   2 	 2/1H  	 1/1H  	 1/1H  	 1/T   	 3/2T   	3	 1:54.3 	 29.2	 P Mackenzie   	0.45	 J Dupont
573	30	2	4	 Lissilas              	    	   4 	 4/6H  	 4/7H  	 4@/3H 	 3/4   	 4/3T   	4	 1:54.4 	 29  	 D St Pierre   	71.00	 Colin Johns
574	30	2	9	 Cool Jack             	    	   8 	 8/12H 	 8/15  	 8/8H  	 5/6   	 5/5    	5	 1:55   	 28.1	 N Steward     	36.75	 J Copley
575	30	2	6	 Winning Drive         	    	   6 	 6/9H  	 6/12  	 6@/5H 	 6/6H  	 6/7T   	6	 1:55.3 	 29.2	 T Moore       	29.50	 R Howie
576	30	2	3	 Whiskey Wisdom        	    	   3 	 3/3H  	 3/4H  	 3/3   	 7/7   	 7/8H   	7	 1:55.3 	 29.4	 T Smith       	33.40	 J Walker
577	30	2	8	 Master Smile          	    	   7 	 7/11  	 7/13H 	 7/7   	 8/8H  	 8/14Q  	8	 1:56.4 	 30.1	 B Davis Jr    	29.15	 J Mcginnis
578	30	2	7	 Barefoot Bluejeans    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
579	30	3	2	 Kona(L)               	    	   2 	 4/4H  	 5/4Q  	 4@/1H 	 3/1H  	 1/1Q   	1	 2:00   	 31.2	 D St Pierre   	1.90	 Colin Johns
580	30	3	1	 Deck The Halls        	    	   1 	 2/1H  	 3/1H  	 3/1H  	 4/1T  	 2/1Q   	2	 2:00.1 	 31.3	 N Steward     	4.60	 P Belanger 
581	30	3	4	 L H Fillybuster       	    	   4 	 1/1H  	 1/1   	 1/NK  	 2/HD  	 3/3H   	3	 2:00.3 	 32.1	 A Carroll     	1.20	 W Budd
582	30	3	5	 Ken U Sing=(L)        	    	   5 	 5/6   	 2@/1  	 2@/NK 	 1/HD  	 4/5Q   	4	 2:01   	 32.3	 D Bowins      	2.55	 D Bowins
583	30	3	3	 Protege Seelster(L)   	    	   3 	 3/3   	 4/3   	 5/8H  	 5/11H 	 5/23T  	5	 2:04.4 	 34.4	 B Davis Jr    	12.90	 P Shepherd
584	30	4	5	 Twomacsonemach(L)     	    	   4 	 4/5H  	 4@/3H 	 2@/1  	 2/1   	 1/HD   	1	 1:55.2 	 27.2	 A Carroll     	3.90	 V Puddy
585	30	4	3	 P L Jackson           	    	   2 	 1/1H  	 1/1H  	 1/1   	 1/1   	 2/HD   	2	 1:55.2 	 27.3	 B Mcclure     	0.35	 R Mcmillan
586	30	4	4	 Day Trade Hanover     	    	   3 	 2/1H  	 2/1H  	 3/1H  	 3/2H  	 3/2Q   	3	 1:55.4 	 27.4	 R Jones       	3.60	 R Jones
587	30	4	9	 Relish                	    	   7 	 7/10  	 7@/7Q 	 6@I/5 	 5/7   	 4/9H   	4	 1:57.1 	 28.2	 P Mackenzie   	31.40	 R Mackenzie
588	30	4	8	 Sippen Whisky         	    	   6 	 6/8H  	 5@/5H 	 4@I/3Q	 4/6H  	 5/11H  	5	 1:57.3 	 29.1	 Tra Henry     	10.55	 C Fuller
589	30	4	7	 Wawanosh Wave         	    	   5 	 5/7   	 6/6   	 7I/5T 	 6/9H  	 6/14H  	6	 1:58.1 	 29.1	 T Smith       	64.00	 J Walker
590	30	4	1	 Lil Richie            	    	   1 	 3/3   	 3/3   	 5X/3H 	 7/16  	 7/DIS  	7	        	     	 A Byron       	17.80	 D Nixon
591	30	4	2	 Only Half Bad         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
592	30	4	6	 Six Flags             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
593	31	1	6	 Heza Workof Art       	    	   5 	 5/5H  	 4@/3  	 2@/1  	 1/NS  	 1/NS   	1	 1:54.2 	 29.1	 B Mcclure     	0.85	 J Watt
594	31	1	7	 Wine Shark            	    	   6 	 1/1   	 1/1   	 1/1   	 2/NS  	 2/NS   	2	 1:54.2 	 29.2	 J Ryan        	2.40	 J Ryan
595	31	1	2	 Arnold Dick           	    	   2 	 4/4   	 5/3H  	 5/7H  	 3/10  	 3/12   	3	 1:56.4 	 30.2	 P Mackenzie   	6.30	 P Mackenzie
596	31	1	3	 Highpoint Chip        	    	   3 	 6/7   	 6/5   	 6@/8H 	 5/12  	 4/17H  	4	 1:57.4 	 31.1	 L House       	41.40	 P Roberts
597	31	1	1	 Roan Bruiser(L)       	    	   1 	 3/2H  	 2@/1  	 4@/7  	 7/14  	 5/17T  	5	 1:58   	 31.3	 Tra Henry     	6.40	 S Halkes
598	31	1	8	 Amillionbucks         	    	   7 	 7/8H  	 7/6H  	 7/9Q  	 6/12H 	 6/18T  	6	 1:58.1 	 31.2	 S Byron       	24.05	 G Cicero
599	31	1	5	 Windsun Cheyenne(L)   	    	   4 	 2/1   	 3/1H  	 3/6H  	 4/11H 	 7/22H  	7	 1:58.4 	 32.3	 N Steward     	5.15	 D Tackoor
600	31	1	4	 Jimmy Be Good         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
601	31	1	9	 Hot Rock Star         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
602	31	2	1	 Classic Bolt          	    	   1 	 2/1H  	 2/1H  	 2/3H  	 2/3   	 2P1/2  	2	 1:57   	 28.4	 J Ryan        	2.60	 C Gilmour
603	31	2	6	 Silversmith           	    	   6 	 1/1H  	 1/1H  	 1/3H  	 1/3   	 3P2/2T 	3	 1:57.1 	 29.3	 P Mackenzie   	1.25	 A Macdonald
604	31	2	3	 Screenwriter          	    	   3 	 4/4H  	 3@/2  	 3@/4  	 3/3T  	 4P3/6Q 	4	 1:57.4 	 29.2	 B Mcclure     	10.80	 C Fuller
605	31	2	4	 Machcellerator        	    	   4 	 5/6   	 5/5   	 6I/7H 	 6/8   	 5P4/9Q 	5	 1:58.2 	 29.2	 S Young       	11.70	 T Stein
606	31	2	2	 Tea With Ms Mcgill    	    	   2 	 3/3   	 4/3H  	 4X/5H 	 4/5   	 1P5/2  	1	 TDIS   	     	 A Macdonald   	1.75	 A Macdonald
607	31	2	7	 Home James            	    	   7 	 7/9   	 6@/5H 	 5@/7  	 5/7H  	 6/9H   	6	 1:58.2 	 29.2	 Tra Henry     	15.05	 Tra Henry
608	31	2	5	 Hazamenaz             	    	   5 	 6/7H  	 7/7   	 7@/8  	 7/12  	 7/22   	7	 2:01   	 31.4	 R Holliday    	36.10	 C Fuller
609	31	3	5	 Go Get Bruce          	    	   5 	 6/6Q  	 4@/5T 	 3@/3  	 3/2Q  	 1/2    	1	 1:58.4 	 30  	 B Forward     	1.65	 S Charlton
610	31	3	2	 Rainbow View          	    	   2 	 2/H   	 1@/H  	 1/1Q  	 1/1   	 2/2    	2	 1:59.1 	 31  	 A Haughan     	5.20	 M Crone
611	31	3	4	 Tyrone Zoey           	    	   4 	 5/4T  	 2@/H  	 2@/1Q 	 2/1   	 3/5Q   	3	 1:59.4 	 31.2	 B Mcclure     	1.50	 J Watt
612	31	3	3	 Burst Hanover         	    	   3 	 4/3Q  	 6/7H  	 5@/8Q 	 5/8H  	 4/9T   	4	 2:00.4 	 31  	 L House       	7.40	 P Roberts
613	31	3	1	 Murs Son=             	    	   1 	 3/1T  	 5/6T  	 6/8T  	 6/9   	 5/10   	5	 2:00.4 	 30.4	 A Carroll     	9.50	 C Carss
614	31	3	6	 Fashion Star=(L)      	    	   6 	 1@/H  	 3/4H  	 4/6Q  	 4/6H  	 6/10H  	6	 2:00.4 	 31.2	 A Macdonald   	3.70	 A Macdonald
615	31	4	2	 Scotty Mach N         	    	   2 	 2/1   	 1/1H  	 1/1H  	 1/1   	 1/H    	1	 1:55.2 	 29.2	 P Mackenzie   	5.05	 G Way
616	31	4	4	 Shootin To Kill       	    	   4 	 3/2H  	 3@/2  	 2@/1H 	 2/1   	 2/H    	2	 1:55.2 	 29.1	 B Mcclure     	0.95	 J Copley
617	31	4	6	 Attaboyaaron          	    	   6 	 4/4   	 5@/4  	 4@/3H 	 3/1H  	 3/H    	3	 1:55.2 	 28.4	 N Steward     	9.50	 J Watt
618	31	4	1	 Acefortyfourtalon     	    	   1 	 5/5H  	 4/3H  	 5/4   	 4/2H  	 4/1H   	4	 1:55.3 	 28.4	 J Ryan        	3.10	 G Durbano
619	31	4	9	 Jolted                	    	   8 	 8/10  	 8/7H  	 8/7H  	 7/5H  	 5/1T   	5	 1:55.4 	 28.2	 Tra Henry     	10.20	 I Darveau
620	31	4	8	 Twang Twang           	    	   7 	 7/8H  	 7@/6  	 7@/6  	 8/6H  	 6/2Q   	6	 1:55.4 	 28.3	 K Sheppard    	17.35	 K Sheppard
621	31	4	3	 Beach Boy             	    	   3 	 6/7   	 6/5H  	 6/5H  	 6/4   	 7/5H   	7	 1:56.2 	 29.2	 R Holliday    	7.45	 S Pryjma
622	31	4	5	 Vijayscam             	    	   5 	 1/1   	 2/1H  	 3/2   	 5/3Q  	 8/6H   	8	 1:56.3 	 30.1	 A Macdonald   	15.40	 D Graham
623	31	4	7	 Regally Magnified     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
624	31	5	1	 Billiondolarsecret    	    	   1 	 2/1H  	 2/1H  	 3/2   	 2/1H  	 1/NS   	1	 1:57.2 	 28.3	 Tra Henry     	18.85	 S Doyle
625	31	5	2	 Bettor Feather        	    	   2 	 1/1H  	 1/1H  	 1/1H  	 1/1H  	 2/NS   	2	 1:57.2 	 29  	 A Carroll     	0.60	 R Moreau
626	31	5	8	 Braonach              	    	   6 	 6/9   	 6/7H  	 5@/5Q 	 3/4   	 3/3Q   	3	 1:58   	 28.3	 A Macdonald   	3.95	 A Macdonald
627	31	5	7	 Skittle Hanover       	    	   5 	 5/7H  	 5/6   	 6/6   	 6/7H  	 4/4T   	4	 1:58.2 	 28.4	 A Haughan     	35.55	 J Williamso
628	31	5	3	 A Royal Hanover       	    	   3 	 3/3   	 3/3   	 4/3H  	 5/6   	 5/8T   	5	 1:59.1 	 30.1	 B Davis Jr    	50.70	 B Macintosh
629	31	5	9	 The Camel Express     	    	   7 	 7/10H 	 7/9   	 7/10  	 7/11H 	 6/10H  	6	 1:59.2 	 29  	 R Holliday    	5.95	 L Joyce
630	31	5	5	 Big Chute             	    	   4 	 4/4H  	 4/4H  	 2@/1H 	 4/4H  	 7/12H  	7	 1:59.4 	 31.1	 P Mackenzie   	2.60	 M Brethour
631	31	5	4	 Crazy Alice           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
632	31	5	6	 Im Stunning           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
633	31	6	4	 Severus Hanover=      	    	   4 	 2/1H  	 3/3   	 2@/1H 	 2/Q   	 1/1T   	1	 1:56.4 	 29.3	 B Mcclure     	10.60	 D Frey
634	31	6	3	 Covert Operative=(L)  	    	   3 	 3/3   	 1/1H  	 1/1H  	 1/Q   	 2DH/1T 	2	 1:57.1 	 30.1	 N Steward     	0.95	 P Henriksen
635	31	6	6	 Utopia=               	    	   6 	 6/8   	 6/7H  	 4@/3  	 4/2   	 2DH/1T 	2	 1:57.1 	 29.3	 J Ryan        	6.10	 J Ryan
636	31	6	5	 Chuckalo Caden        	    	   5 	 1/1H  	 2/1H  	 3/1H  	 3/1H  	 4/2T   	4	 1:57.2 	 30.1	 S Young       	10.90	 C Thompson
637	31	6	2	 Tortola Sunrise=      	    	   2 	 5/6H  	 5/6   	 7/5H  	 7/5   	 5/3H   	5	 1:57.2 	 29.2	 A Macdonald   	1.55	 A Macdonald
638	31	6	1	 Class Me Nice=(L)     	    	   1 	 4/4H  	 4/4H  	 5/3H  	 5/3H  	 6/3H   	6	 1:57.2 	 29.4	 R Holliday    	15.10	 B Weinholdt
639	31	6	7	 Amoureuse Hanover     	    	   7 	 7/9H  	 7/9   	 6@/5  	 6/4   	 7/5    	7	 1:57.4 	 29.4	 A Carroll     	15.50	 B Peterson
640	31	6	8	 Early Hit             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
641	32	1	9	 Dixie Lullaby         	    	   9 	 9/12  	 9@/11 	 8@/6H 	 5/4Q  	 1/1    	1	 1:55.1 	 29  	 B Forward     	6.75	 R Fellows
642	32	1	5	 Rockin Sockem         	    	   5 	 2/1H  	 2/1H  	 2/1H  	 2/1   	 2/1    	2	 1:55.2 	 30.1	 P Mackenzie   	13.95	 T Stokes
643	32	1	4	 Deucette              	    	   4 	 6/7H  	 6@/6H 	 6@/5  	 3/2   	 3/1T   	3	 1:55.3 	 29.3	 B Mcclure     	1.20	 T Jacobson
644	32	1	2	 Jens Credit           	    	   2 	 4/4H  	 4@/4H 	 4@/3  	 4/2H  	 4/3    	4	 1:55.4 	 30.1	 A Carroll     	4.85	 V Puddy
645	32	1	8	 P L Jasmine           	    	   8 	 1/1H  	 1/1H  	 1/1H  	 1/1   	 5/4    	5	 1:56   	 31  	 R Holliday    	11.90	 R Mcmillan
646	32	1	6	 Radar Trap            	    	   6 	 7/9   	 7/8H  	 7/5H  	 8/7H  	 6/4H   	6	 1:56   	 30  	 J Ryan        	29.25	 C Barss
647	32	1	3	 Casimir Overthetop    	    	   3 	 5/6   	 5/5   	 5/3H  	 6/4H  	 7/4T   	7	 1:56.1 	 30.3	 G Large       	12.20	 G Large
648	32	1	7	 Ima Holy Terror       	    	   7 	 8/10H 	 8/9   	 9/14  	 9/12  	 8/12T  	8	 1:57.4 	 30  	 C Steacy      	46.35	 R Hughes
649	32	1	1	 Imacutiepatootie      	    	   1 	 3/3   	 3/3   	 3@/2H 	 7/6   	 9/13   	9	 1:57.4 	 32.2	 M Whelan      	2.25	 A Colville
650	32	2	7	 Lady Crazy            	    	   7 	 2@/1  	 2@/HD 	 2@/H  	 2/HD  	 1/1    	1	 1:56.1 	 30.1	 Tra Henry     	4.50	 C Bradshaw
651	32	2	5	 Jiminey Three         	    	   5 	 1/1   	 1/HD  	 1/H   	 1/HD  	 2/1    	2	 1:56.2 	 30.2	 A Carroll     	2.40	 R Moreau
652	32	2	2	 Bad At Redhot         	    	   2 	 5/4H  	 5@/5H 	 4@/2  	 4/2   	 3/1Q   	3	 1:56.2 	 30  	 R Holliday    	4.45	 W Dunn
653	32	2	4	 Frankies First Luv    	    	   4 	 6/6   	 6/6   	 5@@/3H	 3/1H  	 4DH/1H 	4	 1:56.2 	 29.4	 B Mcclure     	5.45	 J Marsden
654	32	2	8	 Northern Prima        	    	   8 	 8/9   	 8/8H  	 8/6   	 7/5H  	 4DH/1H 	4	 1:56.2 	 29.1	 P Mackenzie   	14.15	 M Brethour
655	32	2	3	 Flower Bomb           	    	   3 	 4/3   	 4/4   	 6/4   	 8/6H  	 6/2H   	6	 1:56.3 	 29.4	 B Forward     	2.70	 B Macintosh
656	32	2	6	 Warrawee Rocket       	    	   6 	 7/7H  	 7/7   	 7@/4H 	 6/4   	 7/2T   	7	 1:56.4 	 30  	 B Davis Jr    	9.95	 T Stein
657	32	2	1	 Inexplicable Ruby     	    	   1 	 3/1H  	 3/3H  	 3/1H  	 5/3H  	 8/4    	8	 1:57   	 30.4	 N Steward     	9.70	 J Copley
658	32	3	1	 Par Intended          	    	   1 	 1/1H  	 1/1H  	 1/1   	 1/1H  	 1/H    	1	 1:56   	 28.4	 A Carroll     	3.00	 V Puddy
659	32	3	2	 Markathy              	    	   2 	 2/1H  	 2/1H  	 3/1H  	 2/1H  	 2/H    	2	 1:56   	 28.3	 N Steward     	6.00	 P Belanger 
660	32	3	3	 E L Spartacus         	    	   3 	 3/3   	 4/3H  	 5/3H  	 4/3   	 3/1H   	3	 1:56.1 	 28.2	 B Mcclure     	7.40	 J Watt
661	32	3	4	 Panedictine(L)        	    	   4 	 4/4H  	 3@/2  	 2@/1  	 3/1H  	 4/2Q   	4	 1:56.2 	 29  	 B Davis Jr    	6.80	 T Stein
662	32	3	6	 Cruizin K C           	    	   6 	 6/7H  	 6@/5H 	 6@/4H 	 7/7   	 5/5Q   	5	 1:57   	 29  	 P Mackenzie   	1.45	 P Coleman
663	32	3	5	 Connery Blue Chip     	    	   5 	 5/6   	 5@/4  	 4@/3  	 5/4H  	 6/7Q   	6	 1:57.2 	 29.3	 C Steacy      	12.55	 P Shepherd
664	32	3	7	 Amble Over Hanover(L) 	    	   7 	 7/9   	 7@/6H 	 7@@/5 	 6/6   	 7/7T   	7	 1:57.3 	 29.2	 Tra Henry     	5.25	 L Fuller
665	32	3	8	 Gunpowder             	    	   8 	 8/10H 	 8/7H  	 8/6Q  	 8/8H  	 8/7T   	8	 1:57.3 	 29.1	 B Forward     	17.95	 M Rain
666	32	4	1	 Platoon Seelster      	    	   1 	 3/3   	 1/1H  	 1/1   	 1/1H  	 1/1    	1	 1:56.2 	 28.4	 R Holliday    	0.90	 D Holliday
667	32	4	7	 Big Rich=(L)          	    	   7 	 1/1H  	 2/1H  	 3/1H  	 3/2   	 2/1    	2	 1:56.3 	 28.4	 B Davis Jr    	5.55	 R Moreau
668	32	4	9	 Delcrest Massy=(L)    	    	   9 	 5/6   	 5/4   	 4@/3  	 2/1H  	 3/1H   	3	 1:56.3 	 28.2	 A Carroll     	29.35	 V Puddy
669	32	4	8	 In Secret=(L)         	    	   8 	 9/12  	 9/10  	 9/7Q  	 7/6   	 4/1H   	4	 1:56.3 	 27.3	 B Mcclure     	11.20	 P Henriksen
670	32	4	3	 Doubledown Gass       	    	   3 	 2/1H  	 3/3   	 5/3H  	 5/4   	 5/1T   	5	 1:56.4 	 28.3	 R Gassien     	4.40	 R Gassien
671	32	4	4	 Call Me Richard       	    	   4 	 7/9   	 6/5H  	 6@/4H 	 6/5H  	 6/3    	6	 1:57   	 28.3	 P Mackenzie   	4.65	 C Bradshaw
672	32	4	2	 Domedomedome(L)       	    	   2 	 6/7H  	 7/7   	 7/6   	 9/7H  	 7/3T   	7	 1:57.1 	 28.2	 Jo Kovacs     	14.05	 J Moiseyev
673	32	4	5	 R Choochoo Charlie=(L)	)   	   5 	 8/10H 	 8@/8H 	 8@/6H 	 8/7   	 8/6H   	8	 1:57.3 	 28.4	 Tra Henry     	15.20	 C Auciello
674	32	4	6	 Warrawee Proton       	    	   6 	 4/4H  	 4/3H  	 2@/1  	 4X/3T 	 9/22   	9	 2:00.4 	 33  	 B Forward     	17.90	 T Langille
675	35	1	1	 Big Yellow(L)         	    	   1 	 2/2   	 2/5   	 1/1   	 1/2   	 1/1H   	1	 1:55.2 	 30.1	 S Young       	2.90	 B Wallace
676	35	1	2	 Upgrade Valley        	    	   2 	 4/4   	 4@/8  	 2/1   	 2/2   	 2/1H   	2	 1:55.3 	 30.1	 P Mackenzie   	5.55	 P Smith
677	35	1	5	 Emperor               	    	   5 	 8/12  	 7/12  	 4@/5  	 3/6   	 3/5H   	3	 1:56.2 	 30.1	 A Carroll     	1.70	 R Mcintosh
678	35	1	8	 The Avenger           	    	   8 	 3@/3  	 3/7   	 3/4   	 4/8   	 4/10   	4	 1:57.2 	 31.2	 B Davis Jr    	36.55	 W Robinson
679	35	1	6	 Stonebridge Marvel    	    	   6 	 9/14  	 8/14  	 7/8   	 6/11  	 5/12T  	5	 1:58   	 31.1	 N Steward     	16.80	 J Belliveau
680	35	1	9	 Zetlan Rocket         	    	   9 	 5/6   	 5/9H  	 5/6   	 5/10  	 6/16H  	6	 1:58.3 	 32.1	 T Smith       	86.05	 J Walker
681	35	1	3	 Wild Chance           	    	   3 	 6/8   	 6@/10 	 8/10  	 7/15  	 7/21   	7	 1:59.3 	 32.2	 B Mcclure     	4.65	 W Whebby
682	35	1	7	 Derby Dale            	    	   7 	 1/2   	 1/5   	 6/7   	 8/17  	 8/30   	8	 2:01.2 	 34.4	 B Forward     	7.40	 V Puddy
683	35	1	4	 Rockstar Drums        	    	   4 	 7X/10 	 9/17  	 9/18  	 9/25  	 9/34   	9	 2:02.1 	 33.2	 L Ouellette   	24.35	 J Morrison
684	35	2	1	 Trishas Wish          	    	   1 	 2/2   	 2/1   	 3/2   	 3/1   	 1/H    	1	 1:58.4 	 30.3	 R Battin      	9.50	 R Battin
685	35	2	5	 Ginger                	    	   5 	 1/2   	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:58.4 	 31  	 B Forward     	7.45	 L Johnson
686	35	2	3	 Blazinhart Hanover    	    	   3 	 6/10  	 6/6H  	 6/5   	 5/2H  	 3/2    	3	 1:59.1 	 30.2	 T Moore       	24.05	 J Wright
687	35	2	2	 Lady Santana          	    	   2 	 5/7   	 5@/3H 	 4@/2H 	 4/1H  	 4/2Q   	4	 1:59.1 	 31  	 B Davis Jr    	2.70	 J Pereira
688	35	2	4	 Mach Of The Town      	    	   4 	 3/4   	 4/3   	 5@/3H 	 6/3   	 5/4Q   	5	 1:59.3 	 31.1	 N Steward     	1.60	 G Robinson
689	35	2	8	 Shanghai Nights       	    	   8 	 9/16  	 9/11  	 8/6H  	 7/3H  	 6/5T   	6	 2:00   	 31  	 P Mackenzie   	12.15	 L Mansfield
690	35	2	9	 Hussys Sport          	    	   9 	 4/5H  	 3@/1H 	 2@/H  	 2/H   	 7/6Q   	7	 2:00   	 32.1	 L House       	9.90	 S Mcniven
691	35	2	7	 On The Rise           	    	   7 	 8/14  	 8@/9  	 9/7H  	 9/5H  	 8/7T   	8	 2:00.2 	 31.1	 R Holliday    	76.15	 W Durbridge
692	35	2	6	 Jinglewriter(L)       	    	   6 	 7/12  	 7@/7  	 7@/5H 	 8/4H  	 9/12   	9	 2:01.1 	 32.2	 A Carroll     	7.35	 B Treen
693	35	3	5	 Unce Hanover          	    	   4 	 4/4H  	 3@/2  	 2@/1  	 2/1   	 1/NS   	1	 2:02.1 	 30  	 A Carroll     	2.95	 C Coleman
694	35	3	4	 Hands Up For Luck     	    	   3 	 2/1   	 1/1   	 1/1   	 1/1   	 2/NS   	2	 2:02.1 	 30.1	 B Davis Jr    	0.65	 A Macdonald
695	35	3	3	 Cam Engine            	    	   2 	 6/7H  	 5@/4  	 3@@/2 	 3/1H  	 3/1    	3	 2:02.2 	 30  	 P Mackenzie   	15.70	 M Rivest
696	35	3	7	 Chalky                	    	   6 	 1/1   	 2/1   	 4/3H  	 4/2H  	 4/1Q   	4	 2:02.2 	 29.4	 Mi Horner     	12.05	 Ma Horner
697	35	3	8	 Flying Solo           	    	   7 	 7/9   	 7@/6  	 5@/4H 	 6/4H  	 5/3T   	5	 2:03   	 30.1	 Tra Henry     	22.10	 V Cochrane
698	35	3	9	 All Access            	    	   9 	 5/6   	 6/5   	 7@/6H 	 7/5H  	 6/4T   	6	 2:03.1 	 30  	 N Boyd        	22.90	 J Dean
699	35	3	1	 Best Of Luck Bilbo    	    	   1 	 3/3   	 4/3   	 6/5H  	 5/4   	 7/5    	7	 2:03.1 	 30.1	 S Hudon       	22.00	 K Gangell
700	35	3	6	 Little Johnny         	    	   5 	 8/10  	 8/7H  	 8/8H  	 8/8H  	 8/7H   	8	 2:03.3 	 30  	 B Forward     	9.15	 N Liadis
701	35	3	2	 About A Boy           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
702	35	4	1	 Gia Diamond(L)        	    	   1 	 1/1H  	 1/1   	 1/1H  	 1/3   	 1/7T   	1	 1:57.1 	 29  	 J Ryan        	3.20	 J Ryan
703	35	4	6	 Squeeze This          	    	   6 	 5/5   	 6@/5  	 5@@/4 	 4/4H  	 2/7T   	2	 1:58.4 	 29.4	 Tra Henry     	0.85	 D Lindsey
704	35	4	9	 Shes Dignified        	    	   9 	 2/1H  	 2/1   	 2/1H  	 2/3   	 3/8    	3	 1:58.4 	 30.2	 P Mackenzie   	22.55	 S Gillard
705	35	4	3	 All The Ladies        	    	   3 	 4/4   	 5@/3H 	 3@@/2H	 3/3H  	 4/9H   	4	 1:59   	 30.2	 A Haughan     	38.00	 M Crone
706	35	4	2	 Sportsonthebeach      	    	   2 	 3/3   	 3@/2  	 6@/5  	 6/7   	 5/11H  	5	 1:59.2 	 30.1	 A Carroll     	10.00	 G Mcdonnell
707	35	4	4	 Casimir Lucky Lady    	    	   4 	 6/6   	 4/3   	 4/3H  	 5/6H  	 6/15H  	6	 2:00.1 	 31.2	 B Mcclure     	17.70	 B Kempton
708	35	4	7	 Blushing Promise      	    	   7 	 8/9H  	 8/8H  	 8/6H  	 8/9   	 7/15T  	7	 2:00.2 	 31  	 C Brown       	40.25	 G Laurignan
709	35	4	8	 Mach Shark            	    	   8 	 9/11  	 9/11  	 9/7H  	 9/10H 	 8/16   	8	 2:00.2 	 30.4	 G Rooney      	41.55	 V Mcmurren
710	35	4	5	 Mighty Mouse          	    	   5 	 7/8   	 7@/7  	 7@@/5H	 7/7H  	 9/16H  	9	 2:00.2 	 31.1	 N Steward     	4.50	 J Watt
711	35	5	9	 Littlebitaswagger     	    	   9 	 4/3   	 4/3   	 6/4   	 4/2H  	 1/H    	1	 1:56.3 	 29  	 Tra Henry     	24.60	 J Harris
712	35	5	2	 Blue Zombie           	    	   2 	 1/1H  	 1/1   	 1/H   	 1/H   	 2/H    	2	 1:56.3 	 29.4	 A Carroll     	1.10	 C Coleman
713	35	5	3	 Adore Him             	    	   3 	 5/4H  	 5@/3H 	 2@@/H 	 2/H   	 3/H    	3	 1:56.3 	 29.4	 N Steward     	1.85	 C Blake
714	35	5	1	 Deseronto(L)          	    	   1 	 2/1H  	 2/1   	 3/2   	 3/1H  	 4/1T   	4	 1:57   	 29.4	 R Holliday    	9.65	 D Lindsey
715	35	5	4	 Another Great Pick    	    	   4 	 6/6H  	 6/5   	 8/6   	 5/4   	 5/3    	5	 1:57.1 	 29.1	 R Battin      	18.85	 R Battin
716	35	5	5	 Art Again             	    	   5 	 3@/2  	 3@/1H 	 4@/2H 	 6/4H  	 6/6    	6	 1:57.4 	 30.3	 B Mcclure     	6.15	 G Mcdonnell
717	35	5	7	 Distinctiv Sean       	    	   7 	 8/9   	 9/7H  	 9/8   	 7/6   	 7/6H   	7	 1:57.4 	 29.2	 G Rooney      	62.60	 V Mcmurren
718	35	5	8	 Harbourlite Jerry     	    	   8 	 9/10H 	 8@/6H 	 7@/5  	 8/6H  	 8/8    	8	 1:58.1 	 30.2	 B Forward     	189.35	 J Rankin
719	35	5	6	 Mr Irresistible       	    	   6 	 7/7H  	 7@/5H 	 5@/3H 	 9/7   	 9/10H  	9	 1:58.3 	 31.1	 P Mackenzie   	24.00	 M Etsell
720	35	6	2	 Youths Awesome(L)     	    	   2 	 4/4   	 5/4   	 5@/3H 	 5/3   	 1/NS   	1	 1:57.1 	 30  	 R Battin      	15.40	 R Battin
721	35	6	6	 Here Comes William    	    	   6 	 6@/5H 	 4@/2H 	 4@/2H 	 3/1H  	 2/NS   	2	 1:57.1 	 30.1	 D Dupont      	0.75	 M Dupont
722	35	6	9	 Goldstar Badlands     	    	   9 	 3/2   	 2@/H  	 2@/H  	 1/1   	 3/1Q   	3	 1:57.2 	 30.4	 G Rooney      	9.70	 H Toll
723	35	6	3	 Evasive Card Shark    	    	   3 	 2/1   	 3/2   	 3/2   	 4/2   	 4/1Q   	4	 1:57.2 	 30.2	 D St Pierre   	9.55	 T Staley
724	35	6	7	 Monster In Law        	    	   7 	 9/9H  	 9/8   	 7/5H  	 6/4H  	 5/1H   	5	 1:57.2 	 29.4	 N Steward     	47.40	 D Beatson
725	35	6	1	 Intrigued Intended    	    	   1 	 1/1   	 1/H   	 1/H   	 2/1   	 6/3T   	6	 1:58   	 31.2	 R Holliday    	13.55	 G Weatherbe
726	35	6	5	 Grits N Gravy         	    	   5 	 7/7   	 7@/6H 	 8@/6  	 7/5   	 7/3T   	7	 1:58   	 30.1	 B Mcclure     	8.80	 W Hamm
727	35	6	8	 Big Moment            	    	   8 	 8@/7H 	 8/7   	 9/8   	 8/6   	 8/4    	8	 1:58   	 29.4	 A Carroll     	13.85	 R Mcintosh
728	35	6	4	 Relleno Hanover(L)    	    	   4 	 5/5   	 6@/4H 	 6@/4H 	 9/7   	 9/4H   	9	 1:58   	 30.3	 B Forward     	6.50	 G Mcdonnell
729	36	1	1	 Dreydl Hanover        	    	   1 	 1/H   	 1/1H  	 1/1H  	 1/4   	 1/4H   	1	 1:57.1 	 30.2	 A Haughan     	1.10	 G Remmen
730	36	1	9	 Bugger Max            	    	   9 	 3/2   	 3@/2  	 2@/1H 	 2/4   	 2/4H   	2	 1:58   	 31  	 N Steward     	4.30	 D Beatson
731	36	1	6	 St Lads Zeke          	    	   6 	 9/10  	 9/13  	 7@/5H 	 7/7   	 3/5    	3	 1:58.1 	 30.2	 S Young       	13.85	 G Wain
732	36	1	3	 Kendal Fresco         	    	   3 	 2@/H  	 2/1H  	 4/3   	 3/4H  	 4/5Q   	4	 1:58.1 	 30.4	 L House       	11.40	 S Mcniven
733	36	1	4	 Hussys Blu Boy        	    	   4 	 6/6   	 6@/5H 	 5@/3H 	 5/5H  	 5/6    	5	 1:58.2 	 31  	 B Mcclure     	3.00	 S Mcniven
734	36	1	5	 Boysgotfever          	    	   5 	 7/7   	 7@/7  	 8/6H  	 6/6H  	 6/6Q   	6	 1:58.2 	 30.2	 T Moore       	20.50	 M Macri
735	36	1	2	 The Kop               	    	   2 	 5/4H  	 5/5   	 6@/4H 	 8/7H  	 7/10T  	7	 1:59.2 	 31.4	 R Holliday    	20.55	 F Maguire
736	36	1	7	 Terra Cotta Lad       	    	   7 	 4@/3  	 4@/3  	 3@@/2 	 4/5   	 8/13T  	8	 2:00   	 32.4	 B Forward     	26.25	 G Mcdonnell
737	36	1	8	 Machme To The Moon    	    	   8 	 8/8H  	 8/12  	 9/10  	 9/12  	 9/17T  	9	 2:00.4 	 32  	 A Carroll     	42.50	 W Robinson
738	36	2	9	 Spartan Victory       	    	   9 	 5/4   	 3@/1H 	 3@/1H 	 2/NS  	 1/1Q   	1	 2:00.3 	 28.3	 R Holliday    	2.10	 K Di Cenzo
739	36	2	7	 Thundering Ovation    	    	   7 	 1@/1  	 1/1   	 1/1   	 1/NS  	 2/1Q   	2	 2:00.4 	 29  	 P Mackenzie   	1.50	 G Sloan
740	36	2	4	 Sonny With Achance    	    	   4 	 3/2   	 4/2H  	 4/3   	 4/4   	 3/5H   	3	 2:01.3 	 29.1	 J Obrien      	38.05	 J Obrien
741	36	2	2	 Stolen Goods          	    	   2 	 2/1   	 2/1   	 2/1   	 3/2H  	 4/5H   	4	 2:01.3 	 29.3	 B Forward     	13.35	 J Rankin
742	36	2	5	 Flexie                	    	   5 	 4@/3  	 6/4H  	 7/5H  	 6/5H  	 5/6Q   	5	 2:01.4 	 29  	 Tra Henry     	26.35	 M Giles
743	36	2	6	 Lexus Rocky           	    	   6 	 7/6   	 7@/5H 	 6@/4H 	 7/6H  	 6/7Q   	6	 2:02   	 29.2	 A Carroll     	5.15	 D Sinclair
744	36	2	3	 Majestic Mystic=      	    	   3 	 6/5   	 5@/3H 	 5@/3H 	 5/4H  	 7/8T   	7	 2:02.2 	 30  	 G Ketros      	38.25	 G Ketros
745	36	2	8	 Bambino Hall(L)       	    	   8 	 8/8   	 8/6H  	 8@/6H 	 8/7H  	 8/10   	8	 2:02.3 	 29.3	 J Ryan        	5.00	 J Ryan
746	36	2	1	 Piscean(L)            	    	   X1	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 B Mcclure     	\N	 C Beelby
747	36	3	6	 Argyle Alberwhosur    	    	   6 	 6/7   	 2@/1  	 2@/H  	 1/3   	 1/7    	1	 1:59   	 30.2	 B Forward     	5.00	 J Pedden
748	36	3	3	 Gossip Model          	    	   3 	 3/3   	 4@/3  	 5@/3H 	 3/3H  	 2/7    	2	 2:00.2 	 31.1	 Tra Henry     	0.90	 K Di Cenzo
749	36	3	2	 Noodles               	    	   2 	 1/1H  	 1/1   	 1/H   	 2/3   	 3/8H   	3	 2:00.3 	 32  	 N Steward     	4.75	 R Mitchell
750	36	3	4	 Flysantanna           	    	   4 	 2/1H  	 3/2   	 3/2   	 4/4   	 4/9H   	4	 2:00.4 	 31.4	 P Mackenzie   	5.65	 Alan W Fair
751	36	3	1	 Maritime Girl         	    	   1 	 4/4H  	 5/4   	 4/3   	 5/4H  	 5/10   	5	 2:01   	 31.4	 S Young       	15.85	 J Wright
752	36	3	7	 Impatient Lady        	    	   7 	 7/8   	 6@/5  	 6@/5  	 7/6   	 6/10T  	6	 2:01.1 	 31.3	 T Moore       	25.00	 R Duld
753	36	3	5	 Acefourtyfouramber    	    	   5 	 5/6   	 7/6H  	 8/6H  	 8/7   	 7/10T  	7	 2:01.1 	 31.2	 J Ryan        	38.45	 S Peacock
754	36	3	8	 Sportsillustrator     	    	   8 	 8/9   	 8@/7  	 7@@/5H	 6/5H  	 8/11H  	8	 2:01.1 	 31.3	 B Mcclure     	13.65	 R Mcneill
755	36	4	1	 B Fast Eddie          	    	   1 	 1/1   	 1/1   	 1/H   	 1/1H  	 1/2Q   	1	 1:57.1 	 29  	 B Mcclure     	1.75	 B Baillarge
756	36	4	5	 The Big Beast         	    	   5 	 3/2   	 3/2   	 3/2   	 2/1H  	 2/2Q   	2	 1:57.3 	 29  	 L Ouellette   	5.65	 M Ouimet
757	36	4	4	 Preppy Art            	    	   4 	 6/5   	 6/4H  	 6/4H  	 4/3H  	 3/3Q   	3	 1:57.4 	 28.4	 T Fritz       	31.25	 T Fritz
758	36	4	2	 Sutton Seelster       	    	   2 	 2/1   	 2/1   	 2@/H  	 3/2   	 4/3H   	4	 1:57.4 	 29.3	 T Moore       	1.50	 Dr I Moore
759	36	4	3	 Mister Big Top        	    	   3 	 5/4   	 5@/3H 	 5@@/4 	 5/4   	 5/5H   	5	 1:58.1 	 29.1	 Tra Henry     	44.90	 J Byron
760	36	4	7	 Shaker                	    	   7 	 7/6   	 7/5H  	 7/6   	 6/6   	 6/5T   	6	 1:58.2 	 29  	 B Forward     	33.30	 P Shakes
761	36	4	6	 Rough Trade           	    	   6 	 8/7H  	 9/7H  	 9/8H  	 7/8   	 7/7T   	7	 1:58.4 	 29  	 P Mackenzie   	14.10	 F Hincks
762	36	4	8	 Cams Lucky Sam(L)     	    	   8 	 9/9   	 8@/6  	 8@/6H 	 8/10  	 8/9    	8	 1:59   	 29.3	 J Ryan        	13.15	 N Gallucci
763	36	4	9	 Invinceable B         	    	   9 	 4/3   	 4@/2H 	 4@/3H 	 9/12  	 9/20   	9	 2:01.1 	 32.2	 G Rooney      	11.65	 K Campbell
764	37	1	1	 Rosberg               	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1   	 1/T    	1	 2:01.3 	 29.4	 J Moiseyev    	0.60	 J Walker
765	37	1	4	 Zorgwijk Rocket=      	    	   4 	 2/1H  	 2/1   	 2/1   	 2/1   	 2/T    	2	 2:01.4 	 29.4	 J Hudon Jr    	3.30	 J Hudon Jr
766	37	1	6	 Mr Marshmellow=       	    	   6 	 3/3   	 3/2H  	 3/2   	 3/2   	 3/3H   	3	 2:02.1 	 30  	 O Gois        	5.50	 O Gois
767	37	1	7	 Many A Man            	    	   7 	 6/9   	 6@/7  	 5/5   	 5/4   	 4/5    	4	 2:02.3 	 29.4	 A Carroll     	40.60	 R Mcintosh
768	37	1	2	 Yo Yo Mass=           	    	   2 	 5/7H  	 5@/5H 	 4/3H  	 4/3   	 5/6    	5	 2:02.4 	 30.2	 B Mcclure     	6.85	 K Reibeling
769	37	1	3	 Stonebridge Brass     	    	   3 	 4/6   	 4/5   	 6/10  	 6/16  	 6/27   	6	 2:07   	 33.1	 S Byron       	63.65	 J Bax
770	37	1	5	 Adventure Ahead=      	    	   5 	 X7X/24	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 A Macdonald   	24.55	 A Macdonald
771	37	2	4	 Kitarro               	    	   4 	 3/3   	 3/2   	 3@/1  	 3/1H  	 1/8H   	1	 2:03.2 	 30.1	 P Mackenzie   	4.60	 K Reibeling
772	37	2	3	 Northern Dazzle       	    	   3 	 1/H   	 2/1   	 4/4   	 4/7   	 2/8H   	2	 2:05   	 31.1	 D Mcnair      	19.30	 R Mcnair
773	37	2	2	 Critical Mass=        	    	   2 	 2@/H  	 1/1   	 1/H   	 1I/H  	 3/11T  	3	 2:05.4 	 32.4	 B Mcclure     	0.55	 D Menary
774	37	2	5	 My Big Kadillac       	    	   5 	 4/5   	 4/3   	 2@/H  	 2IX/H 	 4/12H  	4	 2:05.4 	 32.4	 A Carroll     	2.90	 R Mcintosh
775	37	2	1	 Laminin               	    	   1X	 5/12  	 5/13  	 5X/14 	 5X/19 	 5/22   	5	 2:07.4 	 32  	 C Jamieson    	11.40	 C Jamieson
776	37	2	6	 Bourne=               	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
777	37	2	7	 More Than Majestic=   	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
778	37	3	1	 Clear Idea            	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:59.2 	 29.2	 B Davis Jr    	1.90	 B Macintosh
779	37	3	4	 Cousin Mary           	    	   4 	 4/5   	 4@/3  	 3@@/1H	 2/1   	 2/H    	2	 1:59.2 	 29.1	 R Holliday    	1.40	 J Kerr
780	37	3	3	 Michelles Hattrick    	    	   3 	 3/3   	 2@/1  	 2@/1  	 3/1H  	 3/2    	3	 1:59.4 	 29.3	 Trev Henry    	2.85	 J Pereira
781	37	3	2	 Dirt On My Skirt      	    	   2 	 2/1   	 3/2   	 4/2   	 4/2   	 4/2H   	4	 1:59.4 	 29.2	 S Young       	15.25	 C Flanigan
782	37	3	6	 Fading Shadow         	    	   6 	 6/8   	 6@/5  	 5@/3H 	 5/3   	 5/3Q   	5	 2:00   	 29.2	 D Mcnair      	11.85	 J Darling
783	37	3	5	 Lyons Moonlight       	    	   5 	 5/6H  	 5/4H  	 6/4H  	 6/5   	 6/4    	6	 2:00.1 	 29.2	 A Haughan     	68.10	 B Goit
784	37	3	7	 Dancing Shadows K     	    	   7 	 8/10H 	 7@/6H 	 7@/5  	 7/6   	 7/7H   	7	 2:00.4 	 29.4	 Ja Macdonald  	47.65	 P Reid
785	37	3	9	 Uncool                	    	   9 	 7/9H  	 8/9H  	 8/11  	 8/14  	 8/23   	8	 2:04   	 31.4	 N Steward     	80.65	 Alan W Fair
786	37	3	8	 Lady Oxford           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
787	37	4	2	 Prettyndangerous      	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/H    	1	 1:55.2 	 30  	 J Ryan        	2.30	 B Curran
788	37	4	3	 Moon Lake(L)          	    	   2 	 2/1   	 2/1   	 2/1   	 2/1   	 2/H    	2	 1:55.2 	 29.4	 B Forward     	9.50	 D Lehan
789	37	4	7	 Romance In Camelot(L) 	    	   6 	 6/7   	 5/4H  	 3/2H  	 3/2   	 3/3Q   	3	 1:56   	 30.1	 R Holliday    	35.35	 M Rivest
790	37	4	8	 St Lads Pixie         	    	   7 	 7/9   	 7/6H  	 5/4H  	 4/3H  	 4/4T   	4	 1:56.2 	 30.1	 B Mcclure     	20.95	 J Watt
791	37	4	4	 Cyndalianne Duc       	    	   3 	 4/4   	 4@/3  	 6@/5  	 6/4H  	 5/5Q   	5	 1:56.2 	 30  	 N Steward     	4.55	 G Robinson
792	37	4	6	 Good Luck Kathy       	    	   5 	 5/5   	 6@/5H 	 7/6   	 7/6H  	 6/5H   	6	 1:56.2 	 29.4	 A Carroll     	9.40	 S Rose
793	37	4	5	 Little Anna Mae(L)    	    	   4 	 3/2   	 3@/2  	 4@/3  	 5/4   	 7/5T   	7	 1:56.3 	 30.3	 Trev Henry    	1.15	 L Lalonde J
794	37	4	1	 Twilight Katie        	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
795	37	5	4	 Themanofmydreams      	    	   3 	 2/1   	 1/1H  	 1/1H  	 1/1H  	 1/2T   	1	 2:03.3 	 30  	 D St Pierre   	0.45	 T Staley
796	37	5	5	 Little Lion Man       	    	   4 	 1/1   	 2/1H  	 2/1H  	 2/1H  	 2/2T   	2	 2:04.1 	 30.2	 Trev Henry    	6.85	 R Moreau
797	37	5	2	 Lexus Gilmore=        	    	   1 	 3/2   	 3/2H  	 4/3   	 3/3   	 3/6    	3	 2:04.4 	 30.3	 L House       	28.35	 N Dunstan
798	37	5	8	 Smoking Mass          	    	   7 	 6/7H  	 6/6H  	 6/5   	 5/4H  	 4/7T   	4	 2:05.1 	 30.3	 D Dupont      	35.90	 M Dupont
799	37	5	7	 A J Ricochet          	    	   6 	 5/6   	 5/5H  	 5@/4  	 6/5   	 5/8Q   	5	 2:05.1 	 30.4	 A Carroll     	31.25	 A Dimmers
800	37	5	3	 Motown Jackpot        	    	   2 	 4/4H  	 4/4   	 3@/2  	 4/3H  	 6/9    	6	 2:05.2 	 31.2	 M Baillargeon 	3.25	 B Baillarge
801	37	5	6	 Lmc Mass Gem          	    	   5X	 7/10  	 X7/7  	 7/25  	 7/30  	 7/42   	7	 2:12   	 33.2	 P Mackenzie   	11.35	 K Reibeling
802	37	5	1	 Majestic Streak       	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
803	37	6	5	 Coherent=             	    	   5 	 6@/4H 	 3@/2  	 2@/H  	 2/H   	 1/NK   	1	 2:02.4 	 30.3	 R Jenkins Jr  	10.80	 F Marion
804	37	6	4	 Tinas War             	    	   4 	 3/2   	 4/3   	 4/3H  	 4/2H  	 2/NK   	2	 2:02.4 	 30  	 G Mcknight    	8.45	 G Mcknight
805	37	6	3	 Shes All Muscle       	    	   3 	 1/1   	 1/1   	 1/H   	 1/H   	 3/1    	3	 2:03   	 30.4	 J Ryan        	2.40	 J Wilson
806	37	6	9	 Angel Assault=        	    	   9 	 5/4   	 8/7   	 7/6   	 5/3H  	 4/2Q   	4	 2:03.1 	 29.4	 M Whelan      	6.45	 W Whelan
807	37	6	2	 Tymal Bolt            	    	   2 	 2/1   	 2/1   	 3/2   	 3/2   	 5/3Q   	5	 2:03.2 	 30.4	 T Borth       	7.80	 F Baker Jr
808	37	6	6	 Its Easy To Dance     	    	   6 	 7/6   	 5@/4  	 5@/4  	 7/6   	 6/11H  	6	 2:05   	 32  	 R Shepherd    	2.85	 P Shepherd
809	37	6	8	 Zorgwijk Priority=    	    	   7 	 8/7H  	 7@/6  	 6@/5  	 EX6/4H	 7BE/26 	7	 2:08   	 34.4	 P Mackenzie   	32.15	 T Mckibbin
810	37	6	1	 Scorr Again           	    	   1 	 4/3   	 6/5H  	 X8/16 	 8/26  	 8/DIS  	8	        	     	 Do Brown      	4.30	 Do Brown
811	37	6	7	 Whatdreamsrmadeof     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
812	38	1	1	 Tauriel               	    	   1 	 1/1   	 1/1   	 1/1   	 1/1H  	 1/1    	1	 1:57.1 	 28.3	 B Forward     	3.65	 J Barton
813	38	1	3	 Greystone Ladyluck    	    	   3X	 2/1   	 2/1   	 3/2   	 2/1H  	 2/1    	2	 1:57.2 	 28.2	 B Davis Jr    	1.30	 B Belore
814	38	1	9	 Life Groove           	    	   9 	 5/5H  	 3@/2  	 2/1   	 3/2   	 3/2H   	3	 1:57.3 	 28.4	 P Mackenzie   	6.25	 R Laarman
815	38	1	2	 Alliwannadoisplay     	    	   2 	 4/4H  	 5/4H  	 5/4   	 4/4H  	 4/6T   	4	 1:58.3 	 29.1	 R Shepherd    	25.45	 G Adair
816	38	1	5	 On A Cloud            	    	   5 	 6/7   	 6/6   	 7/6   	 6/6H  	 5/7Q   	5	 1:58.3 	 28.4	 Ja Macdonald  	4.60	 T Bain
817	38	1	6	 Boyur Attractive      	    	   6 	 7/8   	 7@/6H 	 6@/4H 	 7/7H  	 6/9T   	6	 1:59.1 	 29.4	 Trev Henry    	14.80	 R Steward
818	38	1	7	 Tz Tizzy              	    	   7 	 8/9   	 8/7H  	 8@/6H 	 8/8   	 7/10   	7	 1:59.1 	 29.2	 L House       	28.00	 S Mcniven
819	38	1	4	 Evas Best Girl        	    	   4 	 3/2H  	 4@/3  	 4@/3  	 5/5   	 8/12   	8	 1:59.3 	 30.2	 N Steward     	8.45	 P Core
820	38	1	8	 Lady London           	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
821	38	2	2	 St Lads Moonwalk      	    	   2 	 4@/3  	 1/1H  	 1/1H  	 1/1H  	 1/2H   	1	 1:53.4 	 28.1	 D Mcnair      	0.75	 J Darling
822	38	2	3	 Newbie                	    	   3 	 1@/1  	 2/1H  	 2/1H  	 2/1H  	 2/2H   	2	 1:54.1 	 28.2	 B Davis Jr    	2.05	 I Hyatt
823	38	2	6	 Rockabella            	    	   5 	 6/9   	 6/7H  	 6/5   	 4/4   	 3/8    	3	 1:55.2 	 28.4	 Trev Henry    	8.45	 T Stein
824	38	2	8	 Raylan Givens(L)      	    	   7 	 2/1   	 3/3   	 4/3H  	 3/3   	 4/8T   	4	 1:55.3 	 29.2	 C Steacy      	89.55	 J Morrison
825	38	2	7	 Rock N Roll Legacy(L) 	    	   6 	 8/11  	 8/9H  	 8/7   	 7/6H  	 5/9Q   	5	 1:55.3 	 28.3	 G Rooney      	29.15	 R Marriage
826	38	2	1	 Ciona Bromach(L)      	    	   1 	 5/6   	 5/6   	 5@/4  	 5/4H  	 6/9Q   	6	 1:55.3 	 29.1	 A Haughan     	25.60	 D Obrienmor
827	38	2	4	 Two Of Clubs          	    	   4 	 3/2H  	 4/4   	 3@/2  	 6/5   	 7/17   	7	 1:57.1 	 31.1	 S Young       	13.00	 G Rivest
828	38	2	9	 Kid Galahad N         	    	   9 	 7/10  	 7@/8  	 7@/6  	 8/7   	 8/17   	8	 1:57.1 	 30.2	 L House       	15.15	 S Taylor
829	38	2	5	 Mister X              	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
830	38	3	1	 Tougher Than Ever=    	    	   1 	 3/2H  	 3/3   	 2@/H  	 2/H   	 1/2Q   	1	 2:02.2 	 30.3	 Ja Macdonald  	2.75	 R Norman
831	38	3	5	 Warrawee Shipshape=   	    	   5 	 2/1   	 2/1H  	 3/2   	 3/2   	 2/2Q   	2	 2:02.4 	 30.3	 A Green       	2.00	 A Green
832	38	3	7	 Dontcrampmystyle=     	    	   7 	 1@/1  	 1/1H  	 1/H   	 1/H   	 3/3Q   	3	 2:03   	 31.1	 Trev Henry    	2.15	 A Mccabe
833	38	3	4	 Jack In My Coke=      	    	   4 	 6/12  	 5@/6H 	 4/3H  	 4/3   	 4/6H   	4	 2:03.3 	 31.1	 J Maguire     	7.00	 J Maguire
834	38	3	3	 Charmbo Chrome        	    	   3 	 5/11  	 6/8   	 5/6H  	 5/6   	 5/7T   	5	 2:04   	 31  	 A Hamilton    	38.05	 J Rier
835	38	3	6	 Piston Popper         	    	   6 	 7/15  	 7/12  	 6/9   	 6/11  	 6/16   	6	 2:05.3 	 32  	 G Rivest      	47.70	 G Rivest
836	38	3	2	 Airborne Seelster     	    	   2 	 4/8   	 4/5H  	 X7/18 	 7/18  	 7/24   	7	 2:07.1 	 31.4	 D Mcnair      	7.15	 R Mcnair
837	38	4	2	 Top Of The Morning(L) 	    	   2 	 3/2   	 3@/1H 	 2@/H  	 2/H   	 1/NK   	1	 1:58.1 	 30.4	 T Moore       	2.85	 T Moore
838	38	4	7	 Nor Star Renegade     	    	   7 	 2@/1  	 1/1   	 1/H   	 1/H   	 2/NK   	2	 1:58.1 	 30.4	 D Mcnair      	6.80	 R Lindenfie
839	38	4	9	 Kablooie(L)           	    	   9 	 6/7H  	 6@/5  	 5@/3H 	 5/3   	 3/2Q   	3	 1:58.3 	 30.3	 B Mcclure     	3.65	 D Lagace
840	38	4	3	 Star Struck Luck      	    	   3 	 7/8H  	 7@/6H 	 6@/5  	 7/4H  	 4/3Q   	4	 1:58.4 	 30.2	 Br Richardson 	9.55	 E Laybourne
841	38	4	5	 Joeys Kidd            	    	   5 	 8/10  	 9@/8H 	 7@/6  	 6/3H  	 5/3H   	5	 1:58.4 	 30.1	 P Mackenzie   	64.20	 V Cochrane
842	38	4	1	 Bandicoot             	    	   1 	 4/4H  	 4@/3H 	 4/3   	 3/2   	 6/5    	6	 1:59.1 	 31.1	 Trev Henry    	2.50	 M Stoikopou
843	38	4	4	 Rocknroll Band        	    	   4 	 5/6   	 5/4H  	 8/7   	 8/6H  	 7/6    	7	 1:59.2 	 30.3	 N Steward     	7.15	 P Belanger 
844	38	4	6	 Jackson Killean(L)    	    	   6 	 1/1   	 2/1   	 3/2   	 4/2H  	 8/7    	8	 1:59.3 	 31.4	 B Forward     	14.85	 L Privett
845	38	4	8	 Two Face(L)           	    	   8 	 9/11H 	 8/8   	 9@/8  	 9/7   	 9/7H   	9	 1:59.3 	 30.3	 M Whelan      	39.85	 F Soyka
846	39	1	4	 Ms Medusa=            	    	   4 	 2/1   	 2/1H  	 3/2   	 3/1H  	 1/H    	1	 2:01.1 	 29.4	 P Henriksen   	6.65	 P Henriksen
847	39	1	2	 Willie Wonka=         	    	   2 	 3/6   	 3/4   	 2@/1  	 2/1   	 2/H    	2	 2:01.1 	 30  	 A Carroll     	8.70	 R Mcintosh
848	39	1	1	 Hilarious Hero=       	    	   1 	 1/1   	 1/1H  	 1/1   	 1/1   	 3/1Q   	3	 2:01.2 	 30.2	 B Mcclure     	2.25	 T Macdonnel
849	39	1	6	 Moon Dance            	    	   6 	 5/9   	 5/8   	 4@/3  	 4/3   	 4/2H   	4	 2:01.3 	 30  	 T Durand      	2.25	 T Durand
850	39	1	3	 Prince Of Minto       	    	   3 	 4/8   	 4/7   	 5/4   	 5/6   	 5/5H   	5	 2:02.1 	 30.2	 M Baillargeon 	3.35	 B Baillarge
851	39	1	9	 Whos Cheatin Who=     	    	   9 	 6/10H 	 6/11  	 6/5   	 X6/8  	 X6/18H 	6	 2:04.4 	 32.4	 R Shepherd    	18.55	 D Sinclair
852	39	1	7	 Style Spotlight       	    	   7 	 7/12H 	 7/16  	 7/17  	 7/20  	 7/31   	7	 2:07.2 	 33  	 P Walker      	69.55	 P Walker
853	39	1	5	 South Win Bax         	    	   5 	 9/16  	 9/23  	 8@/18 	 8/21  	 8/32   	8	 2:07.3 	 33  	 J Bax         	18.70	 J Bax
854	39	1	8	 Jungle Gem            	    	   8 	 8/14  	 8/19  	 9/20  	 9/24  	 9/37   	9	 2:08.3 	 33.3	 D Fritz       	33.35	 D Fritz
855	39	2	1	 J J Mystic Storm      	    	   1 	 1/1H  	 1/1   	 1/1   	 1/2   	 1/2T   	1	 1:57.2 	 29  	 P Mackenzie   	1.80	 S Charlton
856	39	2	5	 Southwind Jagger      	    	   5 	 2/1H  	 2/1   	 2/1   	 2/2   	 2/2T   	2	 1:58   	 29.2	 T Moore       	6.60	 R Ellis
857	39	2	4	 Catch Twenty Two      	    	   4 	 5/5H  	 3@/1H 	 3@/1H 	 3/3   	 3/7H   	3	 1:58.4 	 30.1	 B Mcclure     	8.40	 S Friend
858	39	2	6	 Hes Got Style         	    	   6 	 6/6H  	 5@/3  	 4@/3  	 4/4   	 4/7H   	4	 1:58.4 	 29.4	 L House       	11.55	 S Mcniven
859	39	2	2	 Jansen Hanover        	    	   2 	 3/3   	 4/2H  	 5/4   	 5/5H  	 5/7T   	5	 1:59   	 29.4	 Br Richardson 	1.35	 E Laybourne
860	39	2	7	 Moot Court            	    	   7 	 7/7H  	 7/5   	 6/5   	 6/7   	 6/16   	6	 2:00.3 	 31.1	 R Holliday    	16.75	 R Mcnair
861	39	2	3	 Spaniard              	    	   3 	 4@/4H 	 6/4H  	 7/12  	 7/19  	 7/31   	7	 2:03.3 	 32.4	 A Carroll     	17.65	 M Etsell
862	39	3	1	 Life Strikes          	    	   1 	 1/3   	 1/1H  	 1/1H  	 1/1H  	 1/T    	1	 2:00.4 	 31.4	 M Baillargeon 	1.25	 M Robitaill
863	39	3	7	 Summajestic           	    	   5 	 4/6   	 4/4H  	 3@/2  	 3/2   	 2/T    	2	 2:01   	 31.3	 S Byron       	5.95	 D Byron
864	39	3	5	 P L Jade=             	    	   3 	 2/3   	 2/1H  	 2/1H  	 2/1H  	 3/1H   	3	 2:01   	 31.4	 M Dupuis      	1.75	 M Dupuis
865	39	3	9	 Shes All Magic        	    	   9 	 3/4   	 3/3   	 4/3H  	 4/3H  	 4/3    	4	 2:01.2 	 31.4	 P Henriksen   	7.45	 P Henriksen
866	39	3	4	 Relevant=             	    	   2 	 5/8   	 5/6   	 5/9H  	 5/9H  	 5/14T  	5	 2:03.4 	 33  	 G Macdonald   	23.75	 L Privett
867	39	3	8	 Tala Seelster         	    	   6 	 X6/12 	 6/12  	 6/11  	 6/11  	 6/15   	6	 2:03.4 	 32.3	 B Mcclure     	20.05	 W Budd
868	39	3	6	 Moxie Begonia         	    	   4X	 7/24  	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Harris      	18.50	 G Oliver
869	39	3	2	 Shezastrikin Loral    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
870	39	3	3	 Daytrooper            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
871	39	4	1	 Marina Desbi          	    	   1 	 1/1   	 1/1   	 1/1   	 1/1   	 1/2    	1	 1:57.3 	 29.3	 L House       	1.55	 M Paulic
872	39	4	2	 Lucky                 	    	   2 	 3/2H  	 3@/1H 	 2@/1  	 2/1   	 2/2    	2	 1:58   	 29.4	 Tra Henry     	5.80	 M Fitzgeral
873	39	4	3	 Twin B Amour          	    	   3 	 2/1   	 2/1   	 3/2   	 3/2   	 3/5    	3	 1:58.3 	 30.1	 J Harris      	3.05	 J Harris
874	39	4	4	 The Prophet Mary(L)   	    	   4 	 4/4   	 4/3   	 4/3H  	 4/3   	 4/5T   	4	 1:58.4 	 30.1	 N Steward     	4.35	 J Watt
875	39	4	8	 Im A Debutant+(L)     	    	   8 	 7@/7  	 7@/5H 	 7@/6  	 7/5H  	 5/6Q   	5	 1:58.4 	 29.3	 T Moore       	14.35	 L Privett
876	39	4	6	 Lotteria              	    	   6 	 8/8   	 8/6H  	 8@/7  	 8/6   	 6/8    	6	 1:59.1 	 29.4	 B Mcclure     	14.30	 G Laurignan
877	39	4	9	 Alibi Terror          	    	   9 	 5/5   	 5@/3H 	 5@/4  	 5/3H  	 7/8    	7	 1:59.1 	 30.2	 R Holliday    	26.40	 T Schlatman
878	39	4	5	 Mach Denali           	    	   5 	 6/6   	 6/5   	 6/5H  	 6/5   	 8/8Q   	8	 1:59.1 	 30.1	 A Carroll     	20.60	 M Etsell
879	39	4	7	 Oh Chute              	    	   7 	 9/9   	 9/7   	 9@/8  	 9/9   	 9/16   	9	 2:00.4 	 31.1	 P Mackenzie   	38.50	 Alan W Fair
880	39	5	2	 Wilma C               	    	   2 	 3/6   	 2/1   	 2@/H  	 2/H   	 1/1    	1	 2:01.3 	 31.1	 K Sheppard    	0.95	 K Sheppard
881	39	5	9	 T C Sno Massive=      	    	   9 	 4/7   	 4@/3  	 3@/1H 	 3/1   	 2/1    	2	 2:01.4 	 31.1	 B Mcclure     	9.75	 Ri Zeron
882	39	5	5	 Clone The Tone        	    	   5 	 2/1   	 3/2   	 4/2H  	 4/2H  	 3/1T   	3	 2:02   	 31.1	 R Shepherd    	44.75	 S Weber
883	39	5	6	 Zorgwijk Queen        	    	   6 	 1/1   	 1/1   	 1/H   	 1/H   	 4/2    	4	 2:02   	 31.3	 T Borth       	17.40	 R Wade
884	39	5	10	 Vimy Ridge Vesta      	    	   1 	 X6/11 	 6/6   	 6/7   	 5/5H  	 5/10   	5	 2:03.3 	 31.4	 L House       	9.20	 S Loughran
885	39	5	7	 Stonebridge Peace     	    	   X7	 7/19  	 7/13  	 7/13  	 7/11  	 6/14H  	6	 2:04.2 	 31.2	 T Moore       	7.80	 J Copley
886	39	5	4	 Beer Before Noon=     	    	   4X	 X8/24 	 8/19  	 8/14  	 8/13  	 7/16H  	7	 2:04.4 	 31.3	 A Carroll     	6.10	 P Lawrence
887	39	5	8	 Don Jarvis            	    	   8 	 5/9   	 5/4H  	 5/5H  	 6/7H  	 8/16T  	8	 2:05   	 33.3	 R Holliday    	47.95	 M Giles
888	39	5	3	 Lovin Karma           	    	   X3	 X9/DIS	 X9/DIS	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 P Mackenzie   	5.40	 C Yates
889	39	5	1	 Citizen Hall          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
890	39	6	2	 Let Em Bounce         	    	   2 	 2/1   	 1/1   	 1/1   	 1/1   	 1/T    	1	 1:57.3 	 29.4	 B Mcclure     	1.90	 W Budd
891	39	6	7	 Heza Workof Art       	    	   7 	 1@/1  	 2/1   	 2/1   	 2/1   	 2/T    	2	 1:57.4 	 29.4	 J Harris      	20.00	 J Watt
892	39	6	5	 Whim Roader           	    	   5 	 7/7   	 5/11  	 3@/4  	 3/2   	 3/3    	3	 1:58.1 	 29.3	 B Forward     	37.20	 L Privett
893	39	6	9	 Sports Vision         	    	   9 	 6/5H  	 4/10  	 4/5   	 4/4   	 4/8T   	4	 1:59.2 	 30.3	 A Carroll     	7.60	 S Friend
894	39	6	8	 Casimir Obama         	    	   8 	 9/10  	 7/13  	 5/6H  	 5/5   	 5/10H  	5	 1:59.3 	 30.3	 L House       	68.30	 R Deacon
895	39	6	6	 Gotameeting           	    	   6 	 8/8H  	 6/12  	 6/8   	 6/7   	 6/12   	6	 2:00   	 30.3	 P Mackenzie   	39.35	 J Loosemore
896	39	6	4	 Sharks Play           	    	   4 	 5/4   	 8/23  	 7/12  	 7/13  	 7/30   	7	 2:03.3 	 33.2	 N Steward     	15.90	 P Shepherd
897	39	6	3	 Jet Er Done(L)        	    	   3 	 3/2   	 3/7   	 8/17  	 8/25  	 8CH/DIS	8	        	     	 T Moore       	35.90	 T Moore
898	39	6	1	 Master Smile          	    	   1 	 4/3   	 9/DIS 	 PULLED	UP     	 DNF    	\N	        	     	 Tra Henry     	2.85	 J Mcginnis
899	40	1	1	 Whosgoingtocatchus    	    	   1 	 1/1   	 1/H   	 1/1   	 1/1   	 1/1Q   	1	 1:59.1 	 30.1	 A Carroll     	1.00	 J Pond
900	40	1	2	 Tymal Wizard=         	    	   2 	 2/1   	 3/1H  	 3/1H  	 2/1   	 2/1Q   	2	 1:59.2 	 30.1	 P Mackenzie   	4.55	 Alan W Fair
901	40	1	6	 Howie=                	    	   6 	 3@/1H 	 2@/H  	 2@/1  	 3/1H  	 3/3H   	3	 1:59.4 	 30.3	 R Shepherd    	5.45	 C Yates
902	40	1	4	 Irish Thunder         	    	   4 	 4/3   	 4/2H  	 4/2H  	 4/2H  	 4/4    	4	 2:00   	 30.3	 L House       	14.00	 P Brickman
903	40	1	5	 Windsun Hugo          	    	   5 	 6/6   	 6@/5  	 5@/3  	 5/3   	 5/4Q   	5	 2:00   	 30.2	 R Holliday    	14.25	 K Di Cenzo
904	40	1	9	 William Star          	    	   9 	 5/5   	 5/4   	 6@/4  	 6/3H  	 6/4Q   	6	 2:00   	 30.1	 J Maguire     	16.20	 J Maguire
905	40	1	7	 Allies Gift           	    	   7 	 8/8   	 8@X/8 	 7@@/4H	 7/4   	 7/4H   	7	 2:00   	 30.1	 B Mcclure     	7.85	 L Ouellette
906	40	1	3	 Hot Stikynsweet       	    	   3 	 7/7   	 7/7H  	 8/6   	 8/5   	 8/5H   	8	 2:00.1 	 30  	 S Young       	36.25	 G Carachi
907	40	1	8	 All Out Henry         	    	   8 	 9/9   	 9/9   	 9@/6H 	 9/6   	 9/5T   	9	 2:00.2 	 30.1	 Do Brown      	20.60	 P Forgie
908	40	2	1	 Rain Cloud Hanover    	    	   1 	 1/1H  	 1/1   	 1/1   	 1/1H  	 1/T    	1	 1:55.1 	 28.3	 P Mackenzie   	3.05	 C Nicol
909	40	2	2	 Tilikum               	    	   2 	 2/1H  	 2/1   	 3/1H  	 2/1H  	 2/T    	2	 1:55.2 	 28.3	 D St Pierre   	1.85	 T Staley
910	40	2	6	 Doo Wee Rusty(L)      	    	   6 	 7/8   	 3@/1H 	 2@/1  	 3/2   	 3/5Q   	3	 1:56.1 	 29.2	 J Harris      	4.15	 J Harris
911	40	2	3	 Miss Brandi K         	    	   3 	 3/3   	 4/3   	 5/3H  	 4/3   	 4/6Q   	4	 1:56.2 	 29.1	 R Shepherd    	8.40	 D Obrien
912	40	2	4	 Fast Flyin Mach       	    	   4 	 4/4H  	 6/5   	 6@/4H 	 6/4H  	 5/8    	5	 1:56.4 	 29.2	 D Fritz       	27.45	 D Fritz
913	40	2	7	 Island Blue           	    	   7 	 8/9H  	 5@/3H 	 4@/2  	 5/3H  	 6/8T   	6	 1:57   	 30  	 L House       	58.95	 S Mcniven
914	40	2	9	 Cards That Count      	    	   9 	 6/7   	 8@/6H 	 8@/7  	 8/8   	 7/14   	7	 1:58   	 30  	 R Holliday    	16.80	 P Core
915	40	2	5	 Emerald Rihanna       	    	   5 	 5/6   	 7/6   	 7/6H  	 7/7   	 8/16   	8	 1:58.2 	 30.3	 N Steward     	3.95	 C Schneider
916	40	2	8	 Winning Matrimony     	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
917	40	3	3	 Spy Flex=             	    	   3 	 1/1   	 1/1   	 1/H   	 1/1   	 1/NK   	1	 2:01.1 	 30.3	 G Rooney      	4.15	 F Drouillar
918	40	3	4	 Don Luigi             	    	   4 	 2/1   	 2/1   	 3/1H  	 2/1   	 2/NK   	2	 2:01.1 	 30.2	 J Harris      	6.70	 R Griffiths
919	40	3	1	 Toss It Back          	    	   1 	 4/4H  	 4/2H  	 4/3   	 4/3   	 3/1    	3	 2:01.2 	 30.1	 P Mackenzie   	4.65	 P Hunt
920	40	3	7	 Talbotcreek Suzie=    	    	   7 	 3/2   	 3@/1H 	 2@/H  	 3/1H  	 4/5    	4	 2:02.1 	 31.3	 G Mcknight    	5.85	 G Mcknight
921	40	3	6	 Nashville             	    	   6 	 5/6H  	 5@/3  	 5@/3H 	 5/3H  	 5/7Q   	5	 2:02.3 	 31.2	 R Holliday    	3.60	 N Elliott
922	40	3	8	 Dead Red Hitter=      	    	   8 	 7/9H  	 7/6   	 7/5H  	 6/5   	 6/7T   	6	 2:02.4 	 31.1	 A Carroll     	71.55	 M Giles
923	40	3	9	 Tiz                   	    	   9 	 6/8   	 6@/5  	 6@/4H 	 7/5H  	 7/8    	7	 2:02.4 	 31.2	 B Forward     	18.25	 J Pedden
924	40	3	5	 Holiday Bro           	    	   5I	 8/10H 	 8/8   	 8/6H  	 8/7   	 8/10T  	8	 2:03.2 	 31.3	 T Moore       	5.60	 I Gallant
925	40	3	10	 Leroys Dream=         	    	   2X	 9/12  	 9/9   	 9/8H  	 9/11  	 9/20   	9	 2:05.1 	 33  	 A Macdonald   	6.95	 A Macdonald
926	40	3	2	 La Bella Rosa         	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
927	40	4	4	 Lady Caterina=        	    	   4 	 2/1   	 2/1H  	 2/1   	 3/1H  	 1/NS   	1	 2:00.1 	 31  	 N Steward     	6.45	 Alan D Fair
928	40	4	1	 Chewey=               	    	   1 	 1@/1  	 1/1H  	 1/1   	 1/H   	 2/NS   	2	 2:00.1 	 31.1	 B Mcclure     	1.30	 E Galinski
929	40	4	9	 Noble Power           	    	   9 	 3/2   	 3@/2  	 3@/1H 	 2/H   	 3/1    	3	 2:00.2 	 31.1	 P Mackenzie   	10.10	 S Kerwood
930	40	4	6	 Excellence            	    	   6 	 4/3   	 5/4   	 4/2   	 4/3   	 4/1T   	4	 2:00.3 	 31.1	 J Harris      	8.00	 I Downey
931	40	4	2	 Increditable(L)       	    	   2 	 5/4   	 4@/3  	 5@/3  	 5/3H  	 5/2T   	5	 2:00.4 	 31.1	 R Shepherd    	3.85	 J Dupont
932	40	4	7	 Incredable Frank(L)   	    	   7 	 8/7H  	 8/7H  	 8/7   	 7/6   	 6/3H   	6	 2:00.4 	 30.2	 A Carroll     	7.35	 R Moreau
933	40	4	10	 Mr Putter             	    	   5 	 7/6   	 7/6H  	 6/5   	 6/4H  	 7/4H   	7	 2:01   	 31  	 R Holliday    	18.85	 T Genoe
934	40	4	3	 Lima Playtime         	    	   3 	 6/5   	 6@/5  	 7/6   	 8/8   	 8/6T   	8	 2:01.3 	 31.2	 S Barrington  	24.40	 Ri Zeron
935	40	4	8	 Nomad=(L)             	    	   8 	 9/9   	 9@/8  	 9/8H  	 9/9   	 9/9    	9	 2:02   	 31.2	 Do Brown      	34.10	 L Jonasson
936	40	4	5	 Lady Dynamite=(L)     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
937	45	1	6	 What A Promise        	    	   6 	 2/2   	 I1/3H 	 1/13  	 1/3   	 2P1/1H 	2	 2:14.2 	 35.3	 R Remillard   	4.45	 B Mcnaughto
938	45	1	5	 Heartland Spark       	    	   5 	 5@/11 	 I4/5  	 3/13Q 	 3/12  	 3P2/18H	3	 2:17.4 	 36.2	 M Fillion     	0.95	 M Fillion
939	45	1	4	 Trishas Fancy         	    	   4 	 3/6   	 IX6/15	 5/20  	 4/19  	 4P3/24 	4	 2:19   	 36.1	 K Rogers      	4.45	 K Rogers
940	45	1	2	 Margies Candy         	    	   2 	 4/10  	 I3/3T 	 4/18  	 5/DIS 	 5P4/DIS	5	        	     	 R Rey         	\N	 R Rey
941	45	1	7	 Dont Chud Me          	    	   7 	 6/12  	 IX5/8H	 6/25  	 6/DIS 	 6P5/DIS	6	        	     	 C Manning     	9.95	 C Manning
942	45	1	3	 Luvn The Life         	    	   3 	 1/2   	 X2@/3H	 2@/13 	 2/3   	 1P6/1H 	1	 2:14.1 	 32.4	 D Rey         	0.95	 D Rey
943	45	1	1	 Cordees Whitesocks    	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
944	45	2	3	 Gold Star Sonata      	    	   3 	 1/1H  	 1/Q   	 2/H   	 2/2   	 1/NS   	1	 2:04.1 	 32  	 D Howlett     	3.45	 T Williams
945	45	2	4	 Wild Chic             	    	   4 	 2/1H  	 2@/Q  	 1@/H  	 1/2   	 2/NS   	2	 2:04.1 	 32  	 R Remillard   	1.20	 R Remillard
946	45	2	2	 Smoky Moon            	    	   2 	 4/5   	 3@/4H 	 3/6   	 3/13  	 3/13   	3	 2:06.4 	 33.2	 M Fillion     	1.40	 K Hildebran
947	45	2	5	 Gottaluckydeal+       	    	   5 	 X6/14 	 6/9H  	 6@/11 	 4/18  	 4/21   	4	 2:08.2 	 34  	 C Manning     	\N	 C Manning
948	45	2	1	 Come On Kathryn       	    	   1 	 3/3   	 4/4T  	 4/7H  	 5/19  	 5/25   	5	 2:09.1 	 35.3	 T Grundy      	5.65	 C Manning
949	45	2	6	 Freedom Forever       	    	   6 	 5/7   	 5/7   	 5/10  	 6/37  	 6/39   	6	 2:12   	 37.4	 M Rey         	3.45	 M Rey Clark
950	45	3	1	 Good Chemistry        	    	   1 	 2/1H  	 2/2H  	 2/2   	 3/1H  	 1/1    	1	 2:09.2 	 32  	 D Howlett     	2.50	 T Williams
951	45	3	4	 Diggin A Trench       	    	   4 	 3/3   	 3/4H  	 3@/3  	 1/H   	 2/1    	2	 2:09.3 	 32  	 M Rey         	3.10	 R Rey
952	45	3	5	 Home Matters          	    	   5 	 1/1H  	 1/2H  	 1/2   	 2/H   	 3/3    	3	 2:10   	 33  	 D Rey         	3.10	 R Rey
953	45	3	3	 Redonkulous           	    	   3 	 4/4H  	 4/6H  	 4/5   	 4/11  	 4/12   	4	 2:11.4 	 33.4	 R Rey         	0.45	 R Rey
954	45	3	2	 Mixed Blessings+      	    	   SC	TCHED -	VET(LAM	)      	       	        	\N	        	     	               	\N	 
955	46	1	5	 Eastcoast Lizzy       	    	   5 	 4/5   	 4/5Q  	 4/4   	 3/H   	 1/Q    	1	 2:04.1 	 28.4	 S Macdonald   	2.45	 S Macdonald
956	46	1	3	 Rez Rampage           	    	   3 	 2/1H  	 2/1H  	 2@/1  	 2/Q   	 2/Q    	2	 2:04.1 	 29.2	 A Macquarrie  	0.60	 L Macisaac
957	46	1	2	 Our Ryall Flush       	    	   2 	 1/1H  	 1/1H  	 1/1   	 1/Q   	 3/1Q   	3	 2:04.2 	 29.4	 K Bailey      	10.60	 K Bailey
958	46	1	4	 Cheyenne Nixon        	    	   4 	 3/3Q  	 3/3Q  	 3@/2  	 4/1T  	 4/2H   	4	 2:04.3 	 29.3	 T Gillis      	10.60	 T Gillis
959	46	1	1	 Tymal Torrance        	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
960	46	2	4	 Woodmere Terror       	    	   4 	 3@/2  	 3/2H  	 4/3   	 2/Q   	 1/NS   	1	 2:04.1 	 31  	 A Maclean     	4.85	 A Maclean
961	46	2	2	 B Catastic            	    	   2 	 7/6   	 7/8H  	 6@@/3T	 3/T   	 2/NS   	2	 2:04.1 	 30.4	 R Gillis      	1.55	 T Maclean
962	46	2	1	 Camco Tyler           	    	   1 	 4/3   	 5/4Q  	 5@/3Q 	 5/1T  	 3/1T   	3	 2:04.3 	 31.2	 C Fraser      	6.15	 F Fraser
963	46	2	5	 Warrawee Raven        	    	   5 	 5@/3Q 	 2/1H  	 2/1H  	 4/1H  	 4/2H   	4	 2:04.3 	 31.4	 R Campbell    	1.90	 J Copley
964	46	2	6	 A Bs Future           	    	   6 	 1/1H  	 1/1H  	 1/1H  	 1/Q   	 5/3T   	5	 2:05   	 32.2	 A Mac Donald  	5.40	 B Macdonald
965	46	2	3	 Aint Shesoshy         	    	   3 	 2/1H  	 4/3Q  	 3@/1H 	 6/6   	 6/10T  	6	 2:06.2 	 33.3	 K Passerini   	15.10	 K Passerini
966	46	2	8	 J Gs Waylon           	    	   8 	 6/4T  	 6/7   	 7/7   	 7/10  	 7/16T  	7	 2:07.3 	 33.3	 J Kennedy     	8.20	 T Maclean
967	46	2	7	 Redwood Origional     	    	   SC	TCHED -	JUDGES 	       	       	        	\N	        	     	               	\N	 
968	46	3	5	 Liams Dynesty         	    	   5 	 1/1H  	 1/1H  	 1/1H  	 1/2   	 1/1    	1	 2:02   	 30.4	 C Kelly       	3.85	 C Ryan
969	46	3	3	 Im Indigo             	    	   3 	 2/1H  	 3/1T  	 3/1T  	 2/2   	 2/1    	2	 2:02.1 	 30.3	 J Poirier     	30.80	 J Poirier
970	46	3	1	 Business Time         	    	   1 	 3/2H  	 4/3Q  	 4/3   	 3/4   	 3/3    	3	 2:02.3 	 30.4	 J Macdonald   	6.95	 W Macdonald
971	46	3	6	 Scootin Mcardle       	    	   6 	 4@/3  	 2@/1H 	 2@/1H 	 4/5   	 4/4    	4	 2:02.4 	 31.2	 K Passerini   	14.90	 K Passerini
972	46	3	8	 Valid Appeal          	    	   8 	 8/7H  	 6@/5  	 6@/4Q 	 5/5H  	 5/5T   	5	 2:03.1 	 31.1	 S Miller      	3.70	 K Macdonald
973	46	3	7	 Take The Chance       	    	   7 	 6/5H  	 7/5H  	 7/4H  	 6/6H  	 6/6    	6	 2:03.1 	 31.1	 R Campbell    	4.75	 E Campbell
974	46	3	4	 Dans Ideal            	    	   4 	 5/4H  	 5@/3Q 	 5@/3Q 	 7/7H  	 7/6H   	7	 2:03.1 	 31.2	 A Macquarrie  	0.80	 A Beaton
975	46	3	2	 Miss All Fun          	    	   2 	 7/6H  	 8/6T  	 8/5H  	 8/8Q  	 8/7T   	8	 2:03.3 	 31.2	 R Gillis      	6.95	 L Beaton
976	46	4	5	 Likeathunderbolt      	    	   5 	 6/4H  	 6/4Q  	 3@/1Q 	 2/Q   	 1/Q    	1	 2:01.3 	 30  	 C Kelly       	3.15	 J Mac Donal
977	46	4	3	 Iona Katie            	    	   3 	 4/2T  	 4/2T  	 1@/T  	 1/Q   	 2/Q    	2	 2:01.3 	 30.1	 J Poirier     	3.65	 J Poirier
978	46	4	4	 Allamerican Baller    	    	   4 	 5@/3H 	 2@/1Q 	 4/2   	 3/Q   	 3/1H   	3	 2:01.4 	 30  	 R Campbell    	3.65	 E Beaton
979	46	4	1	 Rachel Alesandra      	    	   1 	 3/1H  	 5/3Q  	 5/3T  	 4/6   	 4/6H   	4	 2:02.4 	 30.3	 K Bailey      	4.30	 K Bailey
980	46	4	6	 Overcard              	    	   6 	 2@/1  	 1/1Q  	 2/T   	 5/9   	 5/10Q  	5	 2:03.3 	 32  	 K Passerini   	2.65	 J Poirier
981	46	4	2	 Spectacular Future    	    	   2 	 1/1   	 3/1T  	 6/4T  	 6/22  	 6/24H  	6	 2:06.2 	 34  	 L Hanscombe   	3.15	 G Mac Lean
982	46	5	3	 Oppies Lifes Line     	    	   3 	 1/1H  	 1/1   	 1/H   	 1/1   	 1/HD   	1	 2:02.2 	 30.4	 J Poirier     	2.50	 J Poirier
983	46	5	2	 Eastcoast Cruiser     	    	   2 	 3/2H  	 2@/1  	 2@/H  	 2/1   	 2/HD   	2	 2:02.2 	 30.4	 R Gillis      	1.90	 T Sutherlan
984	46	5	1	 Orillia Santina       	    	   1 	 4/3H  	 5/3H  	 4/2   	 3/2   	 3/2    	3	 2:02.4 	 30.4	 K Passerini   	10.65	 K Passerini
985	46	5	4	 Remember The Night    	    	   4 	 2/1H  	 3/1T  	 3@/2  	 4/3H  	 4/4Q   	4	 2:03.1 	 31.1	 A Macquarrie  	3.90	 A Macquarri
986	46	5	5	 Ramadawn              	    	   5 	 5@/4  	 4@/2H 	 6@/3  	 5/3H  	 5/4Q   	5	 2:03.1 	 31  	 C Fraser      	4.40	 F Fraser
987	46	5	7	 Grayland Astrid       	    	   7 	 6/4H  	 7/5Q  	 7/3H  	 6/4   	 6/4H   	6	 2:03.1 	 31  	 J Macdonald   	6.75	 S Harper Jr
988	46	5	6	 Locky                 	    	   6 	 7/5H  	 6@/4  	 5@@/2T	 7/10  	 7/11   	7	 2:04.3 	 32.2	 J Kennedy     	6.75	 L Macisaac
989	46	6	1	 Western Bandit        	    	   1 	 1/1H  	 1/1H  	 1/4   	 1/8   	 1/9    	1	 1:59.1 	 29.2	 R Campbell    	1.70	 R Mullins
990	46	6	5	 D E Harkness          	    	   5 	 2/1H  	 3/1H  	 2/4   	 2/8   	 2/9    	2	 2:01   	 30.2	 A Mac Neil    	6.85	 A Mac Neil
991	46	6	6	 You Gotta See This    	    	   6 	 5/6H  	 4@/3Q 	 4@@/4Q	 3/8Q  	 3/9    	3	 2:01   	 30.2	 C Kelly       	4.15	 S Harper Jr
992	46	6	2	 Nephin                	    	   2 	 X4@/6 	 2@/1H 	 3@/4Q 	 4/10  	 4/10   	4	 2:01.1 	 30.3	 J Macdonald   	3.45	 W Macdonald
993	46	6	4	 Twisted Frisco        	    	   4 	 3/5   	 5/4Q  	 5/5H  	 5/10Q 	 5/11   	5	 2:01.2 	 30.3	 S Macdonald   	2.80	 S Macdonald
994	46	6	3	 Benny Rabbit          	    	   3 	 6/7H  	 6/5   	 6@/6H 	 6/15  	 6/16T  	6	 2:02.3 	 31.3	 R Gillis      	4.15	 E Campbell
995	47	1	4	 Surrealist            	    	   4 	 4/4H  	 4@/4  	 1/H   	 1/8   	 1/8H   	1	 1:55.3 	 29  	 C Kelly       	0.95	 R Mullins
996	47	1	3	 Schooner              	    	   3 	 1/1H  	 1/1T  	 2/H   	 2/8   	 2/8H   	2	 1:57.1 	 30.3	 A Macquarrie  	2.20	 A Beaton
997	47	1	5	 Rambling Gambler      	    	   5 	 5/5H  	 5/6   	 4/3   	 3/8H  	 3/9    	3	 1:57.2 	 30.1	 R Gillis      	4.20	 D Beaton
998	47	1	1	 Grins Little Flirt    	    	   1 	 2/1H  	 2/1T  	 3/2H  	 4/9   	 4/9H   	4	 1:57.2 	 30.2	 R Campbell    	2.30	 R Mac Leod
999	47	1	2	 Kennairn Fame         	    	   2 	 3/3   	 3/4   	 5/10  	 5/15  	 5/16H  	5	 1:58.4 	 30.1	 J Poirier     	17.30	 D Mac Lella
1000	47	2	4	 Danny William         	    	   4 	 1/1H  	 1/1H  	 1/1H  	 1/1   	 1/H    	1	 1:59.4 	 28.4	 A Mac Neil    	1.10	 A Mac Neil
1001	47	2	3	 Tiger Town            	    	   3 	 4/4   	 4@/3T 	 4@@/2 	 2/1   	 2/H    	2	 1:59.4 	 28.2	 A Macdonell   	3.85	 M Maceachen
1002	47	2	1	 My Tie Wind           	    	   1 	 2/1H  	 2/1H  	 3/1H  	 3/4   	 3/4T   	3	 2:00.4 	 29.3	 J Kennedy     	7.90	 D Kennedy
1003	47	2	2	 Macnamarra            	    	   2 	 3/2H  	 3@/2  	 2@/1H 	 4/5   	 4/5    	4	 2:00.4 	 29.3	 J Mac Dougall 	8.15	 R Smith
1004	47	2	5	 Boswell Hanover       	    	   5 	 5/5H  	 5/5   	 5/3H  	 5/6   	 5/5T   	5	 2:01   	 29.2	 C Kelly       	3.45	 J Mac Donal
1005	47	2	6	 Imbadimnationwide     	    	   6 	 6/6H  	 6@/6  	 6/4T  	 6/7   	 6/8    	6	 2:01.2 	 29.2	 R Campbell    	4.15	 R Copley
1006	48	1	2	 Great Luck            	    	   2 	 2/2H  	 2/2T  	 2/2H  	 2/1   	 1/Q    	1	 2:06.1 	 30.3	 R Gillis      	\N	 J Murphy
1007	48	1	1	 P H Showboat          	    	   1 	 1/2H  	 1/2T  	 1/2H  	 1/1   	 2/Q    	2	 2:06.1 	 31  	 A Macdonell   	\N	 A Macdonell
1008	49	1	1	 Bay Win               	    	   1 	 1/NR  	 1/NR  	 1/NR  	 1/NR  	 1/NR   	1	 2:07.3 	 31.1	 R Gillis      	\N	 D Beaton
1009	52	1	1	 Jolts Prayer          	    	   1 	 3/2Q  	 4/3T  	 5@@/2Q	 2/H   	 1/H    	1	 1:54.3 	 29.3	 J Jamieson    	17.30	 D Lamy
1010	52	1	2	 Tarahumara            	    	   2 	 2@/1Q 	 1/H   	 1/H   	 1/H   	 2/H    	2	 1:54.3 	 30  	 S Filion      	0.80	 R Fellows
1011	52	1	3	 Sophie Blu            	    	   3 	 5/5   	 6/6Q  	 6/3T  	 6/2H  	 3/T    	3	 1:54.4 	 29.2	 Ph Hudon      	39.10	 G Laurignan
1012	52	1	4	 Big Tsunami           	    	   4 	 6/7Q  	 5@/5Q 	 3@@/T 	 3/T   	 4/2    	4	 1:55   	 30.1	 J Moiseyev    	19.25	 R Montgomer
1013	52	1	9	 Lissoy                	    	   9 	 9/14H 	 9/12T 	 9/5H  	 7/3Q  	 5/2    	5	 1:55   	 29.2	 D Mcnair      	49.40	 R Fellows
1014	52	1	7	 Hex                   	    	   7 	 4@/2T 	 2@/H  	 2/H   	 4/1Q  	 6/2H   	6	 1:55   	 30.2	 Ja Macdonald  	2.75	 D Nixon
1015	52	1	8	 Business As Usual(L)  	    	   8 	 8/12  	 8/9T  	 8@@/5H	 8/3H  	 7/4Q   	7	 1:55.2 	 29.4	 M Baillargeon 	13.15	 M Rogers
1016	52	1	6	 Woodmere Articblue    	    	   6 	 1/1Q  	 3/1T  	 4/1H  	 5/2Q  	 8/7H   	8	 1:56   	 31.1	 Trev Henry    	6.75	 J Belliveau
1017	52	1	5	 Squirt                	    	   5 	 7/9Q  	 7@/7H 	 7@/4H 	 9/4H  	 9/8Q   	9	 1:56.1 	 30.4	 P Macdonell   	24.55	 H Dinning
1018	52	2	7	 On A Sunny Day        	    	   7 	 1@/H  	 1/1H  	 1/Q   	 1/1   	 1/1H   	1	 1:57.2 	 29.1	 S Filion      	0.95	 L Blais
1019	52	2	5	 Literally             	    	   5 	 5/10Q 	 5@/8Q 	 2@/Q  	 2/1   	 2/1H   	2	 1:57.3 	 29.2	 R Jones       	1.55	 R Jones
1020	52	2	6	 Tropicana As          	    	   6 	 2/H   	 2/1H  	 3/2   	 3/3Q  	 3/3Q   	3	 1:58   	 29.2	 J Jamieson    	9.10	 A Lorentzon
1021	52	2	1	 Holiday Promise       	    	   1 	 7/13Q 	 6@/10H	 4@/3H 	 4/5T  	 4/4T   	4	 1:58.2 	 29.3	 J Moiseyev    	19.75	 P Reid
1022	52	2	4	 Magic Maddy           	    	   4 	 4/8Q  	 4/6T  	 6@/6H 	 5/9T  	 5/6Q   	5	 1:58.3 	 29.1	 Ja Macdonald  	34.35	 M Steacy
1023	52	2	2	 Janderson             	    	   2 	 X6X/10	 7/25T 	 7/21T 	 7/22H 	 6/19   	6	 2:01.1 	 28.3	 P Macdonell   	6.60	 M Keeling
1024	52	2	3	 Paradise Image=       	    	   3 	 3/3H  	 3/4H  	 5/6   	 6/12H 	 7/20   	7	 2:01.2 	 32  	 M Johnson     	133.45	 M Johnson
1025	52	3	2	 Winter Sweet Frost    	    	   2 	 2/1T  	 1/3T  	 1/2   	 1/1H  	 1/2H   	1	 1:58.2 	 29.2	 D Mcnair      	0.85	 P Reid
1026	52	3	1	 Gravitator            	    	   1 	 3/4   	 2/3T  	 2/2   	 2/1H  	 2/2H   	2	 1:58.4 	 29.2	 S Filion      	3.45	 L Blais
1027	52	3	5	 Expose Yourself       	    	   5 	 4/5T  	 4/6Q  	 4/4   	 3/3Q  	 3/3Q   	3	 1:59   	 29.1	 W Henry       	68.55	 W Henry
1028	52	3	6	 Stormont Royalty      	    	   6 	 5/7Q  	 5/9H  	 3@/3T 	 4/3H  	 4/3T   	4	 1:59.1 	 29.2	 Ri Zeron      	5.95	 K Benn
1029	52	3	4	 Royal Witch           	    	   4X	 X7/35T	 6/33T 	 5/22T 	 5/20H 	 5/20   	5	 2:02.2 	 28.4	 M Baillargeon 	4.05	 B Baillarge
1030	52	3	3	 Mrstery Bear=         	    	   3X	 X6/26H	 7X/36 	 6/DIS 	 6X/DIS	 6/DIS  	6	        	     	 J Jamieson    	17.40	 D Menary
1031	52	3	7	 Mass Psychology       	    	   7 	 1/1T  	 X3X/5H	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 C Christoforou	27.40	 J Macmillan
1032	52	4	8	 Talbot Chanel         	    	   8 	 8/14Q 	 7@/12Q	 5/6   	 5/6H  	 1/NK   	1	 1:57.1 	 27.3	 S Filion      	5.25	 L Blais
1033	52	4	3	 Maching Me Zilly      	    	   3 	 4/5H  	 4/6   	 4@/5  	 3/4Q  	 2/NK   	2	 1:57.1 	 27.4	 Ph Hudon      	13.80	 M Brethour
1034	52	4	7	 Amulet Seelster       	    	   7 	 1@/T  	 1/2   	 1/1T  	 1/2Q  	 3/H    	3	 1:57.1 	 28.4	 D Mcnair      	1.20	 R Mcnair
1035	52	4	5	 Fashion Writer        	    	   5 	 2/T   	 2/2   	 2/1T  	 2/2Q  	 4/1H   	4	 1:57.2 	 28.3	 J Jamieson    	10.25	 S Gillard
1036	52	4	4	 Lotus Seelster        	    	   4 	 3/2T  	 3/4   	 3@/3T 	 4/5   	 5/1T   	5	 1:57.3 	 28.2	 Trev Henry    	3.60	 S Mceneny
1037	52	4	1	 Windsong Natalie      	    	   1 	 5/7   	 5/8   	 6/7Q  	 6/7H  	 6/3    	6	 1:57.4 	 28  	 Ra Waples     	49.55	 W Robinson
1038	52	4	6	 All Is Well           	    	   6 	 7/12  	 8/12H 	 7@/8Q 	 7/8H  	 7/3H   	7	 1:57.4 	 27.4	 P Macdonell   	15.15	 R Mcintosh
1039	52	4	9	 Miss Mittzie Bee      	    	   9 	 9/16H 	 9@/15H	 9/11T 	 9/11T 	 8/4T   	8	 1:58.1 	 27.2	 C Christoforou	84.05	 S Arsenault
1040	52	4	2	 Show Me Some Magic    	    	   2 	 6/9Q  	 6/10H 	 8/9Q  	 8/10H 	 9/5    	9	 1:58.1 	 28  	 Ja Macdonald  	6.45	 T Gillespie
1041	52	5	1	 Secretcode Hanover=(L)	)   	   1 	 6/7T  	 5@/6T 	 4@/2  	 2/H   	 1/1    	1	 1:55.4 	 28.3	 M Vanderkemp  	54.45	 M Vanderkem
1042	52	5	6	 Pennies From Above    	    	   5 	 7/9T  	 7@/8T 	 5@/3H 	 3/2Q  	 2/1    	2	 1:56   	 28.3	 R Jones       	2.05	 R Jones
1043	52	5	4	 Mission Man           	    	   4 	 5/6   	 3@/4T 	 2@/NK 	 1/H   	 3/3    	3	 1:56.2 	 29.3	 Ph Hudon      	9.50	 R Bax
1044	52	5	10	 Windsong Luxury       	    	   9 	 1@/Q  	 2/3   	 3/1T  	 5/2H  	 4/4Q   	4	 1:56.3 	 29.2	 J Jamieson    	13.95	 C Auciello
1045	52	5	3	 Bow Ties N Bourbon=   	    	   3 	 3/2   	 1/3   	 1/NK  	 4/2Q  	 5/7    	5	 1:57.1 	 30.2	 M Saftic      	11.75	 M Barrieau
1046	52	5	9	 Hills Angel           	    	   8 	 2/Q   	 4/5   	 6/3T  	 6/4T  	 6/8H   	6	 1:57.2 	 29.4	 P Macdonell   	5.30	 J Bax
1047	52	5	2	 Franniegetyourgun=(L) 	    	   2 	 4/4   	 6/7Q  	 7/6T  	 7/7H  	 7/12T  	7	 1:58.2 	 30.1	 C Christoforou	73.40	 H Holland
1048	52	5	7	 Frankly Speaking(L)   	    	   6 	 8/11T 	 8/10T 	 8/8H  	 8/10H 	 8/15   	8	 1:58.4 	 30.2	 S Filion      	29.55	 R Moreau
1049	52	5	8	 Unicum Bi=            	    	   7X	 X9/DIS	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 Ja Macdonald  	1.40	 P Henriksen
1050	52	5	5	 Asterix=              	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1051	52	6	6	 Rose Run Speedster=   	    	   5 	 3/4   	 1/1T  	 1/2   	 1/3Q  	 1/H    	1	 1:58.4 	 28.3	 Ja Macdonald  	0.55	 A Macdonald
1052	52	6	2	 Northern Major=       	    	   2 	 2/2Q  	 3/3T  	 3/3T  	 3/4   	 2/H    	2	 1:58.4 	 27.4	 J Moiseyev    	11.85	 R Fellows
1053	52	6	1	 Jake=                 	    	   1 	 1/2Q  	 2/1T  	 2/2   	 2/3Q  	 3/2T   	3	 1:59.2 	 28.4	 S Filion      	1.95	 L Blais
1054	52	6	8	 Soho Hanover=         	    	   7 	 5/8T  	 5/8Q  	 5/8   	 4/10Q 	 4/8T   	4	 2:00.3 	 28.4	 D Mcnair      	10.30	 R Mcnair
1055	52	6	5	 Dressed To Impress    	    	   4 	 4/6Q  	 4/6   	 4X/6Q 	 X5/13T	 5/11H  	5	 2:01   	 29.3	 R Jones       	28.10	 R Jones
1056	52	6	7	 Magic Night           	    	   6X	 X6/28Q	 6/20H 	 6/13T 	 6/18  	 6/19   	6	 2:02.3 	 29.3	 W Henry       	80.10	 W Henry
1057	52	6	3	 Blurred               	    	   3X	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 P Macdonell   	43.15	 J Bax
1058	52	6	4	 Lucys Man             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1059	53	1	3	 The Wayfaring Man(L)  	    	   3 	 1@/1H 	 1/2   	 1/1H  	 1/2   	 1/1T   	1	 1:51.2 	 28.1	 M Saftic      	0.20	 N Comegna
1060	53	1	7	 They Call Me Gordy    	    	   7 	 2/1H  	 2/2   	 2/1H  	 2/2   	 2/1T   	2	 1:51.4 	 28.2	 D Mcnair      	56.15	 J Wilson
1061	53	1	2	 Blissfull Years       	    	   2 	 4/5H  	 4/6Q  	 5/5T  	 3/6   	 3/2T   	3	 1:52   	 27.3	 S Filion      	9.95	 R Adams
1062	53	1	6	 Waltzking Hanover(L)  	    	   6 	 5/7Q  	 6/8H  	 7/7H  	 6/8   	 4/3    	4	 1:52   	 27.2	 J Jamieson    	16.90	 C Mcguire
1063	53	1	4	 Curator               	    	   4 	 7/11  	 7@/9Q 	 6@/6  	 5/6T  	 5/5    	5	 1:52.2 	 28  	 Trev Henry    	7.25	 J Copley
1064	53	1	8	 Sir Machalot          	    	   8 	 8/14Q 	 8@/11T	 8@/8Q 	 7/9   	 6/6T   	6	 1:52.4 	 28  	 C Christoforou	31.90	 L Macarthur
1065	53	1	1	 Statesman N(L)        	    	   1 	 3/3H  	 3/4Q  	 3/3T  	 4/6   	 7/7    	7	 1:52.4 	 28.4	 Do Brown      	32.05	 Do Brown
1066	53	1	9	 Tomitta Bayama        	    	   9 	 9/16H 	 9/13  	 9/9T  	 10/10T	 8/9T   	8	 1:53.2 	 28.1	 Ja Macdonald  	75.25	 T Hamm
1067	53	1	10	 Jimmys Secret(L)      	    	   10	 10/18 	 10@/14	 10@/10	 9/10H 	 9/10Q  	9	 1:53.2 	 28.1	 Ph Hudon      	98.45	 W Preszcato
1068	53	1	5	 Good Friday Three     	    	   5 	 6/9   	 5@/6T 	 4@/4H 	 8/9T  	 10/15  	10	 1:54.2 	 30.2	 Ra Waples     	29.90	 W Robinson
1069	53	2	5	 Magic Presto=         	    	   5 	 4/6T  	 3/3H  	 2/1T  	 2/1T  	 1/1    	1	 1:57.2 	 27.3	 Trev Henry    	5.35	 R Norman
1070	53	2	3	 Sweet Of My Heart     	    	   3 	 1/4T  	 1/1T  	 1/1T  	 1/1T  	 2BE/1  	2	 1:57.3 	 28.1	 C Christoforou	0.75	 P Reid
1071	53	2	6	 Lady Justice          	    	   6 	 2@/4T 	 2/1T  	 3/3T  	 3/5H  	 3/8Q   	3	 1:59   	 28.4	 W Henry       	10.55	 W Henry
1072	53	2	7	 Majestic Kat          	    	   7 	 5/9H  	 4/5H  	 4@/4H 	 4/5T  	 4/9Q   	4	 1:59.1 	 29  	 Ja Macdonald  	30.50	 M Steacy
1073	53	2	4	 Hudsons Ya Ya         	    	   4 	 3X/5Q 	 5/9Q  	 X5/13H	 5/24  	 5/31   	5	 2:03.3 	 31.3	 S Byron       	68.30	 J Bax
1074	53	2	1	 Dixies Dream Girl     	    	   1 	 X6/13Q	 6/13  	 X6/19Q	 6/DIS 	 6/DIS  	6	        	     	 Ri Zeron      	2.85	 T Osullivan
1075	53	2	2	 Ladydabra             	    	   2X	 X7/DIS	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Jamieson    	10.35	 H Okusko Jr
1076	53	3	1	 Big Place             	    	   1 	 4/3Q  	 1@/1T 	 1/2H  	 1/5T  	 1/3H   	1	 1:53.2 	 28.3	 D Mcnair      	2.40	 R Mcnair
1077	53	3	7	 Bugger Jerry          	    	   7 	 1/1H  	 3/3H  	 4/4Q  	 3/6Q  	 2/3H   	2	 1:54   	 28.2	 Ja Macdonald  	4.45	 C Auciello
1078	53	3	3	 Carolina Hurricane    	    	   3 	 5/5H  	 4@/4  	 3@/4  	 4/6H  	 3/4    	3	 1:54.1 	 28.3	 Ri Zeron      	0.90	 R Adams
1079	53	3	6	 Four Card Major       	    	   6 	 8/11H 	 8/12  	 7@@/7 	 5/7T  	 4/6Q   	4	 1:54.3 	 28.2	 Ra Waples     	15.60	 Corey Johns
1080	53	3	8	 The Loan Ranger       	    	   8 	 3@/2H 	 2/1T  	 2/2H  	 2/5T  	 5/6T   	5	 1:54.4 	 29.3	 Trev Henry    	38.15	 P Core
1081	53	3	4	 Century Churchill     	    	   4 	 7/9T  	 6@/8H 	 5@/5T 	 7/9Q  	 6/9T   	6	 1:55.2 	 29.2	 J Hudon Jr    	26.25	 J Hudon Jr
1082	53	3	5	 Give Em Back          	    	   5 	 2/1H  	 5/5T  	 6/6   	 6/9   	 7/10Q  	7	 1:55.2 	 29.2	 Ph Hudon      	12.00	 B Sinclair
1083	53	3	2	 Crusing Charlie       	    	   2 	 6/7T  	 7/9   	 8/8H  	 8/12T 	 8/15   	8	 1:56.2 	 30  	 C Christoforou	67.05	 G Kingshott
1084	53	4	1	 Tom Hill              	    	   1 	 5/8Q  	 5@/7Q 	 4@/4T 	 2/1Q  	 1/3    	1	 1:51.2 	 26.2	 Ra Waples     	3.25	 T Alagna
1085	53	4	5	 Ok Iceman(L)          	    	   5 	 2/1T  	 2/2   	 3/1T  	 4/1H  	 2/3    	2	 1:52   	 27.3	 J Jamieson    	3.80	 M Steacy
1086	53	4	9	 Daylight Rush         	    	   8 	 1/1T  	 1/2   	 1/1   	 1/1Q  	 3/3T   	3	 1:52.1 	 28.1	 D Mcnair      	7.80	 B Macintosh
1087	53	4	2	 Some Gold             	    	   2 	 4/6   	 4@/5Q 	 2@/1  	 3/1Q  	 4/4Q   	4	 1:52.1 	 28  	 C Christoforou	1.00	 Dr I Moore
1088	53	4	7	 Tango Star            	    	   7 	 7/13H 	 7/10Q 	 8/8T  	 7/6T  	 5/4H   	5	 1:52.1 	 26.2	 M Baillargeon 	17.95	 M Lachance
1089	53	4	4	 King Of Sports        	    	   4 	 3/3H  	 3/4   	 5/5   	 5/5Q  	 6/6Q   	6	 1:52.3 	 27.3	 Ph Hudon      	65.35	 B Macdonald
1090	53	4	6	 Rock Power            	    	   6 	 6/10H 	 6/8Q  	 6/7   	 6/6   	 7/8T   	7	 1:53.1 	 27.4	 S Filion      	14.70	 T Osullivan
1091	53	4	10	 Micro Force(L)        	    	   9 	 8/16  	 8@/12Q	 7@/8Q 	 8/10  	 8/14T  	8	 1:54.2 	 28.4	 Trev Henry    	38.80	 M Weller
1092	53	4	3	 Rolling Rock          	    	   X3	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 M Saftic      	\N	 J Obrien
1093	53	4	8	 Blaise Mm Hanover     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1094	54	1	8	 Traceur Hanover       	    	   8 	 1/1T  	 2/1T  	 2/1T  	 3/2Q  	 1/NS   	1	 1:55.2 	 27.2	 S Filion      	\N	 R Moreau
1095	54	1	4	 Beast Mode            	    	   4 	 2/1T  	 1/1T  	 1/1T  	 1/1   	 2/NS   	2	 1:55.2 	 27.4	 Trev Henry    	\N	 C Nicol
1096	54	1	7	 Ideal Jet             	    	   7 	 3/4   	 3/3H  	 3/3H  	 2/1   	 3/H    	3	 1:55.2 	 27.1	 J Jamieson    	\N	 C Barss
1097	54	1	5	 Bringhome Theblue     	    	   5 	 4/6T  	 4/5H  	 4@/5Q 	 4/6T  	 4/6Q   	4	 1:56.3 	 28  	 C Auciello    	\N	 C Auciello
1098	54	1	2	 Homer Run             	    	   2 	 6/13H 	 6/12H 	 6@/11 	 6/13T 	 5/17   	5	 1:58.4 	 29  	 Dr J Flanigan 	\N	 Dr J Flanig
1099	54	1	1	 Passion Quizrace      	    	   1 	 5/10  	 5/8   	 5/9H  	 5/12H 	 6/19   	6	 1:59.1 	 29.4	 Ph Hudon      	\N	 K Gangell
1100	54	1	3	 Real Buzz             	    	   3 	 7/18  	 7/15H 	 7/12Q 	 7/16T 	 7/22   	7	 1:59.4 	 29.4	 Do Brown      	\N	 L Blais
1101	54	1	6	 Nicholas Ryan         	    	   6 	 8/21H 	 8/17  	 8/14H 	 8/20H 	 8/28   	8	 2:01   	 30.3	 J Drury       	\N	 C Auciello
1102	54	2	8	 Mister Herbie         	    	   8 	 2/1H  	 1/3   	 1/8H  	 1/8T  	 1/4Q   	1	 1:56.1 	 29.1	 J Jamieson    	\N	 J Gillis
1103	54	2	2	 Marquis Volo=         	    	   2 	 5/9H  	 5/11T 	 4@/11H	 2/8T  	 2/4Q   	2	 1:57   	 27.4	 P Henriksen   	\N	 P Henriksen
1104	54	2	3	 Way Outta Here=       	    	   3 	 6/11T 	 6/14T 	 5@/13Q	 4/12H 	 3/9Q   	3	 1:58   	 28.2	 M Vanderkemp  	\N	 M Vanderkem
1105	54	2	6	 Moonbeam Hall         	    	   6 	 4/7   	 4/9H  	 6/13H 	 6/15H 	 4/12   	4	 1:58.3 	 29  	 M Baillargeon 	\N	 B Baillarge
1106	54	2	7	 Little Stuie          	    	   7 	 1/1H  	 2/3   	 2/8H  	 3/11H 	 5/14Q  	5	 1:59   	 30.2	 Ph Hudon      	\N	 W Dunn
1107	54	2	1	 Joyous Hall           	    	   1 	 3/3T  	 3/5T  	 3/10Q 	 5/14  	 6/19   	6	 2:00   	 31  	 M Saftic      	\N	 B Bahr
1108	54	2	5	 Danielle Hall         	    	   5X	 X8/DIS	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 C Jamieson    	\N	 C Jamieson
1109	54	2	4	 April Breeze On By=   	    	   4X	 X7/DIS	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 J Renaud      	\N	 J Walker
1110	54	3	4	 Happy Hannah          	    	   4 	 2/H   	 1/4   	 1/3H  	 1/3H  	 1/8T   	1	 1:56.2 	 28.3	 Ra Waples     	\N	 M Steacy
1111	54	3	6	 Manhattan Play        	    	   6 	 8/13H 	 8/19  	 7/14T 	 7/12  	 2/8T   	2	 1:58.1 	 27.2	 M Saftic      	\N	 N Comegna
1112	54	3	5	 Dance Craze           	    	   5 	 5@/6H 	 5/10T 	 5/10  	 5/10Q 	 3/9T   	3	 1:58.2 	 28.3	 S Filion      	\N	 T Osullivan
1113	54	3	2	 Wicked Hill           	    	   2 	 3/2H  	 3/6T  	 3/5T  	 3/4T  	 4/10   	4	 1:58.2 	 29.2	 J Jamieson    	\N	 D Menary
1114	54	3	8	 B Fifteen             	    	   8 	 4@/4  	 4/8T  	 4/8Q  	 4/7H  	 5/10T  	5	 1:58.3 	 29.1	 C Christoforou	\N	 C Christofo
1115	54	3	7	 Little Hanover        	    	   7 	 1@/H  	 2/4   	 2/3H  	 2/3H  	 6/11   	6	 1:58.3 	 30.1	 Do Brown      	\N	 L Blais
1116	54	3	1	 Just Too Spoiled      	    	   1 	 6/7T  	 6/13H 	 6/13H 	 6/11T 	 7/11T  	7	 1:58.4 	 28.2	 D Mcnair      	\N	 P Reid
1117	54	3	3	 Two Hearted           	    	   3 	 7/10H 	 7/16  	 8@/15H	 8/17T 	 8/26   	8	 2:01.3 	 30.4	 Trev Henry    	\N	 P Hunt
1118	54	4	7	 Dunbar Hall=          	    	   7 	 2/2H  	 1/2H  	 1/3H  	 1/5H  	 1/8H   	1	 2:01   	 28.3	 J Jamieson    	\N	 C Jamieson
1119	54	4	4	 Kameran Hanover       	    	   4 	 3/7H  	 3/7T  	 3/5T  	 2/5H  	 2/8H   	2	 2:02.3 	 29  	 C Christoforou	\N	 C Christofo
1120	54	4	3	 Quadrangle            	    	   3 	 7/19Q 	 7/19H 	 6@/13H	 5/12H 	 3/12T  	3	 2:03.3 	 28.3	 J Moiseyev    	\N	 C Christofo
1121	54	4	8	 Upvote Hanover=       	    	   8 	 1/2H  	 2/2H  	 2/3H  	 3/6T  	 4/13H  	4	 2:03.3 	 30.3	 P Henriksen   	\N	 P Henriksen
1122	54	4	1	 Regal Hill            	    	   1 	 4/13  	 4/13H 	 4/7T  	 4/10T 	 5/14H  	5	 2:03.4 	 29.4	 G Peck        	\N	 G Peck
1123	54	4	5	 Whirlaway Hanover     	    	   5 	 6/16T 	 6/17  	 7/13T 	 6/13  	 6/15   	6	 2:04   	 28.4	 Ri Zeron      	\N	 N Bardier J
1124	54	4	6	 Persuaded=            	    	   6 	 5@/15T	 5@/15Q	 5/12  	 7/16T 	 7/18   	7	 2:04.3 	 29.4	 S Mahar       	\N	 S Mahar
1125	54	4	2	 Jd Luther             	    	   2X	 X8/28 	 8/27  	 8/22  	 8/31  	 8/39   	8	 2:08.4 	 32  	 Tra Henry     	\N	 Dr J Chandl
1126	54	5	3	 Ready Any Time=       	    	   3 	 3/5Q  	 3/4H  	 1@/1Q 	 1/3T  	 1/7T   	1	 1:57.1 	 28.4	 P Henriksen   	\N	 P Henriksen
1127	54	5	5	 Magic Missions=       	    	   5 	 2/2H  	 2/2   	 3/2T  	 2/3T  	 2/7T   	2	 1:58.4 	 29.4	 Ph Hudon      	\N	 W Budd
1128	54	5	8	 Sos Harddrive=        	    	   8 	 4/10T 	 4/7   	 4/8T  	 3/11H 	 3/16   	3	 2:00.2 	 30.1	 J Maguire     	\N	 J Maguire
1129	54	5	1	 Sass That Mass=       	    	   1 	 6/20  	 5@/14T	 5/12H 	 4/14H 	 4/18   	4	 2:00.4 	 30  	 J Renaud      	\N	 J Walker
1130	54	5	4	 Weve Had Enough       	    	   4X	 X7/25H	 7/20H 	 7/19T 	 6/18H 	 5/21   	5	 2:01.2 	 29  	 R Mayotte     	\N	 R Mayotte
1131	54	5	6	 Warrawee Rob          	    	   6 	 5/17T 	 6/15  	 6/16T 	 7/19  	 6/25   	6	 2:02.1 	 30.2	 M Baillargeon 	\N	 B Baillarge
1132	54	5	7	 Derivative=           	    	   7 	 1/2H  	 1/2   	 2/1Q  	 X5X/17	 7/DIS  	7	        	     	 T Burgess     	\N	 B Burgess
1133	54	5	2	 Work That Magic       	    	   X2	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS 	 8/DIS  	8	        	     	 C Christoforou	\N	 S Charlton
1134	54	6	5	 Hurricane Beach       	    	   4 	 3/4   	 3/3T  	 3@/3  	 1/H   	 1/1T   	1	 1:57.4 	 28.3	 S Filion      	\N	 L Blais
1135	54	6	2	 Forrest Porsche       	    	   2 	 1/1T  	 1/1H  	 1/2H  	 2/H   	 2/1T   	2	 1:58.1 	 29.3	 D Graham      	\N	 D Graham
1136	54	6	6	 Beach Volley Ball     	    	   5 	 5/10H 	 5/8   	 5/8H  	 4/6   	 3/3    	3	 1:58.2 	 28.1	 Do Brown      	\N	 L Blais
1137	54	6	1	 Major Master Piece    	    	   1 	 2/1T  	 2/1H  	 2/2H  	 3/3H  	 4/4Q   	4	 1:58.3 	 29.3	 J Jamieson    	\N	 D Menary
1138	54	6	3	 East Bound Eddie      	    	   3 	 4/5T  	 4/5H  	 4/6H  	 5/10H 	 5/17   	5	 2:01.1 	 31.2	 A Macdonald   	\N	 A Macdonald
1139	55	1	1	 Timepiece=            	    	   1 	 5/16T 	 2@/1T 	 1/3H  	 1/3H  	 1/2Q   	1	 2:03.4 	 30.4	 A Macdonald   	\N	 A Macdonald
1140	55	1	6	 Irenes Love=          	    	   5 	 3/9   	 4/5Q  	 3/4T  	 2/3H  	 2/2Q   	2	 2:04.1 	 30.1	 M Saftic      	\N	 M Dowling
1141	55	1	8	 Stritch=              	    	   7 	 4/12T 	 5/9H  	 4/7H  	 4/6T  	 3/4    	3	 2:04.3 	 30.1	 C Steacy      	\N	 M Steacy
1142	55	1	2	 For A Reason          	    	   2 	 1/3H  	 1/1T  	 2/3H  	 3/6   	 4/9    	4	 2:05.3 	 32  	 J Jamieson    	\N	 V Cochrane
1143	55	1	7	 Kuil Deva=            	    	   6 	 2/3H  	 3/2H  	 X5/17H	 5/23  	 5/16   	5	 2:07   	 30.3	 J Whelan      	\N	 J Whelan
1144	55	1	5	 Sweet Kimmy=          	    	   4X	 7/DIS 	 6/DIS 	 6/DIS 	 6/DIS 	 6/DIS  	6	        	     	 Ra Waples     	\N	 B Maxwell
1145	55	1	4	 Da Miracle            	    	   X3	 6/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 Trev Henry    	\N	 P Hunt
1146	56	1	5	 Janettes Image        	    	   5 	 4/5T  	 4/5T  	 3@/2H 	 2/NK  	 1/H    	1	 1:54.3 	 27.3	 Ja Macdonald  	1.00	 D Nixon
1147	56	1	6	 Diamond Tested        	    	   6 	 6/10H 	 6/10H 	 5@/4H 	 3/2   	 2/H    	2	 1:54.3 	 27.1	 D Mcnair      	25.90	 M Brethour
1148	56	1	3	 Misty De Vie          	    	   3 	 5/8H  	 5/8Q  	 6/6   	 6/6H  	 3BE/2H 	3	 1:55   	 27.1	 C Christoforou	15.50	 G Hunt
1149	56	1	1	 Place To Rocknroll    	    	   1 	 1/1T  	 1/2Q  	 1/2Q  	 1/NK  	 4/2H   	4	 1:55   	 28.2	 S Filion      	0.85	 T Alagna
1150	56	1	2	 Nic Nac Patty Mach    	    	   2 	 3/3H  	 3/3H  	 4/3T  	 5/4T  	 5/3    	5	 1:55.1 	 27.4	 Ra Waples     	20.40	 C Mitchell
1151	56	1	4	 Electric Ponder       	    	   4 	 2/1T  	 2/2Q  	 2/2Q  	 4/3H  	 6/5H   	6	 1:55.3 	 28.3	 M Saftic      	44.80	 D Brewer
1152	56	1	7	 City Charm            	    	   7 	 7/12H 	 7/12H 	 7@/6H 	 7/7Q  	 7/12H  	7	 1:57   	 29.1	 J Drury       	67.00	 B Macintosh
1153	56	2	6	 Candlelight Dinner    	    	   5 	 3@/2  	 1/2   	 2@/H  	 1/2   	 1/6    	1	 1:54.2 	 27.2	 J Drury       	0.10	 C Coleman
1154	56	2	5	 Black Jack Pat        	    	   4 	 1/2   	 2/2   	 3/2H  	 3/3T  	 2/6    	2	 1:55.3 	 28.1	 J Jamieson    	12.25	 D Menary
1155	56	2	2	 Moment To Ponder      	    	   2 	 4/4   	 4/5T  	 6@/6  	 6/8Q  	 3/7Q   	3	 1:55.4 	 27.3	 Ra Waples     	16.85	 R Mcintosh
1156	56	2	7	 Touching Thought      	    	   6 	 6/7H  	 6@/8Q 	 1/H   	 2/2   	 4/7T   	4	 1:56   	 29  	 Trev Henry    	9.30	 R Mcintosh
1157	56	2	1	 Braida Hanover        	    	   1 	 2/2   	 3/4   	 5/4H  	 4/6H  	 5/7T   	5	 1:56   	 28.1	 Ph Hudon      	39.95	 Colin Johns
1158	56	2	3	 Ohello Blue Chip(L)   	    	   3 	 5/5T  	 5/8   	 4@/4Q 	 5/7H  	 6/12   	6	 1:56.4 	 29  	 A Macdonald   	41.35	 A Macdonald
1159	56	2	8	 Takeyourbreathaway    	    	   7 	 7/10  	 7@/11 	 7/8T  	 7/11H 	 7/13H  	7	 1:57   	 28.1	 C Christoforou	46.75	 B Macintosh
1160	56	2	4	 Somemoneysomewhere    	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1161	56	3	2	 Inner Drive           	    	   2 	 2/1T  	 2/T   	 2/1T  	 2/1H  	 1/NK   	1	 1:59.4 	 30.1	 P Macdonell   	0.75	 R Mcintosh
1162	56	3	6	 Hab Faith=            	    	   5 	 4/6Q  	 1@/T  	 1/1T  	 1/1H  	 2/NK   	2	 1:59.4 	 30.3	 D Mcnair      	1.90	 R Mcnair
1163	56	3	5	 Parkhill Nocredit     	    	   4 	 1/1T  	 3/3   	 3/4   	 3/4   	 3/2Q   	3	 2:00.1 	 30.1	 S Byron       	9.30	 J Bax
1164	56	3	1	 Sunnyday Kash         	    	   1 	 3/4Q  	 4/5T  	 4/10T 	 4/14H 	 4/19   	4	 2:03.3 	 32.1	 Da Wall       	86.05	 L Gibbons
1165	56	3	8	 Oh Miss Sophie        	    	   7 	 6/10T 	 X6X/10	 6/29  	 6/30  	 5/23H  	5	 2:04.2 	 29.2	 Ra Waples     	5.50	 Ro Waples J
1166	56	3	7	 Ticket To Seattle     	    	   6 	 5/8H  	 5/7T  	 X5X/16	 5/28  	 6/23H  	6	 2:04.2 	 32  	 Ja Macdonald  	36.15	 M Steacy
1167	56	3	3	 Duet Seelster=        	    	   3 	 X7/19H	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 R Holliday    	74.70	 R Maclean
1168	56	3	4	 Blink Shes Gone=      	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1169	56	4	9	 Three Rivers Dell(L)  	    	   9 	 1/NK  	 2/1H  	 3/2   	 2/Q   	 1/1    	1	 1:53.3 	 28.2	 S Filion      	8.25	 R Fellows
1170	56	4	6	 Mayfield Duke         	    	   6 	 4/3H  	 4/5H  	 7/5T  	 6/3   	 2/1    	2	 1:53.4 	 27.4	 M Saftic      	14.05	 J Green
1171	56	4	5	 Jack Rackham          	    	   5 	 8/11T 	 8@/10 	 6@/4H 	 4/1H  	 3/2    	3	 1:54   	 28.2	 Trev Henry    	1.30	 A Montini
1172	56	4	4	 Archangel Three       	    	   4 	 7/10  	 6@/8Q 	 4@/2T 	 1/Q   	 4/2Q   	4	 1:54   	 28.3	 Ri Zeron      	3.85	 K Benn
1173	56	4	2	 To His Credit         	    	   2 	 5/6   	 5@/6H 	 2@/1  	 5/2   	 5/7    	5	 1:55   	 30  	 J Jamieson    	2.50	 C Jamieson
1174	56	4	1	 Corsica Hall(L)       	    	   1 	 3/1T  	 3/3Q  	 5/3T  	 7/3H  	 6/9H   	6	 1:55.2 	 29.4	 J Drury       	27.35	 C Auciello
1175	56	4	7	 Rose Run Ranger       	    	   7 	 9/13T 	 9/12H 	 8@/8Q 	 8/7T  	 7/12H  	7	 1:56   	 29.3	 R Holliday    	89.60	 J Pentland
1176	56	4	10	 Chalk Player          	    	   10	 2@/NK 	 1/1H  	 1/1   	 3X/H  	 8/12T  	8	 1:56.1 	 31.2	 D Mcnair      	19.80	 J Ritchie
1177	56	4	8	 Einhorn(L)            	    	   8 	 10/16Q	 10/17 	 10/14H	 10/13 	 9/14T  	9	 1:56.3 	 29  	 Ja Macdonald  	106.65	 M Rogers
1178	56	4	3	 Jet Black Cadillac    	    	   3 	 6/8Q  	 7/8T  	 9/8T  	 9/11H 	 10/23H 	10	 1:58.1 	 31.3	 S Condren     	110.60	 Alan W Fair
1179	56	5	6	 Monopoly              	    	   6 	 2/1H  	 2/1H  	 2/1H  	 1/T   	 1/4    	1	 1:56.2 	 29.3	 Trev Henry    	10.85	 G Cicero
1180	56	5	2	 Agent Dinozzo=        	    	   2 	 6/13T 	 6@/10T	 6@@/7 	 4/4H  	 2/4    	2	 1:57.1 	 29.1	 S Young       	1.10	 V Hayter
1181	56	5	7	 Silky Flashy Nfast    	    	   7 	 3/3H  	 3/3T  	 3/3Q  	 3/2Q  	 3/5Q   	3	 1:57.2 	 30.1	 M Baillargeon 	2.65	 B Baillarge
1182	56	5	9	 Rose Run Rudi         	    	   9 	 1@/1H 	 1/1H  	 1/1H  	 2/T   	 4/7Q   	4	 1:57.4 	 31.1	 S Byron       	7.35	 D Byron
1183	56	5	1	 Uf Musclemass Star    	    	   1 	 4/6Q  	 4/5T  	 4/5Q  	 5/6   	 5/11Q  	5	 1:58.3 	 31  	 S Filion      	9.45	 R Moreau
1184	56	5	10	 Archery=              	    	   10	 8/19Q 	 7@/13H	 7/7Q  	 6/7   	 6/11T  	6	 1:58.4 	 30.4	 D Mcnair      	57.30	 R Mcnair
1185	56	5	8	 Scotties Spirit=      	    	   8 	 5/10T 	 5/8Q  	 5@/6T 	 7/7T  	 7/16Q  	7	 1:59.3 	 31.3	 C Christoforou	18.85	 M Brethour
1186	56	5	3	 Copper Blues=         	    	   3 	 7/17H 	 8/18  	 8/16T 	 8/18H 	 8/26H  	8	 2:01.3 	 31.3	 C Steacy      	70.15	 M Steacy
1187	56	5	4	 Deuce Deuce Deuce     	    	   4X	 9/26  	 9/35  	 9/33T 	 9/33  	 9/35   	9	 2:03.2 	 30  	 J Moiseyev    	13.35	 J Moiseyev
1188	56	5	5	 Stormont Viceroy=     	    	   X5	 10/DIS	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 Ja Macdonald  	91.95	 N Jones
1189	56	6	5	 Powerful Mission      	    	   4 	 3/5Q  	 3/4   	 2@/1  	 1/Q   	 1/3    	1	 1:59.2 	 28.4	 Ph Hudon      	2.30	 K St Charle
1190	56	6	8	 Man Shes Hot          	    	   7 	 4/7   	 4/6   	 4@/2T 	 3/2Q  	 2/3    	2	 2:00   	 29  	 C Christoforou	1.85	 D Fontaine
1191	56	6	2	 Whole Lot Of Sugar    	    	   1 	 1/2T  	 1/2   	 1/1   	 2/Q   	 3/3    	3	 2:00   	 29.3	 J Jamieson    	3.30	 G Demers
1192	56	6	4	 You Cant Afford Me    	    	   3 	 6/10H 	 6/10T 	 6/7T  	 6/6T  	 4/5Q   	4	 2:00.2 	 28.2	 R Mayotte     	6.75	 S Mceneny
1193	56	6	3	 Warrawee Storm        	    	   2 	 5/8H  	 5/8Q  	 5/5H  	 5/6T  	 5/9H   	5	 2:01.1 	 29.4	 W Henry       	40.15	 W Henry
1194	56	6	6	 Hopeswishesndreams    	    	   5 	 2/2T  	 2/2   	 3/2Q  	 4/3H  	 6/12T  	6	 2:02   	 31.1	 D Mcnair      	6.90	 R Mcnair
1195	56	6	7	 Majestic Wanda        	    	   6 	 X7@/18	 7/25  	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 P Macdonell   	21.10	 J Bax
1196	56	6	1	 Rare Ruby             	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1197	57	1	1	 Give Em Heck(L)       	    	   1 	 1/1T  	 1/1H  	 1/1T  	 1/1H  	 1/1H   	1	 1:54   	 29  	 Trev Henry    	0.80	 M Weller
1198	57	1	2	 P L Dangerous         	    	   2 	 5/8Q  	 5@/6H 	 4@@/3 	 2/1H  	 2/1H   	2	 1:54.1 	 28.3	 Ja Macdonald  	10.35	 B Gibson
1199	57	1	8	 Maracasso(L)          	    	   8 	 2/1T  	 2/1H  	 2/1T  	 3/2H  	 3/3H   	3	 1:54.3 	 29.1	 Ra Waples     	3.45	 N Gallucci
1200	57	1	5	 Rolandale Buster      	    	   5 	 3/4   	 3@/3Q 	 3@/1T 	 4/3Q  	 4/5Q   	4	 1:55   	 29.3	 G Ketros      	33.20	 G Ketros
1201	57	1	6	 Evening Job(L)        	    	   6 	 4/6   	 4/4T  	 5/3Q  	 5/4T  	 5/5T   	5	 1:55.1 	 29.3	 Ph Hudon      	21.50	 T Riley
1202	57	1	7	 Big Harold(L)         	    	   7 	 8/17Q 	 7@/9H 	 7@@/5Q	 6/4T  	 6/8Q   	6	 1:55.3 	 29.3	 S Filion      	9.95	 J Libby
1203	57	1	4	 Highland Boreas       	    	   4 	 6/11Q 	 6/8H  	 6/5   	 7/5H  	 7/19   	7	 1:57.4 	 31.4	 J Jamieson    	15.40	 M Fine
1204	57	1	3	 Twin B Sportsman      	    	   3 	 7/15  	 8@/11H	 8@/8  	 8/10Q 	 8/19   	8	 1:57.4 	 31.1	 S Byron       	69.30	 C Campbell
1205	57	1	9	 Hp Black Shadow(L)    	    	   9X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 D Mcnair      	8.35	 V Puddy
1206	57	2	2	 Golden Son            	    	   2 	 1/1T  	 1/1T  	 1/1H  	 1/2H  	 1/4    	1	 1:55.2 	 28.3	 S Filion      	0.45	 R Moreau
1207	57	2	5	 Mostinterestingman=   	    	   5 	 4/5H  	 4/5H  	 3@/4H 	 2/2H  	 2/4    	2	 1:56.1 	 28.3	 S Condren     	10.35	 M Dupuis
1208	57	2	6	 French Bastille=      	    	   6 	 6/10H 	 6/9   	 6@/7H 	 4/5T  	 3/4    	3	 1:56.1 	 28  	 Ja Macdonald  	24.85	 M Steacy
1209	57	2	9	 I Want Kandy(L)       	    	   9 	 2/1T  	 2/1T  	 2/1H  	 3/2H  	 4/7H   	4	 1:56.4 	 29.4	 Ph Hudon      	57.20	 A Montini
1210	57	2	3	 Dewtiful Lass=        	    	   3 	 5/8Q  	 5/7Q  	 5/6T  	 6/7Q  	 5/10Q  	5	 1:57.2 	 29.1	 Ra Waples     	118.15	 B Macdonald
1211	57	2	1	 Stormont Esquire=(L)  	    	   1 	 3/3T  	 3/3H  	 4/4T  	 5/7Q  	 6/13H  	6	 1:58   	 30.1	 J Jamieson    	46.45	 K Benn
1212	57	2	10	 Moonlight Cocktail    	    	   10	 8/15T 	 8/14H 	 8@/14T	 7/14  	 7/13T  	7	 1:58.1 	 28.2	 P Macdonell   	23.35	 J Bax
1213	57	2	7	 Dewy Dont Cheat       	    	   7 	 7/14Q 	 7/12H 	 7/13Q 	 8/16  	 8/17H  	8	 1:58.4 	 29.2	 Ri Zeron      	2.45	 Ri Zeron
1214	57	2	8	 Dynamic Edge          	    	   X8	 10/37T	 9/24H 	 9/22H 	 9/27T 	 9/32   	9	 2:01.4 	 30.3	 D Mcnair      	52.05	 R Mcnair
1215	57	2	4	 Classical Son=        	    	   4X	 X9X/17	 10/DIS	 10/DIS	 10/DIS	 10/DIS 	10	        	     	 M Baillargeon 	143.40	 S Larocque
1216	57	3	6	 Ideal Wheel           	    	   5 	 3/3H  	 3/3   	 2@/H  	 1/1T  	 1/2H   	1	 1:54   	 28  	 J Drury       	0.35	 C Coleman
1217	57	3	9	 Darlings Dragon       	    	   8 	 1/2   	 2/1H  	 3/2Q  	 3/2   	 2/2H   	2	 1:54.2 	 28  	 D Dupont      	4.30	 M Dupont
1218	57	3	3	 Woodacudashuda        	    	   2 	 5/6T  	 5/6T  	 4/4Q  	 5/6   	 3/7Q   	3	 1:55.2 	 28.3	 D Mcnair      	21.70	 J Morrison
1219	57	3	7	 One Source            	    	   6 	 4/5Q  	 4/4T  	 5@/4T 	 4/5Q  	 4/7T   	4	 1:55.3 	 28.3	 S Filion      	9.00	 R Moreau
1220	57	3	5	 Rock This Way         	    	   4 	 2/2   	 1/1H  	 1/H   	 2/1T  	 5/8T   	5	 1:55.4 	 29.4	 M Baillargeon 	8.90	 B Baillarge
1221	57	3	8	 Heza Big Dealer       	    	   7 	 8/11T 	 7/13T 	 7@/11Q	 6/12T 	 6/9H   	6	 1:55.4 	 27.3	 Ph Hudon      	30.40	 M Brethour
1222	57	3	1	 Word Game             	    	   1 	 6/8   	 6/9   	 6/9T  	 7/17T 	 7/29   	7	 1:59.4 	 31.4	 M Saftic      	101.65	 R Mcnair
1223	57	3	4	 Mavericks A Terror    	    	   3 	 7/10Q 	 X8/18T	 8/22H 	 8/30T 	 8/35   	8	 2:01   	 30.3	 Ja Macdonald  	81.90	 S Mceneny
1224	57	3	2	 Southwind General     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1225	57	4	7	 Anikadabra            	    	   7 	 1/3Q  	 1/1T  	 1/2   	 1/1T  	 1/3    	1	 1:59.3 	 29.4	 Ri Zeron      	10.35	 R Fellows
1226	57	4	5	 P C Pipe Dream        	    	   5 	 6/12T 	 5@/9  	 3@/3T 	 3/2H  	 2/3    	2	 2:00.1 	 29.3	 C Clements    	1.40	 P Clements
1227	57	4	3	 Late Shift=           	    	   3 	 2/3Q  	 2/1T  	 2/2   	 2/1T  	 3/4H   	3	 2:00.2 	 30.1	 Ja Macdonald  	7.75	 M Steacy
1228	57	4	2	 Tymal Declan          	    	   2 	 3/6Q  	 3/4H  	 4/4Q  	 4/5T  	 4/5T   	4	 2:00.4 	 30.1	 S Byron       	6.00	 J Bax
1229	57	4	6	 Kendras Coco          	    	   X6	 7/17Q 	 7@/10T	 6/9Q  	 5X/8H 	 X5/10Q 	5	 2:01.3 	 30  	 D Boughton    	1.75	 J Drennan
1230	57	4	4	 Judy Judy Judy=       	    	   4 	 5/10H 	 4/8   	 5/6H  	 6/9T  	 6/19Q  	6	 2:03.2 	 32.2	 S Filion      	20.60	 K Jones
1231	57	4	1	 Ionia=                	    	   1 	 4/8   	 X6X/10	 7/24  	 7/28H 	 7/DIS  	7	        	     	 Ra Waples     	21.20	 Colin Johns
1232	57	5	7	 Mystic Deuce(L)       	    	   7 	 5/11  	 5/10H 	 6/7H  	 5/4Q  	 1/NK   	1	 1:52.4 	 28.4	 C Christoforou	1.55	 N Gallucci
1233	57	5	5	 Hemingway(L)          	    	   5 	 6/13H 	 7/12H 	 7@/8T 	 4/3T  	 2/NK   	2	 1:52.4 	 28.2	 Trev Henry    	9.65	 R Moffatt
1234	57	5	10	 Highland Tartan       	    	   10	 1@/1T 	 1/1T  	 1/3H  	 1/1H  	 3/T    	3	 1:53   	 30.2	 J Drury       	8.55	 M Fine
1235	57	5	6	 Better Art(L)         	    	   6 	 7/15H 	 6@/12H	 5@/6H 	 3/2H  	 4/1    	4	 1:53   	 29.1	 S Filion      	4.75	 E Laybourne
1236	57	5	8	 Velocity Headlight(L) 	    	   8 	 4/8T  	 4/8H  	 3@/4H 	 2/1H  	 5/3Q   	5	 1:53.2 	 30  	 D Mcnair      	5.20	 L Bako
1237	57	5	4	 Stimulus Spending     	    	   4 	 10/21H	 10/20T	 10@/14	 9/9   	 6/6T   	6	 1:54.1 	 28.4	 Ja Macdonald  	33.75	 K Di Cenzo
1238	57	5	3	 Highland Bogart       	    	   3 	 3/6Q  	 3/5   	 4/5H  	 7/6H  	 7/12Q  	7	 1:55.1 	 31.3	 M Saftic      	43.70	 S Friend
1239	57	5	1	 Never Been Told       	    	   1 	 2/1T  	 2/1T  	 2/3H  	 6/5T  	 8/12Q  	8	 1:55.1 	 32  	 Ph Hudon      	4.35	 A Montini
1240	57	5	2	 P L Inferno           	    	   2 	 9/19Q 	 9@/17H	 8@@/10	 8/7T  	 9/19Q  	9	 1:56.3 	 32  	 S Young       	32.85	 J Libby
1241	57	5	9	 Sky Guy               	    	   9 	 8@/17H	 8/15H 	 9/13H 	 10/16H	 10/24H 	10	 1:57.3 	 32.2	 A Macdonald   	49.15	 A Macdonald
1242	58	1	4	 Lil Richie            	    	   4 	 1/1T  	 1/3H  	 1/2H  	 1/3   	 1/7H   	1	 1:56   	 30  	 B Mcclure     	\N	 D Nixon
1243	58	1	6	 Badlyinclined         	    	   6 	 2/1T  	 2/3H  	 2/2H  	 2/3   	 2/7H   	2	 1:57.2 	 31  	 M Saftic      	\N	 Alan D Fair
1244	58	1	1	 Norcross Blue Chip    	    	   1 	 4/5Q  	 5/11T 	 6/17  	 6/14H 	 3/14T  	3	 1:59   	 29.3	 D Megens      	\N	 D Megens
1245	58	1	7	 Pylater               	    	   7 	 7/10T 	 6@/13Q	 4@/15H	 3/10H 	 4/15   	4	 1:59   	 30  	 Ph Hudon      	\N	 K Mcmaster
1246	58	1	3	 Big Dylan             	    	   3 	 6@/8Q 	 3@/7T 	 3/14H 	 5/13H 	 5/16   	5	 1:59.1 	 30.2	 S Young       	\N	 M Brealey
1247	58	1	8	 Acefortyfouramanda    	    	   8 	 8/12T 	 8/16  	 8/18Q 	 7/17  	 6/16   	6	 1:59.1 	 29.3	 W Henry       	\N	 L Bako
1248	58	1	9	 Birdie                	    	   9 	 3/3T  	 4/11H 	 5@@/15	 4/12  	 7/17   	7	 1:59.2 	 30.1	 S Filion      	\N	 D Daigneaul
1249	58	1	2	 Fade Away             	    	   2 	 5/8   	 7/15T 	 7@/17H	 8/25  	 8/28   	8	 2:01.3 	 32.1	 Ja Macdonald  	\N	 R Muir
1250	58	1	5	 Brightside Gretel     	    	   5X	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS 	 9/DIS  	9	        	     	 J Jamieson    	\N	 W Reda
1251	58	2	5	 Noblecrest            	    	   3 	 2/2H  	 1/2H  	 1/2H  	 1/4   	 1/4Q   	1	 2:03   	 30.2	 J Jamieson    	\N	 V Hayter
1252	58	2	3	 Crazy Girl=           	    	   2 	 1/2H  	 2/2H  	 2/2H  	 2/4   	 2/4Q   	2	 2:03.4 	 30.4	 S Condren     	\N	 C Mitchell
1253	58	2	2	 Try To Resist         	    	   1 	 3/8   	 3/15  	 3/25  	 3/35  	 3/46   	3	 2:12.1 	 34.3	 M Saftic      	\N	 G Sloan
1254	58	3	2	 Real Lucky Day        	    	   2 	 2/4   	 2/1T  	 2/2H  	 2/2H  	 1/HD   	1	 1:59.3 	 30.2	 S Filion      	\N	 S Larocque
1255	58	3	1	 Magic Night           	    	   1 	 1/4   	 1/1T  	 1/2H  	 1/2H  	 2/HD   	2	 1:59.3 	 30.4	 W Henry       	\N	 W Henry
1256	58	3	4	 Victors Magic=        	    	   X4	 4/30  	 4/25  	 3/25  	 3/22  	 3/22   	3	 2:04   	 30.1	 J Jamieson    	\N	 J Darling
1257	58	3	3	 Jayport Sport=        	    	   X3	 3/25  	 3/DIS 	 4/DIS 	 4/DIS 	 4/DIS  	4	        	     	 M Saftic      	\N	 D Obrian
1258	58	4	2	 Gateway To Victory    	    	   2X	 5/7H  	 1@/1Q 	 1/2   	 1/3   	 1/H    	1	 1:56   	 29.1	 J Jamieson    	\N	 T Alagna
1259	58	4	6	 Rodeo Sports          	    	   6 	 2@/1Q 	 2/1Q  	 2/2   	 2/3   	 2/H    	2	 1:56   	 28.4	 J Drury       	\N	 C Coleman
1260	58	4	3	 Fade                  	    	   3 	 3/2T  	 4/5T  	 4/9   	 4/6T  	 3/2T   	3	 1:56.3 	 28  	 S Condren     	\N	 C Coleman
1261	58	4	1	 Pretty Angel Eyes     	    	   1 	 1/1Q  	 3/4   	 3/5H  	 3/5T  	 4/5Q   	4	 1:57   	 29.1	 R Mayotte     	\N	 R Mayotte
1262	58	4	5	 Treasure Mach         	    	   5 	 4/5H  	 5/8   	 5/10H 	 5/9   	 5/8H   	5	 1:57.3 	 28.4	 S Filion      	\N	 T Osullivan
1263	58	4	4	 Daenerys Hanover      	    	   4 	 6/11  	 6/11H 	 6/13T 	 6/11T 	 6/10Q  	6	 1:58   	 28.2	 P Macdonell   	\N	 S Mehlenbac
1264	58	5	3	 Anutherdynamic        	    	   3 	 1/3H  	 1/4   	 1/Q   	 1/3   	 1/4H   	1	 2:00.2 	 30  	 P Macdonell   	\N	 W Walters
1265	58	5	4	 Windshield=           	    	   4 	 3/5T  	 3/7Q  	 3/3T  	 3/5T  	 2/4H   	2	 2:01.1 	 30  	 Ja Macdonald  	\N	 G Graham
1266	58	5	2	 Thee Desperado=       	    	   2 	 2/3H  	 2/4   	 2@/Q  	 2/3   	 3/4H   	3	 2:01.1 	 30.4	 S Condren     	\N	 T Mckibbin
1267	58	5	1	 Results May Vary=     	    	   1 	 4/8   	 4/10T 	 4/6T  	 4/9T  	 4/12Q  	4	 2:02.4 	 31  	 M Saftic      	\N	 K Bodz
1268	60	1	1	 Goodmorning Ky        	    	   1 	 2/Q   	 1@/T  	 1@/1  	 1/2   	 1/2    	1	 2:05   	 31.1	 N Rogers      	\N	 N Rogers
1269	60	1	3	 Southfield Speedy     	    	   3 	 3/3   	 3/3H  	 3@/2Q 	 3/3   	 2/2    	2	 2:05.2 	 31.1	 T Gallant     	\N	 T Gallant
1270	60	1	2	 Myambrose             	    	   2 	 1@/Q  	 2/T   	 2/1   	 2/2   	 3/4Q   	3	 2:05.4 	 31.4	 G Chappell    	\N	 C Macdougal
1271	60	2	3	 R Es Nancy+           	    	   3 	 1/7H  	 1/14  	 1/23  	 1/25  	 1/29   	1	 1:59   	 29.2	 M Pezzarello  	\N	 D Sweet
1272	60	2	1	 Southfield Spirit     	    	   1 	 2/7H  	 2/14  	 2/23  	 2/25  	 2/29   	2	 2:04.4 	 30.3	 N Rogers      	\N	 T Mann
1273	60	2	2	 Elm Grove Kaptain     	    	   X2	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS 	 3/DIS  	3	        	     	 J Hughes      	\N	 B Mckenna
1274	60	3	2	 Shouldabeenaclown     	    	   2 	 1/1T  	 2/1Q  	 2/2Q  	 2/1T  	 1/NK   	1	 2:11.1 	 31.4	 E Stewart     	\N	 E Stewart
1275	60	3	1	 Winny                 	    	   1 	 2/1T  	 1@/1Q 	 1/2Q  	 1/1T  	 2/NK   	2	 2:11.1 	 32.1	 N Rogers      	\N	 N Rogers
1276	60	3	3	 Ladies Gone Wild(T)   	    	   X3	 3BE/3T	 3/2T  	 3/4T  	 3/4T  	 3/5Q   	3	 2:12.1 	 32.1	 G Cole        	\N	 G Cole
1277	61	1	5	 Deacon Brodie         	    	   5 	 1/1H  	 1/1T  	 1/1Q  	 1/1H  	 1/1H   	1	 2:02   	 29  	 M Macdonald   	0.95	 M Macdonald
1278	61	1	4	 Sangria Seelster      	    	   4 	 2/1H  	 2/1T  	 2/1Q  	 2/1H  	 2/1H   	2	 2:02.1 	 29  	 P Langille    	6.50	 C Macdonald
1279	61	1	3	 Paper Lantern         	    	   3I	 5/6   	 5/7Q  	 5@/7  	 4/5H  	 3/8    	3	 2:03.3 	 29.1	 C Isenor      	5.95	 W Mcneil
1280	61	1	8	 Prime Time Cowboy     	    	   8 	 3/3   	 3/4   	 3/4   	 3/4H  	 4/9Q   	4	 2:03.4 	 30  	 D Romo        	6.80	 K Harper
1281	61	1	6	 Arrow Dramatic        	    	   6X	 7/17Q 	 7/11H 	 7I/11H	 7/10Q 	 5/19   	5	 2:05.4 	 30.3	 R Laffin      	6.80	 D Gillis
1282	61	1	2	 Brookdale Bruiser     	    	   2I	 4/4H  	 4/5H  	 4X/6  	 5/8T  	 6P7P6/2	6	 2:06.2 	 32.1	 B Mccallum    	2.95	 B Mccallum
1283	61	1	1	 P H Bossman           	    	   X1	 6/7Q  	 6/8H  	 6IX/8 	 6/9Q  	 7P6P7/2	7	 2:06.2 	 31.4	 T Trites      	12.20	 Dr T Shive
1284	61	1	7	 Craigmore Christy     	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1285	61	2	3	 Eyebebuckntuff        	    	   3 	 3/5   	 2@/1  	 1/1Q  	 2/1   	 1/NS   	1	 2:00.1 	 31.2	 J Ramsay Jr   	1.30	 D Oconnor
1286	61	2	4	 N S Acadian           	    	   4 	 4/6Q  	 4@/3  	 2@/1Q 	 1/1   	 2/NS   	2	 2:00.1 	 31.1	 R Smallwood   	1.95	 H Smallwood
1287	61	2	6	 Putnams Force+        	    	   6 	 7/14T 	 6@/6Q 	 4@/2T 	 3/2Q  	 3/T    	3	 2:00.2 	 31  	 A Campbell    	5.40	 J Green
1288	61	2	5	 Metro Man             	    	   5 	 5/8H  	 5/5Q  	 7@/4  	 5/4T  	 4/4T   	4	 2:01.1 	 31.3	 D Crowe       	5.45	 K Gillis
1289	61	2	1	 Pick N Scoop          	    	   1 	 6/13H 	 7/8T  	 5@@/3 	 4/4Q  	 5/5    	5	 2:01.1 	 31.4	 P Langille    	7.35	 C Macdonald
1290	61	2	7	 Sauble Liz            	    	   7 	 1@/1  	 3/2   	 6/3T  	 7/6H  	 6/9H   	6	 2:02   	 32.2	 K Parris      	24.75	 C Covin
1291	61	2	2	 Milliondollarkevin    	    	   2 	 2/1   	 1/1   	 3/1T  	 6/5T  	 7/14   	7	 2:03   	 33.4	 S Dixon       	6.35	 S Dixon
1292	61	3	4	 Mystic Cruiser        	    	   4 	 1@/1Q 	 1/3H  	 1/3H  	 1/3Q  	 1/T    	1	 1:58.1 	 30.3	 E Laffin      	2.15	 F Saunders
1293	61	3	6	 Djnorthernstar        	    	   6 	 6@/6H 	 6@/9Q 	 5@@/5T	 2/3Q  	 2/T    	2	 1:58.2 	 29.3	 M Macdonald   	0.60	 D Jackson
1294	61	3	5	 Hog Aufray            	    	   5 	 5@/5  	 5@/7T 	 3@/5  	 4/3T  	 3/3H   	3	 1:58.4 	 30.1	 T Trites      	9.00	 N White
1295	61	3	7	 Oppies Artist         	    	   7 	 7@/7T 	 7@/10T	 6@/7T 	 6/5Q  	 4/5    	4	 1:59.1 	 30  	 A Campbell    	32.55	 A Campbell
1296	61	3	2	 Western Scot          	    	   2 	 2/1Q  	 2/3H  	 2/3H  	 3/3T  	 5/5Q   	5	 1:59.1 	 31  	 P Langille    	9.70	 D Gillis
1297	61	3	1	 Brookdale Buster      	    	   1 	 3/2H  	 3/5H  	 4/5H  	 5/5   	 6/5Q   	6	 1:59.1 	 30.3	 B Mccallum    	4.40	 B Mccallum
1298	61	3	3	 Lexilowguy            	    	   3 	 4/3T  	 4@/6H 	 7/8Q  	 7/7Q  	 7/7Q   	7	 1:59.3 	 30.2	 R Laffin      	3.25	 O Fletcher
1299	61	4	2	 Four Starz Hold Em    	    	   2 	 1/1Q  	 1/1   	 1/4   	 1/3H  	 1/5    	1	 1:58.4 	 30.1	 D Spence      	0.45	 N White
1300	61	4	3	 Djs Kocakolacowboy    	    	   3 	 5/5H  	 4@/3  	 2/4   	 2/3H  	 2/5    	2	 1:59.4 	 30.2	 H Smallwood   	3.05	 H Smallwood
1301	61	4	4	 Pictonians Derbie     	    	   4 	 4/2H  	 5/4   	 5/6Q  	 3/6Q  	 3/6T   	3	 2:00.1 	 30.2	 B Mccallum    	6.95	 B Mccallum
1302	61	4	7	 Fluid Motion          	    	   7 	 7/8   	 7/6T  	 6@/7  	 6/8   	 4/9Q   	4	 2:00.3 	 30.3	 D Carey       	14.10	 D Carey
1303	61	4	5	 Bo Butler             	    	   5 	 6/6T  	 6@/6Q 	 4@/5Q 	 4/7Q  	 5/12Q  	5	 2:01.1 	 31.3	 K Parris      	12.05	 C Covin
1304	61	4	1	 Nikitas Halo          	    	   1 	 2/1Q  	 3/2   	 3/5Q  	 5/7T  	 6/16T  	6	 2:02.1 	 32.3	 K Parker Jr   	8.50	 K Parker Jr
1305	61	4	6	 Flag Of Honor         	    	   6 	 3@/1H 	 2@/1  	 7/8Q  	 7/11H 	 7/19H  	7	 2:02.3 	 32.2	 J Ramsay Jr   	9.20	 D Settle
1306	61	5	1	 Modern Best           	    	   1 	 1/1Q  	 1/1   	 1/1H  	 1/2   	 1/6Q   	1	 1:58.3 	 29.4	 K Parris      	1.20	 C Covin
1307	61	5	6	 M M Lass              	    	   6 	 5@/5H 	 4@/2H 	 3/3   	 3/3Q  	 2/6Q   	2	 1:59.4 	 30.2	 D Carey       	2.80	 D Carey
1308	61	5	3	 Just Lovey            	    	   3 	 2/1Q  	 3/2   	 2/1H  	 2/2   	 3/6H   	3	 1:59.4 	 30.4	 D Spence      	4.60	 N White
1309	61	5	2	 Mattadors Rose        	    	   2 	 3/3Q  	 6/5Q  	 5/5Q  	 5/6   	 4/10Q  	4	 2:00.3 	 30.4	 J Lilley      	4.60	 J Lilley
1310	61	5	4	 Maiden Heaven         	    	   4 	 4@/4Q 	 2@/1  	 4@/3H 	 4/5T  	 5/13   	5	 2:01.1 	 31.4	 P Langille    	10.15	 P Langille
1311	61	5	7	 Dashwood Darling      	    	   7 	 6@/6T 	 5@/5  	 6/5T  	 6/8   	 6/16H  	6	 2:01.4 	 31.4	 J Ramsay Jr   	6.40	 T Ellis
1312	61	5	8	 Video Storage         	    	   8 	 7/8Q  	 7/9Q  	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 D Crowe       	11.35	 L Johnson
1313	61	5	5	 Scotian Lass          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1314	61	6	3	 Gwinning Gwen         	    	   3 	 1@/1  	 1/2   	 1/1   	 1/1   	 1/1H   	1	 1:58   	 31  	 R Ellis       	4.05	 G Rennison
1315	61	6	7	 Threestepstoheaven    	    	   7 	 7/10  	 7@/10T	 7@/7  	 5/4T  	 2/1H   	2	 1:58.1 	 29.4	 P Langille    	1.55	 G Rennison
1316	61	6	2	 Mr Rock               	    	   2 	 3/3H  	 3/4T  	 3/2H  	 3/2   	 3/2T   	3	 1:58.3 	 31.1	 M Macdonald   	10.40	 E Wilson
1317	61	6	5	 Saulsbrook Quick      	    	   5 	 5/6H  	 6@/8T 	 6@/7  	 7/6T  	 4/6Q   	4	 1:59.1 	 30.4	 J Ramsay Jr   	5.40	 J Green
1318	61	6	1	 Cavallo Frosty        	    	   1 	 2/1   	 2/2   	 2@/1  	 2/1   	 5/6H   	5	 1:59.1 	 32  	 D Crowe       	2.55	 D Crowe
1319	61	6	4	 Pride Of Paradise     	    	   4 	 4/5Q  	 4/7   	 4/5Q  	 4/4T  	 6/6T   	6	 1:59.2 	 31.2	 H Smallwood   	8.00	 H Smallwood
1320	61	6	6	 Sock It To Em         	    	   6 	 6/7T  	 5@/7Q 	 5@/5T 	 6/6   	 7/9H   	7	 1:59.4 	 31.3	 K Parker Jr   	5.70	 K Parker Jr
1321	62	1	5	 Distinctiv Rusty      	    	   5 	 2/1Q  	 3/2   	 2/1T  	 2/1   	 1/5    	1	 1:57.4 	 29.2	 R Ellis       	2.00	 G Rennison
1322	62	1	7	 Sharon The Moment     	    	   7 	 7/8   	 7/6T  	 6/7T  	 5/6T  	 2/5    	2	 1:58.4 	 29.1	 D Carey       	21.40	 D Carey
1323	62	1	3	 Dontstandinmyway      	    	   3 	 3/2H  	 5/4Q  	 3/6T  	 3/5H  	 3/5    	3	 1:58.4 	 29.2	 P Rogerson    	4.90	 P Rogerson
1324	62	1	2	 Neigh Monster         	    	   2 	 1/1Q  	 1/1   	 1/1T  	 1/1   	 4/5Q   	4	 1:58.4 	 30.4	 P Langille    	3.95	 D Gillis
1325	62	1	6	 Our Star              	    	   6 	 6/6T  	 6@/5H 	 5@@/7 	 4/5H  	 5/5H   	5	 1:58.4 	 29.2	 T Trites      	4.65	 G Rennison
1326	62	1	4	 Chief Exec Officer    	    	   4 	 5/5Q  	 4@/3Q 	 7/10  	 6/9   	 6/15Q  	6	 2:00.4 	 30.4	 E Mackay      	5.30	 T Mac Kay
1327	62	1	1	 Primeride             	    	   1 	 4/3T  	 2@/1  	 4@/7  	 7/10  	 7/26Q  	7	 2:03   	 33.3	 D Crowe       	2.45	 D Ellis Abb
1328	62	2	4	 Icandothat            	    	   4 	 1/2Q  	 1/3H  	 1/3   	 1/1Q  	 1/1H   	1	 1:58.2 	 30.1	 R Ellis       	2.60	 R Ellis
1329	62	2	5	 C L La Rousse         	    	   5I	 5/6Q  	 5@/7Q 	 4/4Q  	 3/2H  	 2/1H   	2	 1:58.3 	 29.3	 M Macdonald   	2.90	 L Parker
1330	62	2	2	 Kendal Courageous     	    	   2I	 3/3H  	 3/4T  	 3@/3  	 2/1Q  	 3/3Q   	3	 1:59   	 30.1	 C Stevens     	15.05	 C Stevens
1331	62	2	6	 Charlottes Style      	    	   6I	 6/7H  	 6@/8H 	 5@/5H 	 5/4Q  	 4/7T   	4	 2:00   	 30.4	 D Carey       	13.15	 D Oconnor
1332	62	2	1	 Lifeinthecountry      	    	   1I	 2/2Q  	 2/3H  	 2/3   	 4/4   	 5/9H   	5	 2:00.1 	 31.2	 J Ramsay Jr   	1.00	 J Ramsay Jr
1333	62	2	7	 Desir Dorleans        	    	   7 	 7/10T 	 7@/11T	 7@/8Q 	 6/8Q  	 6/13T  	6	 2:01.1 	 31.2	 H Graves      	8.00	 F Saunders
1334	62	2	3	 P H Powerful          	    	   3 	 4/4T  	 4/6   	 6/6T  	 7/9H  	 7/16   	7	 2:01.3 	 32  	 T Trites      	14.15	 H Mac Kay
1335	62	2	8	 Udine Bayama          	    	   8 	 8/12  	 8/12Q 	 8/9Q  	 8/11  	 8/17T  	8	 2:02   	 32  	 E Laffin      	30.80	 L Johnson
1336	62	3	4	 Gerries Beach         	    	   4 	 1/1Q  	 2/Q   	 1/1   	 1/1   	 1/HD   	1	 1:58   	 29.3	 D Romo        	2.65	 K Harper
1337	62	3	1	 Pasta Vera            	    	   1 	 4/3T  	 1@/Q  	 2@/1  	 2/1   	 2/HD   	2	 1:58   	 29.2	 D Crowe       	1.60	 P Moore
1338	62	3	5	 Threes A Crowd        	    	   5 	 5/5   	 5/3T  	 4@/2Q 	 3/2Q  	 3/T    	3	 1:58.1 	 29.2	 T Trites      	2.35	 Dr T Shive
1339	62	3	6	 Woodmere Dancenart    	    	   6 	 6/6Q  	 6@/4H 	 5@/3T 	 5/3T  	 4/4    	4	 1:58.4 	 29.3	 M Macdonald   	5.10	 M Macdonald
1340	62	3	3	 Walbert               	    	   3 	 3/2H  	 4@/2T 	 6@/5  	 6/6Q  	 5/6H   	5	 1:59.1 	 29.4	 K Parris      	12.00	 C Covin
1341	62	3	2	 Bagel Man             	    	   2 	 2/1Q  	 3/1T  	 3/2   	 4/2T  	 6/7    	6	 1:59.2 	 30.3	 E Laffin      	4.70	 R Collette
1342	62	4	3	 Big Kisser            	    	   3 	 1/1Q  	 1/3   	 1/1Q  	 1/1H  	 1/4T   	1	 1:58   	 29.4	 C Macdonald   	4.15	 C Macdonald
1343	62	4	8	 Shalara               	    	   8 	 3/2T  	 3@/3T 	 2@/1Q 	 2/1H  	 2/4T   	2	 1:59   	 30.3	 M Macdonald   	5.95	 M Macdonald
1344	62	4	1	 Preceptor             	    	   1 	 8/13T 	 8/14T 	 BE6@/6	 5/3H  	 3/7H   	3	 1:59.2 	 30  	 P Langille    	0.65	 P Langille
1345	62	4	4	 Gigs And Reels        	    	   4 	 6@/7  	 4@/7  	 4@/2H 	 4/3Q  	 4/8H   	4	 1:59.3 	 31  	 D Crowe       	7.80	 D Crowe
1346	62	4	5	 Pictonian Sylvia      	    	   5 	 2/1Q  	 2/3   	 3BE/2Q	 3/3Q  	 5/9Q   	5	 1:59.4 	 31.1	 E Mackay      	11.40	 T Mac Kay
1347	62	4	2	 Mrs Krabappel         	    	   2 	 4/5   	 5/9Q  	 5/5   	 6/5H  	 6/10H  	6	 2:00   	 30.4	 C Isenor      	6.80	 W Mcneil
1348	62	4	6	 Woodmere Costalot     	    	   6 	 7/10Q 	 7/12T 	 8/8T  	 8/7T  	 7/12   	7	 2:00.2 	 30.2	 D Romo        	16.35	 W Turner
1349	62	4	7	 Putnams Legacy+       	    	   7 	 5/6T  	 6@/10Q	 7/7   	 7/6H  	 8/12Q  	8	 2:00.2 	 30.4	 B Mccallum    	17.15	 B Mccallum
1350	63	1	2	 Rj Gigolo             	    	   2 	 1/2Q  	 1/3   	 1/2   	 1/1   	 1/2Q   	1	 2:05.1 	 30.3	 D Carey       	\N	 J Green
1351	63	1	3	 Howmacs Dragonator    	    	   3 	 3/4H  	 3/5H  	 3@/3  	 2/1   	 2/2Q   	2	 2:05.3 	 30.2	 B Mccallum    	\N	 B Mccallum
1352	63	1	1	 Bourbonstreet Lady+   	    	   1 	 2/2Q  	 2/3   	 2/2   	 3/2T  	 3/4Q   	3	 2:06   	 31  	 D Romo        	\N	 D Romo
1353	63	2	2	 Lucbobski             	    	   2 	 2@/2  	 1/4H  	 1/6   	 1/8H  	 1/19H  	1	 2:00.4 	 29.1	 D Romo        	\N	 D Romo
1354	63	2	4	 Secret Fantasy        	    	   4 	 1/2   	 2/4H  	 2/6   	 2/8H  	 2/19H  	2	 2:04.3 	 31.4	 R Ellis       	\N	 R Chase
1355	63	2	3	 Southwind Oasis       	    	   3 	 3/2Q  	 3/7T  	 3/13  	 3/13H 	 3/21   	3	 2:05   	 30.4	 C Isenor      	\N	 W Mcneil
1356	63	2	1	 Big Joe Doby          	    	   1 	 4/4   	 4/10H 	 4/15  	 4/15  	 4/23   	4	 2:05.2 	 30.4	 B Mccallum    	\N	 J Janega
1357	64	1	1	 Pappy Go Go           	    	   1 	 2@/2  	 1/3H  	 1/1T  	 1/1H  	 1/T    	1	 2:06.3 	 31.2	 Ma Campbell   	0.25	 Ma Campbell
1358	64	1	4	 Wicked Nick=          	    	   4 	 1/2   	 2/3H  	 2/1T  	 2/1H  	 2/T    	2	 2:06.4 	 31.1	 G Chappell    	20.50	 G Chappell
1359	64	1	3	 Howmacs Survivor      	    	   3 	 3/2T  	 3/6T  	 3/5Q  	 3/6H  	 3/9H   	3	 2:08.2 	 32.1	 T Gallant     	11.70	 T Gallant
1360	64	1	2	 Talk Of Windemere=    	    	   2 	 4/7T  	 4/10Q 	 4/10Q 	 4/13H 	 4/19   	4	 2:10.2 	 33.1	 K Murphy      	37.20	 J Pineau
1361	64	1	7	 Fireside Al=          	    	   7 	 6/10H 	 5/15Q 	 5/12  	 5/16  	 5/20T  	5	 2:10.4 	 33.1	 D Macdonald   	37.20	 D Macdonald
1362	64	1	6	 Hop Up                	    	   6 	 7/12  	 6/21Q 	 6/18  	 6/18H 	 6/21H  	6	 2:10.4 	 32  	 K Campbell    	\N	 K Campbell
1363	64	1	5	 Dusty Lane Min        	    	   5 	 5/9Q  	 X7/DIS	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 J Hughes      	7.45	 J Hughes
1364	64	2	4	 Mr Bower              	    	   4 	 3/2H  	 3/2H  	 2@/3H 	 2/1H  	 1/1H   	1	 2:02   	 31.1	 K Arsenault   	0.40	 K Arsenault
1365	64	2	1	 Oceanview Lefty=      	    	   1 	 1/1Q  	 1/1Q  	 1/3H  	 1/1H  	 2/1H   	2	 2:02.1 	 32  	 M Mcguigan    	5.50	 E Smallwood
1366	64	2	6	 Time Warp=            	    	   6 	 2/1Q  	 2/1Q  	 3/4Q  	 3/4Q  	 3/8Q   	3	 2:03.3 	 32.3	 D Macdonald   	15.25	 D Macdonald
1367	64	2	5	 Dunmore Ace=          	    	   5 	 4/7   	 4/6   	 4/10Q 	 4/7Q  	 4/8H   	4	 2:03.3 	 31.2	 J Panting     	10.05	 R Annear
1368	64	2	2	 Cardigan Jack         	    	   2 	 5/13  	 5/11  	 5/14T 	 5/11H 	 5/15   	5	 2:05   	 31.4	 C Macpherson  	7.10	 P Morrison
1369	64	2	3	 All Canadian=         	    	   3X	 6/33  	 6/26  	 6/29T 	 6/31H 	 6/29   	6	 2:07.4 	 31.3	 Ma Campbell   	3.15	 Ma Campbell
1370	64	3	1	 Bj Lorado=            	    	   1 	 2/Q   	 2/2Q  	 2/1Q  	 2/NS  	 1/NK   	1	 2:06.1 	 32.2	 P Lanigan     	16.55	 B Honkoop
1371	64	3	6	 Mary Leah             	    	   6 	 4/5T  	 4@/10Q	 3/2H  	 3/1Q  	 2/NK   	2	 2:06.1 	 32.1	 D Macdonald   	2.55	 D Macdonald
1372	64	3	3	 Majian Tango          	    	   3 	 3/3T  	 3/10Q 	 4/6Q  	 4/2H  	 3/1    	3	 2:06.2 	 31.3	 J Ripley      	14.85	 J Ripley
1373	64	3	4	 Windemerepartyman     	    	   4I	 1@/Q  	 1/2Q  	 1/1Q  	 1/NS  	 4/4    	4	 2:07   	 33.2	 J Panting     	4.10	 R Annear
1374	64	3	7	 Just A Little Tad=    	    	   7 	 5/8H  	 5@/13 	 5@/7Q 	 5/3T  	 5/7H   	5	 2:07.3 	 32.3	 C Macpherson  	5.45	 R Gass
1375	64	3	2	 Play Along=           	    	   2X	 X6/20H	 6/25  	 X6/27Q	 6/25T 	 6/24T  	6	 2:11.1 	 32.1	 T Easter      	0.90	 T Easter
1376	64	3	5	 Revenueofwindemere    	    	   5X	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS 	 7/DIS  	7	        	     	 T Gallant     	9.80	 T Gallant
1377	64	4	2	 Glencove Zani         	    	   2 	 1/2Q  	 1/5   	 1/3T  	 1/2   	 1/4Q   	1	 2:03   	 30.2	 L Mcguigan    	1.30	 E Smallwood
1378	64	4	6	 Craigh Na Dun         	    	   6 	 2/2Q  	 2/5   	 2/3T  	 2/2   	 2/4Q   	2	 2:03.4 	 30.2	 J Hughes      	1.70	 N Oakes
1379	64	4	4	 Howmac Gypsy          	    	   X4	 6/9   	 5@/9  	 5@@/7T	 4/5Q  	 3/7H   	3	 2:04.2 	 30.1	 J Panting     	4.10	 R Annear
1380	64	4	1	 Unsinkableone=        	    	   1 	 3/3H  	 3/7   	 3/5Q  	 3/3T  	 4/8Q   	4	 2:04.3 	 31  	 C Macpherson  	4.00	 R Gass
1381	64	4	5	 Rustico Duchess       	    	   5 	 5@/8H 	 4@/7Q 	 4@/6T 	 5/6Q  	 5/14   	5	 2:05.4 	 31.4	 K Murphy      	7.90	 J Pineau
1382	64	4	3	 Silverhill Flame=     	    	   3 	 4/7Q  	 6/10Q 	 6/10H 	 6/12Q 	 6/23Q  	6	 2:07.3 	 33  	 R Neill       	16.15	 L Neill
1383	64	5	2	 Heres The Beach       	    	   2 	 1/4Q  	 1/6   	 1/5   	 1/2   	 1/1T   	1	 2:04.1 	 32  	 C Macpherson  	3.95	 C Macpherso
1384	64	5	4	 Livin The Moment      	    	   4 	 3/5H  	 3@/6Q 	 3@/5  	 2/2   	 2/1T   	2	 2:04.3 	 31.2	 J Hughes      	0.30	 J Hughes
1385	64	5	3	 Dreamy Honey          	    	   3 	 2/4Q  	 2/6   	 2/5   	 3/2Q  	 3/3T   	3	 2:05   	 31.4	 H Graves      	4.95	 K Arsenault
1386	64	5	5	 P H Stephanie         	    	   5 	 4/10H 	 4/9T  	 4/10  	 4/7Q  	 4/5T   	4	 2:05.2 	 31.1	 Dr T Shive    	3.15	 Dr T Shive
1387	64	5	1	 Doug Little Girl      	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1388	64	6	6	 Elektra Express       	    	   6 	 6@/8T 	 1@/H  	 1/1T  	 1/1H  	 1/3T   	1	 1:59.3 	 29.4	 Ma Campbell   	0.25	 Ma Campbell
1389	64	6	3	 Tobins Secret         	    	   3 	 1/1Q  	 2/H   	 2/1T  	 2/1H  	 2/3T   	2	 2:00.2 	 30.1	 A Smith       	7.00	 A Smith
1390	64	6	2	 Woodmere Finesse+     	    	   2 	 5@/7H 	 4@/3T 	 3@/3T 	 3/2T  	 3/4Q   	3	 2:00.2 	 29.4	 G Barrieau    	9.65	 J Arsenault
1391	64	6	1	 Magical Cowgirl       	    	   1 	 3/3T  	 5/5   	 5/5H  	 5/4Q  	 4/6Q   	4	 2:00.4 	 30  	 C Macpherson  	10.05	 R Gass
1392	64	6	4	 Gold Record           	    	   4 	 2@/1Q 	 3/3H  	 4/4Q  	 4/4   	 5/11   	5	 2:01.4 	 31.1	 B Mccallum    	16.65	 B Mccallum
1393	64	6	5	 Im Not Lisa           	    	   5 	 4/6Q  	 7/6H  	 7/7H  	 6/6H  	 6/15   	6	 2:02.3 	 31.2	 K Arsenault   	5.30	 K Arsenault
1394	64	6	7	 Saulsbrook Fresh      	    	   7 	 7/11H 	 6@/5H 	 6@/6H 	 7/12H 	 7/29   	7	 2:05.2 	 34.2	 R Campbell    	21.10	 N Fiander
1395	65	1	1	 Georgie Rose          	    	   1I	 4/6   	 3@/2  	 2@/H  	 2/Q   	 1/Q    	1	 2:03.1 	 30.2	 G Chappell    	7.50	 C Mackay
1396	65	1	4	 Not So Shy            	    	   4 	 5/8H  	 5@/3H 	 4@/2H 	 3/1Q  	 2/Q    	2	 2:03.1 	 30  	 G Barrieau    	1.40	 E Watts
1397	65	1	5	 Im On Schedule        	    	   5 	 6/9T  	 6@/5  	 5@/3T 	 5/2T  	 3/3T   	3	 2:04   	 30.2	 C Macpherson  	15.20	 D Wallace
1398	65	1	2	 Kiss My Sass          	    	   2I	 1@/1  	 2/1H  	 3/1H  	 4/1T  	 4/5    	4	 2:04.1 	 31.1	 D Spence      	3.20	 M Macinnis
1399	65	1	3	 Elm Grove Luck        	    	   3X	 3/3Q  	 1/1H  	 1/H   	 1/Q   	 5/6H   	5	 2:04.2 	 31.3	 R Ellis       	0.95	 J Baxter
1400	65	1	6	 Noras Little Rose     	    	   6 	 2/1   	 4/3Q  	 6/4T  	 6/10T 	 6/19T  	6	 2:07.1 	 33.2	 R Campbell    	29.65	 W Mcgean
1401	65	2	6	 Kinda Like Her        	    	   6 	 1/1Q  	 1/1   	 1/T   	 1/1H  	 1/7Q   	1	 2:00.1 	 28.4	 K Arsenault   	0.15	 R Dooley
1402	65	2	4	 Pictonian Dazzle      	    	   4 	 2/1Q  	 3/2   	 3/1T  	 2/1H  	 2/7Q   	2	 2:01.3 	 29.4	 B Mccallum    	35.70	 B Mccallum
1403	65	2	2	 Elm Grove Ladyluck    	    	   2 	 4/3T  	 4/4   	 5/3Q  	 5/3T  	 3/7H   	3	 2:01.3 	 29.3	 Ma Campbell   	9.10	 Ma Campbell
1404	65	2	7	 Imahawkchick          	    	   7 	 5/5Q  	 5@/5  	 4@/3  	 4/3H  	 4/9T   	4	 2:02.1 	 30.1	 D Romo        	5.35	 D Romo
1405	65	2	1	 Keep It Country       	    	   1 	 3/2H  	 2@/1  	 2@/T  	 3/2H  	 5/10H  	5	 2:02.1 	 30.3	 D Spence      	14.05	 P Biggar
1406	65	2	3	 Gulf Queen            	    	   3 	 6/6H  	 6/9   	 6@/4T 	 6/5T  	 6/11Q  	6	 2:02.2 	 30  	 M Haig        	25.80	 M Land
1407	65	2	5	 Glenview Paisley      	    	   5 	 7/8   	 7X/11Q	 7/14T 	 7/25T 	 7/33   	7	 2:06.4 	 32.2	 D Carey       	6.30	 D Carey
1408	65	3	2	 Positive Outcome      	    	   2 	 1/1Q  	 1/1   	 1/1Q  	 1/2   	 1/4T   	1	 2:04.2 	 29.2	 D Crowe       	1.00	 D Crowe
1409	65	3	3	 Putnams Fire          	    	   3 	 4/3T  	 5/4H  	 5/2T  	 5/3Q  	 2/4T   	2	 2:05.2 	 29.4	 B Mccallum    	17.55	 B Mccallum
1410	65	3	1	 Sweetgeorgia          	    	   1 	 2/1Q  	 3/1T  	 3/1Q  	 2/2   	 3/5    	3	 2:05.2 	 30.1	 K Murphy      	8.20	 N Oakes
1411	65	3	5	 Calabash              	    	   X5	 6/6T  	 4@/3  	 4@/2H 	 4/3Q  	 4/5T   	4	 2:05.3 	 30.1	 G Barrieau    	2.40	 E Mackay
1412	65	3	4	 Molly Vance           	    	   4 	 5/5H  	 6@/5  	 6@/4Q 	 6/4T  	 5/7T   	5	 2:06   	 30.1	 P Langille    	3.05	 P Langille
1413	65	3	6	 Glenview Pippa        	    	   6 	 3/2H  	 2@/1  	 2@/1Q 	 3/3Q  	 6/13H  	6	 2:07   	 31.4	 J Hughes      	4.70	 J Hughes
1414	65	4	6	 Woodmere Dreams       	    	   6 	 7@/10Q	 4@/6Q 	 2@/1  	 1/NS  	 1/H    	1	 2:00.1 	 29.3	 G Barrieau    	4.05	 K Wilkie
1415	65	4	1	 Shesaroyal Cowgirl    	    	   1 	 2/2Q  	 2/2   	 3/1T  	 3/1Q  	 2/H    	2	 2:00.1 	 29.2	 M Bradley     	1.80	 M Bradley
1416	65	4	5	 Filly Forty Seven     	    	   5 	 1/2Q  	 1/2   	 1/1   	 2/NS  	 3/T    	3	 2:00.2 	 30  	 Ma Campbell   	1.40	 Ma Campbell
1417	65	4	2	 Darn Quick            	    	   2 	 3/4T  	 3/5Q  	 4/3   	 4/2H  	 4/2H   	4	 2:00.3 	 29.3	 D Romo        	6.45	 D Romo
1418	65	4	4	 Woodmere Sandylu      	    	   4 	 6/9   	 7@/9T 	 5@/4  	 5/4   	 5/7T   	5	 2:01.4 	 30.3	 R Ellis       	8.25	 Ma Campbell
1419	65	4	7	 Putthecherryontop     	    	   7 	 4@/5T 	 5/7Q  	 6/5Q  	 6/5   	 6/9H   	6	 2:02   	 30.3	 M Haig        	19.35	 T Gunn
1420	65	4	3	 Oceanview Beemer      	    	   3 	 5/7   	 6@/7H 	 7@/6H 	 7/6Q  	 7/11   	7	 2:02.2 	 30.4	 A Smith       	8.35	 A Smith
1421	65	5	2	 N S Acadian           	    	   2 	 4/6   	 4@/3H 	 1/3H  	 1/5   	 1/4T   	1	 2:00   	 30.3	 H Smallwood   	9.75	 H Smallwood
1422	65	5	5	 A Regal Beauty        	    	   5 	 6/10  	 6/6H  	 4@/4H 	 3/5H  	 2/4T   	2	 2:01   	 30.4	 G Chappell    	3.35	 J Burton
1423	65	5	9	 Sauble Liz            	    	   4 	 5/8Q  	 5@/5H 	 2@/3H 	 2/5   	 3/5T   	3	 2:01.1 	 31.1	 C Isenor      	5.10	 C Covin
1424	65	5	1	 Flag Of Honor         	    	   1 	 3/3H  	 3/3   	 6@/6  	 4/7   	 4/9Q   	4	 2:01.4 	 31.1	 J Ramsay Jr   	6.55	 D Settle
1425	65	5	8	 Mach Vegas            	    	   8 	 8/12T 	 7@/7H 	 7@/7Q 	 6/10H 	 5/12Q  	5	 2:02.2 	 31.3	 R Ellis       	6.15	 R Chase
1426	65	5	7	 Western Scot          	    	   7 	 7/11H 	 8/9   	 8@/8H 	 7/11H 	 6/13   	6	 2:02.3 	 31.3	 P Langille    	13.10	 D Gillis
1427	65	5	6	 Electric Syl          	    	   6 	 1/2   	 1/1H  	 3/4H  	 5/10H 	 7/16   	7	 2:03.1 	 33  	 J Hughes      	1.05	 G Rennison
1428	65	5	3	 Bizzy Izzy            	    	   3 	 2/2   	 2/1H  	 5/6   	 8/14  	 8/24Q  	8	 2:04.4 	 34.1	 D Spence      	15.15	 N White
1429	65	5	4	 Intrepidus            	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
1430	66	1	3	 Video Storage         	    	   3 	 1/5   	 1/9   	 1/7   	 1/5   	 1/3    	1	 2:02   	 29.4	 D Crowe       	\N	 L Johnson
1431	66	1	2	 Maudail Mac           	    	   2 	 2/5   	 2/9   	 2/7   	 2/5   	 2/3    	2	 2:02.3 	 29  	 M Macdonald   	\N	 M Macdonald
1432	66	1	1	 Heads Up Hanover      	    	   1 	 3/6H  	 3/10T 	 3/9   	 3/6H  	 3/3H   	3	 2:02.3 	 28.3	 C Isenor      	\N	 W Mcneil
1433	67	1	7	 Gigs And Reels        	    	   7 	 7/8T  	 4@/1Q 	 1@/1H 	 1/1H  	 1/3H   	1	 2:01   	 30.2	 D Crowe       	3.65	 D Crowe
1434	67	1	8	 Putnams Legacy+       	    	   8 	 8/10  	 6@/3  	 4@@/2T	 3/2H  	 2/3H   	2	 2:01.3 	 30.2	 B Mccallum    	13.70	 B Mccallum
1435	67	1	3	 Flag Of Honor         	    	   3 	 2/1Q  	 3/1Q  	 3@/1T 	 2/1H  	 3/4T   	3	 2:02   	 31  	 J Ramsay Jr   	7.25	 D Settle
1436	67	1	4	 Metro Man             	    	   4 	 6/7Q  	 8@/4H 	 6@/4Q 	 5/5Q  	 4/7T   	4	 2:02.3 	 31.1	 P Langille    	7.35	 K Gillis
1437	67	1	1	 Prime Time Cowboy     	    	   1 	 4/3   	 5/2T  	 5/4Q  	 4/5   	 5/8    	5	 2:02.3 	 31.1	 D Romo        	1.15	 K Harper
1438	67	1	2	 J Gs Waylon           	    	   2 	 5/5   	 7/4   	 7/5T  	 6/7Q  	 6/11T  	6	 2:03.2 	 31.3	 D Spence      	13.70	 T Maclean
1439	67	1	6	 Secret Fantasy        	    	   6 	 1/1Q  	 1/Q   	 2/1H  	 7/8Q  	 7/22Q  	7	 2:05.2 	 34.3	 R Ellis       	8.45	 R Chase
1440	67	1	5	 Milliondollarkevin    	    	   5 	 3@/1T 	 2@/Q  	 8/13T 	 8/18Q 	 8/30Q  	8	 2:07   	 33.3	 Ma Campbell   	3.70	 S Dixon
1441	67	2	3	 Colin N Down          	    	   3 	 2@/NS 	 1/2Q  	 1/1H  	 1/1H  	 1/2Q   	1	 2:00   	 29.2	 G Barrieau    	0.40	 S Mason
1442	67	2	4	 J J Antonio           	    	   4 	 1/NS  	 2/2Q  	 2/1H  	 2/1H  	 2/2Q   	2	 2:00.2 	 29.3	 T Trites      	3.25	 E Watts
1443	67	2	5	 Ashes To Ashes        	    	   5 	 5/7Q  	 5/6H  	 4/3T  	 4/3Q  	 3/2Q   	3	 2:00.2 	 29  	 J Hughes      	0.65	 B Mckenna
1444	67	2	1	 Cowboys Dont Cry      	    	   1 	 3/1Q  	 3/3T  	 3/2H  	 3/2H  	 4/3T   	4	 2:00.4 	 29.4	 Ma Campbell   	4.05	 K Maclean
1445	67	2	2	 Private Paradise      	    	   2 	 4/5Q  	 4@/4  	 5/8Q  	 5/10Q 	 5/21Q  	5	 2:04.1 	 32  	 R Ellis       	8.60	 W Mackinnon
1446	67	3	5	 Ic A Free Spirit      	    	   5 	 1/2   	 1/1   	 1/2H  	 1/2   	 1/NK   	1	 2:00.4 	 29.4	 E Laffin      	1.05	 E Laffin
1447	67	3	4	 J J Cassius           	    	   4 	 2@/2  	 3/2   	 2/2H  	 2/2   	 2/NK   	2	 2:00.4 	 29.2	 D Romo        	5.90	 J Belliveau
1448	67	3	1	 Last Laugh            	    	   1 	 5/10H 	 5/7   	 5/7T  	 5/9   	 3/12   	3	 2:03.1 	 30.3	 A Camilli     	3.35	 A Camilli
1449	67	3	2	 P H Bossman           	    	   2 	 3/3   	 4/4H  	 4/4H  	 4/5T  	 4/13   	4	 2:03.2 	 31.3	 T Trites      	5.20	 Dr T Shive
1450	67	3	3	 Brookdale Jim         	    	   3 	 6/13  	 6/11Q 	 6/12T 	 6/16  	 5/22   	5	 2:05.1 	 31.3	 B Mccallum    	10.65	 B Mccallum
1451	67	3	6	 Windemeredancenart    	    	   6 	 4/5H  	 2@/1  	 3@X/3H	 3/5   	 6/43   	6	 2:09.2 	 37.4	 Ma Campbell   	2.70	 E Watts
1452	67	4	4	 N S Acadian           	    	   4 	 1/2H  	 1/1Q  	 1/3T  	 1/3T  	 1/6H   	1	 1:57.4 	 29.3	 Ma Campbell   	1.30	 H Smallwood
1453	67	4	3	 Brookdale Buster      	    	   3 	 2/2H  	 2/1Q  	 2/3T  	 2/3T  	 2/6H   	2	 1:59   	 30  	 B Mccallum    	1.60	 B Mccallum
1454	67	4	2	 Pictonians Derbie     	    	   2 	 4/9Q  	 4/6Q  	 4/6T  	 4/5H  	 3/7H   	3	 1:59.1 	 29.3	 A Campbell    	10.75	 B Mccallum
1455	67	4	1	 A Regal Beauty        	    	   1 	 3/7H  	 3/4   	 3@/4Q 	 3/4Q  	 4/7T   	4	 1:59.2 	 30.2	 D Spence      	3.50	 J Burton
1456	67	4	7	 P H Powerful          	    	   6 	 6/13T 	 6/9T  	 6@/9H 	 6/9Q  	 5/12Q  	5	 2:00.1 	 30.1	 T Trites      	11.50	 H Mac Kay
1457	67	4	5	 Ilava                 	    	   5 	 5/12Q 	 5/8Q  	 5@/8  	 5/6T  	 6/13H  	6	 2:00.2 	 30.3	 D Romo        	8.80	 J Janega
1458	67	4	8	 Maiden Heaven         	    	   7 	 7/15Q 	 7/11T 	 7/11H 	 7/11H 	 7/14Q  	7	 2:00.3 	 30.1	 P Langille    	14.60	 P Langille
1459	67	4	6	 Bad Break             	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1460	67	5	4	 Matts Tuition         	    	   4 	 7/7Q  	 6@/6  	 5@@/2Q	 4/1H  	 1/H    	1	 2:04.1 	 31.4	 D Crowe       	1.45	 D Crowe
1461	67	5	2	 Dixie Flyer           	    	   2 	 2/1Q  	 3/2Q  	 2@/H  	 1/1   	 2/H    	2	 2:04.1 	 32.1	 G Barrieau    	1.60	 G Barrieau
1462	67	5	5	 Dividend Day          	    	   5 	 5/4Q  	 5@/4T 	 6@/3H 	 6/2T  	 3/1T   	3	 2:04.3 	 32  	 S Mason       	10.05	 S Mason
1463	67	5	1	 Rj Gigolo             	    	   1 	 4/2T  	 4/3H  	 4@/2Q 	 3/1H  	 4/2    	4	 2:04.3 	 32.1	 D Carey       	9.15	 J Green
1464	67	5	7	 Big Joe Doby          	    	   7 	 3@/1T 	 2@/1  	 1/H   	 2/1   	 5/4Q   	5	 2:05   	 33  	 D Romo        	6.75	 G Mc Callum
1465	67	5	3	 Howmacs Dragonator    	    	   3 	 6/5H  	 7/6Q  	 7/3H  	 7/4Q  	 6/5    	6	 2:05.1 	 32.3	 B Mccallum    	8.00	 B Mccallum
1466	67	5	6	 Slide Guitar          	    	   6 	 1/1Q  	 1/1   	 3/2   	 5/2H  	 7/5Q   	7	 2:05.1 	 32.4	 P Langille    	5.65	 P Pinkney
1467	67	6	3	 Mighty Cowboy         	    	   3 	 1/1H  	 1/1T  	 1/T   	 1/1Q  	 1/1    	1	 2:00.1 	 29  	 D Crowe       	0.55	 D Crowe
1468	67	6	4	 Complete Player       	    	   4 	 2/1H  	 2/1T  	 3/1T  	 3/1H  	 2/1    	2	 2:00.2 	 28.4	 M Bradley     	2.50	 T Weatherbi
1469	67	6	6	 Libertys Choice       	    	   5 	 5/5H  	 4@/5  	 2@/T  	 2/1Q  	 3/2    	3	 2:00.3 	 29.1	 J Hughes      	7.55	 J Hughes
1470	67	6	1	 The Hawk              	    	   1 	 3/3H  	 3/4   	 4/3T  	 4/3   	 4/4Q   	4	 2:01   	 29  	 D Romo        	3.75	 D Romo
1471	67	6	2	 Windemerenightlife    	    	   2 	 4/4Q  	 5/6   	 5@/4T 	 5/5H  	 5/9Q   	5	 2:02   	 29.4	 Ma Campbell   	7.15	 E Watts
1472	67	6	5	 Casstielle            	    	   SC	TCHED -	JUDGES(	RANSPOR	ATION) 	        	\N	        	     	               	\N	 
1473	68	1	7	 Our Star              	    	   7 	 7/8H  	 7@/8  	 2@/1Q 	 1/1   	 1/4    	1	 1:58   	 29.3	 R Ellis       	1.85	 G Rennison
1474	68	1	1	 Pride Of Paradise     	    	   1 	 3/2H  	 1/3H  	 1/1Q  	 2/1   	 2/4    	2	 1:58.4 	 30.3	 Ma Campbell   	7.90	 H Smallwood
1475	68	1	8	 Sharon The Moment     	    	   8 	 8/10  	 8/9Q  	 4@/3T 	 3/2Q  	 3/4H   	3	 1:58.4 	 29.4	 D Carey       	11.25	 D Carey
1476	68	1	4	 Lil Orphan Cam        	    	   4 	 6@/6T 	 5@/6Q 	 6@/4T 	 4/4Q  	 4/5Q   	4	 1:59   	 29.4	 P Langille    	3.25	 J Ellis
1477	68	1	6	 Arizona Bucks         	    	   6 	 4/4   	 4@/5  	 3/3T  	 5/4T  	 5/8T   	5	 1:59.4 	 30.4	 G Barrieau    	4.40	 D Pinkney
1478	68	1	2	 Eye Forty Seven       	    	   2 	 2/T   	 3/4T  	 8/6H  	 7/7Q  	 6/9    	6	 1:59.4 	 30.2	 T Trites      	6.10	 J Burton
1479	68	1	3	 Go With It            	    	   3 	 5/5H  	 6/7   	 7@/6Q 	 6/7   	 7/9Q   	7	 1:59.4 	 30.2	 B Mccallum    	8.30	 G Mccabe
1480	68	1	5	 I C Anastro           	    	   5 	 1@/T  	 IP2/3H	 5/4T  	 8/9H  	 8/17   	8	 2:01.2 	 32.1	 D Spence      	5.40	 N White
1481	68	2	6	 Jigtime Jones         	    	   6 	 4/7T  	 4/4T  	 4@/2T 	 1/Q   	 1/1    	1	 2:00   	 29.2	 R Macdonald   	4.30	 M Macdonald
1482	68	2	4	 Nameisonthehalter     	    	   4 	 3/5T  	 3@/3  	 2@/1  	 2/Q   	 2/1    	2	 2:00.1 	 30  	 G Barrieau    	0.70	 L Snow
1483	68	2	5	 Lucbobski             	    	   5 	 6/12T 	 6/8   	 6/6H  	 6/4   	 3/2    	3	 2:00.2 	 29.1	 D Romo        	4.90	 D Romo
1484	68	2	2	 Pownal Bay Saul       	    	   2 	 2/2Q  	 2/1T  	 3/1H  	 4/2Q  	 4/2H   	4	 2:00.2 	 30.1	 M Bradley     	34.30	 T Weatherbi
1485	68	2	3	 Ryans Allstar         	    	   3 	 5/10H 	 5/6Q  	 5@/5Q 	 5/3T  	 5/7T   	5	 2:01.3 	 30.3	 Ma Campbell   	3.65	 Ma Campbell
1486	68	2	1	 Windemerefallnforu    	    	   1 	 1/2Q  	 1/1T  	 1/1   	 3/1Q  	 6/13Q  	6	 2:02.3 	 32.3	 T Trites      	4.30	 E Watts
1487	68	3	2	 Distinctiv Rusty      	    	   2 	 1/2   	 1/2T  	 1/1H  	 1/1H  	 1/2    	1	 1:56.1 	 28.4	 R Ellis       	0.45	 G Rennison
1488	68	3	4	 Gerries Beach         	    	   4 	 2/2   	 2/2T  	 2/1H  	 2/1H  	 2/2    	2	 1:56.3 	 29  	 D Romo        	4.45	 K Harper
1489	68	3	1	 Mortal Combat         	    	   X1	 4/5Q  	 4/5Q  	 3/3   	 3/3H  	 3/3T   	3	 1:57   	 29  	 D Spence      	3.05	 A Maclean
1490	68	3	6	 J Rs Hurricane        	    	   6 	 6@/8  	 6/10  	 6@/6  	 6/8   	 4/9Q   	4	 1:58   	 29.2	 G Barrieau    	4.80	 J Belliveau
1491	68	3	3	 Dontstandinmyway      	    	   3 	 5/7   	 5/8   	 5/5   	 4/6T  	 5/9H   	5	 1:58   	 29.3	 P Rogerson    	54.55	 P Rogerson
1492	68	3	5	 Threes A Crowd        	    	   5 	 3/3H  	 3@/3Q 	 4@/4  	 5/6T  	 6/12Q  	6	 1:58.3 	 30.2	 T Trites      	12.05	 Dr T Shive
1493	68	4	6	 Tobinator             	    	   6 	 1/2T  	 1/2H  	 1/2   	 1/2Q  	 1/T    	1	 1:58   	 28.2	 R Ellis       	1.25	 T Hicken
1494	68	4	1	 Carters Caper         	    	   1 	 2/2T  	 2/2H  	 2/2   	 2/2Q  	 2/T    	2	 1:58.1 	 28.1	 M Macdonald   	1.15	 M Macdonald
1495	68	4	2	 Southsidelightning    	    	   2 	 3/4   	 4/4Q  	 4/3T  	 4/4   	 3/8    	3	 1:59.3 	 29.1	 M Bradley     	7.25	 T Weatherbi
1496	68	4	4	 Island Energetic      	    	   4 	 5/9T  	 5@/4T 	 5@@/3T	 3/3T  	 4/8Q   	4	 1:59.3 	 29.1	 D Romo        	4.95	 D Romo
1497	68	4	3	 Woodmere Soul         	    	   3 	 4/6H  	 3@/3Q 	 3@/3  	 5/4H  	 5/11H  	5	 2:00.1 	 30  	 G Barrieau    	5.40	 E Watts
1498	68	4	5	 Jdcyril               	    	   5 	 6/11Q 	 6@/6Q 	 6/5   	 6/6H  	 6/13T  	6	 2:00.4 	 30.1	 Ma Campbell   	48.65	 K Maclean
1499	68	5	1	 Oppies Artist         	    	   1 	 1/2Q  	 1/1T  	 1/1T  	 1/1Q  	 1/1T   	1	 1:57.1 	 30.3	 A Campbell    	2.85	 A Campbell
1500	68	5	7	 Four Starz Hold Em    	    	   7 	 2/2Q  	 2/1T  	 2/1T  	 2/1Q  	 2/1T   	2	 1:57.3 	 30.3	 D Spence      	3.10	 N White
1501	68	5	3	 Putnams Force+        	    	   3 	 I4/8H 	 3@/5T 	 4/3T  	 4/3   	 3/2T   	3	 1:57.4 	 30.2	 T Trites      	4.25	 J Green
1502	68	5	4	 Djs Kocakolacowboy    	    	   4 	 5/11Q 	 5@/7  	 3@/2T 	 3/2Q  	 4/7T   	4	 1:58.4 	 31.3	 Ma Campbell   	2.80	 H Smallwood
1503	68	5	6	 Brookdale Liz         	    	   6 	 7/14T 	 6@/12 	 6/6T  	 5/5Q  	 5/9T   	5	 1:59.1 	 31.1	 B Mccallum    	4.45	 B Mccallum
1504	68	5	2	 Eyebebuckntuff        	    	   2 	 X3/7Q 	 4/6T  	 5@/5T 	 6/6T  	 6/10H  	6	 1:59.1 	 31.2	 J Ramsay Jr   	4.30	 D Oconnor
1505	68	5	5	 Dashwood Darling      	    	   5 	 6/13Q 	 7/12Q 	 7@/8  	 7/8   	 7/17Q  	7	 2:00.3 	 32.2	 P Langille    	20.90	 T Ellis
1506	68	5	9	 Bizzy Izzy            	    	   8 	 8/16H 	 8/14T 	 8@/12 	 8/11T 	 8/17Q  	8	 2:00.3 	 31.3	 D Carey       	\N	 N White
1507	68	5	8	 Electric Syl          	    	   SC	TCHED -	VET(SIC	)      	       	        	\N	        	     	               	\N	 
\.


--
-- Name: race_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: colin
--

SELECT pg_catalog.setval('race_details_id_seq', 1507, true);


--
-- Name: race_id_seq; Type: SEQUENCE SET; Schema: public; Owner: colin
--

SELECT pg_catalog.setval('race_id_seq', 151, true);


--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: colin
--

COPY track (id, name, code, country) FROM stdin;
1	Century Downs Racetrack And Casino	cnde	America
2	Charlottetown Driving Park	chrtn	America
3	Clinton Raceway	clntn	America
4	Dresden Raceway	dres	America
5	Exhibition Park Raceway	epr	America
6	Fredericton Raceway	frdtn	America
7	Georgian Downs	geodf	America
8	Glenboro	glbr	America
9	Grand River Raceway	grvr	America
10	Hanover Raceway	hnvr	America
11	Hiawatha Horse Park	sarf	America
12	Hippodrome 3r	trrvs	America
13	Holland Fair	holln	America
14	Inverness Raceway	invrn	America
15	Kawartha Downs	kdf	America
16	Mohawk Racetrack	mohs	America
17	Northside Downs	ntsdn	America
18	Nouvelle	nouvl	America
19	Ormstown	ormst	America
20	Rideau Carleton Raceway	ridcf	America
21	Saint Esprit	stes	America
22	Summerside Raceway	summ	America
23	Truro Raceway	truro	America
25	Cobram	CO	Australia
26	Newcastle	NR	Australia
27	Kilmore	KI	Australia
28	Penrith	PE	Australia
29	Charlton	CH	Australia
30	Ballarat	BA	Australia
31	Bathurst	BH	Australia
32	Bunbury	BY	Australia
33	Wanneroo	WQ	Australia
34	Nswhrc at Tabcorp Pk Menangle	PC	Australia
35	Gloucester Park	GP	Australia
24	Gold Coast	GC	Australia
37	Globe Derby Park	GD	Australia
38	Cranbourne	CR	Australia
39	Albion Park	AP	Australia
40	Goulburn	LM	Australia
41	Geelong	GE	Australia
42	Hobart	EH	Australia
43	Byford	BD	Australia
44	Pinjarra	PA	Australia
45	Narrogin	NG	Australia
46	Maryborough	MH	Australia
47	TABCORP PK MENANGLE 	ME	Australia
49	Bendigo	BN	Australia
50	Northam	NM	Australia
51	Parkes	PK	Australia
52	Wagin	WA	Australia
53	Warragul	WR	Australia
54	Bankstown	BK	Australia
55	Dubbo	DU	Australia
56	Devonport	DV	Australia
57	Leeton	LE	Australia
58	Port Pirie	PP	Australia
59	Tabcorp Park Melton	MX	Australia
61	Redcliffe	RE	Australia
62	Tamworth	TA	Australia
63	Echuca	EC	Australia
64	Mildura	ML	Australia
65	Terang	TE	Australia
66	York at Northam	ZY	Australia
67	Shepparton	SP	Australia
68	Canberra	CB	Australia
69	Wagga	WW	Australia
71	Swan Hill	FD	Australia
72	Stawell	SW	Australia
73	Young	YU	Australia
74	Launceston	LN	Australia
75	Kilcoy	IJ	Australia
76	Hamilton	HM	Australia
77	Fairfield	FF	Australia
78	Kapunda	KP	Australia
79	Peak Hill	PH	Australia
80	Mooroopna at Shepparton	VC	Australia
81	Marburg	UG	Australia
82	Ouyen at Mildura	RP	Australia
83	Yarra Valley	YG	Australia
84	Ararat	AR	Australia
86	Horsham	HS	Australia
89	Cowra	CA	Australia
90	Central Wheatbelt	ZO	Australia
91	Gold Coast at Albion Park	VQ	Australia
\.


--
-- Name: track_id_seq; Type: SEQUENCE SET; Schema: public; Owner: colin
--

SELECT pg_catalog.setval('track_id_seq', 91, true);


--
-- Name: race_details_pkey; Type: CONSTRAINT; Schema: public; Owner: colin; Tablespace: 
--

ALTER TABLE ONLY race_details_20160724
    ADD CONSTRAINT race_details_pkey PRIMARY KEY (id);


--
-- Name: track_pkey; Type: CONSTRAINT; Schema: public; Owner: colin; Tablespace: 
--

ALTER TABLE ONLY track
    ADD CONSTRAINT track_pkey PRIMARY KEY (id);


--
-- Name: uqc_code_country; Type: INDEX; Schema: public; Owner: colin; Tablespace: 
--

CREATE UNIQUE INDEX uqc_code_country ON track USING btree (code, country);


--
-- Name: race_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: colin
--

ALTER TABLE ONLY race
    ADD CONSTRAINT race_track_id_fkey FOREIGN KEY (track_id) REFERENCES track(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: race; Type: ACL; Schema: public; Owner: colin
--

REVOKE ALL ON TABLE race FROM PUBLIC;
REVOKE ALL ON TABLE race FROM colin;
GRANT ALL ON TABLE race TO colin;
GRANT SELECT,INSERT,DELETE ON TABLE race TO sb_app;


--
-- Name: race_id_seq; Type: ACL; Schema: public; Owner: colin
--

REVOKE ALL ON SEQUENCE race_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE race_id_seq FROM colin;
GRANT ALL ON SEQUENCE race_id_seq TO colin;
GRANT SELECT,USAGE ON SEQUENCE race_id_seq TO sb_app;


--
-- Name: track; Type: ACL; Schema: public; Owner: colin
--

REVOKE ALL ON TABLE track FROM PUBLIC;
REVOKE ALL ON TABLE track FROM colin;
GRANT ALL ON TABLE track TO colin;
GRANT SELECT ON TABLE track TO sb_app;


--
-- PostgreSQL database dump complete
--

